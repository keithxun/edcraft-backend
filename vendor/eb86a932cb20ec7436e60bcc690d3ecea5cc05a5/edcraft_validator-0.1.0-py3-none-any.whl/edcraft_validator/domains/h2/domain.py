"""Author, check and replay a constrained family under its existing subject."""

from __future__ import annotations

import json
import random
import re
from typing import Self

from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    TemplateRequest,
    build_review_view,
    build_template_id,
    content_sha256,
    require_checked,
    save_checked_evidence,
    seeded_index,
)
from edcraft_validator.domains.h2.catalogue import (
    CATALOGUES,
    eligible_cases,
    family_digest,
    family_digests,
    family_for,
)
from edcraft_validator.domains.h2.checks import CHECK_NAME, identity
from edcraft_validator.domains.h2.families import AnswerType, Item
from edcraft_validator.domains.h2.reviewed_cases import ReviewedVariants
from edcraft_validator.domains.h2.schemas import (
    FORMAT,
    Candidate,
    CheckedTemplate,
    H2ValidationSummary,
    Proposal,
    Question,
    Subject,
)
from edcraft_validator.domains.h2.selection import offered_families, proposal_type
from edcraft_validator.domains.h2.task_requirements import (
    CASE_TASKS,
    FAMILY_TASKS,
    AuthoredProposal,
    compatible_cases,
    resolve_requirements,
    supported_requirements,
    teacher_clauses,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.check_contracts import ToolEvidence
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.distractor_pool import DistractorPoolError
from edcraft_validator.validation.property_summary import (
    property_details,
)


def _display_choices(
    item: Item, selected_slots: list[int], answer_type: AnswerType
) -> list[str] | None:
    """Resolve the choices this saved selector can display for one input."""
    if max(selected_slots) >= len(item.distractors):
        return None
    choices = [item.answer, *(item.distractors[i] for i in selected_slots)]
    return (
        choices
        if len({identity(text, answer_type) for text in choices}) == len(choices)
        else None
    )


def requires_student_submission(prompt: str) -> bool:
    # Only decisive submission requests qualify. Describing a diagram or code
    # inside a multiple-choice stem is supported.
    return bool(
        re.search(
            r"\b(?:run|execute|listen to|observe|watch|grade|mark|score)\s+"
            r"(?:an?\s+|the\s+)?(?:student|pupil|candidate)(?:['’]s)?\s+"
            r"(?:own\s+)?(?:uploaded|handwritten|oral|freehand|live|operate|build)\b"
            r"|\b(?:grade|mark|score)\s+(?:an?\s+)?(?:original\s+)?handwritten\b",
            prompt,
            re.IGNORECASE,
        )
    )


class H2Domain:
    """Author from original subject families with checked stems and options."""

    tool_scope = "h2-syllabus"
    request_model = TemplateRequest
    candidate_model = Candidate
    question_model = Question
    validated_model = CheckedTemplate
    template_language = None
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )

    def __init__(self, subject: Subject):
        self.name = subject

    def review_view(self, artifact: CheckedTemplate) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=None)
        if view is None:
            return None
        family = family_for(self.name, artifact.template.family)
        sample = self.generate_question(artifact, seed=0)
        previews = []
        if isinstance(family.render, ReviewedVariants):
            for index in eligible_cases(family, artifact.template.allowed_cases):
                item = family.render.items[index]
                choices = _display_choices(
                    item, artifact.selected_slots, family.answer_type
                )
                if choices is None:
                    continue
                previews.append(
                    ReviewCasePreview(
                        case_id=f"{family.number}/{index}",
                        outcome=family.scope,
                        question=item.stem,
                        answer=item.answer,
                        choices=choices,
                    )
                )
        else:
            seen = set()
            for seed in (0, 31, 847):
                variant = (
                    sample if seed == 0 else self.generate_question(artifact, seed=seed)
                )
                case = variant.parameters["case"]
                if case in seen:
                    continue
                seen.add(case)
                previews.append(
                    ReviewCasePreview(
                        case_id=f"{family.number}/{case}",
                        outcome=family.scope,
                        question=variant.question,
                        answer=variant.answer,
                        choices=variant.choices,
                        seed=seed,
                    )
                )
        demand_note = None
        if artifact.template.difficulty == "hard" and family.number in {
            "6.4.variance-totals",
            "6.4.variance-shifted-totals",
            "6.4.variance-raw-observations",
            "1.2.merge-tie-rule",
            "1.2.merge-output",
            "4.1.cartesian-conjugate",
            "2.4.boundary-predicate",
        }:
            demand_note = (
                "This selection preserves the requested routine operation. "
                "Review the displayed choices before using it as a hard question."
            )
        return view.model_copy(
            update={
                "case_previews": previews,
                "candidate": {
                    **view.candidate,
                    "scope": family.scope,
                    "difficulty_scope_note": demand_note,
                    "family_capabilities": sorted(
                        FAMILY_TASKS.get(family.number, set())
                    ),
                    "selected_cases": artifact.template.allowed_cases,
                    "authoring_mode": (
                        "Curated H2 cases"
                        if isinstance(family.render, ReviewedVariants)
                        else "Parameterised H2 family"
                    ),
                    "sample_question": sample.question,
                    "sample_choices": sample.choices,
                    "sample_answer": sample.answer,
                },
            }
        )

    def generation_request(
        self, request: TemplateRequest
    ) -> StructuredGenerationRequest[PlannedGenerationResponse[Proposal]]:
        offered = offered_families(self.name, request.prompt)
        entries = []
        for number in offered:
            family = family_for(self.name, number)
            render = family.render
            if isinstance(render, ReviewedVariants):
                items = render.items
                curated = True
            else:
                items = (render(0),)
                curated = False
            entries.append(f"{number} {family.topic} | {family.scope}")
            if number in FAMILY_TASKS:
                entries.append(
                    "Task capabilities: " + ", ".join(sorted(FAMILY_TASKS[number]))
                )
            for i, item in enumerate(items):
                if number in CASE_TASKS:
                    entries.append(
                        "Case capabilities: " + ", ".join(sorted(CASE_TASKS[number][i]))
                    )
                choices = list(dict.fromkeys((item.answer, *item.distractors)))
                random.Random(f"{self.name}/{number}/{i}").shuffle(choices)
                label = f"Case {i}" if curated else "Parameterised example"
                entries.append(f"{label}: {item.stem}\nChoices: {' | '.join(choices)}")
        catalogue = "\n\n".join(entries)
        clauses = list(enumerate(teacher_clauses(request.prompt)))
        instructions = (
            f"Select one 2026 Singapore H2 {self.name} family. Each entry lists "
            "its scope and an example. Only select a family that addresses the "
            "requested skill AND the required student response across its variants. "
            f"Allowed requirement terms: {supported_requirements(offered)}. "
            "For each explicit positive requirement described by these terms, "
            "give its term and clause number. Ignore negated terms. "
            "A term describing an input is different from a term describing an answer. "
            "For unrelated skills use []. If difficulty and task conflict, "
            "preserve the task. Add errors or combine groups only when requested. "
            "Compare the action in the actual questions with the action requested. "
            "Choose the family that consistently asks for the requested result. "
            "For a parameterised family use null for allowed_cases. For a curated "
            "family compare every numbered case. If only some fulfil the request, "
            "return their numbers in ascending order in allowed_cases. A reusable "
            "selection needs at least two matching cases. Use null if all fit. "
            "Solve the first selected case (or the first example when all fit). "
            "Every family assesses "
            "a student choosing one answer from displayed options. When the teacher "
            "requires producing, submitting or performing original work, a related "
            "multiple-choice question does not fulfil the requested response. "
            "If no family fulfils the request, use 'unsupported' as the family and "
            "explain the missing skill in example_answer. Otherwise solve the "
            "selected example and copy its correct choice into example_answer. "
            f"Select {CHECK_NAME} and the offered advisory checks with empty "
            "arguments."
        )
        return StructuredGenerationRequest(
            messages=[
                {"role": "system", "content": f"{instructions}\n\n{catalogue}"},
                {
                    "role": "user",
                    "content": (
                        f"{request.prompt}\nTeacher clauses: {clauses}\n"
                        f"Requested difficulty {request.difficulty}, "
                        f"{request.num_distractors} distractors."
                    ),
                },
            ],
            # Pydantic specialises the response with a request-specific model.
            response_model=PlannedGenerationResponse[proposal_type(offered)],  # type: ignore[misc, arg-type]
            prompt_version="h2-syllabus-2026.9",
        )

    def build_candidate(
        self, request: TemplateRequest, proposal: Proposal
    ) -> Candidate:
        offered = offered_families(self.name, request.prompt)
        if requires_student_submission(request.prompt):
            raise UnsupportedAuthoringRequest(
                "This task requires assessing the student’s own work. "
                "The H2 question family accepts a selected answer."
            )
        if proposal.family == "unsupported":
            raise UnsupportedAuthoringRequest(proposal.example_answer)
        if proposal.family not in offered:
            raise DistractorPoolError(
                f"No matching H2 family selected from {list(offered)}. "
                f"{proposal.example_answer}"
            )
        requirements = (
            resolve_requirements(request.prompt, proposal.task_requirements)
            if isinstance(proposal, AuthoredProposal)
            else []
        )
        if (
            isinstance(proposal, AuthoredProposal)
            and proposal.family in FAMILY_TASKS
            and not requirements
            and proposal.family not in request.prompt
        ):
            raise DistractorPoolError(
                "Quote the task required by the teacher for this family."
            )
        if not compatible_cases(
            proposal.family, proposal.allowed_cases, request.prompt, requirements
        ):
            raise DistractorPoolError(
                "The selected variants do not support the quoted requirements. "
                "Select a compatible family or report the missing capability."
            )
        saved = Proposal.model_validate(
            proposal.model_dump(exclude={"task_requirements"})
        )
        return Candidate(
            **saved.model_dump(),
            quoted_requirements=requirements or None,
            subject=self.name,
            template_id=build_template_id(self.name, request, saved),
            difficulty=request.difficulty,
            required=request.num_distractors,
        )

    def required_checks(self, candidate: Candidate) -> frozenset[str]:
        return frozenset({CHECK_NAME})

    def distractor_count(self, candidate: Candidate) -> int:
        return candidate.required

    def tool_bindings(
        self, request: TemplateRequest, candidate: Candidate, tool_name: str
    ) -> dict[str, object]:
        if tool_name == CHECK_NAME:
            return {"candidate": candidate.model_dump(mode="json")}
        family = family_for(self.name, candidate.family)
        cases = eligible_cases(family, candidate.allowed_cases)
        example = family.render(cases[0])
        sha = content_sha256(candidate)
        if tool_name == TEMPLATE_RELEVANCE_CHECK:
            return {
                "author_request": request.prompt,
                "question_text": example.stem,
                "subject_sha256": sha,
            }
        if tool_name == TEMPLATE_DIFFICULTY_CHECK:
            return {
                "rubric_id": f"{self.name}-h2",
                "question_payload": json.dumps(
                    {
                        "question": example.stem,
                        "scope": family.scope,
                        "answer": example.answer,
                        "alternatives": example.distractors[: candidate.required],
                    },
                    ensure_ascii=False,
                ),
                "distractor_count": candidate.required,
                "requested_difficulty": candidate.difficulty,
                "subject_sha256": sha,
            }
        raise ValueError(f"Unknown H2 check {tool_name}")

    def checked_tool_bindings(
        self,
        request: TemplateRequest,
        candidate: Candidate,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, object]:
        bindings = self.tool_bindings(request, candidate, tool_name)
        if tool_name not in (TEMPLATE_DIFFICULTY_CHECK, TEMPLATE_RELEVANCE_CHECK):
            return bindings
        checked = self.finalize_checked_template(
            candidate,
            [item for item in evidence if item.tool == CHECK_NAME],
            advisory_checks=frozenset(),
        )
        # Both advisers see the same learner-visible options the released
        # generator can actually emit, including any reserve slots selected.
        samples = []
        for seed in (0, 31, 847):
            question = self.generate_question(checked, seed=seed)
            display = {"question": question.question, "choices": question.choices}
            if display not in samples:
                samples.append(display)
        field = (
            "question_payload"
            if tool_name == TEMPLATE_DIFFICULTY_CHECK
            else "question_text"
        )
        bindings[field] = json.dumps(samples, ensure_ascii=False)
        return bindings

    def finalize_checked_template(
        self,
        candidate: Candidate,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> CheckedTemplate:
        require_checked(
            evidence,
            required=self.required_checks(candidate),
            advisory_checks=advisory_checks,
        )
        check = next(e for e in evidence if e.tool == CHECK_NAME)
        digest = content_sha256(candidate)
        if check.details.get("subject_sha256") != digest:
            raise ValueError("The H2 check belongs to a different template")
        saved = [
            save_checked_evidence(e, digest, advisory_checks=advisory_checks)
            for e in evidence
        ]
        return CheckedTemplate(
            template=candidate,
            family_sha256=family_digest(self.name, candidate.family),
            selected_slots=check.details["selected_slots"],
            validation=H2ValidationSummary(
                **property_details(check.details), evidence=saved
            ),
        )

    def generate_question(self, validated: CheckedTemplate, *, seed: int) -> Question:
        candidate = validated.template
        if candidate.subject != self.name:
            raise ValueError("The stored H2 question belongs to a different subject")
        family = family_for(self.name, candidate.family)
        if validated.family_sha256 not in family_digests(self.name, candidate.family):
            raise ValueError(
                "Restore the checked catalogue revision to replay this family"
            )
        cases = eligible_cases(family, candidate.allowed_cases)
        for attempt in range(32):
            index = seeded_index(
                candidate.template_id, seed, f"h2-case-{attempt}", len(cases)
            )
            case = cases[index]
            item = family.render(case)
            choices = _display_choices(
                item, validated.selected_slots, family.answer_type
            )
            if choices is None:
                continue
            random.Random(
                seeded_index(candidate.template_id, seed, "h2-order", 2**32)
            ).shuffle(choices)
            return Question(
                template_id=candidate.template_id,
                artifact_id=validated.artifact_id,
                seed=seed,
                parameters={"case": case},
                family=family.number,
                topic=family.topic,
                question=item.stem,
                choices=choices,
                answer=item.answer,
                correct_index=choices.index(item.answer),
            )
        raise ValueError("No usable H2 variant within the generation budget")


class H2SyllabusModes:
    """Add the H2 catalogue while retaining the subject's ordinary authoring format."""

    name: Subject

    def syllabus_prompts(self) -> dict[str, str]:
        return {
            f"{family.number} · {family.topic}": (
                f"H2 skill {family.number}. {family.scope}."
            )
            for family in CATALOGUES[self.name].values()
        }

    def for_authoring(self, request: TemplateRequest) -> H2Domain | Self:
        syllabus_reference = re.search(
            r"(?:^\s*(?:Singapore\s+)?H2\b|\b(?:an?|Singapore)\s+H2\s+(?=[a-z])|"
            r"\bH2\s+(?:maths?|mathematics|computing|MCQs?|questions?|syllabus)\b)",
            request.prompt,
            flags=re.IGNORECASE,
        )
        # Uppercase H2 in a classroom request can precede any syllabus topic.
        # Keep code identifiers and HTML heading tags on the ordinary path.
        classroom = re.search(r"(?<![<\w])H2(?![>\w])", request.prompt) and re.search(
            r"\b(class|classroom|students?|pupils?|teachers?|question|problem|"
            r"examinations?|exams?|MCQs?|warm-up|challenge|mark|grade|score|learners?|statistics|syllabus)\b",
            request.prompt,
            re.IGNORECASE,
        )
        if syllabus_reference or classroom:
            return H2Domain(self.name)
        return self

    def for_saved_format(self, version: str | None) -> H2Domain | Self:
        return H2Domain(self.name) if version == FORMAT else self
