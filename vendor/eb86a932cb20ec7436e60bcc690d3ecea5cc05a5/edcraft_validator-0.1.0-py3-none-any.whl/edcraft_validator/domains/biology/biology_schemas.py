"""Canonical request, template, and question schemas for biology."""

from __future__ import annotations

import re
from typing import Annotated, Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.biology.biology_types import (
    BIOLOGY_CHECKING_MODE,
    BIOLOGY_FORMAT_VERSION,
    BIOLOGY_VALIDATOR_VERSION,
    MAX_COUNT_VALUE,
    MAX_COUNT_VALUES,
    MAX_GENOTYPE_VALUES,
    MAX_PARAMETERS,
    MAX_PHENOTYPE_VALUES,
    MIN_PARAMETERS,
    PHENOTYPES,
    RESERVED_PLACEHOLDERS,
    Difficulty,
)
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.validation.property_summary import PropertyCheckSummary
from edcraft_validator.validation.validation_contracts import ValidationEvidence

COUNT_VALUE_PATTERN = re.compile(r"^[1-9][0-9]{0,4}$")

# One request shape serves every domain; the name is kept for existing imports.
BiologyTemplateRequest = TemplateRequest


class GeneSpec(BaseModel):
    """One gene with a single-letter symbol and two visible phenotypes."""

    model_config = ConfigDict(extra="forbid", strict=True)

    symbol: str = Field(pattern=r"^[A-Z]$")
    dominant_phenotype: str = Field(pattern=r"^[a-z][a-z -]{0,39}$")
    recessive_phenotype: str = Field(pattern=r"^[a-z][a-z -]{0,39}$")

    @model_validator(mode="after")
    def check_phenotypes(self) -> GeneSpec:
        if self.dominant_phenotype == self.recessive_phenotype:
            raise ValueError("dominant_phenotype and recessive_phenotype must differ")
        for name in ("dominant_phenotype", "recessive_phenotype"):
            if getattr(self, name) in PHENOTYPES:
                raise ValueError(f"{name} must name a phenotype, not {name!r}")
        return self


class AssumptionSpec(BaseModel):
    """The inheritance model the question claims to use.

    Unsupported values parse so the checker can fail them with a named code.
    """

    model_config = ConfigDict(extra="forbid", strict=True)

    inheritance: Literal["autosomal", "x_linked", "y_linked", "mitochondrial"]
    dominance: Literal["complete", "incomplete", "codominant"]
    segregation: Literal["mendelian", "non_mendelian"]
    allele_count: int = Field(ge=1, le=10)


class ParameterSpec(BaseModel):
    """One finite authoring axis.

    Genotype token syntax is deliberately left to the checker, so a bad token
    fails as ``MALFORMED_GENOTYPE`` rather than as a schema error.
    """

    model_config = ConfigDict(extra="forbid", strict=True)

    name: str = Field(pattern=r"^[a-z][a-z0-9_]{0,31}$")
    kind: Literal["genotype", "phenotype", "count"]
    values: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def check_name_and_values(self) -> ParameterSpec:
        if self.name in RESERVED_PLACEHOLDERS:
            raise ValueError(f"parameter name {self.name!r} is a reserved placeholder")
        if len(self.values) != len(set(self.values)):
            raise ValueError("parameter values must be unique")
        caps = {
            "genotype": MAX_GENOTYPE_VALUES,
            "phenotype": MAX_PHENOTYPE_VALUES,
            "count": MAX_COUNT_VALUES,
        }
        if len(self.values) > caps[self.kind]:
            raise ValueError(
                f"{self.kind} parameters allow at most {caps[self.kind]} values"
            )
        if self.kind == "count":
            for value in self.values:
                if not COUNT_VALUE_PATTERN.fullmatch(value):
                    raise ValueError(
                        f"count value {value!r} must be an integer 1..10000"
                    )
                if int(value) > MAX_COUNT_VALUE:
                    raise ValueError(f"count value {value!r} must be at most 10000")
        if self.kind == "phenotype":
            for value in self.values:
                if value not in PHENOTYPES:
                    raise ValueError(
                        f"phenotype value {value!r} must be 'dominant' or 'recessive'"
                    )
        return self


class CrossSpec(BaseModel):
    """The two parent-parameter names; the same name declares a self-cross."""

    model_config = ConfigDict(extra="forbid", strict=True)

    parent1: str
    parent2: str


class TargetSpec(BaseModel):
    """What the question asks about: a genotype or a phenotype class."""

    model_config = ConfigDict(extra="forbid", strict=True)

    kind: Literal["genotype", "phenotype"]
    param: str


class GivenSpec(BaseModel):
    """The phenotype the offspring are conditioned on."""

    model_config = ConfigDict(extra="forbid", strict=True)

    phenotype: Literal["dominant", "recessive"]


class QuestionSpec(BaseModel):
    """One closed question shape: probability, expected count, or ratio."""

    model_config = ConfigDict(extra="forbid", strict=True)

    quantity: Literal["probability", "expected_count", "ratio"]
    target: TargetSpec | None = None
    given: GivenSpec | None = None
    offspring_count: str | None = None
    ratio_kind: Literal["genotype", "phenotype"] | None = None

    @model_validator(mode="after")
    def check_quantity_fields(self) -> QuestionSpec:
        if self.quantity == "ratio":
            if self.ratio_kind is None:
                raise ValueError("ratio questions require ratio_kind")
            if self.target is not None:
                raise ValueError("ratio questions cannot have a target")
            if self.given is not None:
                raise ValueError("ratio questions cannot have a given")
            if self.offspring_count is not None:
                raise ValueError("ratio questions cannot have offspring_count")
            return self

        if self.target is None:
            raise ValueError(f"{self.quantity} questions require a target")
        if self.ratio_kind is not None:
            raise ValueError("only ratio questions may set ratio_kind")
        if self.quantity == "probability" and self.offspring_count is not None:
            raise ValueError("probability questions cannot have offspring_count")
        if self.quantity == "expected_count" and self.offspring_count is None:
            raise ValueError("expected_count questions require offspring_count")
        return self


class TextSpec(BaseModel):
    """The authored question text; v1 has no answer anchors."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: str = Field(min_length=1, max_length=1200)


class ClaimedExample(BaseModel):
    """One declared parameter combination and the answer the author expects."""

    model_config = ConfigDict(extra="forbid", strict=True)

    parameters: dict[str, str]
    answer: str


class AnswerRecipe(BaseModel):
    """An exact recipe whose examples are re-derived by the engine."""

    model_config = ConfigDict(extra="forbid", strict=True)

    rule: Literal["exact"]
    claimed_examples: list[ClaimedExample] = Field(min_length=1, max_length=3)


class DistractorSpec(BaseModel):
    """One named misconception that should produce a wrong option."""

    model_config = ConfigDict(extra="forbid", strict=True)

    rule: Literal[
        "unconditioned",
        "reverse_condition",
        "forget_heterozygote",
        "phenotype_for_genotype",
        "uniform_genotype_classes",
        "complement",
        "swap_dominance",
        "genotype_ratio_for_phenotype",
        "phenotype_ratio_for_genotype",
        "fixed_value",
    ]
    misconception: str = Field(min_length=1, max_length=200)
    reason: str = Field(default="", max_length=400)
    value: str | None = None

    @model_validator(mode="after")
    def check_value(self) -> DistractorSpec:
        if self.rule == "fixed_value" and self.value is None:
            raise ValueError("fixed_value distractors require value")
        if self.rule != "fixed_value" and self.value is not None:
            raise ValueError("only fixed_value distractors may set value")
        return self


class MonohybridTemplateSpec(BaseModel):
    """A complete monohybrid template before any variant is generated."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["bio-mono/0.1"]
    topic: str = Field(pattern=r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$")
    organism: str = Field(min_length=1, max_length=120)
    trait: str = Field(min_length=1, max_length=80)
    gene: GeneSpec
    assumptions: AssumptionSpec
    parameters: list[ParameterSpec] = Field(
        min_length=MIN_PARAMETERS, max_length=MAX_PARAMETERS
    )
    cross: CrossSpec
    question: QuestionSpec
    text: TextSpec
    answer_recipe: AnswerRecipe
    distractors: list[DistractorSpec] = Field(default_factory=list)

    @model_validator(mode="after")
    def check_references(self) -> MonohybridTemplateSpec:
        names = [parameter.name for parameter in self.parameters]
        if len(names) != len(set(names)):
            raise ValueError("parameter names must be unique")
        by_name = {parameter.name: parameter for parameter in self.parameters}
        referenced: set[str] = set()

        def require(name: str, kind: str, field: str) -> None:
            parameter = by_name.get(name)
            if parameter is None:
                raise ValueError(f"{field} references undeclared parameter {name!r}")
            if parameter.kind != kind:
                raise ValueError(f"{field} must reference a {kind} parameter")
            referenced.add(name)

        require(self.cross.parent1, "genotype", "cross.parent1")
        require(self.cross.parent2, "genotype", "cross.parent2")
        if self.question.target is not None:
            require(
                self.question.target.param,
                self.question.target.kind,
                "question.target.param",
            )
        if self.question.offspring_count is not None:
            require(
                self.question.offspring_count,
                "count",
                "question.offspring_count",
            )
        unused = [name for name in names if name not in referenced]
        if unused:
            raise ValueError("unused parameters: " + ", ".join(unused))
        return self


class H2CaseSelection(BaseModel):
    """Select source-controlled H2 cases and order their distractor recipes."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["bio-h2/1"]
    cases: list[Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.]{0,63}$")]] = Field(
        min_length=1, max_length=32
    )
    distractors: list[Annotated[int, Field(ge=0, le=6)]] = Field(
        min_length=1, max_length=13
    )

    @model_validator(mode="after")
    def unique_cases(self) -> H2CaseSelection:
        if len(self.cases) != len(set(self.cases)):
            raise ValueError("each selected case must be distinct")
        return self


class H2TemplateSpec(H2CaseSelection):
    """The application-owned case selection stored in a validated artifact."""

    catalogue_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")


class BiologyUnsupportedSpec(BaseModel):
    """The requested learner task has no verified Biology response format."""

    model_config = ConfigDict(extra="forbid", strict=True, str_strip_whitespace=True)

    schema_version: Literal["bio-unsupported/1"]
    reason: str = Field(min_length=1, max_length=400)


class BiologyAuthorProposal(BaseModel):
    """Author-only envelope, specialised to the offered formats and cases."""

    model_config = ConfigDict(extra="forbid", strict=True)

    item: BiologyUnsupportedSpec | MonohybridTemplateSpec | H2CaseSelection


BiologyTemplateSpec = MonohybridTemplateSpec | H2TemplateSpec


class BiologyTemplateContent(BaseModel):
    """Model-authored biology template wrapped in the shared content envelope."""

    model_config = ConfigDict(extra="forbid", strict=True)

    item: BiologyTemplateSpec


class BiologyTemplateCandidate(BiologyTemplateContent):
    """Provider-neutral reusable template contract for biology items."""

    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]*$")
    difficulty: Difficulty
    question_type: Literal["mcq"] = "mcq"


class BiologyValidationSummary(PropertyCheckSummary):
    """Sampled-domain evidence for one checked biology template."""

    validator_version: Literal["mcp-biology-template-v1"] = BIOLOGY_VALIDATOR_VERSION
    checking_mode: Literal["property_based"] = BIOLOGY_CHECKING_MODE
    evidence: list[ValidationEvidence] = Field(min_length=1)


class ValidatedBiologyTemplate(ValidatedTemplateArtifact):
    """A template whose recipes passed bounded property-based checks."""

    model_config = ConfigDict(extra="forbid", strict=True)

    format_version: Literal["1.0.0"] = BIOLOGY_FORMAT_VERSION
    template: BiologyTemplateCandidate
    validation: BiologyValidationSummary


class BiologyCrossParents(BaseModel):
    """The concrete parent genotypes behind one generated instance."""

    model_config = ConfigDict(extra="forbid", strict=True)

    parent1: str
    parent2: str


class BiologyGametes(BaseModel):
    """The gametes each parent can contribute, for reviewer display."""

    model_config = ConfigDict(extra="forbid", strict=True)

    parent1: list[str]
    parent2: list[str]


class BiologyQuestionBase(BaseModel):
    """Fields shared by both reproducible biology question formats."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template_id: str
    artifact_id: str | None = None
    seed: int
    parameters: dict[str, str]
    question: str = Field(min_length=1)
    choices: list[str] = Field(min_length=2)
    correct_index: int = Field(ge=0)
    answer: str = Field(min_length=1)
    topic: str
    requires_manual_review: Literal[True] = True

    @model_validator(mode="after")
    def validate_choices(self) -> BiologyQuestionBase:
        if self.correct_index >= len(self.choices):
            raise ValueError("correct_index must identify one choice")
        if len(self.choices) != len(set(self.choices)):
            raise ValueError("choices must be distinct")
        if self.choices[self.correct_index] != self.answer:
            raise ValueError("answer must equal the choice at correct_index")
        return self


class BiologyQuestionInstance(BiologyQuestionBase):
    """A monohybrid question with reviewer-only cross evidence."""

    cross: BiologyCrossParents
    gametes: BiologyGametes
    punnett: list[list[str]]
    genotype_distribution: dict[str, str]
    phenotype_distribution: dict[str, str]


class H2BiologyFigure(BaseModel):
    """One packaged diagram or micrograph. The answerer sees its caption and alt."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    data_url: str = Field(pattern=r"^data:image/png;base64,[A-Za-z0-9+/=]+$")
    alt: str = Field(min_length=1)
    credit: str = Field(min_length=1)


class H2BiologyQuestionInstance(BiologyQuestionBase):
    """A canonical H2 case with reviewer-only explanation."""

    case_id: str
    explanation: str
    figure: H2BiologyFigure | None = None

    @model_serializer(mode="wrap")
    def omit_absent_figure(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        """Keep text-only question payloads identical to the original format."""
        payload = handler(self)
        if self.figure is None:
            payload.pop("figure", None)
        return payload


class BiologyQuestionPayload(
    RootModel[BiologyQuestionInstance | H2BiologyQuestionInstance]
):
    """The two flat question formats accepted at the domain boundary."""
