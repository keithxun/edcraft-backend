"""Build biology-domain prompts and the structured LLM request."""

from __future__ import annotations

import json
from dataclasses import asdict

from edcraft_validator.domains.biology.author_offer import (
    BiologyAuthorOffer,
    biology_author_offer,
    biology_author_proposal_type,
)
from edcraft_validator.domains.biology.biology_schemas import (
    BiologyAuthorProposal,
    BiologyTemplateRequest,
)
from edcraft_validator.domains.biology.biology_types import (
    BIOLOGY_CROSS_TOOL,
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

BIOLOGY_TEMPLATE_PROMPT_VERSION = "biology-template-v10"

BIOLOGY_SCOPE_PROMPT = """\
Return one JSON object with exactly two top-level fields, `proposal` and
`checks`. Put the item object at `proposal.item`. Its `schema_version` and
other fields belong inside `item`. Put the nonempty array of check objects at
`checks`. First decide whether the learner action, format and content fit a
verified Biology question.
A multiple-choice question can assess interpretation of provided text, data
and figures. It cannot assess an original essay, independently produced drawing
or direct performance in a laboratory. Supporting material for a teacher does
not change what the learner must do.

If the requested objective cannot be assessed by an offered case or by the
available monohybrid model, return an item with schema_version "bio-unsupported/1"
and a brief reason. Keep one offered check in the response envelope. It will
not execute for an unsupported item. Never replace an unsupported objective
or image kind with a nearby topic or different task to make it fit.
"""

BIOLOGY_TEMPLATE_SYSTEM_PROMPT = """\
For a custom reusable one-gene calculation supported by the monohybrid model,
use the recipe below. Use the H2 catalogue selection for requests served by
the listed cases. The application derives identity, difficulty and question type.

ITEM FAMILY (`item`)
- `item.schema_version` is exactly "bio-mono/0.1".
- `item.topic` is a stable dotted identifier such as
  "genetics.monohybrid.probability".
- `item.organism` and `item.trait` are short labels. Both organisms and traits
  must be hypothetical: invent names, and never use a real organism, breed,
  species or human disease. The checker rejects terms such as pea, fruit fly,
  human, mouse, maize, cystic fibrosis or sickle. "A hypothetical flowering
  plant called the glimmerwort" is acceptable; "a pea plant" is not.
- `item.gene` declares one letter `symbol` (the dominant allele is upper case,
  the recessive allele lower case) and two distinct phenotype words. Phenotype
  words are lowercase letters, spaces or hyphens, for example "purple" and
  "white".
- `item.assumptions` must state inheritance "autosomal", dominance "complete",
  segregation "mendelian" and allele_count 2. Other values parse so that the
  checker can reject them with a named code.
- `item.parameters` declares one to four finite axes. Each parameter has a
  `name`, a `kind` (genotype, phenotype or count) and a list of `values`.
  Names are lowercase identifiers and must not reuse a reserved placeholder.
  Genotype parameters allow at most three values, each a canonical two-letter
  token over the gene symbol: `PP`, `Pp` or `pp` (dominant homozygote,
  heterozygote, recessive homozygote). Phenotype parameters allow at most two
  values, exactly "dominant" and "recessive". Count parameters allow at most
  twelve integer strings from 1 to 10000. Declare values in a useful order: the
  first value and the last value are always checked as boundaries.
- `item.cross.parent1` and `item.cross.parent2` name genotype parameters. Use
  the same parameter name twice for a self-cross.
- `item.question.quantity` is probability, expected_count or ratio.
  Probability questions require `target` and no count or ratio kind.
  Expected-count questions require `target` and `offspring_count`, which names a
  count parameter. Ratio questions require `ratio_kind` (genotype or phenotype)
  and no target, given or count.
  `target.kind` is genotype or phenotype and `target.param` names a parameter of
  that kind. `given` is an optional phenotype ("dominant" or "recessive") that
  conditions the question, for example "of the purple offspring".
  Every declared parameter must be referenced at least once.
- `item.answer_recipe.rule` is exactly "exact". Supply one to three
  `claimed_examples`, each with a complete declared parameter mapping and the
  exact answer the template should compute. The checker recomputes every
  example from the cross, so a wrong claim fails the template.
- `item.distractors` lists candidate wrong choices in order of pedagogical
  plausibility. Supply exactly the candidate recipe count in the request. The
  application selects one fixed set of the requested usable size. Give each
  candidate a `rule` from the vocabulary, a short `misconception` tag and an
  optional `reason`. Only `fixed_value` may set `value`. Use a fixed value when
  it represents a specific, recognisable error.

DISTRACTOR RULES (closed vocabulary)
- `unconditioned`: P(target) ignoring the given phenotype. Applies when `given`
  is set.
- `reverse_condition`: P(given phenotype | target). Applies when `given` is set.
- `forget_heterozygote`: remaps phenotypes so only the dominant homozygote is
  dominant and a heterozygote shows the recessive phenotype. Applies when the
  target is a phenotype or `given` is set.
- `phenotype_for_genotype`: P(the phenotype of the target genotype). Applies
  when the target kind is genotype.
- `uniform_genotype_classes`: treats every distinct genotype class in the
  Punnett square as equally likely. Applies to probability or expected_count.
- `complement`: one minus the key for a probability, or N minus the key for an
  expected count. Applies to probability or expected_count.
- `swap_dominance`: remaps phenotypes so the recessive allele is treated as
  dominant. Applies when the target is a phenotype or `given` is set.
- `genotype_ratio_for_phenotype`: reports the genotype ratio. Applies to a
  phenotype ratio question.
- `phenotype_ratio_for_genotype`: reports the phenotype ratio. Applies to a
  genotype ratio question.
- `fixed_value`: parses `value` exactly like an answer. Applies to any question.
  For expected-count questions the value must be a whole-number count; for
  probability questions it must be in [0, 1].
Count rules use the probability rule and then multiply by N. Use only rules
applicable to the question. The same selected recipes must yield distinct wrong
values for every checked input. Anticipate collisions between errors on unusual
inputs by offering genuinely different misconceptions.

TEXT (`item.text.template`)
- Write learner-facing prose of 1 to 1200 characters. It may use these reserved
  placeholders: `{organism}`, `{trait}`, `{dominant_phenotype}`,
  `{recessive_phenotype}` and `{given_phenotype}` (the phenotype word of the
  given phenotype). It may also use every declared parameter name as a
  placeholder: a genotype parameter renders as its genotype token, a phenotype
  parameter as its phenotype word, and a count as an integer.
- Every genotype, number and phenotype that varies must come from a placeholder.
  Do not write genotype tokens, digits or zygosity words literally in the text.
  Words such as heterozygous, homozygous, hybrid, pure-breeding, carrier,
  X-linked, linked, incomplete, codominant, dihybrid, pedigree or generation are
  rejected because the checker supplies those facts itself.
- Use `{given_phenotype}` exactly when the question declares a given phenotype,
  and never otherwise. Every declared parameter must appear as a placeholder.
  Escape literal braces by doubling them. Do not write a parent genotype as
  prose; use the parameter placeholder instead.
- The checker runs deterministic anchors before any model parse, so a literal
  genotype, digit or inheritance word fails the template even if the rest reads
  correctly.

ANSWER FORMS
- Probability: an exact fraction such as "2/3" or a whole number "0" or "1".
  Never use percentages, decimals or mixed numbers.
- Expected count: a whole-number count such as "60". A combination whose exact
  expected count is not an integer is unusable, so declare count values that keep
  every variant whole.
- Ratio: a fully labelled ratio such as "1 PP : 2 Pp : 1 pp" or
  "3 purple : 1 white". Every class label appears at most once; an unlabelled
  "3:1" is rejected.

UNSUPPORTED FEATURES FOR THE MONOHYBRID SCHEMA
- Do not use incomplete dominance, codominance, multiple alleles, sex linkage,
  mitochondrial inheritance, non-Mendelian segregation, two or more genes,
  linkage, epistasis, lethal genotypes, penetrance, pedigrees, multi-generation
  crosses, or inference of parents from offspring. Each has a named failure code.
- The model writes declarative data only. Never include executable code.

CHECK PLAN
- Select a nonempty fixed subset of the available MCP tools using their supplied
  descriptions. Use each tool name at most once and do not invent names. Supply
  each selected check's model-owned arguments using its planning schema; use {}
  for checks without model-owned arguments.
- The application always runs biology_verify_cross, biology_validate_options and
  biology_verify_text_fidelity, whether or not you select them.
- Select assess_template_difficulty and assess_template_relevance. They are
  advisory evidence for educator review and never block a technically checked
  template. The difficulty rubric is provisional and uncalibrated.

WORKED PROPOSAL EXAMPLE
Use the object below as the value of the top-level `proposal` field and include
`checks` alongside `proposal` in the complete response.
This conditional-count example requests three usable distractors and supplies
six candidates. It declares a Pp x Pp
cross, conditions on the dominant phenotype, and asks for the expected number of
heterozygotes among N offspring. For N = 30, 60, 90, 120 the keys are 20, 40, 60,
80. The first three candidates give N/2, N/3 and N across these inputs.

{
  "item": {
    "schema_version": "bio-mono/0.1",
    "topic": "genetics.monohybrid.conditional_count",
    "organism": "a hypothetical flowering plant called the glimmerwort",
    "trait": "petal colour",
    "gene": {"symbol": "P", "dominant_phenotype": "purple",
             "recessive_phenotype": "white"},
    "assumptions": {"inheritance": "autosomal", "dominance": "complete",
                    "segregation": "mendelian", "allele_count": 2},
    "parameters": [
      {"name": "parent1", "kind": "genotype", "values": ["Pp"]},
      {"name": "parent2", "kind": "genotype", "values": ["Pp"]},
      {"name": "target", "kind": "genotype", "values": ["Pp"]},
      {"name": "n", "kind": "count", "values": ["30", "60", "90", "120"]}
    ],
    "cross": {"parent1": "parent1", "parent2": "parent2"},
    "question": {"quantity": "expected_count",
                 "target": {"kind": "genotype", "param": "target"},
                 "given": {"phenotype": "dominant"},
                 "offspring_count": "n"},
    "text": {"template": "In {organism}, {dominant_phenotype} {trait} is dominant over \
{recessive_phenotype}. A {parent1} plant is crossed with a {parent2} plant. Of {n} \
offspring with {given_phenotype} petals, how many are expected to have genotype \
{target}?"},
    "answer_recipe": {
      "rule": "exact",
      "claimed_examples": [
        {"parameters": {"parent1": "Pp", "parent2": "Pp", "target": "Pp",
                        "n": "90"}, "answer": "60"}
      ]
    },
    "distractors": [
      {"rule": "unconditioned",
       "misconception": "unconditioned instead of conditioned probability",
       "reason": "uses 1/2 of all offspring"},
      {"rule": "complement",
       "misconception": "counts homozygous dominant instead",
       "reason": "1/3 of N"},
      {"rule": "reverse_condition",
       "misconception": "confuses P(dominant | Pp) with P(Pp | dominant)",
       "reason": "every Pp plant is purple"},
      {"rule": "forget_heterozygote",
       "misconception": "assumes only the dominant homozygote shows purple"},
      {"rule": "fixed_value", "value": "2",
       "misconception": "reports the two matching Punnett square cells as the count"},
      {"rule": "fixed_value", "value": "1",
       "misconception": "counts the one target genotype class as one offspring"}
    ]
  }
}
"""


H2_CATALOGUE_GUIDANCE = """\
H2 CATALOGUE ITEM FAMILY
Use closed case selections only. All cases in the family must share one topic.
Select at most 32 cases.
Prefer multiple relevant cases for a reusable family. Provide the exact requested
candidate count using integers 1 through 6 in preferred order. Slot 0 is the
key and is never a wrong choice. When more than six candidate slots are requested,
repeat some slots after the six distinct options. The catalogue can provide up
to six usable wrong choices per question. The application supplies the catalogue
digest and renders the question and all choices. Do not include a free-text
stem, answer, topic or distractor text. Set schema_version to "bio-h2/1".
Use the case ID verbatim from the offer's ID column. The family header
groups cases and is never part of the case ID. Compare the complete stem and
the supplied image kind to the educator's request before selecting a case.

Offered cases grouped by family (case ID, image kind and stem):
"""


def _h2_inventory(offer: BiologyAuthorOffer) -> str:
    groups: dict[str, list[str]] = {}
    for case in offer.cases:
        kind = case.figure_kind or "text only"
        groups.setdefault(case.topic, []).append(
            f"- `{case.id}` | {kind} | {case.question}"
        )
    return "\n".join(f"{topic}\n" + "\n".join(cases) for topic, cases in groups.items())


RESPONSE_GUIDANCE = """\
Use native JSON values. Parameter values are strings such as "30" or "Pp".
Answer values and fixed distractors are exact fractions, whole-number counts or
fully labelled ratios. Only learner-facing text uses `{...}` placeholders.
"""


def build_biology_generation_request(
    request: BiologyTemplateRequest,
) -> StructuredGenerationRequest[PlannedGenerationResponse[BiologyAuthorProposal]]:
    """Return the per-request closed author contract."""
    offer = biology_author_offer(request.prompt, request.difficulty)
    author_model = biology_author_proposal_type(
        tuple(case.id for case in offer.cases), offer.allows_monohybrid
    )
    instructions = [BIOLOGY_SCOPE_PROMPT]
    if offer.scope_note:
        instructions.append(offer.scope_note)
    if offer.task:
        instructions.extend(
            (
                "Required task capabilities: " + json.dumps(asdict(offer.task)),
                "Select all offered variants satisfying the complete request. "
                "If an additional constraint is unavailable, request clarification "
                "via bio-unsupported/1.",
            )
        )
    if offer.difficulty_note:
        instructions.append("Difficulty note: " + offer.difficulty_note)
    if offer.allows_monohybrid:
        instructions.append(BIOLOGY_TEMPLATE_SYSTEM_PROMPT)
    candidate_count = request.num_distractors + SURPLUS_RECIPES
    example_item: dict[str, object] | None = None
    if offer.cases:
        instructions.extend((H2_CATALOGUE_GUIDANCE, _h2_inventory(offer)))
        if offer.task:
            example_item = {
                "schema_version": "bio-h2/1",
                "cases": [case.id for case in offer.cases],
                "distractors": [index % 6 + 1 for index in range(candidate_count)],
            }
    elif not offer.allows_monohybrid:
        example_item = {
            "schema_version": "bio-unsupported/1",
            "reason": offer.scope_note,
        }
    if example_item is not None:
        example = {
            "proposal": {"item": example_item},
            "checks": [{"name": BIOLOGY_CROSS_TOOL, "arguments": {}}],
        }
        instructions.append("Example complete JSON response:\n" + json.dumps(example))
    user_prompt = f"""\
Author request (preserve its meaning):
{request.prompt}

Requested difficulty: {request.difficulty}
Required usable distractors: {request.num_distractors}
Candidate distractor recipes to supply: {candidate_count}
Supported usable distractor range: {MIN_DISTRACTORS} to {MAX_DISTRACTORS}
"""

    return StructuredGenerationRequest(
        revise_from_authored_pool=True,
        messages=[
            {
                "role": "system",
                "content": "\n".join(instructions),
            },
            {"role": "user", "content": f"{user_prompt}\n{RESPONSE_GUIDANCE}"},
        ],
        response_model=PlannedGenerationResponse[author_model],
        prompt_version=f"{BIOLOGY_TEMPLATE_PROMPT_VERSION}+response-v1",
        schema_name="template_proposal_and_check_plan",
        check_argument_models=(),
    )
