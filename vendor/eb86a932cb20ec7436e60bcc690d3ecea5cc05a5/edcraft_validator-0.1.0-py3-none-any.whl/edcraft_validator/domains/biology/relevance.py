"""Learner-facing text projection for shared template relevance.

The measurement, threshold and verdict live in the shared classifier. This
module only renders what a learner would actually see, so the same relevance
policy can judge a biology template without knowing anything about genotypes.
"""

from __future__ import annotations

from edcraft_validator.domains.biology.biology_schemas import (
    BiologyTemplateCandidate,
    H2TemplateSpec,
)
from edcraft_validator.domains.biology.h2_cases import resolve_h2_cases


def template_relevance_text(candidate: BiologyTemplateCandidate) -> str:
    """Render the reusable task without answers, hints or distractor recipes."""
    template = candidate.item
    if isinstance(template, H2TemplateSpec):
        return "\n".join(case.learner_context() for case in resolve_h2_cases(template))
    parameters = "; ".join(
        f"{parameter.name} in [{', '.join(parameter.values)}]"
        for parameter in template.parameters
    )

    return (
        "Biology multiple-choice question template\n\n"
        f"Topic: {template.topic}\n"
        f"Organism: {template.organism}\n"
        f"Trait: {template.trait}\n"
        f"Task: {template.text.template}\n"
        f"Parameter values: {parameters}\n"
        "Each generated question substitutes one allowed value for every "
        "parameter.\n"
    )
