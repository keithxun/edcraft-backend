"""Chemistry-domain implementation of the generic domain contract.

The domain builds a candidate from a model proposal, binds its MCP checks,
finalises the checked template, and expands it into a seeded question.
"""

from typing import Any

from fastmcp import FastMCP
from pydantic import BaseModel

from edcraft_validator.application.difficulty_rubrics import (
    register_difficulty_rubric,
)
from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.chemistry.candidate_builder import (
    build_chemistry_candidate,
    template_sha256,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    ChemistryConceptItemSpec,
    ChemistryItemSpec,
    ChemistryQuestionInstance,
    ChemistryTemplateCandidate,
    ChemistryTemplateContent,
    ChemistryTemplateRequest,
    ChemistryValidationSummary,
    ConceptCatalogueSnapshot,
    ValidatedChemistryTemplate,
)
from edcraft_validator.domains.chemistry.chemistry_types import (
    CHEMISTRY_BALANCE_TOOL,
    CHEMISTRY_CONTENT_TOOL,
    CHEMISTRY_OPTIONS_TOOL,
)
from edcraft_validator.domains.chemistry.concept_evidence import concept_key_evidence
from edcraft_validator.domains.chemistry.difficulty import (
    CHEMISTRY_DIFFICULTY_RUBRIC_ID,
    CHEMISTRY_H2_DIFFICULTY_RUBRIC_ID,
    blinded_chemistry_template_payload,
    h2_chemistry_difficulty_rubric,
    load_chemistry_difficulty_rubric,
)
from edcraft_validator.domains.chemistry.extensions import evaluate_extension
from edcraft_validator.domains.chemistry.prompt_builder import (
    ChemistryGenerationResponse,
    build_chemistry_generation_request,
)
from edcraft_validator.domains.chemistry.question_generator import (
    generate_chemistry_question,
    render_extension_choices,
)
from edcraft_validator.domains.chemistry.relevance import template_relevance_text
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    build_review_view,
    require_checked,
    require_type,
    save_checked_evidence,
)
from edcraft_validator.llm.llm_contracts import StructuredGenerationRequest
from edcraft_validator.mcp.chemistry_tools import register_chemistry_tools
from edcraft_validator.mcp.tool_dependencies import ToolDependencies
from edcraft_validator.validation.check_contracts import ToolEvidence
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.property_summary import property_details


class ChemistryDomain:
    """Prompting, validation, and expansion for chemistry balancing templates."""

    name = "chemistry"
    request_model = ChemistryTemplateRequest
    candidate_model = ChemistryTemplateCandidate
    validated_model = ValidatedChemistryTemplate
    question_model = ChemistryQuestionInstance
    template_language = None
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )

    def register_tools(self, server: FastMCP, dependencies: ToolDependencies) -> None:
        """Register the chemistry domain's authoritative and advisory tools."""
        register_difficulty_rubric(load_chemistry_difficulty_rubric())
        register_difficulty_rubric(h2_chemistry_difficulty_rubric())
        register_chemistry_tools(server)

    def review_view(
        self, artifact: ValidatedTemplateArtifact
    ) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=self.template_language)
        if view is None or not isinstance(artifact, ValidatedChemistryTemplate):
            return view
        template = artifact.template
        catalogue = template.catalogue
        if not isinstance(catalogue, ConceptCatalogueSnapshot):
            return view
        spec = template.template_spec()
        cases = []
        for context in catalogue.contexts:
            result = evaluate_extension(spec, {"context": context.id})
            rendered = render_extension_choices(result, template.template_id, seed=0)
            if rendered is None:
                continue
            choices, correct_index = rendered
            cases.append(
                ReviewCasePreview(
                    case_id=context.id,
                    question=result.question,
                    answer=choices[correct_index],
                    choices=choices,
                    key_source="catalogue",
                    key_evidence=concept_key_evidence(context),
                )
            )
        view.case_previews = cases or None
        return view

    def generation_request(
        self, request: BaseModel
    ) -> StructuredGenerationRequest[ChemistryGenerationResponse]:
        typed_request = require_type(request, ChemistryTemplateRequest)
        return build_chemistry_generation_request(typed_request)

    def build_candidate(
        self, request: BaseModel, proposal: BaseModel
    ) -> ChemistryTemplateCandidate:
        return build_chemistry_candidate(
            require_type(request, ChemistryTemplateRequest),
            require_type(proposal, ChemistryTemplateContent),
        )

    def tool_bindings(
        self, request: BaseModel, candidate: BaseModel, tool_name: str
    ) -> dict[str, Any]:
        """Application-owned values never come from model tool arguments."""
        typed_candidate = require_type(candidate, ChemistryTemplateCandidate)
        item = typed_candidate.item
        if tool_name == TEMPLATE_RELEVANCE_CHECK:
            return {
                "author_request": require_type(
                    request, ChemistryTemplateRequest
                ).prompt,
                "question_text": template_relevance_text(typed_candidate),
                "subject_sha256": template_sha256(typed_candidate),
            }
        if tool_name == TEMPLATE_DIFFICULTY_CHECK:
            return {
                "rubric_id": CHEMISTRY_DIFFICULTY_RUBRIC_ID
                if isinstance(item, ChemistryItemSpec)
                else CHEMISTRY_H2_DIFFICULTY_RUBRIC_ID,
                "question_payload": blinded_chemistry_template_payload(typed_candidate),
                "distractor_count": len(item.distractors),
                "requested_difficulty": typed_candidate.difficulty,
                "subject_sha256": template_sha256(typed_candidate),
            }
        return {"template": typed_candidate.template_spec().model_dump(mode="json")}

    def distractor_count(self, candidate: BaseModel) -> int:
        return len(require_type(candidate, ChemistryTemplateCandidate).item.distractors)

    def required_checks(self, candidate: BaseModel) -> frozenset[str]:
        """Require content or reaction authority, as well as option validity."""
        item = require_type(candidate, ChemistryTemplateCandidate).item
        authority = (
            CHEMISTRY_CONTENT_TOOL
            if isinstance(item, ChemistryConceptItemSpec)
            else CHEMISTRY_BALANCE_TOOL
        )
        return frozenset({authority, CHEMISTRY_OPTIONS_TOOL})

    def finalize_checked_template(
        self,
        candidate: BaseModel,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> ValidatedChemistryTemplate:
        """Package the isolated checks' evidence without running them again."""
        template = require_type(candidate, ChemistryTemplateCandidate)

        require_checked(
            evidence,
            required=self.required_checks(template),
            advisory_checks=advisory_checks,
        )

        # The options check covers the whole reaction and slot grid, while the
        # balance check covers reactions only, so the saved coverage comes from
        # the options check and never overstates what was sampled.
        options = next(item for item in evidence if item.tool == CHEMISTRY_OPTIONS_TOOL)
        checked = property_details(options.details)
        if checked["examples_checked"] < 1:
            raise ValueError("option validation checked no parameter combinations")

        saved_evidence = [
            save_checked_evidence(
                item, template_sha256(template), advisory_checks=advisory_checks
            )
            for item in evidence
        ]
        summary = ChemistryValidationSummary(
            **checked,
            catalogue_version=template.catalogue.catalogue_version,
            catalogue_sha256=template.catalogue.catalogue_sha256,
            evidence=saved_evidence,
        )

        return ValidatedChemistryTemplate(template=template, validation=summary)

    def checked_tool_bindings(
        self,
        request: BaseModel,
        candidate: BaseModel,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, Any]:
        """Checking never rewrites a chemistry template, so the candidate is bound."""
        return self.tool_bindings(request, candidate, tool_name)

    def generate_question(
        self, validated: BaseModel, *, seed: int
    ) -> ChemistryQuestionInstance:
        return generate_chemistry_question(
            require_type(validated, ValidatedChemistryTemplate), seed
        )


__all__ = ["ChemistryDomain"]
