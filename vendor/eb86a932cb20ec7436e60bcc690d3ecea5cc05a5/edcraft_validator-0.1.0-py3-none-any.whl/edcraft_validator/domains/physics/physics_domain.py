"""Physics-domain implementation of the generic domain contract.

The domain builds a candidate from a model proposal, binds its MCP checks,
finalises the checked template, and expands it into a seeded question.
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP
from pydantic import BaseModel

from edcraft_validator.application.difficulty_rubrics import (
    register_difficulty_rubric,
)
from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewTemplateView,
    build_review_view,
    require_checked,
    require_type,
    save_checked_evidence,
)
from edcraft_validator.domains.physics.candidate_builder import (
    build_physics_candidate,
    template_sha256,
)
from edcraft_validator.domains.physics.difficulty import (
    H2_PHYSICS_DIFFICULTY_RUBRIC_ID,
    PHYSICS_DIFFICULTY_RUBRIC_ID,
    blinded_physics_template_payload,
    load_h2_physics_difficulty_rubric,
    load_physics_difficulty_rubric,
)
from edcraft_validator.domains.physics.h2_authoring import (
    H2CompactProposal,
    H2CompactUnsupported,
    is_explicit_h2_request,
    normalise_h2_proposal,
)
from edcraft_validator.domains.physics.h2_catalog import FAMILIES
from edcraft_validator.domains.physics.h2_statement_data import (
    H2StatementProposal,
    H2StatementSpec,
)
from edcraft_validator.domains.physics.h2_statements import (
    build_statement_candidate,
    pinned_statement_family,
    statement_case_previews,
)
from edcraft_validator.domains.physics.h2_task_data import (
    H2TaskProposal,
    H2TaskSpec,
    match_task,
    numerical_task_intent,
    references_external_stimulus,
    requests_fixed_graph_data,
)
from edcraft_validator.domains.physics.h2_tasks import (
    build_task_candidate,
    pinned_task_family,
    task_case_previews,
)
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsItem,
    PhysicsQuestionInstance,
    PhysicsTemplateCandidate,
    PhysicsTemplateContent,
    PhysicsTemplateRequest,
    PhysicsValidationSummary,
    ValidatedPhysicsTemplate,
)
from edcraft_validator.domains.physics.physics_types import (
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
    PHYSICS_FIDELITY_TOOL,
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TEXT_TOOL,
)
from edcraft_validator.domains.physics.prompt_builder import (
    build_compact_h2_generation_request,
    build_physics_generation_request,
)
from edcraft_validator.domains.physics.question_generator import (
    generate_physics_question,
)
from edcraft_validator.domains.physics.relevance import template_relevance_text
from edcraft_validator.llm.llm_contracts import StructuredGenerationRequest
from edcraft_validator.mcp.physics_tools import register_physics_tools
from edcraft_validator.mcp.tool_dependencies import ToolDependencies
from edcraft_validator.validation.check_contracts import ToolEvidence
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.property_summary import property_details

_PHYSICS_TOOLS = frozenset(
    {
        PHYSICS_ITEM_TOOL,
        PHYSICS_OPTIONS_TOOL,
        PHYSICS_TEXT_TOOL,
        PHYSICS_FIDELITY_TOOL,
    }
)


class PhysicsDomain:
    """Prompting, validation, and expansion for physics templates."""

    name = "physics"
    request_model = PhysicsTemplateRequest
    candidate_model = PhysicsTemplateCandidate
    validated_model = ValidatedPhysicsTemplate
    question_model = PhysicsQuestionInstance
    template_language = None
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )

    def register_tools(self, server: FastMCP, dependencies: ToolDependencies) -> None:
        """Register the physics domain's authoritative and advisory tools."""
        register_difficulty_rubric(load_physics_difficulty_rubric())
        register_difficulty_rubric(load_h2_physics_difficulty_rubric())
        register_physics_tools(
            server,
            fidelity_provider_factory=dependencies.fidelity_provider_factory,
            fidelity_timeout_seconds=dependencies.fidelity_timeout_seconds,
        )

    def review_view(
        self, artifact: ValidatedTemplateArtifact
    ) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=self.template_language)
        if view is None or not isinstance(artifact, ValidatedPhysicsTemplate):
            return view
        spec = artifact.template.item
        if isinstance(spec, H2TaskSpec):
            family = pinned_task_family(spec)
            view.case_previews = task_case_previews(spec)
            item = view.candidate["item"]
            item.update(
                topic=f"H2 Physics 9478 · Outcome {view.case_previews[0].outcome}",
                rule=family.description,
                parameters=[],
            )
            item["body"].update(
                target=family.description,
                text=view.case_previews[0].question,
                answer_form="selected_response",
                distractors=[],
            )
            return view
        if isinstance(spec, H2StatementSpec):
            view.case_previews = statement_case_previews(spec)
            statement_family = pinned_statement_family(spec)
            item = view.candidate["item"]
            item.update(
                topic=f"H2 Physics 9478 · Outcome {spec.skill_id}",
                rule=statement_family.skill,
                parameters=[],
            )
            item["body"].update(
                target="Statement set",
                text=view.case_previews[0].question,
                answer_form="statement_set",
                distractors=[],
            )
            return view
        if isinstance(spec, H2TemplateSpec):
            family = FAMILIES[spec.family_id]
            item = view.candidate["item"]
            item.update(
                topic=f"H2 Physics 9478 · Topic {family.topic}",
                rule=family.rule,
                parameters=[
                    {
                        "name": axis.name,
                        "quantity": "",
                        "unit": axis.unit,
                        "values": spec.parameters[axis.name],
                    }
                    for axis in family.axes
                ],
            )
            item["body"].update(
                target=family.title,
                text=family.stem,
                answer_form="signed_component" if family.signed else "magnitude",
            )
        return view

    def generation_request(
        self, request: BaseModel
    ) -> StructuredGenerationRequest[Any]:
        typed_request = require_type(request, PhysicsTemplateRequest)
        if is_explicit_h2_request(typed_request.prompt) or match_task(
            typed_request.prompt
        ):
            return build_compact_h2_generation_request(typed_request)
        return build_physics_generation_request(typed_request)

    def build_candidate(
        self, request: BaseModel, proposal: BaseModel
    ) -> PhysicsTemplateCandidate:
        typed_request = require_type(request, PhysicsTemplateRequest)
        if references_external_stimulus(typed_request.prompt):
            raise UnsupportedAuthoringRequest(
                "The requested graph, diagram or data must be included in the "
                "question. This Physics request depends on external material."
            )
        if requests_fixed_graph_data(typed_request.prompt):
            raise UnsupportedAuthoringRequest(
                "The requested graph uses fixed points or values. Available Physics "
                "graph templates generate their own data."
            )
        task_id = match_task(typed_request.prompt)
        if task_id is not None:
            return build_task_candidate(typed_request, task_id)
        if numerical_task_intent(typed_request.prompt):
            raise UnsupportedAuthoringRequest(
                "Available SI prefix and turntable tasks generate their own givens "
                "and assess only the requested numerical conversion."
            )
        if isinstance(proposal, H2TaskProposal):
            raise UnsupportedAuthoringRequest(
                "The registered Physics task does not match the requested operation."
            )
        if isinstance(proposal, H2StatementProposal):
            return build_statement_candidate(typed_request, proposal)
        if isinstance(proposal, (H2CompactProposal, H2CompactUnsupported)):
            proposal = normalise_h2_proposal(proposal)
        return build_physics_candidate(
            typed_request,
            require_type(proposal, PhysicsTemplateContent),
        )

    def tool_bindings(
        self, request: BaseModel, candidate: BaseModel, tool_name: str
    ) -> dict[str, Any]:
        """Application-owned values never come from model tool arguments."""
        typed_candidate = require_type(candidate, PhysicsTemplateCandidate)
        template = typed_candidate.item
        if tool_name == TEMPLATE_RELEVANCE_CHECK:
            return {
                "author_request": require_type(request, PhysicsTemplateRequest).prompt,
                "question_text": template_relevance_text(typed_candidate),
                "subject_sha256": template_sha256(typed_candidate),
            }
        if tool_name == TEMPLATE_DIFFICULTY_CHECK:
            return {
                "rubric_id": (
                    H2_PHYSICS_DIFFICULTY_RUBRIC_ID
                    if isinstance(
                        template, (H2TemplateSpec, H2StatementSpec, H2TaskSpec)
                    )
                    else PHYSICS_DIFFICULTY_RUBRIC_ID
                ),
                "question_payload": blinded_physics_template_payload(typed_candidate),
                "distractor_count": len(template.body.distractors),
                "requested_difficulty": typed_candidate.difficulty,
                "subject_sha256": template_sha256(typed_candidate),
            }
        if tool_name in _PHYSICS_TOOLS:
            return {"template": template.model_dump(mode="json")}
        return {"candidate": typed_candidate.model_dump(mode="json")}

    def distractor_count(self, candidate: BaseModel) -> int:
        template = require_type(candidate, PhysicsTemplateCandidate).item
        return len(template.body.distractors)

    def required_checks(self, candidate: BaseModel) -> frozenset[str]:
        """Require correctness, options, text and fidelity evidence."""
        require_type(candidate, PhysicsTemplateCandidate)
        return _PHYSICS_TOOLS

    def finalize_checked_template(
        self,
        candidate: BaseModel,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> ValidatedPhysicsTemplate:
        """Package the isolated checks' evidence without running them again."""
        template = require_type(candidate, PhysicsTemplateCandidate)
        template_spec = template.item

        require_checked(
            evidence,
            required=self.required_checks(template),
            advisory_checks=advisory_checks,
        )
        _require_distractor_count(template_spec)

        item_spec = _item_spec_evidence(evidence)
        checked = _checked_property_details(item_spec)
        digest = template_sha256(template)
        saved_evidence = []
        for item in evidence:
            saved = save_checked_evidence(item, digest, advisory_checks=advisory_checks)
            if isinstance(template_spec, H2TaskSpec):
                fields = {
                    PHYSICS_ITEM_TOOL: ("operations", "worked_solutions"),
                    PHYSICS_OPTIONS_TOOL: ("contrast_choices",),
                    PHYSICS_FIDELITY_TOOL: (
                        "fidelity_method",
                        "verified_graph_values",
                        "verified_numeric_values",
                    ),
                }.get(item.tool, ())
                task_details = {
                    key: item.details[key] for key in fields if key in item.details
                }
                saved = saved.model_copy(
                    update={"details": saved.details | task_details}
                )
            saved_evidence.append(saved)

        summary = PhysicsValidationSummary(
            **checked,
            evidence=saved_evidence,
        )

        return ValidatedPhysicsTemplate(template=template, validation=summary)

    def checked_tool_bindings(
        self,
        request: BaseModel,
        candidate: BaseModel,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, Any]:
        """Checking never rewrites a physics template, so the candidate is bound."""
        return self.tool_bindings(request, candidate, tool_name)

    def generate_question(
        self, validated: BaseModel, *, seed: int
    ) -> PhysicsQuestionInstance:
        return generate_physics_question(
            require_type(validated, ValidatedPhysicsTemplate), seed
        )


def _require_distractor_count(template: PhysicsItem) -> None:
    """Keep the option count within the range the artifact format allows."""
    count = len(template.body.distractors)
    if count < MIN_DISTRACTORS:
        raise ValueError("Physics templates require at least one distractor")
    if count > MAX_DISTRACTORS:
        raise ValueError(
            f"Physics templates allow at most {MAX_DISTRACTORS} distractors"
        )


def _item_spec_evidence(evidence: list[ToolEvidence]) -> ToolEvidence:
    return next(item for item in evidence if item.tool == PHYSICS_ITEM_TOOL)


def _checked_property_details(item_spec: ToolEvidence) -> dict[str, Any]:
    """Refuse a pass that sampled no parameter combinations."""
    checked = property_details(item_spec.details)
    if checked["examples_checked"] < 1:
        raise ValueError("Physics validation checked no parameter combinations")
    return checked
