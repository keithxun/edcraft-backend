"""Shared request, provider, and selection contracts for LLM calls."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, TypeGuard

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

if TYPE_CHECKING:
    from edcraft_validator.llm.forced_decision import ClassDecision


class RecommendedCheckArguments(BaseModel):
    """Closed default for checks without model-owned planning arguments."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)


class RecommendedCheck(BaseModel):
    """One model-recommended validation check in the fixed plan."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    name: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    # Provider wire schemas and the application validate these against the
    # domain's per-tool argument models before the plan can execute.
    arguments: dict[str, Any]


class CheckPlanResponse(BaseModel):
    """Model-selected checks for a supplied candidate."""

    model_config = ConfigDict(extra="forbid", strict=True)

    checks: list[RecommendedCheck] = Field(min_length=1)

    @model_validator(mode="after")
    def require_unique_check_names(self) -> CheckPlanResponse:
        names = [check.name for check in self.checks]
        if len(names) != len(set(names)):
            raise ValueError("recommended check names must be unique")
        return self


class PlannedGenerationResponse[ProposalT: BaseModel](CheckPlanResponse):
    """A reusable proposal and the fixed checks recommended in the same response."""

    proposal: ProposalT


@dataclass(frozen=True, slots=True)
class ToolCatalogueSnapshot:
    """Immutable MCP definitions offered for one authoring job."""

    definitions_json: str
    names: tuple[str, ...]

    @classmethod
    def from_definitions(
        cls, definitions: tuple[dict[str, Any], ...]
    ) -> ToolCatalogueSnapshot:
        return cls(
            definitions_json=json.dumps(
                definitions, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ),
            names=tuple(definition["name"] for definition in definitions),
        )

    def definitions(self) -> list[dict[str, Any]]:
        """Return a writable copy for tool dispatch and optional diagnostics."""
        return json.loads(self.definitions_json)

    def summaries(self) -> list[dict[str, Any]]:
        """Describe the available checks without saving their large schemas."""
        return [
            {
                "name": tool["name"],
                "version": tool.get("_meta", {}).get("fastmcp", {}).get("version"),
                "description": tool["description"],
            }
            for tool in self.definitions()
        ]


@dataclass(frozen=True)
class StructuredGenerationRequest[ProposalT: BaseModel]:
    """Domain-owned prompt and response schema."""

    messages: list[dict[str, Any]]
    response_model: type[ProposalT]
    prompt_version: str
    schema_name: str = "template_proposal"
    offered_tool_names: tuple[str, ...] = ()
    tool_catalogue: ToolCatalogueSnapshot | None = None
    check_argument_models: tuple[tuple[str, type[BaseModel]], ...] = ()
    # Per-call override, so judge reasoning does not change authoring settings.
    reasoning_effort: str | None = None
    # Pool selection discards reserves from the checked representation.
    revise_from_authored_pool: bool = False


class ModelProvider(Protocol):
    """Domain-agnostic structured-generation provider."""

    provider: str
    model: str

    def generation_settings(self) -> dict[str, Any]:
        """Return non-secret effective settings used by this provider instance."""
        ...

    def generate[ProposalT: BaseModel](
        self, request: StructuredGenerationRequest[ProposalT]
    ) -> ProposalT: ...


class DecisionModelProvider(ModelProvider, Protocol):
    """Optional classification capability with observed token probabilities."""

    def decide(
        self, messages: list[dict[str, Any]], labels: tuple[str, ...]
    ) -> ClassDecision: ...


def supports_decisions(provider: ModelProvider) -> TypeGuard[DecisionModelProvider]:
    """Check the optional capability once at the adapter/session boundary."""
    return callable(getattr(provider, "decide", None))


class TemplateProviderSelection(BaseModel):
    """Provider and optional model selected for one authoring request."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    provider: str = Field(min_length=1)
    model: str | None = Field(default=None, min_length=1)

    @field_validator("provider", "model")
    @classmethod
    def strip_non_blank_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        if not stripped:
            raise ValueError("must not be blank")
        return stripped
