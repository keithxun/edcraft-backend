"""Check that a practice request from lecture material yields fresh visible problems."""

import json

from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding


def check_material_variants(domain, artifact, *, uploaded=True) -> ToolEvidence:
    """Compare the learner's givens, ignoring the answer, option order and seed."""
    seen: set[tuple[str, ...]] = set()
    seeds: list[int] = []
    failure = "All sampled seeds displayed the same problem. Vary a given or operation."
    for seed in range(16):
        seeds.append(seed)
        try:
            question = domain.generate_question(artifact, seed=seed)
        except ValueError:
            failure = f"Seed {seed} could not generate a checked practice question."
            break
        visible = question.question
        if isinstance(visible, str):
            signature = (visible,)
        else:
            # A Python question includes the displayed program and its call arguments.
            signature = (
                visible.question,
                visible.code,
                json.dumps(visible.inputs, sort_keys=True),
            )
        seen.add(signature)
        if len(seen) == 2:
            break
    passed = len(seen) == 2
    return ToolEvidence(
        tool="application_material_variants"
        if uploaded
        else "application_visible_variants",
        version="1",
        status="passed" if passed else "failed",
        findings=[]
        if passed
        else [
            ToolFinding(
                code="MATERIAL_VARIANTS_REQUIRED"
                if uploaded
                else "VISIBLE_VARIANTS_REQUIRED",
                message=failure,
            )
        ],
        details={"seeds": seeds, "distinct_problems": len(seen)},
    )
