"""Reject clear task contradictions using domain-owned wording cues."""

from collections.abc import Mapping

from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.domains.h2.task_requirements import clause_mentions


def _operations(text: str, cues: Mapping[str, str]) -> set[str]:
    return {operation for operation, cue in cues.items() if clause_mentions(cue, text)}


def require_operation_intent(
    request: TemplateRequest,
    operation: str,
    *,
    request_cues: Mapping[str, str],
    source_cues: Mapping[str, str],
) -> None:
    """Check one recognisable target, leaving ambiguous wording for review."""
    _require_match(_operations(request.prompt, request_cues), operation, "The request")
    require_lecture_support(request, operation, source_cues)


def require_lecture_support(
    request: TemplateRequest, operation: str, source_cues: Mapping[str, str]
) -> None:
    """Require some positive evidence in the lecture. A style example cannot supply it."""
    if request.materials is None:
        return
    lecture = set().union(
        *(
            _operations(passage.text, source_cues)
            for passage in request.materials.lecture
        )
    )
    if operation in lecture:
        return
    recognised = ", ".join(sorted(lecture))
    hint = f" The recognised operations were {recognised}." if recognised else ""
    raise UnsupportedAuthoringRequest(
        f"The reviewed lecture material does not identify {operation}.{hint} "
        "Select a passage that teaches the requested operation."
    )


def _require_match(cues: set[str], operation: str, source: str) -> None:
    if len(cues) == 1 and operation not in cues:
        expected = next(iter(cues))
        raise UnsupportedAuthoringRequest(
            f"{source} points to {expected}. The authored task uses {operation}. "
            f"Request an item that checks {expected}."
        )
