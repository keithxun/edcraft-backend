"""Select a subject format for a new request or a saved artifact."""

import json


def for_request(domain, request):
    choose = getattr(domain, "for_authoring", None)
    return choose(request) if choose else domain


def for_artifact(domain, artifact):
    choose = getattr(domain, "for_saved_format", None)
    return choose(getattr(artifact, "format_version", None)) if choose else domain


def load_artifact(domain, raw: str | bytes):
    choose = getattr(domain, "for_saved_format", None)
    if choose:
        header = json.loads(raw)
        if isinstance(header, dict):
            domain = choose(header.get("format_version"))
    artifact = domain.validated_model.model_validate_json(raw)
    provenance = artifact.authoring
    if provenance and provenance.domain != domain.name:
        raise ValueError("Saved template belongs to another subject")
    return artifact
