"""Recognize the Python syntax features referenced by code profiles."""

from __future__ import annotations

import ast
from collections.abc import Iterator

from edcraft_validator.domains.code.code_types import CodeFeature


def extract_code_features(code: str, entry_function: str) -> frozenset[CodeFeature]:
    """Extract the structural features used by code capability profiles."""
    tree = ast.parse(code)
    parents = {
        child: parent
        for parent in ast.walk(tree)
        for child in ast.iter_child_nodes(parent)
    }
    all_functions = {
        node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)
    }

    reachable_names = _reachable_function_names(all_functions, entry_function)
    functions = [
        function for name, function in all_functions.items() if name in reachable_names
    ]
    helper_names = reachable_names - {entry_function}
    nodes = [node for function in functions for node in _function_nodes(function)]

    features: set[CodeFeature] = set()

    if helper_names:
        features.add("helper_function")
    if any(isinstance(node, ast.BinOp) for node in nodes):
        features.add("arithmetic")
    if any(isinstance(node, ast.If) for node in nodes):
        features.add("conditional")
    if any(isinstance(node, ast.For) for node in nodes):
        features.add("loop")
    if any(isinstance(node, ast.Subscript) for node in nodes):
        features.add("list_index")

    calls = [node for node in nodes if isinstance(node, ast.Call)]
    called_names = {node.func.id for node in calls if isinstance(node.func, ast.Name)}
    if called_names & {"all", "any", "max", "min", "sum"}:
        features.add("list_aggregate")
    if "sorted" in called_names:
        features.add("list_sort")

    if_nodes = [node for node in nodes if isinstance(node, ast.If)]
    if any(_has_ancestor(node, ast.If, parents) for node in if_nodes):
        features.add("nested_conditional")
    if any(
        isinstance(node, ast.Return) and _has_ancestor(node, ast.If, parents)
        for node in nodes
    ):
        features.add("early_return")
    if _has_sequential_nodes(functions, ast.If, parents):
        features.add("sequential_conditionals")

    for_nodes = [node for node in nodes if isinstance(node, ast.For)]
    if any(_has_ancestor(node, ast.For, parents) for node in for_nodes):
        features.add("nested_loop")
    if _has_sequential_nodes(functions, ast.For, parents):
        features.add("sequential_loops")

    if any(
        isinstance(node.func, ast.Name)
        and node.func.id in helper_names
        and (_nearest_function(node, parents) or "") in helper_names
        for node in calls
    ):
        features.add("nested_helper")
    return frozenset(features)


def reachable_subscripts(
    code: str, entry_function: str
) -> Iterator[ast.expr | ast.slice]:
    """Find indexing and slicing operations in reachable functions."""
    tree = ast.parse(code)
    functions = {
        node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)
    }
    for name in _reachable_function_names(functions, entry_function):
        for node in _function_nodes(functions[name]):
            if isinstance(node, ast.Subscript):
                yield node.slice


def has_strided_slice(code: str, entry_function: str) -> bool:
    """Check for an explicitly strided slice in a reachable function."""
    for node in reachable_subscripts(code, entry_function):
        if not isinstance(node, ast.Slice) or node.step is None:
            continue
        try:
            step = ast.literal_eval(node.step)
        except (TypeError, ValueError):
            # A computed step is verified by the execution check.
            return True
        if type(step) is int and abs(step) > 1:
            return True
    return False


def _function_nodes(function: ast.FunctionDef) -> Iterator[ast.AST]:
    """Walk one function without treating local function definitions as calls."""
    pending: list[ast.AST] = [function]
    while pending:
        node = pending.pop()
        if isinstance(node, ast.FunctionDef) and node is not function:
            continue
        yield node
        pending.extend(ast.iter_child_nodes(node))


def _reachable_function_names(
    functions: dict[str, ast.FunctionDef], entry_function: str
) -> set[str]:
    reachable: set[str] = set()
    pending = [entry_function]
    while pending:
        name = pending.pop()
        if name in reachable or name not in functions:
            continue
        reachable.add(name)
        called = {
            node.func.id
            for node in _function_nodes(functions[name])
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        pending.extend(called - reachable)
    return reachable


def _has_ancestor(
    node: ast.AST, kind: type[ast.AST], parents: dict[ast.AST, ast.AST]
) -> bool:
    current = parents.get(node)
    while current is not None:
        if isinstance(current, kind):
            return True
        current = parents.get(current)
    return False


def _nearest_function(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> str | None:
    current = parents.get(node)
    while current is not None:
        if isinstance(current, ast.FunctionDef):
            return current.name
        current = parents.get(current)
    return None


def _has_sequential_nodes(
    functions: list[ast.FunctionDef],
    kind: type[ast.If] | type[ast.For],
    parents: dict[ast.AST, ast.AST],
) -> bool:
    for function in functions:
        top_level = [
            node
            for node in _function_nodes(function)
            if isinstance(node, kind)
            and _nearest_function(node, parents) == function.name
            and not _has_ancestor(node, kind, parents)
        ]

        if len(top_level) >= 2:
            return True
    return False
