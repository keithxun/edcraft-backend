"""Author and independently check bounded H2 Computing operation traces."""

import copy
import json
import random
import re
from itertools import combinations
from typing import Any

from fastmcp import FastMCP
from pydantic import TypeAdapter

from edcraft_validator.domains.code.code_types import ParameterValue
from edcraft_validator.domains.code.h2_trace_contracts import (
    CheckedTrace,
    MergeCheckpoint,
    MergeProposal,
    MergeTie,
    QueueOutcomes,
    QueueProposal,
    QueueState,
    TraceAnswer,
    TraceCandidate,
    TraceKind,
    TraceProposal,
    TraceRequirements,
    TraceValidation,
)
from edcraft_validator.domains.code.h2_trace_operations import (
    ComputedTrace,
    compute_trace,
    display_answer,
)
from edcraft_validator.domains.code.proposal_response import UnsupportedComputingTask
from edcraft_validator.domains.code.safe_expressions import SafeExpression
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    TemplateRequest,
    build_review_view,
    build_template_id,
    content_sha256,
    require_checked,
    save_checked_evidence,
    seeded_index,
)
from edcraft_validator.domains.h2.domain import requires_student_submission
from edcraft_validator.domains.h2.schemas import ClosedModel, Question
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.property_summary import property_details
from edcraft_validator.validation.validation_contracts import ValidationFailure

TRACE_CHECK = "code_verify_authored_h2_trace"
CHECK_VERSION = "1.0.0"
CHECK_SCOPE = "code-h2-trace"
_TRACE_SOURCE_CUES = {
    "queue": (
        r"\bcircular (?:array )?(?:queue|buffer)s?\b"
        r"|\b(?:queue|front index)\b[^.!?]{0,65}\b(?:wrap\w*|modulo)\b"
    ),
    "merge": (
        r"\bstable merg(?:e|ing)\b|\bmerge[- ]sort\b"
        r"|\bmerg\w*\b[^.!?]{0,70}\bsorted (?:runs|lists|arrays|sequences)\b"
    ),
}


def trace_kind(prompt: str) -> TraceKind | None:
    if re.search(
        r"\bcircular (?:array )?(?:queue|buffer)s?\b|\b1\.3\.circular-queue"
        r"|\bqueue\b[^.!?]{0,65}\b(?:wrap(?:s)?(?:[- ]?around)?|FIFO)\b",
        prompt,
        re.I,
    ):
        return "queue"
    if re.search(r"\b(?:merge(?:s|d|[- ]sort|[- ]trace)?|merging)\b", prompt, re.I):
        return "merge"
    return None


def _demand(prompt: str, pattern: str) -> bool:
    return bool(re.search(pattern, prompt, re.I))


def _require_trace_material(request: TemplateRequest, kind: TraceKind) -> None:
    materials = request.materials
    if materials is None:
        return
    operation = "circular queue" if kind == "queue" else "stable merge"
    if not any(_demand(p.text, _TRACE_SOURCE_CUES[kind]) for p in materials.lecture):
        raise UnsupportedAuthoringRequest(
            f"The reviewed lecture lacks evidence for a {operation} trace. "
            "Select an excerpt demonstrating the operation to be checked."
        )
    if materials.exam:
        exam = materials.exam.text
        skills = {
            skill for skill, cue in _TRACE_SOURCE_CUES.items() if _demand(exam, cue)
        }
        if skills and kind not in skills:
            raise UnsupportedAuthoringRequest(
                f"The selected exam question does not support a {operation} trace. "
                "Select an exam question about the requested operation."
            )


_NUMBER_WORDS = "zero one two three four five six seven eight nine ten".split()
_COUNT = r"(\d+|" + "|".join(_NUMBER_WORDS) + r")"


def _requested_number(prompt: str, pattern: str) -> int | None:
    match = re.search(pattern, prompt, re.I)
    if not match:
        return None
    word = match[1].lower()
    return int(word) if word.isdecimal() else _NUMBER_WORDS.index(word)


def _require_supported_trace(prompt: str, kind: TraceKind | None) -> None:
    if requires_student_submission(prompt):
        raise UnsupportedAuthoringRequest(
            "Assessing student-produced programs requires a submission checker. "
            "This operation checker supports multiple-choice traces."
        )
    if kind == "queue" and _demand(
        prompt,
        r"\b(?:full (?:circular )?queues? overwrit|overwrit\w* "
        r"(?:the oldest item |elements? )?when (?:it is |the queue is )?full)",
    ):
        raise UnsupportedAuthoringRequest(
            "This circular queue checker requires a full queue to reject an enqueue. "
            "An overwrite-on-full representation needs its own operation checker."
        )


class TraceQuestion(Question):
    parameters: dict[str, ParameterValue]


def _requirements(prompt: str, item: TraceProposal) -> TraceRequirements:
    """Pin explicit, mechanically testable requirements to all emitted cases."""
    if isinstance(item, QueueProposal):
        targets = set()
        if _demand(
            prompt,
            r"\b(?:resulting |final )?queue state\b|\b(?:stored|physical) array\b",
        ):
            targets.add("state")
        if _demand(
            prompt,
            r"\b(?:next (?:item|value) (?:to be )?(?:dequeued|removed)"
            r"|(?:removed|dequeued) next|next (?:successful )?dequeue return"
            r"|gets dequeued next)\b",
        ):
            targets.add("next_removed")
        if _demand(
            prompt, r"\b(?:contents in fifo order|fifo contents|final contents)\b"
        ):
            targets.add("fifo")
        if _demand(
            prompt, r"\b(?:items?|values?)\b[^.!?]{0,30}\bremain in FIFO order\b"
        ):
            targets.add("fifo")
        if _demand(prompt, r"\b(?:final|resulting) front (?:index|pointer)\b"):
            targets.add("front_index")
        if _demand(
            prompt,
            r"\b(?:item|value)\b[^.!?]{0,25}\bat the rear\b|\brear (?:item|value)\b",
        ):
            targets.add("rear_item")
        if _demand(
            prompt,
            r"\b(?:which (?:enqueue )?values? (?:are |is )?rejected"
            r"|which values? (?:the )?dequeues? return)\b",
        ):
            targets.add("outcomes")
        if "outcomes" in targets:
            targets = {"outcomes"}
        if len(targets) > 1 and not _demand(prompt, r"\bor\b"):
            raise UnsupportedAuthoringRequest(
                "This queue checker needs one answer target. Choose final stored "
                "state, front index, rear item, next dequeue value, FIFO contents "
                "or the combined outcome."
            )
        if targets and item.target not in targets:
            raise DistractorPoolError(
                f"Queue answer target must match the requested output {sorted(targets)}"
            )
        wrap = _demand(prompt, r"\bwrap(?:s|ped)?(?:[- ]?around)?\b")
        reinsert = _demand(prompt, r"\bre-?(?:insert|enqueue)(?:s|ed|ing)?\b")
        return TraceRequirements(
            wrap=wrap,
            front_wrap=wrap
            and _demand(
                prompt,
                r"\b(?:front|read)(?: index| pointer)?(?: itself)?\s+(?:must )?wrap"
                r"|\bwrap(?:s|ped)?(?:[- ]around)?\s+(?:of |at )?(?:the )?front",
            ),
            rear_wrap=wrap
            and _demand(
                prompt,
                r"\b(?:rear|tail)(?: index| pointer)?(?: itself)?\s+"
                r"(?:must )?wrap|\bwrap(?:s|ped)?(?:[- ]around)?"
                r"\s+(?:of |at )?(?:the )?rear",
            ),
            write_wrap=wrap
            and _demand(
                prompt,
                r"\b(?:next[-_ ]?)?write(?: index| pointer)?\s+(?:must )?wrap"
                r"|\bwrap(?:s|ped)?(?:[- ]around)?\s+(?:of |at )?(?:the )?"
                r"(?:next[-_ ]?)?write(?: index| pointer)?\b",
            ),
            reinsert_removed=reinsert,
            reinsert_at_rear=reinsert and item.target == "rear_item",
            remove_after_wrap=wrap
            and _demand(
                prompt,
                r"\bthen\b[^.!?]{0,65}\b(?:remov(?:e|ed|es|al)|dequeu(?:e|ed|es))\b"
                r"|\b(?:remov(?:e|ed|es|al)|dequeu(?:e|ed|es))\b[^.!?]{0,65}\bafter\b[^.!?]{0,18}\bwrap",
            ),
            branching=_demand(
                prompt, r"\b(?:data[- ]dependent|conditional|branching)\b|\bif\s+peek\b"
            ),
            rejected_full=_demand(
                prompt,
                r"\bfull[- ]state rejection\b|\bfull queue\b[^.!?]{0,45}\breject"
                r"|\breject[^.!?]{0,45}\bfull queue\b",
            ),
        )

    multiple_ties = _demand(prompt, r"\b(?:multiple|two|2)\b[^.!?]{0,24}\bties?\b")
    has_ties = _demand(prompt, r"\bties?\b|\bequal[- ]keys?\b") or item.target in {
        "tag_order",
        "tie_rule",
    }
    writes = _requested_number(prompt, rf"\bnext {_COUNT} (?:writes|tags|records)\b")
    if writes is not None or _demand(prompt, r"\bhead tags\b"):
        target = "checkpoint"
    elif _demand(prompt, r"\b(?:numerical|keys only|sequence of keys)\b"):
        target = "key_order"
    elif _demand(prompt, r"\b(?:tag order|order of (?:the )?tags)\b"):
        target = "tag_order"
    elif _demand(prompt, r"\btie[- ]rule\b|\bwhich run\b[^.!?]{0,25}\badvance"):
        target = "tie_rule"
    elif _demand(prompt, r"\bcheckpoint\b"):
        target = "checkpoint"
    elif _demand(prompt, r"\btagged\b"):
        target = "tag_order"
    else:
        target = None
    if target and item.target != target:
        raise DistractorPoolError(
            f"Merge answer target must be {target} for this request"
        )
    checkpoint = _requested_number(
        prompt, rf"\bafter (?:writing )?{_COUNT} (?:writes?|records?|tags?)\b"
    )
    if (writes is not None and not 1 <= writes <= 8) or (
        checkpoint is not None and checkpoint > 15
    ):
        raise UnsupportedAuthoringRequest(
            "This merge checker supports a checkpoint before the final write "
            "in two runs of at most eight records each, and asks for up to "
            "eight upcoming writes."
        )
    return TraceRequirements(
        ties=2 if multiple_ties else int(has_ties),
        writes=writes,
        checkpoint=checkpoint if target in {"checkpoint", "tie_rule"} else None,
    )


_ANSWER_TYPE = TypeAdapter(TraceAnswer)
_COMPOUND_ANSWERS = {
    QueueState: ("front", "size", "array"),
    QueueOutcomes: ("rejected", "removed", "front", "next_write", "fifo"),
    MergeCheckpoint: ("left_head", "right_head", "next_writes"),
    MergeTie: ("written", "advance"),
}


def _recipe_value(raw: Any, expected: TraceAnswer) -> TraceAnswer:
    fields = _COMPOUND_ANSWERS.get(type(expected))
    if fields is not None and isinstance(raw, list) and len(raw) == len(fields):
        record = dict(zip(fields, raw, strict=True))
        if isinstance(expected, MergeCheckpoint):
            for field in ("left_head", "right_head"):
                if record[field] == "-":
                    record[field] = None
        return type(expected).model_validate(record)
    return _ANSWER_TYPE.validate_python(raw, strict=True)


def _recipe_input(answer: TraceAnswer) -> Any:
    fields = _COMPOUND_ANSWERS.get(type(answer))
    if fields is None:
        return answer
    return [
        "-" if (value := getattr(answer, field)) is None else value for field in fields
    ]


def _option(value: TraceAnswer) -> OptionValue:
    semantic = value.model_dump() if isinstance(value, ClosedModel) else value
    return OptionValue(semantic, display_answer(value))


def _compatible(value: TraceAnswer, expected: TraceAnswer) -> bool:
    if type(value) is not type(expected):
        return False
    if isinstance(value, QueueState) and isinstance(expected, QueueState):
        return len(value.array) == len(expected.array)
    if isinstance(value, list) and isinstance(expected, list):
        return all(
            type(element) is type(expected[0] if expected else 0) for element in value
        )
    return True


class TraceRecipes:
    def __init__(self, item: TraceProposal):
        names = tuple(p.name for p in item.parameters)
        self.key = SafeExpression(item.proposed_answer, names)
        self.options = []
        for choice in item.distractors:
            try:
                recipe = SafeExpression(choice.expression, (*names, "answer"))
            except ValidationFailure:
                recipe = None
            self.options.append(recipe)

    def compute(
        self, candidate: TraceCandidate, inputs: dict[str, ParameterValue]
    ) -> tuple[ComputedTrace, list[OptionValue | None]]:
        trace = compute_trace(candidate.item, inputs)
        expected = trace.answer
        claim = _recipe_value(self.key.evaluate(inputs), expected)
        if not _compatible(claim, expected) or claim != expected:
            raise ValidationFailure(
                f"For {inputs}, the proposed recipe gives {display_answer(claim)!r} "
                f"and the visible trace yields {display_answer(expected)!r}.",
                code="TRACE_ANSWER_MISMATCH",
                field="proposed_answer",
            )
        _check_facts(candidate.requirements, trace.facts, inputs)
        choice_inputs = inputs | {"answer": _recipe_input(expected)}
        options = []
        for recipe in self.options:
            if recipe is None:
                options.append(None)
                continue
            try:
                value = _recipe_value(recipe.evaluate(choice_inputs), expected)
            except (ValueError, ValidationFailure):
                options.append(None)
            else:
                options.append(_option(value) if _compatible(value, expected) else None)
        return trace, options


def _check_facts(
    requirements: TraceRequirements, facts: dict[str, int], inputs: dict
) -> None:
    pointer_flags = (
        (requirements.front_wrap, "front"),
        (requirements.rear_wrap, "rear"),
        (requirements.write_wrap, "write"),
    )
    specific_wrap = any(required for required, _ in pointer_flags)
    for required, name, failure in (
        (requirements.front_wrap, "front_wrapped", "wrap the front index"),
        (requirements.rear_wrap, "rear_wrapped", "wrap the rear occupied index"),
        (requirements.write_wrap, "write_wrapped", "wrap the next write index"),
        (
            requirements.wrap and not specific_wrap,
            "wrapped",
            "exercise a successful wraparound",
        ),
        (
            requirements.remove_after_wrap and not specific_wrap,
            "removals_after_wrap",
            "successfully remove an item after wraparound",
        ),
        (
            requirements.reinsert_removed,
            "reinserted",
            "reinsert a previously removed item",
        ),
        (
            requirements.reinsert_at_rear,
            "reinserted_at_rear",
            "leave a reinserted item at the rear",
        ),
        (
            requirements.rejected_full,
            "rejected_enqueues",
            "attempt an enqueue on a full queue",
        ),
    ):
        if required and not facts.get(name):
            raise ValueError(f"For {inputs}, the queue operations must {failure}")
    if requirements.remove_after_wrap:
        for required, pointer in pointer_flags:
            if required and not facts.get(f"removals_after_{pointer}_wrap"):
                raise ValueError(
                    f"For {inputs}, remove an item after the {pointer} index wraps"
                )
    if facts.get("cross_run_tie_keys", 0) < requirements.ties:
        raise ValueError(
            f"For {inputs}, the merge must include {requirements.ties} "
            "distinct cross-run tie keys"
        )
    if requirements.writes and facts.get("write_count") != requirements.writes:
        raise ValueError(
            f"The checkpoint must ask for the next {requirements.writes} writes"
        )
    if requirements.checkpoint is not None and requirements.checkpoint != facts.get(
        "checkpoint"
    ):
        raise ValueError(
            f"The merge checkpoint must follow {requirements.checkpoint} writes"
        )


def _boundaries(item: TraceProposal) -> list[dict[str, ParameterValue]]:
    ordered = {
        p.name: sorted(
            p.values, key=lambda v: (len(v), v) if isinstance(v, (list, str)) else v
        )
        for p in item.parameters
    }
    first = {name: values[0] for name, values in ordered.items()}
    last = {name: values[-1] for name, values in ordered.items()}
    cases = [first, last]
    for name, values in ordered.items():
        cases.extend(
            first | {name: v} for v in values if type(v) is int and v in (-1, 0, 1)
        )
        cases.extend((first | {name: values[-1]}, last | {name: values[0]}))
    for (a, left), (b, right) in combinations(ordered.items(), 2):
        shared = [v for v in left if type(v) is type(right[0]) and v in right]
        if shared:
            cases.extend(
                first | {a: value, b: value} for value in (shared[0], shared[-1])
            )
    return cases


def verify_trace(candidate: TraceCandidate) -> ToolEvidence:
    item = candidate.item
    run = PropertyCheckRun(
        PropertyCheckSettings(
            max_examples=32, max_execution_calls=64, timeout_seconds=5, seed=9569
        )
    )

    def verify_variant(inputs: dict, check: PropertyCheckRun):
        check.reserve_execution()
        return recipes.compute(candidate, inputs)

    try:
        recipes = TraceRecipes(item)
        rows = run.check(
            {p.name: p.values for p in item.parameters},
            _boundaries(item),
            verify_variant,
        )
        if len({trace.stem for trace, _ in rows}) < 2:
            raise ValueError(
                "Parameter variations must change the learner-visible trace"
            )
        if candidate.requirements.branching and not any(
            {trace.facts.get(name) for trace, _ in rows} >= {1, 2}
            for name in rows[0][0].facts
            if name.startswith("branch_")
        ):
            raise ValueError(
                "At least one requested queue condition must vary "
                "between true and false"
            )
        slots = select_fixed_subset(
            [(_option(trace.answer), options) for trace, options in rows],
            candidate.required,
            assignments=[json.loads(key) for key in run.passed],
        )
    except (ValueError, ValidationFailure) as error:
        return ToolEvidence(
            tool=TRACE_CHECK,
            version=CHECK_VERSION,
            status="failed",
            findings=[
                ToolFinding(
                    code=getattr(error, "code", "TRACE_INVALID"),
                    message=str(error),
                    field=getattr(error, "field", None),
                )
            ],
            details=run.details(),
        )
    return ToolEvidence(
        tool=TRACE_CHECK,
        version=CHECK_VERSION,
        status="passed",
        details={
            **run.details(),
            "subject_sha256": content_sha256(candidate),
            "selected_slots": list(slots),
            "method": (
                "Simulate visible operations and compare typed recipes "
                "on sampled inputs and boundaries."
            ),
        },
    )


def register_h2_trace_check(server: FastMCP) -> None:
    server.tool(
        name=TRACE_CHECK,
        version=CHECK_VERSION,
        tags={f"domain:{CHECK_SCOPE}"},
        description=(
            "Independently simulate sampled instances of the authored queue "
            "or merge trace and check the answer claims and typed options."
        ),
    )(verify_trace)


class H2ComputingTraceDomain:
    name = "code"
    tool_scope = CHECK_SCOPE
    request_model = TemplateRequest
    candidate_model = TraceCandidate
    validated_model = CheckedTrace
    question_model = TraceQuestion
    template_language = None
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )

    def __init__(self, kind: TraceKind | None = None):
        self.kind = kind

    def generation_request(
        self, request: TemplateRequest
    ) -> StructuredGenerationRequest:
        _require_supported_trace(request.prompt, self.kind)
        explanation = (
            "Author a reusable multiple-choice trace, including an initial "
            "state and one parameterised queue program. State recipes return "
            "a list of front, size and an array of every physical slot. FIFO "
            "answers list occupied "
            "values. front_index, rear_item and next_removed are integers. "
            "The outcomes target returns a list of rejected values, removed "
            "values, front, next write and FIFO values. Dequeue can save a "
            "removed value in a register, and Enqueue can take that register "
            "name as its value to reinsert it. if_peek compares the current "
            "front with an integer or a saved register and selects a sequence "
            "of enqueues and dequeues. The rendered question uses modulo "
            "indices and rejects an enqueue when full or a dequeue when empty. "
            "The rear is the last occupied slot. A rear index wraps when an "
            "enqueue moves it from the last slot to the first one."
            if self.kind == "queue"
            else "Author a reusable multiple-choice trace of ascending stable merging, "
            "including both parameterised sorted runs. The learner sees "
            "how stable ties and exhaustion are handled. Use unique tags for "
            "records. The targets are the complete tag order, complete "
            "numerical key order, checkpoint (left and right head tags plus "
            "next writes as a list; use '-' for exhaustion), or one tie "
            "decision [tag, advance]. Set checkpoint to 0 and "
            "write_count to 1 when those fields are unused."
        )
        model = (
            PlannedGenerationResponse[QueueProposal | UnsupportedComputingTask]
            if self.kind == "queue"
            else PlannedGenerationResponse[MergeProposal | UnsupportedComputingTask]
        )
        return StructuredGenerationRequest(
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"{explanation} Directly preserve the requested task and "
                        "answer target. If a requested operation or target cannot "
                        "be represented, respond with unsupported and describe it. "
                        "Declare 1 to 3 finite parameter domains and use parameters "
                        "in numeric input expressions and initial array expressions. "
                        "Include meaningful boundary values, tied keys or alternate "
                        "queue branches where applicable. Author one independently "
                        "solved proposed_answer expression over your parameters. "
                        "Return exactly the requested distractor count plus three "
                        "parameterised distractor expressions. Distractors may also "
                        "use answer, the canonical result represented as a scalar "
                        "or list. Each models a particular mistake and should stay "
                        "type-compatible and distinct across the parameter domains. "
                        "Use arithmetic, comparisons, conditional expressions, lists, "
                        "indexing, slices, len, sum, min, max and sorted. Expressions "
                        "contain plain parameter names. Use expressions only. "
                        f"Recommend {TRACE_CHECK} and offered advisory checks using "
                        "empty arguments. An independent check derives the key from "
                        "the visible data, checks your proposed keys, and rejects "
                        "colliding options."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"{request.prompt}\nDifficulty {request.difficulty}. "
                        f"Provide {request.num_distractors} usable distractors per "
                        "question, plus exactly three reserves."
                    ),
                },
            ],
            response_model=model,
            prompt_version="h2-computing-trace-1",
        )

    def build_candidate(
        self,
        request: TemplateRequest,
        proposal: TraceProposal | UnsupportedComputingTask,
    ) -> TraceCandidate:
        if isinstance(proposal, UnsupportedComputingTask):
            raise UnsupportedAuthoringRequest(proposal.unsupported)
        _require_supported_trace(request.prompt, self.kind)
        if proposal.kind != self.kind:
            raise UnsupportedAuthoringRequest(
                f"The requested task needs a checked {self.kind} trace"
            )
        _require_trace_material(request, proposal.kind)
        if len(proposal.distractors) != request.num_distractors + SURPLUS_RECIPES:
            raise DistractorPoolError(
                "Author the requested number of distractors plus three reserves"
            )
        return TraceCandidate(
            template_id=build_template_id(self.name, request, proposal),
            difficulty=request.difficulty,
            required=request.num_distractors,
            item=proposal,
            requirements=_requirements(request.prompt, proposal),
        )

    def required_checks(self, candidate: TraceCandidate) -> frozenset[str]:
        return frozenset({TRACE_CHECK})

    def distractor_count(self, candidate: TraceCandidate) -> int:
        return len(candidate.item.distractors)

    def tool_bindings(self, request, candidate, tool_name):
        if tool_name == TRACE_CHECK:
            return {
                "candidate": candidate.model_dump(mode="json"),
            }
        raise ValueError(f"Check {tool_name} needs verified trace options")

    def checked_tool_bindings(self, request, candidate, tool_name, evidence):
        checked = self.finalize_checked_template(
            candidate,
            [item for item in evidence if item.tool == TRACE_CHECK],
            advisory_checks=frozenset(),
        )
        examples = [self.generate_question(checked, seed=seed) for seed in (0, 31, 847)]
        digest = content_sha256(candidate)
        if tool_name == TEMPLATE_RELEVANCE_CHECK:
            return {
                "author_request": request.prompt,
                "question_text": json.dumps(
                    [{"question": q.question, "choices": q.choices} for q in examples]
                ),
                "subject_sha256": digest,
            }
        if tool_name == TEMPLATE_DIFFICULTY_CHECK:
            return {
                "rubric_id": "code-h2",
                "question_payload": json.dumps(
                    [{"question": q.question, "choices": q.choices} for q in examples]
                ),
                "distractor_count": candidate.required,
                "requested_difficulty": candidate.difficulty,
                "subject_sha256": digest,
            }
        raise ValueError(f"Unknown computing trace check {tool_name}")

    def finalize_checked_template(self, candidate, evidence, *, advisory_checks):
        require_checked(
            evidence,
            required=self.required_checks(candidate),
            advisory_checks=advisory_checks,
        )
        check = next(item for item in evidence if item.tool == TRACE_CHECK)
        digest = content_sha256(candidate)
        if check.details.get("subject_sha256") != digest:
            raise ValueError(
                "This computing trace check belongs to a different candidate"
            )
        return CheckedTrace(
            template=candidate,
            selected_slots=check.details["selected_slots"],
            validation=TraceValidation(
                **property_details(check.details),
                evidence=[
                    save_checked_evidence(item, digest, advisory_checks=advisory_checks)
                    for item in evidence
                ],
            ),
        )

    def generate_question(self, validated: CheckedTrace, *, seed: int) -> TraceQuestion:
        template = validated.template
        item = template.item
        recipes = TraceRecipes(item)
        for attempt in range(32):
            inputs = {
                p.name: copy.deepcopy(
                    p.values[
                        seeded_index(
                            template.template_id,
                            seed,
                            f"{p.name}-{attempt}",
                            len(p.values),
                        )
                    ]
                )
                for p in item.parameters
            }
            try:
                trace, options = recipes.compute(template, inputs)
                key = _option(trace.answer)
                accepted = [options[i] for i in validated.selected_slots]
                if any(choice is None for choice in accepted):
                    continue
                choices = [key, *(choice for choice in accepted if choice is not None)]
                if len({choice.display for choice in choices}) != len(choices):
                    continue
            except (ValueError, ValidationFailure):
                continue
            order = [choice.display for choice in choices]
            random.Random(
                seeded_index(template.template_id, seed, "h2-trace-order", 2**32)
            ).shuffle(order)
            return TraceQuestion(
                template_id=template.template_id,
                artifact_id=validated.artifact_id,
                seed=seed,
                parameters=inputs,
                family=f"authored-{item.kind}",
                topic="Circular queue" if item.kind == "queue" else "Stable merge",
                question=trace.stem,
                answer=key.display,
                choices=order,
                correct_index=order.index(key.display),
            )
        raise ValueError(
            "No checked computing trace within the seeded generation budget"
        )

    def review_view(self, artifact: CheckedTrace) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=None)
        if view is None:
            return None
        questions = [
            self.generate_question(artifact, seed=seed) for seed in (0, 31, 847)
        ]
        return view.model_copy(
            update={
                "case_previews": [
                    ReviewCasePreview(
                        case_id=f"seed {question.seed}",
                        seed=question.seed,
                        outcome=question.topic,
                        question=question.question,
                        answer=question.answer,
                        choices=question.choices,
                    )
                    for question in questions
                ],
                "candidate": {
                    **view.candidate,
                    "authoring_mode": "Model-authored operation trace",
                    "scope": f"{questions[0].topic} · {artifact.template.item.target}",
                    "sample_question": questions[0].question,
                    "sample_choices": questions[0].choices,
                    "sample_answer": questions[0].answer,
                },
            }
        )
