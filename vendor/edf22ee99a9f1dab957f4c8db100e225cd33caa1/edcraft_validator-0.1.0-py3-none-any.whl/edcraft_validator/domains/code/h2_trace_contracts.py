"""Authored inputs, operations and typed answer claims for checked H2 traces."""

from typing import Annotated, Literal, Self

from pydantic import Field, model_validator

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domain_types import Difficulty
from edcraft_validator.domains.code.proposal_response import CodeParameterResponse
from edcraft_validator.domains.h2.schemas import ClosedModel
from edcraft_validator.validation.property_summary import PropertyCheckSummary

TRACE_FORMAT = "h2-computing-trace/1.0"
TraceKind = Literal["queue", "merge"]
QueueTarget = Literal[
    "state", "front_index", "rear_item", "next_removed", "fifo", "outcomes"
]
MergeTarget = Literal["tag_order", "key_order", "checkpoint", "tie_rule"]
Value = Annotated[int, Field(ge=-1000, le=1000)]
Expression = Annotated[str, Field(min_length=1, max_length=500)]
ValueExpression = Value | Expression
Register = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]{0,15}$")]
Tag = Annotated[str, Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,11}$")]


class QueueState(ClosedModel):
    front: int = Field(ge=0, le=11)
    size: int = Field(ge=0, le=12)
    array: list[Value] = Field(min_length=1, max_length=12)


class QueueOutcomes(ClosedModel):
    rejected: list[Value] = Field(max_length=48)
    removed: list[Value] = Field(max_length=48)
    front: int = Field(ge=0, le=11)
    next_write: int = Field(ge=0, le=11)
    fifo: list[Value] = Field(max_length=12)


class MergeCheckpoint(ClosedModel):
    left_head: Tag | None
    right_head: Tag | None
    next_writes: list[Tag] = Field(min_length=1, max_length=8)


class MergeTie(ClosedModel):
    written: Tag
    advance: Literal["left", "right", "both", "neither"]


TraceAnswer = (
    Value
    | Annotated[list[Value], Field(max_length=48)]
    | Annotated[list[Tag], Field(max_length=48)]
    | QueueState
    | QueueOutcomes
    | MergeCheckpoint
    | MergeTie
)


class TraceDistractor(ClosedModel):
    expression: Expression
    reason: str = Field(min_length=1, max_length=200)


class TraceBlueprint(ClosedModel):
    parameters: list[CodeParameterResponse] = Field(min_length=1, max_length=3)
    proposed_answer: Expression
    distractors: list[TraceDistractor] = Field(min_length=1, max_length=13)

    @model_validator(mode="after")
    def distinct_parameters(self) -> Self:
        names = [p.name for p in self.parameters]
        if len(set(names)) != len(names) or "answer" in names:
            raise ValueError("Parameter names must be unique and cannot be 'answer'")
        return self


class Enqueue(ClosedModel):
    operation: Literal["enqueue"]
    value: ValueExpression


class Dequeue(ClosedModel):
    operation: Literal["dequeue"]
    save_as: Register | None


QueueAction = Enqueue | Dequeue


class QueueBranch(ClosedModel):
    operation: Literal["if_peek"]
    comparison: Literal["<", "<=", "==", "!=", ">", ">="]
    against: ValueExpression
    then_do: list[QueueAction] = Field(min_length=1, max_length=4)
    else_do: list[QueueAction] = Field(max_length=4)


class QueueInitial(ClosedModel):
    front: ValueExpression
    size: ValueExpression
    array: Expression


class QueueProposal(TraceBlueprint):
    kind: Literal["queue"]
    target: QueueTarget
    initial: QueueInitial
    program: list[QueueAction | QueueBranch] = Field(min_length=1, max_length=12)


class Record(ClosedModel):
    key: ValueExpression
    tag: Tag


class MergeProposal(TraceBlueprint):
    kind: Literal["merge"]
    target: MergeTarget
    left: list[Record] = Field(min_length=1, max_length=8)
    right: list[Record] = Field(min_length=1, max_length=8)
    checkpoint: ValueExpression
    write_count: ValueExpression


TraceProposal = QueueProposal | MergeProposal


class TraceRequirements(ClosedModel):
    wrap: bool = False
    front_wrap: bool = False
    rear_wrap: bool = False
    write_wrap: bool = False
    remove_after_wrap: bool = False
    reinsert_removed: bool = False
    reinsert_at_rear: bool = False
    branching: bool = False
    rejected_full: bool = False
    ties: int = 0
    writes: int | None = None
    checkpoint: int | None = None


class TraceCandidate(ClosedModel):
    template_id: str
    difficulty: Difficulty
    required: int = Field(ge=1, le=10)
    item: TraceProposal
    requirements: TraceRequirements


class TraceValidation(PropertyCheckSummary):
    validator_version: Literal["mcp-code-h2-trace-v1"] = "mcp-code-h2-trace-v1"


class CheckedTrace(ValidatedTemplateArtifact):
    format_version: Literal["h2-computing-trace/1.0"] = TRACE_FORMAT
    template: TraceCandidate
    selected_slots: list[int] = Field(min_length=1, max_length=10)
    validation: TraceValidation

    @model_validator(mode="after")
    def check_saved_selection(self) -> Self:
        limit = len(self.template.item.distractors)
        if (
            len(set(self.selected_slots)) != self.template.required
            or len(self.selected_slots) != self.template.required
            or any(not 0 <= slot < limit for slot in self.selected_slots)
        ):
            raise ValueError("Saved computing trace choice selection is invalid")
        return self
