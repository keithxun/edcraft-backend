"""Mechanically check explicit Computing requirements on ordinary Python traces."""

import ast
import re
from typing import Literal

from edcraft_validator.domains.code.code_schemas import (
    CodeTemplateContent,
    CodeTemplateRequest,
)
from edcraft_validator.domains.code.code_types import AnswerTarget, CodeFeature
from edcraft_validator.domains.code.features import (
    extract_code_features,
    has_strided_slice,
    reachable_subscripts,
)
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.validation.distractor_pool import DistractorPoolError

STRIDED_SLICE = re.compile(
    r"\b(?:strided slic(?:e|ing)|slic(?:e|ing) with a step)\b", re.I
)
_STRIDED_EXPRESSION = re.compile(
    r"\b[A-Za-z_]\w*\s*\[[^\]\r\n:]*:[^\]\r\n:]*:\s*"
    r"(?:[+-]?(?:[2-9]|[1-9]\d+)|[A-Za-z_]\w*)\s*\]"
)

_UNSUPPORTED = (
    (r"\bwhile loops?\b", "while loops"),
    (r"\b(?:list |dictionary |set )?comprehensions?\b", "comprehensions"),
    (r"\b(?:try/except|exception handling)\b", "exception handling"),
    (
        r"\b(?:object[- ]oriented|inheritance|dynamic dispatch)\b",
        "object-oriented class behavior",
    ),
    (r"\b(?:sql|database query|relational join)\b", "database query evaluation"),
)

_FEATURE_REQUIREMENTS: tuple[tuple[str, CodeFeature], ...] = (
    (r"\bnested (?:Python )?loops?\b", "nested_loop"),
    (r"\bnested (?:Python )?(?:if|conditionals?)\b", "nested_conditional"),
    (r"\bsequential (?:Python )?loops?\b", "sequential_loops"),
    (r"\bhelper functions?\b", "helper_function"),
    (r"\bearly return\b", "early_return"),
)

_COUNT_TARGETS: tuple[tuple[str, AnswerTarget], ...] = (
    (r"\b(?:loop )?iterations?\b", "loop_iterations"),
    (r"\b(?:loop executions?|loops? (?:are |is |get )?entered)\b", "loop_executions"),
    (
        r"\b(?:branch executions?|branches? (?:are |is |get )?taken)\b",
        "branch_executions",
    ),
    (r"\b(?:function calls?|times[^?]*\b(?:is |are )?called)\b", "function_calls"),
)
_RETURN_TARGET = r"\breturn value\b|\b(?:what|which)\b[^?]*\breturn\b"

PythonSkill = CodeFeature | Literal["list_slicing", "function_tracing"]
_MATERIAL_SKILLS: tuple[tuple[str, PythonSkill], ...] = (
    *_FEATURE_REQUIREMENTS,
    (
        r"\b(?:for loops?|loop iterations?|loop tracing|tracing (?:a )?loops?)\b"
        r"|^\s*for [^\n:]+ in [^\n:]+:",
        "loop",
    ),
    (
        r"\b(?:if statements?|if/else|conditional branch(?:es)?)\b|^\s*if [^\n:]+:",
        "conditional",
    ),
    (
        r"\b(?:Python arithmetic|arithmetic expressions?|arithmetic operators?)\b",
        "arithmetic",
    ),
    (r"\b(?:list indexing|index(?:ing)? (?:a |Python )?lists?)\b", "list_index"),
    (
        r"\b(?:list aggregation|summing (?:the )?(?:elements|values) of a list)\b"
        r"|\bsum\s*\(",
        "list_aggregate",
    ),
    (r"\b(?:list sort(?:ing)?|sorting (?:a )?lists?)\b|\bsorted\s*\(", "list_sort"),
    (
        r"\b(?:list slicing|slic(?:e|ing) (?:a )?lists?"
        r"|slic(?:e|ing) with a step|strided slic(?:e|ing))\b"
        r"|\b[A-Za-z_]\w*\[[^\]\n:]*:[^\]\n]*\]",
        "list_slicing",
    ),
    (
        r"\b(?:Python function trac(?:e|ing)|trac(?:e|ing) (?:an? )?Python function)\b",
        "function_tracing",
    ),
)


def _contains(prompt: str, pattern: str) -> bool:
    return any(
        not re.search(
            r"\b(?:without|avoid|excluding|no)\b[^,.!?]{0,18}$",
            prompt[: match.start()],
            re.I,
        )
        for match in re.finditer(pattern, prompt, flags=re.I | re.M)
    )


def require_supported_python_task(prompt: str) -> None:
    for pattern, construct in _UNSUPPORTED:
        if _contains(prompt, pattern):
            raise UnsupportedAuthoringRequest(
                f"The bounded Python execution checker does not support {construct}. "
                "Request a supported function trace or provide a checker for the task."
            )


def _target(text: str) -> AnswerTarget | None:
    for cue, target in _COUNT_TARGETS:
        if _contains(text, cue):
            return target
    return "return_value" if _contains(text, _RETURN_TARGET) else None


def requests_strided_slice(request: CodeTemplateRequest) -> bool:
    if STRIDED_SLICE.search(request.prompt):
        return True
    exam = request.materials.exam if request.materials else None
    return bool(
        exam
        and (STRIDED_SLICE.search(exam.text) or _STRIDED_EXPRESSION.search(exam.text))
    )


def _material_skills(text: str) -> set[PythonSkill]:
    skills = {skill for cue, skill in _MATERIAL_SKILLS if _contains(text, cue)}
    if len(skills) > 1:
        skills.discard("function_tracing")
    return skills


def _require_python_material(
    request: CodeTemplateRequest,
    proposal: CodeTemplateContent,
    features: frozenset[CodeFeature],
) -> None:
    materials = request.materials
    if materials is None:
        return
    lecture = {skill for p in materials.lecture for skill in _material_skills(p.text)}
    if lecture & {"nested_loop", "sequential_loops"}:
        lecture.add("loop")
    if lecture & {"nested_conditional", "early_return"}:
        lecture.add("conditional")
    subscripts = list(reachable_subscripts(proposal.code, proposal.entry_function))
    selected: set[PythonSkill] = {*features, "function_tracing"}
    if any(isinstance(subscript, ast.Slice) for subscript in subscripts):
        selected.add("list_slicing")
    if not any(not isinstance(subscript, ast.Slice) for subscript in subscripts):
        selected.discard("list_index")
    expected = _material_skills(request.prompt)
    if expected == {"function_tracing"} and lecture:
        expected.clear()
    exam_skills: set[PythonSkill] = set()
    if materials.exam:
        require_supported_python_task(materials.exam.text)
        exam_skills = _material_skills(materials.exam.text)

    missing = expected - lecture
    if exam_skills and not (exam_skills & lecture):
        missing.update(exam_skills)
    if missing or not (lecture & selected):
        names = ", ".join(skill.replace("_", " ") for skill in sorted(missing))
        detail = f" for {names}" if names else " for the proposed Python operation"
        raise UnsupportedAuthoringRequest(
            f"The reviewed lecture lacks evidence{detail}. "
            "Select an excerpt demonstrating the skill to be checked."
        )
    expected.update(exam_skills & lecture)
    if omitted := expected - selected:
        names = ", ".join(skill.replace("_", " ") for skill in sorted(omitted))
        raise DistractorPoolError(
            f"Show the requested {names} in the learner-visible Python."
        )


def require_python_task(
    request: CodeTemplateRequest,
    proposal: CodeTemplateContent,
    *,
    h2: bool,
) -> None:
    prompt = request.prompt
    require_supported_python_task(prompt)
    needs_stride = requests_strided_slice(request)
    if not h2 and not needs_stride and request.materials is None:
        return
    try:
        if needs_stride and not has_strided_slice(
            proposal.code, proposal.entry_function
        ):
            raise DistractorPoolError(
                "The request requires a strided slice in a function reachable "
                "from the entry function. Use an explicit non-unit step."
            )
        features = extract_code_features(proposal.code, proposal.entry_function)
        if h2:
            required = {
                feature
                for cue, feature in _FEATURE_REQUIREMENTS
                if _contains(prompt, cue)
            }
            missing = required - features
            if missing:
                raise DistractorPoolError(
                    "The learner-visible code is missing required features "
                    f"{sorted(missing)}."
                )
        _require_python_material(request, proposal, features)
    except SyntaxError as error:
        raise DistractorPoolError(
            f"Invalid learner-visible Python: {error.msg}"
        ) from error

    exam = request.materials.exam if request.materials else None
    expected = _target(prompt) or (_target(exam.text) if exam else None)
    if expected and proposal.answer_target != expected:
        raise DistractorPoolError(
            f"The request asks for {expected}, so that must be the answer target."
        )
    if h2:
        question = proposal.question_template
        arguments = r"\s*,\s*".join(
            re.escape("{" + parameter.name + "}") for parameter in proposal.parameters
        )
        entry = re.escape(proposal.entry_function)
        if not re.search(rf"\b{entry}\(\s*{arguments}\s*\)", question):
            raise DistractorPoolError(
                "Show the entry function call with all input placeholders "
                "in argument order."
            )
        if _target(question) != proposal.answer_target:
            raise DistractorPoolError(
                "Use wording that explicitly asks for the selected execution target "
                f"{proposal.answer_target}."
            )
