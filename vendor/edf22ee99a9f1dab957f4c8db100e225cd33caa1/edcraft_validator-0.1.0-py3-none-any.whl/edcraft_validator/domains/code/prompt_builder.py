"""Build code-domain prompts and the structured LLM request."""

from __future__ import annotations

from edcraft_validator.domains.code.check_plan import CODE_CHECK_ARGUMENT_MODELS
from edcraft_validator.domains.code.code_schemas import (
    CodeTemplateRequest,
)
from edcraft_validator.domains.code.code_types import (
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
)
from edcraft_validator.domains.code.h2_python import requests_strided_slice
from edcraft_validator.domains.code.proposal_response import (
    CodeProposalResponse,
    UnsupportedComputingTask,
)
from edcraft_validator.domains.code.template_revision import author_difficulty_guidance
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

CODE_TEMPLATE_PROMPT_VERSION = "code-template-v27-checked-pool"


def build_template_prompt(
    request: CodeTemplateRequest,
) -> str:
    return f"""\
Author request (preserve its meaning; do not replace it with a catalogue topic):
{request.prompt}

Requested difficulty: {request.difficulty}
Required usable distractors: {request.num_distractors}
Supported distractor range: {MIN_DISTRACTORS} to {MAX_DISTRACTORS}
Checks available for recommendation are in the supplied MCP catalogue.

Choose the entry function, finite parameters, learner-facing question template, and
one supported answer_target and an answer_expression recipe. The question_template
must name the entry function and
use every parameter exactly as a plain placeholder such as `{{n}}`. Its wording must
unambiguously ask for the selected answer_target. The exact entry_function identifier
must appear verbatim in question_template as a function call. For example, if
entry_function is `calculate_expression`, write `What does
calculate_expression({{a}}, {{b}}, {{c}}) return?`; do not replace the call with a
description of the arithmetic expression.

Return exactly {request.num_distractors + SURPLUS_RECIPES} distractor candidates
for {request.num_distractors} usable distractors. Model real
misconceptions and remain type-compatible, distinct from the answer, and mutually
distinct across the declared domain. In reason_template,
use only plain
parameter placeholders such as `{{n}}`; never put expressions inside braces.
Declare a broad value list for each parameter, close to the 32-value limit where
the task allows, and include edge values such as zero, one and negatives where
the parameter type allows, and equal operands where those are meaningful. The
program must stay well within the execution trace limit for the largest declared
values, so nested loops need smaller maximum values, and broad lists should add
variety rather than size. Keep
the proposed misconceptions
distinct across that domain. A value such as zero, one or equal operands can
make a wrong operation yield the right answer. To avoid a collision, prefer
replacing a distractor recipe first. Remove a value only when no distractor
choice works.

Recommend a nonempty fixed subset of the available MCP tools using their supplied
descriptions. Use each tool name at most once and do not invent names.
Supply each selected check's model-owned arguments using its planning schema.
Use {{}} for checks without model-owned arguments. For code_require_features,
provide a nonempty required list containing only explicitly requested features.
The application freezes these arguments and supplies the current candidate and
required distractor count. Select tools that obtain
execution-derived answers and checked distractors necessary for a reusable template.
Also select the available template difficulty check to assess the requested level
for the typical instance across the declared parameter distribution.
Also select assess_template_relevance to compare the template with the original
author request. The application supplies that unchanged request and the checked
template. An irrelevant result is advisory evidence for educator review; it does
not request revision or block a technically checked template.
Difficulty feedback is advisory evidence about the reusable template, not a
revision requirement; inspect estimates separately from technical checks.
Only selected checks will run. The application executes them directly without
native tool requests; the check plan remains fixed across revisions.
"""


CODE_TEMPLATE_SYSTEM_PROMPT = """\
Generate one complete reusable Python execution-trace MCQ proposal and recommend its
fixed validation checks in the same structured response. Do not generate one concrete
question. The local application derives identity, difficulty, version, and question
type; you author the question template, code, entry function, answer target,
finite parameters, an answer_expression recipe, and distractors. The application
compares the recipe with isolated execution on sampled inputs. Generation evaluates
the recipe for new inputs without executing every generated question; drafts are
manually reviewed. Supply a general recipe, not one concrete answer.

Declare bounded typed parameter values. The application checks every combination
of a small declared domain and uses property-based sampling with boundary
examples and shrinking for a larger domain. Passing samples does not prove every
possible variant correct.

Rules:
- `code` is the learner-facing Python program that the question asks about. It must
  directly perform the selected topic's computation or control flow. Never write a
  question generator, template generator, metadata dictionary, schema, or code that
  stores answer/distractor expressions as strings. Keep code and distractor
  candidates as separate schema fields.
- Define one module-level entry function whose positional arguments exactly match the
  parameter names and order. Use every parameter in executed learner-facing behavior.
  Define called helper functions at module level, not inside another function.
  Recursion is allowed. Recursive code must have a base case
  and use bounded inputs suitable for manual tracing.
- Supported Python subset (statically enforced; code outside it is rejected before
  execution). Allowed statements are module-level `def`, module-level assignment,
  `if`, `for`, `return`, `break`, `continue`, `pass`, and expression statements.
  Allowed calls are direct calls to module-level functions you define and these
  built-ins only: abs, all, any, bool, enumerate, float, int, len, list, max, min,
  range, reversed, round, sorted, str, sum, tuple, zip. Do not call `print`, do not
  use attribute or method access (`.append`, `.items`, `.upper`, ...), do not call a
  function defined inside another function, and do not call through a variable.
  Forbidden constructs are import, class, decorator, lambda, list/dict/set/generator
  comprehension, `yield` and `yield from`, `try`/`except`/`finally`, `raise`,
  `while`, `with`, `del`, `global`, `nonlocal`, `async`/`await`, and any name
  starting with `__`. Integer literals must not exceed 10,000 in absolute value.
  Define every helper you call at module level; a nested `def` is not callable
  under this subset, so prefer inlining the logic in the entry function.
- Every parameter declares a kind and two to 32 distinct finite values. Supported
  kinds are integer (-100 through 100), boolean, string (non-empty short printable
  text), and
  integer_list (at most eight integers from -100 through 100). Encode parameter
  values according to the response schema and the user prompt's format guidance.
- Select exactly one supported answer_target: return_value, loop_iterations,
  loop_executions, branch_executions, or function_calls. Answer and distractor
  expressions use
  parameter names,
  numeric constants, arithmetic, comparisons, boolean operators, or a conditional
  expression. String constants, list literals, indexing, slices, and functions
  len, sum, min, max, sorted, all, and any are also supported. Do not use methods or
  other function calls. Expressions use bare parameter names, for example `a + b`.
  Placeholder braces belong only in question_template and reason_template.
- Answer and distractor recipes are closed-form expressions over the declared
  parameter names only. If the code accumulates in a local variable, derive the
  result from the inputs. The recipe has no access to the function's local
  variables or the function itself. For a count of executions, use loop_iterations,
  loop_executions, branch_executions, or function_calls with a closed-form count.
- question_template must name the entry function and use plain placeholders for every
  declared parameter. Its wording must match answer_target.
- Each distractor candidate must represent a specific misconception. The MCP tool
  selects one fixed subset that is unique, type-compatible and different from
  the answer on all checked samples. It does not exclude bad inputs or insert
  fallback options. Supply enough usable candidates. A failed property returns
  a counterexample so you can revise the answer recipe, code, or distractors.
  Fix the general rule, not just the reported sample. Check membership stays fixed.
- reason_template explains its misconception and may use only a bare parameter
  placeholder such as `{n}`. Do not place arithmetic or any other expression inside
  braces.
- During initial generation, return the combined proposal-and-check-plan schema.
  Return `code` as a JSON array of individual Python lines, including indentation
  spaces at the beginning of each indented line. Keep each statement on its own
  line; do not put newline characters inside an array entry. Use at most 160 lines
  and one to three parameters, with no extra/default entry-function arguments.
  During revision, return only proposal fields matching the supplied schema; the
  application keeps the original check plan. Return every model-authored field,
  including unchanged fields, rather than a partial patch. Keep code, function
  signature, parameters, wording, answer and distractors coherent. Do not include
  locally derived fields.
  Select any model-owned check arguments in the initial plan. Select only features
  explicitly required by the educator. The application freezes names and arguments
  and runs checks directly; no native tool calls or acknowledgement are needed.
"""

UNSUPPORTED_GUIDANCE = """\
Retain the precise operation,
representation and answer target required by the educator. If the requested
task cannot be assessed as a supported Python execution trace, return
{"unsupported": "Describe the specific missing checker and a supported scope."}
as the proposal. Use the ordinary code check for the check-plan field.
For example, a written program submission, query evaluation in a database,
an unsupported Python construct explicitly requested, or a qualitative ethics
judgement needs a different checker. Do not translate such an objective into
an unrelated Python question. Use the full proposal only when the learner-facing
code, inputs and target directly express the teacher's objective.
"""

H2_GUIDANCE = """\
This is a Singapore H2 Computing request.
Use the actual entry-function call in the question text, in argument order.
Ask directly for the return value, loop iterations, loop executions,
branch executions or function calls, matching the exact requested target.
"""


RESPONSE_GUIDANCE = """\
Use native JSON values matching each parameter's `kind`: integers use JSON numbers;
booleans use JSON booleans; strings use JSON strings; integer_list values use nested
JSON arrays of numbers. Do not encode numbers, booleans, or arrays as strings.

An answer recipe example is "answer_expression": "a + b".
A distractor expression example is "expression": "a - b". Only text templates use
placeholders, for example
"question_template": "What does add({a}, {b}) return?". Expressions are evaluated
as Python using the parameter values, while text templates are formatted as text.
"""


def build_code_generation_request(
    request: CodeTemplateRequest,
    *,
    h2: bool = False,
) -> StructuredGenerationRequest:
    """Return the provider-independent code proposal contract."""
    stride = requests_strided_slice(request)
    stride_guidance = (
        "\nUse a Python slice with an explicit non-unit step in the visible code. "
        "Answer recipes can use indexing and slices such as sum(xs[1::2])."
        if stride
        else ""
    )
    system_message = {
        "role": "system",
        "content": (
            CODE_TEMPLATE_SYSTEM_PROMPT
            + "\n"
            + UNSUPPORTED_GUIDANCE
            + (H2_GUIDANCE if h2 else "")
            + stride_guidance
            + "\n"
            + author_difficulty_guidance()
        ),
    }
    user_prompt = build_template_prompt(request)

    return StructuredGenerationRequest(
        messages=[
            system_message,
            {
                "role": "user",
                "content": f"{user_prompt}\n{RESPONSE_GUIDANCE}",
            },
        ],
        response_model=PlannedGenerationResponse[
            CodeProposalResponse | UnsupportedComputingTask
        ],
        prompt_version=(
            "h2-computing-python-1"
            if h2
            else f"{CODE_TEMPLATE_PROMPT_VERSION}+response-v9-code-or-unsupported"
            + ("+strided-slice" if stride else "")
        ),
        schema_name="template_proposal_and_check_plan",
        check_argument_models=CODE_CHECK_ARGUMENT_MODELS,
    )
