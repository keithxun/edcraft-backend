"""Render and derive answers from author-supplied H2 trace programs and runs."""

import operator
from dataclasses import dataclass

from edcraft_validator.domains.code.code_types import ParameterValue
from edcraft_validator.domains.code.h2_trace_contracts import (
    Dequeue,
    Enqueue,
    MergeCheckpoint,
    MergeProposal,
    MergeTie,
    QueueAction,
    QueueBranch,
    QueueOutcomes,
    QueueProposal,
    QueueState,
    TraceAnswer,
    TraceProposal,
    ValueExpression,
)
from edcraft_validator.domains.code.safe_expressions import SafeExpression
from edcraft_validator.domains.h2.operation_traces import QueueBuffer, _merge

_COMPARISONS = {
    "<": operator.lt,
    "<=": operator.le,
    "==": operator.eq,
    "!=": operator.ne,
    ">": operator.gt,
    ">=": operator.ge,
}


@dataclass(frozen=True)
class ComputedTrace:
    stem: str
    answer: TraceAnswer
    facts: dict[str, int]


def _integer(expression: ValueExpression, inputs: dict[str, ParameterValue]) -> int:
    value = (
        expression
        if type(expression) is int
        else SafeExpression(expression, tuple(inputs)).evaluate(inputs)
    )
    if type(value) is not int or abs(value) > 1000:
        raise ValueError(
            f"Trace input {expression!r} must produce an integer in -1000 to 1000"
        )
    return value


def _action_text(
    action: QueueAction, inputs: dict[str, ParameterValue], registers: set[str]
) -> str:
    if isinstance(action, Enqueue):
        value = (
            action.value
            if action.value in registers
            else _integer(action.value, inputs)
        )
        return f"Enqueue({value})"
    return f"{action.save_as} = Dequeue()" if action.save_as else "Dequeue()"


def _queue_line(
    operation: QueueAction | QueueBranch,
    inputs: dict[str, ParameterValue],
    registers: set[str],
) -> str:
    if not isinstance(operation, QueueBranch):
        return _action_text(operation, inputs, registers)
    then = ", ".join(
        _action_text(action, inputs, registers) for action in operation.then_do
    )
    bound = operation.against
    if bound not in registers:
        bound = _integer(bound, inputs)
    line = f"IF Peek() {operation.comparison} {bound} THEN {then}"
    if operation.else_do:
        line += " ELSE " + ", ".join(
            _action_text(action, inputs, registers) for action in operation.else_do
        )
    return line


def _queue(proposal: QueueProposal, inputs: dict[str, ParameterValue]) -> ComputedTrace:
    initial = QueueState(
        front=_integer(proposal.initial.front, inputs),
        size=_integer(proposal.initial.size, inputs),
        array=SafeExpression(proposal.initial.array, tuple(inputs)).evaluate(inputs),
    )
    capacity = len(initial.array)
    if initial.front >= capacity or initial.size > capacity:
        raise ValueError("The initial front or size exceeds the circular array")
    state = QueueBuffer(tuple(initial.array), initial.front, initial.size)
    variables: dict[str, int] = {}
    declared_registers = {
        action.save_as
        for command in proposal.program
        for action in (
            command.then_do + command.else_do
            if isinstance(command, QueueBranch)
            else [command]
        )
        if isinstance(action, Dequeue) and action.save_as
    }
    if declared_registers & inputs.keys():
        raise ValueError("Queue registers cannot shadow authoring parameters")

    rejected, removed, lines = [], [], []
    front_wrap = rear_wrap = write_wrap = False
    removals_after = dict(front_wrap=0, rear_wrap=0, write_wrap=0, wrap=0)
    reinserted = 0
    paths: dict[str, int] = {}
    reinserted_slots: set[int] = set()

    def operand(value: ValueExpression) -> int:
        if value in declared_registers:
            if value not in variables:
                raise ValueError(f"Queue register {value} is read before assignment")
            return variables[value]
        return _integer(value, inputs)

    for step, command in enumerate(proposal.program):
        lines.append(_queue_line(command, inputs, declared_registers))
        if isinstance(command, QueueBranch):
            if not state.size:
                raise ValueError("A tested queue program peeks at an empty queue")
            bound = operand(command.against)
            take_true = _COMPARISONS[command.comparison](state.peek(), bound)
            paths[f"branch_{step}"] = 1 if take_true else 2
            actions = command.then_do if take_true else command.else_do
        else:
            actions = [command]

        for action in actions:
            if isinstance(action, Enqueue):
                value = operand(action.value)
                if state.size == capacity:
                    rejected.append(value)
                    continue
                slot = (state.front + state.size) % capacity
                rear_wrap |= state.size > 0 and slot == 0
                write_wrap |= slot == capacity - 1
                if action.value in variables:
                    reinserted += 1
                    reinserted_slots.add(slot)
                else:
                    reinserted_slots.discard(slot)
                state = state.enqueue(value)
            elif state.size:
                removed.append(state.peek())
                if action.save_as:
                    variables[action.save_as] = state.peek()
                removals_after["front_wrap"] += int(front_wrap)
                removals_after["rear_wrap"] += int(rear_wrap)
                removals_after["write_wrap"] += int(write_wrap)
                removals_after["wrap"] += int(front_wrap or rear_wrap)
                front_wrap |= state.front == capacity - 1
                state = state.dequeue()
            elif action.save_as:
                raise ValueError("Cannot save the result of a rejected dequeue")

    fifo = [state.array[(state.front + i) % capacity] for i in range(state.size)]
    target = proposal.target
    answer: TraceAnswer
    if target == "state":
        answer = QueueState(front=state.front, size=state.size, array=list(state.array))
        question = (
            "What is the resulting queue state "
            "(front, size and stored array in index order)?"
        )
    elif target == "front_index":
        answer = state.front
        question = "What is the final front index after these operations?"
    elif target == "rear_item":
        if not fifo:
            raise ValueError("The final queue must contain an item at the rear")
        answer = fifo[-1]
        question = "Which item is at the rear of the queue after these operations?"
    elif target == "next_removed":
        if not state.size:
            raise ValueError("The final queue must contain an item to dequeue next")
        answer = state.peek()
        question = "Which value would the next successful dequeue return?"
    elif target == "fifo":
        answer = fifo
        question = "What are the final queue contents in FIFO order?"
    else:
        answer = QueueOutcomes(
            rejected=rejected,
            removed=removed,
            front=state.front,
            next_write=(state.front + state.size) % capacity,
            fifo=fifo,
        )
        question = (
            "Which enqueue values are rejected, what values do the successful "
            "dequeues return in order, and what are the final front, next write "
            "index and queue contents in FIFO order?"
        )
    program = "\n".join(lines)
    stem = (
        f"A circular queue has capacity {capacity}. It starts with this array "
        f"in index order: {initial.array}\n"
        f"The initial front index is {initial.front} and size is {initial.size}.\n"
        "Indices start at 0; size counts occupied slots. Peek() reads the front "
        "item. The rear is the last occupied slot. Dequeue() returns the front "
        "item, advances front by one modulo the "
        "array length, and reduces size without clearing the cell. Enqueue() "
        "uses the next write index, (front + size) modulo the array length, "
        "then increases size. "
        "An enqueue on a full queue or a dequeue on an empty queue is rejected "
        "and leaves the queue unchanged.\n"
        f"{program}\n{question}"
    )
    return ComputedTrace(
        stem,
        answer,
        {
            "wrapped": int(front_wrap or rear_wrap),
            "front_wrapped": int(front_wrap),
            "rear_wrapped": int(rear_wrap),
            "write_wrapped": int(write_wrap),
            "reinserted": reinserted,
            "reinserted_at_rear": int(
                bool(fifo)
                and (state.front + state.size - 1) % capacity in reinserted_slots
            ),
            **{
                f"removals_after_{name}": count
                for name, count in removals_after.items()
            },
            "rejected_enqueues": len(rejected),
            **paths,
        },
    )


def _merge_trace(
    proposal: MergeProposal, inputs: dict[str, ParameterValue]
) -> ComputedTrace:
    target = proposal.target
    left = [(_integer(record.key, inputs), record.tag) for record in proposal.left]
    right = [(_integer(record.key, inputs), record.tag) for record in proposal.right]
    checkpoint = _integer(proposal.checkpoint, inputs)
    write_count = _integer(proposal.write_count, inputs)
    if checkpoint < 0 or not 1 <= write_count <= 8:
        raise ValueError(
            "The merge checkpoint must be nonnegative and the write count 1 to 8"
        )
    if any(
        [key for key, _ in run] != sorted(key for key, _ in run)
        for run in (left, right)
    ):
        raise ValueError("Both input runs must be sorted in ascending order by key")
    tags = [tag for _, tag in left + right]
    if len(tags) != len(set(tags)):
        raise ValueError("Merge record tags must uniquely identify records")
    writes = _merge(left, right)
    if target in {"checkpoint", "tie_rule"} and checkpoint >= len(writes):
        raise ValueError("The merge checkpoint must precede the final write")
    answer: TraceAnswer
    written = f"{checkpoint} {'record' if checkpoint == 1 else 'records'}"
    if target == "tag_order":
        answer = [write.record[1] for write in writes]
        question = "What is the complete order of tags written to the merged run?"
    elif target == "key_order":
        answer = [write.record[0] for write in writes]
        question = "What is the complete sequence of keys written to the merged run?"
    elif target == "checkpoint":
        remaining = writes[checkpoint:]
        if write_count > len(remaining):
            raise ValueError("The requested number of writes exceeds the remaining run")
        head = remaining[0]
        answer = MergeCheckpoint(
            left_head=head.left_head if head.left_head != "–" else None,
            right_head=head.right_head if head.right_head != "–" else None,
            next_writes=[write.record[1] for write in remaining[:write_count]],
        )
        question = (
            f"After writing {written}, what are the left and right head "
            f"tags, and what are the next {write_count} tags written in order? "
            "Use a dash for an exhausted run."
        )
    else:
        head = writes[checkpoint]
        keys = {tag: key for key, tag in left + right}
        if head.left_head not in keys or keys[head.left_head] != keys.get(
            head.right_head
        ):
            raise ValueError(
                "The tie-rule target requires equal keys at both current heads"
            )
        answer = MergeTie(written=head.record[1], advance="left")
        question = (
            f"After writing {written}, what tag is written at the next "
            "comparison, and which run advances?"
        )
    return ComputedTrace(
        "Merge these two ascending runs by key. The left run precedes the right "
        "run in the original input. Compare the first unused records, preserving "
        "original order among equal keys by taking from the left run on a tie. "
        "When a run is exhausted, append the other run's remaining records in order.\n"
        f"Left run (key, tag): {left}\nRight run (key, tag): {right}\n{question}",
        answer,
        {
            "cross_run_tie_keys": len(set(dict(left)) & set(dict(right))),
            "write_count": write_count,
            "checkpoint": checkpoint,
        },
    )


def compute_trace(
    proposal: TraceProposal, inputs: dict[str, ParameterValue]
) -> ComputedTrace:
    if isinstance(proposal, QueueProposal):
        return _queue(proposal, inputs)
    return _merge_trace(proposal, inputs)


def display_answer(value: TraceAnswer) -> str:
    if isinstance(value, QueueState):
        return f"front = {value.front}, size = {value.size}, array = {value.array}"
    if isinstance(value, QueueOutcomes):
        return (
            f"Rejected {value.rejected}, removed {value.removed}, front = "
            f"{value.front}, next write = {value.next_write}, FIFO = {value.fifo}"
        )
    if isinstance(value, MergeCheckpoint):
        return (
            f"Heads {value.left_head or '–'}, {value.right_head or '–'}. "
            f"Next {', '.join(value.next_writes)}"
        )
    if isinstance(value, MergeTie):
        return f"Write {value.written}, advance {value.advance}"
    if isinstance(value, list) and all(isinstance(tag, str) for tag in value) and value:
        return ", ".join(value)
    return str(value)
