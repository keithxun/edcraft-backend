"""Reviewed source passages included with an authoring request."""

import hashlib
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from edcraft_validator.artifact_contracts import SourceReference


class SourcePassage(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    document: str = Field(min_length=1, max_length=300)
    pages: list[int] = Field(min_length=1, max_length=300)
    text: str = Field(min_length=1, max_length=60_000)
    edited: bool = False

    @model_validator(mode="after")
    def validate_source(self) -> "SourcePassage":
        if not self.document.strip() or not self.text.strip():
            raise ValueError("Provide a document name and non-blank source text.")
        if any(not 1 <= page <= 300 for page in self.pages):
            raise ValueError("Use physical PDF page numbers from 1 to 300.")
        return self


class AuthoringMaterials(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    lecture: list[SourcePassage] = Field(min_length=1, max_length=750)
    exam: SourcePassage | None = None

    @model_validator(mode="after")
    def check_lengths(self) -> "AuthoringMaterials":
        if sum(len(p.text) for p in self.lecture) > 60_000:
            raise ValueError("Limit lecture excerpts to 60,000 characters in total.")
        if self.exam and len(self.exam.text) > 24_000:
            raise ValueError("Limit the exam excerpt to 24,000 characters.")
        return self

    def references(self) -> list[SourceReference]:
        def reference(
            role: Literal["lecture", "exam"], passage: SourcePassage
        ) -> SourceReference:
            return SourceReference(
                role=role,
                document=passage.document,
                pages=passage.pages,
                teacher_reported_edit=passage.edited,
                text_sha256=hashlib.sha256(passage.text.encode("utf-8")).hexdigest(),
            )

        refs = [reference("lecture", passage) for passage in self.lecture]
        if self.exam:
            refs.append(reference("exam", self.exam))
        return refs
