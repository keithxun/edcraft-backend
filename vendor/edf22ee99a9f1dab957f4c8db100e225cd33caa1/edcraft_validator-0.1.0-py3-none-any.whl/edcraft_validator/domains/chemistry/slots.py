"""Positional species slots such as ``reactant:2`` and ``product:1``.

A family fixes how many reactants and products each reaction has, so a slot
names the same position in every reaction of a template. Every module parses
slots through :func:`parse_slot` so they all apply one rule.
"""

from __future__ import annotations

import re
from typing import Literal

ASKED = "asked"
SLOT_PATTERN = r"^(reactant|product):[1-9]$"

Side = Literal["reactant", "product"]
_SLOT = re.compile(SLOT_PATTERN)


def parse_slot(slot: str) -> tuple[Side, int]:
    """Return the side and the one-based position of a slot."""
    if not _SLOT.fullmatch(slot):
        raise ValueError(f"invalid slot {slot!r}")
    side, _, position = slot.partition(":")
    return ("reactant" if side == "reactant" else "product"), int(position)


def slot_formula(slot: str, reactants: list[str], products: list[str]) -> str | None:
    """The formula a slot names, or ``None`` when the slot is out of range."""
    side, position = parse_slot(slot)
    formulas = reactants if side == "reactant" else products
    return formulas[position - 1] if position <= len(formulas) else None


def slot_index(slot: str, reactant_count: int) -> int:
    """The coefficient-vector index of a slot: reactants first, then products."""
    side, position = parse_slot(slot)
    return position - 1 if side == "reactant" else reactant_count + position - 1
