"""Property-checked balance and MCQ option checks for chemistry templates.

Both checks return plain dictionaries so the isolated worker and the MCP tools
can pass them across a JSON boundary without importing pydantic models. The
embedded catalogue snapshot is never trusted: the balance check compares it
with the live catalogue before sampling, and every key is recomputed from the
snapshot formulas with exact arithmetic.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from typing import Any

from edcraft_validator.domains.chemistry.balance import (
    BalanceError,
    balance_equation,
)
from edcraft_validator.domains.chemistry.calculation_requests import (
    paired_calculation_case,
)
from edcraft_validator.domains.chemistry.catalogue import (
    ReactionEntry,
    catalogue_sha256,
    load_catalogue,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    CatalogueSnapshot,
    ChemistryConceptItemSpec,
    ChemistryItemSpec,
    ChemistryTemplateSpec,
    ConceptCatalogueSnapshot,
    ReactionSnapshot,
)
from edcraft_validator.domains.chemistry.concept_catalogue import (
    CONCEPT_CATALOGUE_VERSIONS,
    concept_snapshot_digest,
    load_concepts,
)
from edcraft_validator.domains.chemistry.extensions import evaluate_extension
from edcraft_validator.domains.chemistry.formula import (
    FormulaError,
    canonical_formula,
)
from edcraft_validator.domains.chemistry.options import (
    OptionValue,
    duplicate_reason,
    evaluate_recipe,
    format_equation,
    option_key,
    prove_option,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

MAX_ROWS = 64
_DEFAULT_SETTINGS = PropertyCheckSettings()

Finding = dict[str, str]


def check_balance(
    spec: ChemistryTemplateSpec,
    settings: PropertyCheckSettings = _DEFAULT_SETTINGS,
) -> dict[str, Any]:
    """Check that every snapshot reaction still matches the catalogue and balances."""
    if isinstance(spec.catalogue, ConceptCatalogueSnapshot):
        return check_content(spec, settings)
    run = PropertyCheckRun(settings)
    reactions = spec.catalogue.reactions
    findings = [
        *_identity_findings(spec),
        *_family_findings(spec.catalogue),
        *_snapshot_findings(reactions),
    ]
    if findings:
        run.declared_domain_size = len(reactions)
        return _report(spec, run, findings, [])

    failure_rows: list[dict[str, Any]] = []

    def property_check(inputs: dict[str, Any], budget: PropertyCheckRun) -> Any:
        budget.reserve_execution()
        reaction = _reaction(spec, str(inputs["reaction"]))
        try:
            result = balance_equation(reaction.reactants, reaction.products)
        except (BalanceError, FormulaError) as error:
            raise ValidationFailure(
                f"reaction {reaction.id}: {error.message}",
                code=error.code,
                field="template.catalogue.reactions",
            ) from None

        row = {
            "reaction_id": reaction.id,
            "elements": list(result.elements),
            "matrix": [list(values) for values in result.matrix],
            "nullity": result.nullity,
            "coefficients": list(result.coefficients),
            "equation": format_equation(
                reaction.reactants, reaction.products, result.coefficients
            ),
        }
        failure_rows[:] = [row]
        return [row]

    return _run_check(
        spec,
        run,
        {"reaction": [reaction.id for reaction in reactions]},
        property_check,
        failure_rows,
    )


def check_options(
    spec: ChemistryTemplateSpec,
    settings: PropertyCheckSettings = _DEFAULT_SETTINGS,
) -> dict[str, Any]:
    """Check the key and every distractor recipe over the declared grid."""
    item = spec.item
    if not isinstance(item, ChemistryItemSpec):
        return _check_extension_options(spec, settings)
    run = PropertyCheckRun(settings)
    parameters = _parameters(item)
    failure_rows: list[dict[str, Any]] = []

    def property_check(inputs: dict[str, Any], budget: PropertyCheckRun) -> Any:
        budget.reserve_execution()
        reaction = _reaction(spec, str(inputs["reaction"]))
        asked_slot = str(inputs["species"]) if "species" in inputs else None
        try:
            rows, findings = _option_rows(item, reaction, asked_slot)
        except (BalanceError, FormulaError) as error:
            raise ValidationFailure(
                f"reaction {reaction.id}: {error.message}",
                code=error.code,
                field="template.catalogue.reactions",
            ) from None

        failure_rows[:] = rows
        if findings:
            raise ValidationFailure(
                findings[0]["message"],
                code=findings[0]["code"],
                field="template.item.distractors",
                context={"findings": findings},
            )
        return rows

    return _run_check(spec, run, parameters, property_check, failure_rows)


def check_content(
    spec: ChemistryTemplateSpec, settings: PropertyCheckSettings = _DEFAULT_SETTINGS
) -> dict[str, Any]:
    """Authenticate the embedded H2 context and options against the vetted catalogue."""
    snapshot = spec.catalogue
    if not isinstance(snapshot, ConceptCatalogueSnapshot):
        return check_balance(spec, settings)
    version = snapshot.catalogue_version
    recognised = version in CONCEPT_CATALOGUE_VERSIONS
    catalogue = load_concepts(version)[0] if recognised else {}
    run = PropertyCheckRun(settings)
    first = snapshot.contexts[0]
    if (
        not recognised
        or snapshot.catalogue_sha256
        != concept_snapshot_digest(version, snapshot.contexts)
        or snapshot.family.title != first.topic_title
        or snapshot.family.description != f"H2 Chemistry 9476 topic {first.topic}."
        or any(catalogue.get(context.id) != context for context in snapshot.contexts)
    ):
        run.declared_domain_size = len(snapshot.contexts)
        return _report(
            spec,
            run,
            [
                _finding(
                    "CHEM_CONCEPT_MISMATCH",
                    "A concept snapshot does not match the curated H2 catalogue",
                )
            ],
            [],
        )

    contexts = {context.id: context for context in snapshot.contexts}

    def check(inputs: dict[str, Any], budget: PropertyCheckRun) -> list[dict[str, Any]]:
        budget.reserve_execution()
        context = contexts[inputs["context"]]
        return [
            {
                "context_id": context.id,
                "topic": context.topic,
                "question": context.question,
            }
        ]

    return _run_check(spec, run, {"context": list(contexts)}, check, [])


def _check_extension_options(
    spec: ChemistryTemplateSpec, settings: PropertyCheckSettings
) -> dict[str, Any]:
    run = PropertyCheckRun(settings)
    failure_rows: list[dict[str, Any]] = []
    parameters: dict[str, Any] = {
        axis.name: axis.values for axis in spec.item.parameters
    }
    if (
        isinstance(spec.item, ChemistryConceptItemSpec)
        and any(paired_calculation_case(case) for case in parameters["context"])
        and not {1, 2} <= {recipe.index for recipe in spec.item.distractors}
    ):
        run.declared_domain_size = len(parameters["context"])
        return _report(
            spec,
            run,
            [
                _finding(
                    "CHEM_PAIRED_CONTRAST_MISSING",
                    "Keep both alternatives that differ from the key in one result.",
                )
            ],
            [],
        )

    def check(inputs: dict[str, Any], budget: PropertyCheckRun) -> list[dict[str, Any]]:
        budget.reserve_execution()
        result = evaluate_extension(spec, inputs)
        verdicts = ("key", *result.verdicts())
        recipes = (spec.item.answer_recipe, *spec.item.distractors)
        values = (result.key, *result.options)
        rows = [
            {
                "reaction_id": result.context_id,
                "inputs": inputs,
                "option": index,
                "recipe": recipe.model_dump(mode="json"),
                "rendered": value.display if value else None,
                "verdict": verdict,
                "reason": {},
            }
            for index, (recipe, value, verdict) in enumerate(
                zip(recipes, values, verdicts, strict=True)
            )
        ]
        failure_rows[:] = rows
        findings = [
            finding
            for index, verdict in enumerate(verdicts)
            if (finding := _option_finding(result.context_id, index, verdict))
            is not None
        ]
        if findings:
            raise ValidationFailure(
                findings[0]["message"],
                code=findings[0]["code"],
                field="template.item.distractors",
                context={"findings": findings, "inputs": inputs},
            )
        return rows

    return _run_check(spec, run, parameters, check, failure_rows)


def _run_check(
    spec: ChemistryTemplateSpec,
    run: PropertyCheckRun,
    parameters: dict[str, Any],
    property_check: Callable[[dict[str, Any], PropertyCheckRun], Any],
    failure_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    """Run the grid, turning any property failure into a failed report."""
    try:
        reports = run.check(
            parameters,
            boundary=[],
            property_check=property_check,
            cover_small_domain=True,
        )
    except ValidationFailure as failure:
        return _failed_report(spec, run, failure, failure_rows)

    rows = [row for report in reports for row in report]
    return _report(spec, run, [], rows)


def _parameters(item: ChemistryItemSpec) -> dict[str, list[str]]:
    """Return the grid axes in declaration order."""
    parameters: dict[str, list[str]] = {}
    for parameter in item.parameters:
        parameters[parameter.name] = list(parameter.values)
    return parameters


def _reaction(spec: ChemistryTemplateSpec, reaction_id: str) -> ReactionSnapshot:
    assert isinstance(spec.catalogue, CatalogueSnapshot)
    for reaction in spec.catalogue.reactions:
        if reaction.id == reaction_id:
            return reaction
    raise ValidationFailure(
        f"reaction {reaction_id} is missing from the embedded catalogue snapshot",
        code="CHEM_CATALOGUE_UNKNOWN_REACTION",
        field="template.catalogue.reactions",
    )


def _option_rows(
    item: ChemistryItemSpec,
    reaction: ReactionSnapshot,
    asked_slot: str | None,
) -> tuple[list[dict[str, Any]], list[Finding]]:
    """Evaluate the key and every distractor for one reaction and asked slot."""
    key = balance_equation(reaction.reactants, reaction.products).coefficients
    key_option = evaluate_recipe(item.answer_recipe, reaction, key, asked_slot)
    options: list[tuple[int, Any, OptionValue]] = [(0, item.answer_recipe, key_option)]
    for index, recipe in enumerate(item.distractors, start=1):
        options.append((index, recipe, prove_option(recipe, reaction, key, asked_slot)))

    duplicates = _duplicate_indices(options)
    rows: list[dict[str, Any]] = []
    findings: list[Finding] = []
    for index, recipe, option in options:
        verdict = "duplicate" if index in duplicates else option.verdict
        reason = duplicate_reason() if index in duplicates else dict(option.reason)
        rows.append(
            {
                "reaction_id": reaction.id,
                "asked_slot": asked_slot,
                "option": index,
                "recipe": recipe.model_dump(mode="json"),
                "misconception": getattr(recipe, "misconception", None),
                "rendered": _render(option, reaction),
                "verdict": verdict,
                "reason": reason,
            }
        )
        finding = _option_finding(reaction.id, index, verdict)
        if finding is not None:
            findings.append(finding)
    return rows, findings


def _duplicate_indices(
    options: list[tuple[int, Any, OptionValue]],
) -> set[int]:
    """Return the distractor numbers that share a canonical key with another."""
    groups: dict[Any, list[int]] = defaultdict(list)
    for index, _, option in options:
        if index == 0 or option.verdict not in {"wrong", "correct"}:
            continue
        identity = option_key(option)
        if identity is not None:
            groups[identity].append(index)
    return {
        index for indices in groups.values() if len(indices) > 1 for index in indices
    }


def _option_finding(reaction_id: str, index: int, verdict: str) -> Finding | None:
    """Build the failing finding for one option verdict, if it fails."""
    if index == 0:
        return None
    if verdict == "correct":
        return _finding(
            "CHEM_DISTRACTOR_CORRECT",
            f"reaction {reaction_id} option {index}: the distractor is correct",
        )
    if verdict == "duplicate":
        return _finding(
            "CHEM_DISTRACTOR_DUPLICATE",
            f"reaction {reaction_id} option {index}: another option has the same value",
        )
    if verdict == "unusable":
        return _finding(
            "CHEM_DISTRACTOR_UNUSABLE",
            f"reaction {reaction_id} option {index}: the distractor is not a "
            "usable option",
        )
    return None


def _render(option: OptionValue, reaction: ReactionSnapshot) -> str:
    """Render one option for the report, tolerating unusable options."""
    if option.value is not None:
        return str(option.value)
    if option.coefficients is not None:
        return format_equation(
            option.reactants or tuple(reaction.reactants),
            option.products or tuple(reaction.products),
            option.coefficients,
        )
    size = len(option.reactants) + len(option.products)
    return format_equation(
        option.reactants or tuple(reaction.reactants),
        option.products or tuple(reaction.products),
        [1] * size,
    )


def _identity_findings(spec: ChemistryTemplateSpec) -> list[Finding]:
    """The claimed catalogue identity must be the catalogue being checked against."""
    catalogue = load_catalogue()
    snapshot = spec.catalogue
    if (
        snapshot.catalogue_version == catalogue.catalogue_version
        and snapshot.catalogue_sha256 == catalogue_sha256()
    ):
        return []
    return [
        _finding(
            "CHEM_CATALOGUE_MISMATCH",
            "the snapshot names catalogue "
            f"{snapshot.catalogue_version} ({snapshot.catalogue_sha256[:12]}), "
            f"but the current catalogue is {catalogue.catalogue_version} "
            f"({catalogue_sha256()[:12]})",
        )
    ]


def _family_findings(snapshot: CatalogueSnapshot) -> list[Finding]:
    """Compare the embedded family text with the live catalogue entry.

    The family description is the stem's context sentence, so a snapshot that
    rewrites it would put model-edited prose in front of a learner.
    """
    catalogue = load_catalogue()
    try:
        family = catalogue.family(snapshot.family.id)
    except KeyError:
        return [
            _finding(
                "CHEM_FAMILY_MISMATCH",
                f"family {snapshot.family.id} is not in the catalogue",
            )
        ]
    if (
        family.title == snapshot.family.title
        and family.description == snapshot.family.description
    ):
        return []
    return [
        _finding(
            "CHEM_FAMILY_MISMATCH",
            f"family {snapshot.family.id} does not match the catalogue title "
            "and description",
        )
    ]


def _snapshot_findings(reactions: list[ReactionSnapshot]) -> list[Finding]:
    """Compare each snapshot reaction with the live catalogue entry."""
    catalogue = load_catalogue()
    findings: list[Finding] = []
    for reaction in reactions:
        try:
            entry = catalogue.reaction(reaction.id)
        except KeyError:
            findings.append(
                _finding(
                    "CHEM_CATALOGUE_UNKNOWN_REACTION",
                    f"reaction {reaction.id} is not in the catalogue",
                )
            )
            continue
        try:
            differs = _snapshot_differs(reaction, entry)
        except FormulaError as error:
            findings.append(
                _finding(error.code, f"reaction {reaction.id}: {error.message}")
            )
            continue
        if differs:
            findings.append(
                _finding(
                    "CHEM_SKELETON_MISMATCH",
                    f"reaction {reaction.id} does not match the catalogue skeleton",
                )
            )
    return findings


def _snapshot_differs(snapshot: ReactionSnapshot, entry: ReactionEntry) -> bool:
    """Whether a snapshot's skeleton, family or variants differ from the catalogue."""
    if snapshot.family != entry.family:
        return True
    if _canonical(snapshot.reactants) != _canonical(entry.reactants):
        return True
    if _canonical(snapshot.products) != _canonical(entry.products):
        return True
    return _variants(snapshot) != _variants(entry)


def _canonical(formulas: list[str]) -> tuple[str, ...]:
    return tuple(canonical_formula(formula) for formula in formulas)


def _variants(
    reaction: ReactionSnapshot | ReactionEntry,
) -> dict[str, tuple[str, str]]:
    return {
        name: (variant.slot, canonical_formula(variant.formula))
        for name, variant in reaction.variants.items()
    }


def _finding(code: str, message: str) -> Finding:
    return {"code": code, "message": message}


def _report(
    spec: ChemistryTemplateSpec,
    run: PropertyCheckRun,
    findings: list[Finding],
    rows: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "status": "failed" if findings else "passed",
        "findings": findings,
        "rows": rows[:MAX_ROWS],
        "rows_truncated": len(rows) > MAX_ROWS,
        **run.details(),
        "catalogue_version": spec.catalogue.catalogue_version,
        "catalogue_sha256": spec.catalogue.catalogue_sha256,
    }


def _failed_report(
    spec: ChemistryTemplateSpec,
    run: PropertyCheckRun,
    failure: ValidationFailure,
    rows: list[dict[str, Any]],
) -> dict[str, Any]:
    """Turn a property failure into a failed report that keeps coverage details."""
    findings: list[Finding] = []
    raw_findings = failure.context.get("findings")
    if isinstance(raw_findings, list):
        findings = [item for item in raw_findings if isinstance(item, dict)]
    if not findings:
        findings = [{"code": failure.code, "message": str(failure)}]
    return _report(spec, run, findings, rows)


__all__ = ["MAX_ROWS", "check_balance", "check_content", "check_options"]
