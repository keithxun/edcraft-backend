"""Strict parsing of school-chemistry formulas.

The grammar accepts element symbols, integer subscripts, nested groups and
hydrate parts. Charges, isotopes, state symbols and electrons are rejected so a
formula always denotes a neutral species with an exact element count.
"""

from __future__ import annotations

from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_FORMULA_LENGTH,
    MAX_GROUP_DEPTH,
    MAX_SUBSCRIPT,
)
from edcraft_validator.domains.chemistry.elements import ELEMENT_SYMBOLS

_DOTS = frozenset({"·", ".", "*"})
_STATE_SUFFIXES = ("(aq)", "(s)", "(l)", "(g)")
_CHARGE_CHARACTERS = frozenset({"+", "-", "^", "⁺", "⁻"})


class FormulaError(ValueError):
    """A formula outside the strict school-chemistry grammar."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def parse_formula(text: str) -> dict[str, int]:
    """Return the element counts of ``text``, sorted by element symbol."""
    _reject_non_formula_text(text)
    return _FormulaParser(text).parse()


def canonical_formula(text: str) -> str:
    """Return ``text`` with every hydrate dot normalised to ``·``."""
    parse_formula(text)
    return text.replace(".", "·").replace("*", "·")


def _reject_non_formula_text(text: str) -> None:
    """Reject text that cannot be a formula before grammar parsing starts."""
    if not text or any(character.isspace() for character in text):
        raise FormulaError(
            "CHEM_FORMULA_EMPTY",
            "formula must not be empty or contain whitespace",
        )
    if len(text) > MAX_FORMULA_LENGTH:
        raise FormulaError(
            "CHEM_FORMULA_TOO_LONG",
            f"formula must be at most {MAX_FORMULA_LENGTH} characters",
        )
    if text in {"e", "e-"}:
        raise FormulaError(
            "CHEM_FORMULA_ELECTRON",
            "a bare electron is not a chemical formula",
        )
    if text.endswith(_STATE_SUFFIXES):
        raise FormulaError(
            "CHEM_FORMULA_STATE_SYMBOL",
            "formula must not end with a state symbol",
        )
    if any(character in _CHARGE_CHARACTERS for character in text):
        raise FormulaError(
            "CHEM_FORMULA_CHARGE",
            "formula must not carry a charge",
        )
    if _looks_like_isotope(text):
        raise FormulaError(
            "CHEM_FORMULA_ISOTOPE",
            "formula must not start with a number: a leading mass number names "
            "an isotope, and a coefficient belongs outside the formula",
        )


def _looks_like_isotope(text: str) -> bool:
    if text[0].isdigit():
        return True
    if len(text) >= 2 and text[0] == "[" and text[1].isdigit():
        return True
    return text[0] in {"D", "T"} and (len(text) == 1 or not text[1].islower())


class _FormulaParser:
    """One single-use recursive-descent parser over a validated string."""

    def __init__(self, text: str) -> None:
        self._text = text
        self._position = 0

    def parse(self) -> dict[str, int]:
        counts = self._parse_part(depth=0)
        if not counts:
            self._fail(
                "CHEM_FORMULA_SYNTAX",
                "formula must start with an element or a group",
            )
        while self._peek() in _DOTS:
            self._position += 1
            multiplier = self._parse_count()
            part = self._parse_part(depth=0)
            if not part:
                self._fail(
                    "CHEM_FORMULA_SYNTAX",
                    "hydrate dot must be followed by a formula part",
                )
            counts = _merge(counts, _scaled(part, multiplier))
        if self._position != len(self._text):
            self._fail(
                "CHEM_FORMULA_SYNTAX",
                f"unexpected character {self._text[self._position]!r}",
            )
        return dict(sorted(counts.items()))

    def _parse_part(self, depth: int) -> dict[str, int]:
        counts: dict[str, int] = {}
        while True:
            character = self._peek()
            if character is None or character in _DOTS or character == ")":
                return counts
            if character == "(":
                counts = _merge(counts, self._parse_group(depth))
            elif character.isupper():
                symbol = self._parse_element()
                counts[symbol] = counts.get(symbol, 0) + self._parse_count()
            else:
                self._fail(
                    "CHEM_FORMULA_SYNTAX",
                    f"unexpected character {character!r}",
                )

    def _parse_group(self, depth: int) -> dict[str, int]:
        if depth + 1 > MAX_GROUP_DEPTH:
            self._fail(
                "CHEM_FORMULA_DEPTH",
                f"parentheses may be nested at most {MAX_GROUP_DEPTH} deep",
            )
        self._position += 1
        if self._peek() == ")":
            self._fail(
                "CHEM_FORMULA_SYNTAX",
                "a parenthesised group must not be empty",
            )
        inner = self._parse_part(depth + 1)
        if self._peek() != ")":
            self._fail("CHEM_FORMULA_SYNTAX", "unbalanced parentheses")
        self._position += 1
        return _scaled(inner, self._parse_count())

    def _parse_element(self) -> str:
        start = self._position
        self._position += 1
        next_character = self._peek()
        if next_character is not None and next_character.islower():
            self._position += 1
        symbol = self._text[start : self._position]
        if symbol in {"D", "T"}:
            self._fail(
                "CHEM_FORMULA_ISOTOPE",
                f"{symbol!r} names a hydrogen isotope, not an element",
            )
        if symbol not in ELEMENT_SYMBOLS:
            self._fail(
                "CHEM_FORMULA_UNKNOWN_ELEMENT",
                f"unknown element symbol {symbol!r}",
            )
        return symbol

    def _parse_count(self) -> int:
        start = self._position
        while (character := self._peek()) is not None and character in "0123456789":
            self._position += 1
        if start == self._position:
            return 1
        digits = self._text[start : self._position]
        if digits[0] == "0" or int(digits) > MAX_SUBSCRIPT:
            self._fail(
                "CHEM_FORMULA_COUNT_LIMIT",
                f"subscripts must be between 1 and {MAX_SUBSCRIPT} without "
                "leading zeros",
            )
        return int(digits)

    def _peek(self) -> str | None:
        if self._position >= len(self._text):
            return None
        return self._text[self._position]

    def _fail(self, code: str, message: str) -> None:
        raise FormulaError(code, message)


def _merge(left: dict[str, int], right: dict[str, int]) -> dict[str, int]:
    merged = dict(left)
    for element, count in right.items():
        merged[element] = merged.get(element, 0) + count
    return merged


def _scaled(counts: dict[str, int], multiplier: int) -> dict[str, int]:
    return {element: count * multiplier for element, count in counts.items()}
