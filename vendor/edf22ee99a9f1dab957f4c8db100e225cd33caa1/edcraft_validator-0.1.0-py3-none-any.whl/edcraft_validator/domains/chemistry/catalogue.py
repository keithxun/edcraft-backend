"""Loading, validation and hashing of the curated reaction catalogue."""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from importlib import resources
from typing import Any, cast

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from edcraft_validator.domains.chemistry.balance import balance_equation
from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_FORMULA_LENGTH,
    MAX_REACTIONS,
    MAX_SPECIES,
)
from edcraft_validator.domains.chemistry.formula import parse_formula
from edcraft_validator.domains.chemistry.slots import SLOT_PATTERN, slot_formula

CATALOGUE_VERSION = "chem-catalogue-2026.11-pilot.2"
_CATALOGUE_PACKAGE = "edcraft_validator.domains.chemistry"
_CATALOGUE_FILE = "reactions.json"
_ID_PATTERN = r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$"


class SpeciesVariant(BaseModel):
    """One replacement formula used by the ``swap_species`` distractor."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    slot: str = Field(pattern=SLOT_PATTERN)
    formula: str = Field(min_length=1, max_length=MAX_FORMULA_LENGTH)


class FamilyEntry(BaseModel):
    """A reaction family with its expected skeleton size."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    id: str = Field(pattern=_ID_PATTERN)
    title: str = Field(min_length=1)
    reactant_count: int = Field(ge=1, le=MAX_SPECIES)
    product_count: int = Field(ge=1, le=MAX_SPECIES)
    description: str = Field(min_length=1)

    @field_validator("description")
    @classmethod
    def require_curated_sentence(cls, description: str) -> str:
        """The description becomes learner-facing prose, so keep it plain.

        It must be one sentence ending in a full stop and must not contain a
        digit. The text is curated by hand, but this catches a typo before it
        reaches every stem in the family.
        """
        if any(character.isdigit() for character in description):
            raise ValueError("family description must not contain digits")
        if not description.endswith(".") or any(
            character in description[:-1] for character in ".!?"
        ):
            raise ValueError("family description must be a single sentence")
        return description


class ReactionEntry(BaseModel):
    """One curated reaction skeleton and its optional variants."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    id: str = Field(pattern=_ID_PATTERN)
    family: str = Field(pattern=_ID_PATTERN)
    reactants: list[str] = Field(min_length=1, max_length=MAX_SPECIES)
    products: list[str] = Field(min_length=1, max_length=MAX_SPECIES)
    name: str = Field(min_length=1)
    source: str = Field(min_length=1)
    variants: dict[str, SpeciesVariant] = Field(default_factory=dict)

    @model_validator(mode="after")
    def require_usable_variants(self) -> ReactionEntry:
        require_distinct_variants(self.reactants, self.products, self.variants)
        return self


def require_distinct_variants(
    reactants: list[str],
    products: list[str],
    variants: dict[str, SpeciesVariant],
) -> None:
    """Each variant must name a real slot and change the species' composition.

    A different spelling of the same composition, such as ``(O2)`` for ``O2``,
    would make a "wrong species" option that is actually correct.
    """
    for name, variant in variants.items():
        original = slot_formula(variant.slot, reactants, products)
        if original is None:
            raise ValueError(f"variant {name!r} slot {variant.slot!r} is out of range")
        if parse_formula(variant.formula) == parse_formula(original):
            raise ValueError(
                f"variant {name!r} must change the composition of {original!r}"
            )


class Catalogue(BaseModel):
    """The validated, immutable reaction catalogue."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    catalogue_version: str = Field(min_length=1)
    families: list[FamilyEntry] = Field(min_length=1)
    reactions: list[ReactionEntry] = Field(min_length=1)

    @model_validator(mode="after")
    def require_consistent_families(self) -> Catalogue:
        family_ids = [family.id for family in self.families]
        if len(family_ids) != len(set(family_ids)):
            raise ValueError("family ids must be unique")
        reaction_ids = [reaction.id for reaction in self.reactions]
        if len(reaction_ids) != len(set(reaction_ids)):
            raise ValueError("reaction ids must be unique")

        members: dict[str, list[ReactionEntry]] = {
            family_id: [] for family_id in family_ids
        }
        for reaction in self.reactions:
            if reaction.family not in members:
                raise ValueError(
                    f"reaction {reaction.id!r} names unknown family {reaction.family!r}"
                )
            members[reaction.family].append(reaction)

        for family in self.families:
            entries = members[family.id]
            if not 1 <= len(entries) <= MAX_REACTIONS:
                raise ValueError(
                    f"family {family.id!r} must hold between 1 and "
                    f"{MAX_REACTIONS} reactions"
                )
            for reaction in entries:
                if len(reaction.reactants) != family.reactant_count:
                    raise ValueError(
                        f"reaction {reaction.id!r} needs {family.reactant_count} "
                        "reactants"
                    )
                if len(reaction.products) != family.product_count:
                    raise ValueError(
                        f"reaction {reaction.id!r} needs {family.product_count} "
                        "products"
                    )
                for formula in [*reaction.reactants, *reaction.products]:
                    parse_formula(formula)
                try:
                    balance_equation(reaction.reactants, reaction.products)
                except ValueError as error:
                    raise ValueError(
                        f"reaction {reaction.id!r} does not balance uniquely: {error}"
                    ) from error
        return self

    def family(self, family_id: str) -> FamilyEntry:
        """Return the family with ``family_id`` or raise ``KeyError``."""
        for family in self.families:
            if family.id == family_id:
                return family
        raise KeyError(f"unknown family {family_id!r}")

    def reaction(self, reaction_id: str) -> ReactionEntry:
        """Return the reaction with ``reaction_id`` or raise ``KeyError``."""
        for reaction in self.reactions:
            if reaction.id == reaction_id:
                return reaction
        raise KeyError(f"unknown reaction {reaction_id!r}")


@lru_cache(maxsize=1)
def load_catalogue() -> Catalogue:
    """Load and validate the bundled catalogue once per process."""
    return Catalogue.model_validate(_catalogue_payload())


@lru_cache(maxsize=1)
def catalogue_sha256() -> str:
    """Return the SHA-256 of the canonical catalogue JSON."""
    canonical = json.dumps(
        _catalogue_payload(),
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


@lru_cache(maxsize=1)
def _catalogue_payload() -> dict[str, Any]:
    path = resources.files(_CATALOGUE_PACKAGE).joinpath(_CATALOGUE_FILE)
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))
