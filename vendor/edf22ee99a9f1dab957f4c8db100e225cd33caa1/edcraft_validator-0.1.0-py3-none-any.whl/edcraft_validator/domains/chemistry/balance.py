"""Exact conservation-matrix balancing of chemical equations."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from math import gcd, lcm

from sympy import Matrix, Rational

from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_COEFFICIENT,
    MAX_ELEMENTS,
    MAX_SPECIES,
)
from edcraft_validator.domains.chemistry.formula import parse_formula


@dataclass(frozen=True)
class BalanceResult:
    """The element conservation matrix and its unique positive balance."""

    elements: tuple[str, ...]
    matrix: tuple[tuple[int, ...], ...]
    nullity: int
    coefficients: tuple[int, ...]


class BalanceError(ValueError):
    """An equation that has no unique, small, positive whole-number balance."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def balance_equation(
    reactants: Sequence[str], products: Sequence[str]
) -> BalanceResult:
    """Return the unique smallest positive whole-number balance for an equation."""
    if not reactants or not products:
        raise BalanceError("CHEM_EMPTY_SIDE", "both sides need at least one species")

    species = [*reactants, *products]
    if len(species) > MAX_SPECIES:
        raise BalanceError(
            "CHEM_SPECIES_LIMIT",
            f"an equation may contain at most {MAX_SPECIES} species",
        )

    element_counts = [parse_formula(formula) for formula in species]
    elements, matrix = _conservation_matrix(element_counts, len(reactants))
    if len(elements) > MAX_ELEMENTS:
        raise BalanceError(
            "CHEM_ELEMENT_LIMIT",
            f"an equation may contain at most {MAX_ELEMENTS} distinct elements",
        )
    if len({_signature(counts) for counts in element_counts}) != len(element_counts):
        raise BalanceError(
            "CHEM_DUPLICATE_SPECIES",
            "two species have the same element counts",
        )

    nullspace = Matrix(matrix).nullspace()
    nullity = len(nullspace)
    if nullity == 0:
        raise BalanceError("CHEM_NO_BALANCE", "the equation has no balance")
    if nullity > 1:
        raise BalanceError(
            "CHEM_AMBIGUOUS_BALANCE",
            "the equation has more than one independent balance",
        )

    coefficients = _primitive_integer_vector(
        [nullspace[0][index] for index in range(len(species))]
    )
    if any(value == 0 for value in coefficients) or _has_mixed_signs(coefficients):
        raise BalanceError(
            "CHEM_NO_POSITIVE_BALANCE",
            "the only balance uses a zero or negative coefficient",
        )
    if any(value > MAX_COEFFICIENT for value in coefficients):
        raise BalanceError(
            "CHEM_COEFFICIENT_LIMIT",
            f"every coefficient must be at most {MAX_COEFFICIENT}",
        )

    return BalanceResult(
        elements=elements,
        matrix=matrix,
        nullity=nullity,
        coefficients=tuple(coefficients),
    )


def element_totals(
    formulas: Sequence[str], coefficients: Sequence[int]
) -> dict[str, int]:
    """Return the total atom count for one side of an equation."""
    if len(formulas) != len(coefficients):
        raise ValueError("every formula needs exactly one coefficient")

    totals: dict[str, int] = {}
    for formula, coefficient in zip(formulas, coefficients, strict=True):
        for element, count in parse_formula(formula).items():
            totals[element] = totals.get(element, 0) + count * coefficient
    return dict(sorted(totals.items()))


def first_unbalanced_element(
    reactants: Sequence[str],
    products: Sequence[str],
    coefficients: Sequence[int],
) -> tuple[str, int, int] | None:
    """Return ``(element, left, right)`` for the first unequal element."""
    if len(coefficients) != len(reactants) + len(products):
        raise ValueError("every species needs exactly one coefficient")

    reactant_count = len(reactants)
    left = element_totals(reactants, coefficients[:reactant_count])
    right = element_totals(products, coefficients[reactant_count:])
    for element in sorted(set(left) | set(right)):
        if left.get(element, 0) != right.get(element, 0):
            return element, left.get(element, 0), right.get(element, 0)
    return None


def _conservation_matrix(
    element_counts: Sequence[dict[str, int]], reactant_count: int
) -> tuple[tuple[str, ...], tuple[tuple[int, ...], ...]]:
    elements = tuple(
        sorted({element for counts in element_counts for element in counts})
    )
    rows = []
    for element in elements:
        row = []
        for index, counts in enumerate(element_counts):
            count = counts.get(element, 0)
            row.append(count if index < reactant_count else -count)
        rows.append(tuple(row))
    return elements, tuple(rows)


def _signature(counts: dict[str, int]) -> tuple[tuple[str, int], ...]:
    return tuple(sorted(counts.items()))


def _primitive_integer_vector(vector: Sequence[object]) -> list[int]:
    rationals = [Rational(value) for value in vector]
    denominator = 1
    for value in rationals:
        denominator = lcm(denominator, value.q)
    integers = [int(value * denominator) for value in rationals]

    divisor = 0
    for value in integers:
        divisor = gcd(divisor, abs(value))
    if divisor > 1:
        integers = [value // divisor for value in integers]
    if all(value <= 0 for value in integers) and any(value < 0 for value in integers):
        integers = [-value for value in integers]
    return integers


def _has_mixed_signs(values: Sequence[int]) -> bool:
    return any(value > 0 for value in values) and any(value < 0 for value in values)
