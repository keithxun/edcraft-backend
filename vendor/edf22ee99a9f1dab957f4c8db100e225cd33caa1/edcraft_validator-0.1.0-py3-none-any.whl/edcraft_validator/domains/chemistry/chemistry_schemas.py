"""Request, proposal, template and question schemas for chemistry."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.chemistry.catalogue import (
    ReactionEntry,
    SpeciesVariant,
    load_catalogue,
    require_distinct_variants,
)
from edcraft_validator.domains.chemistry.chemistry_types import (
    CHEMISTRY_CHECKING_MODE,
    CHEMISTRY_FORMAT_VERSION,
    CHEMISTRY_VALIDATOR_VERSION,
    MAX_DISTRACTORS,
    MAX_FORMULA_LENGTH,
    MAX_REACTIONS,
    MAX_SPECIES,
    Difficulty,
)
from edcraft_validator.domains.chemistry.concept_catalogue import (
    ConceptContext,
    resolve_proposal_family,
)
from edcraft_validator.domains.chemistry.slots import ASKED, SLOT_PATTERN, slot_formula
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES
from edcraft_validator.validation.property_summary import PropertyCheckSummary

ChemistryTemplateRequest = TemplateRequest

Slot = Annotated[str, Field(pattern=SLOT_PATTERN)]
Formula = Annotated[str, Field(min_length=1, max_length=MAX_FORMULA_LENGTH)]
_SHARED_HEX_PATTERN = r"^[0-9a-f]{64}$"

# Retired authoring fields. A proposal that still carries one is rejected with a
# clear message instead of a generic extra-field error.


class _Record(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class ReactionParameter(_Record):
    """The catalogue reactions a template expands over."""

    name: Literal["reaction"]
    values: list[str] = Field(min_length=1, max_length=MAX_REACTIONS)

    @field_validator("values")
    @classmethod
    def require_unique_values(cls, values: list[str]) -> list[str]:
        if len(values) != len(set(values)):
            raise ValueError("reaction parameter values must be unique")
        return values


class SpeciesParameter(_Record):
    """The asked slot of a coefficient-target item."""

    name: Literal["species"]
    values: list[Slot] = Field(min_length=1, max_length=MAX_SPECIES)

    @field_validator("values")
    @classmethod
    def require_unique_values(cls, values: list[str]) -> list[str]:
        if len(values) != len(set(values)):
            raise ValueError("species parameter values must be unique")
        return values


Parameter = Annotated[ReactionParameter | SpeciesParameter, Field(discriminator="name")]


class BalancedEquationTarget(_Record):
    kind: Literal["balanced_equation"]


class CoefficientTarget(_Record):
    kind: Literal["coefficient"]


ChemistryTarget = Annotated[
    BalancedEquationTarget | CoefficientTarget, Field(discriminator="kind")
]


class NormalisedCoefficientsRecipe(_Record):
    kind: Literal["normalised_coefficients"]


class _Distractor(_Record):
    reason: str | None = Field(default=None, max_length=200)


class PerturbCoefficient(_Distractor):
    kind: Literal["perturb_coefficient"]
    slot: Slot | Literal["asked"]
    delta: Literal[-2, -1, 1, 2]
    misconception: Literal["unbalanced_element"]

    @field_validator("delta", mode="before")
    @classmethod
    def reject_boolean_delta(cls, value: object) -> object:
        # Literal accepts True as 1, so JSON booleans are refused explicitly.
        if isinstance(value, bool):
            raise ValueError("delta must be an integer, not a boolean")
        return value


class ScaleBalanced(_Distractor):
    kind: Literal["scale_balanced"]
    factor: Literal[2, 3]
    misconception: Literal["non_reduced_coefficients"]


class SkeletonCoefficients(_Distractor):
    kind: Literal["skeleton_coefficients"]
    misconception: Literal["unbalanced_skeleton"]


class SwapCoefficients(_Distractor):
    kind: Literal["swap_coefficients"]
    slot_a: Slot | Literal["asked"]
    slot_b: Slot | Literal["asked"]
    misconception: Literal["misassigned_coefficients"]


class SwapSpecies(_Distractor):
    kind: Literal["swap_species"]
    variant: str = Field(min_length=1, max_length=64)
    misconception: Literal["wrong_species"]


DistractorRecipe = Annotated[
    PerturbCoefficient
    | ScaleBalanced
    | SkeletonCoefficients
    | SwapCoefficients
    | SwapSpecies,
    Field(discriminator="kind"),
]


class ChemistryItemSpec(_Record):
    """One model-authored chemistry item over a declared parameter grid."""

    schema_version: Literal["chem-balance/0.1"]
    family: str = Field(min_length=1)
    parameters: list[Parameter] = Field(min_length=1)
    target: ChemistryTarget
    answer_recipe: NormalisedCoefficientsRecipe
    distractors: list[DistractorRecipe] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )

    @model_validator(mode="before")
    @classmethod
    def reject_removed_authoring_fields(cls, value: object) -> object:
        if not isinstance(value, dict):
            return value
        if "lead_in" in value:
            raise ValueError(
                "lead_in is no longer authored. The application uses the family "
                "description as the context sentence"
            )
        return value

    @model_validator(mode="after")
    def require_consistent_chemistry(self) -> ChemistryItemSpec:
        reaction_parameters = [
            parameter
            for parameter in self.parameters
            if isinstance(parameter, ReactionParameter)
        ]
        species_parameters = [
            parameter
            for parameter in self.parameters
            if isinstance(parameter, SpeciesParameter)
        ]
        if len(reaction_parameters) != 1:
            raise ValueError("item must declare exactly one reaction parameter")

        coefficient_target = self.target.kind == "coefficient"
        if coefficient_target and len(species_parameters) != 1:
            raise ValueError(
                "coefficient target requires exactly one species parameter"
            )
        if not coefficient_target and species_parameters:
            raise ValueError("equation target must not declare a species parameter")

        for recipe in self.distractors:
            if isinstance(recipe, SwapCoefficients) and recipe.slot_a == recipe.slot_b:
                raise ValueError("swap_coefficients slots must differ")
            if isinstance(recipe, SwapSpecies) and coefficient_target:
                raise ValueError(
                    "swap_species distractors are only valid for the equation target"
                )
        slots = _named_slots(self)
        if not coefficient_target and ASKED in slots:
            raise ValueError("asked is only valid for the coefficient target")
        return self


class AmountParameter(_Record):
    name: Literal["reactant_1_mmol", "reactant_2_mmol"]
    values: list[Annotated[int, Field(ge=1, le=1000)]] = Field(
        min_length=1, max_length=32
    )

    @field_validator("values")
    @classmethod
    def require_unique_amounts(cls, values: list[int]) -> list[int]:
        if len(values) != len(set(values)):
            raise ValueError("amount parameter values must be unique")
        return values


class YieldTarget(_Record):
    kind: Literal["theoretical_yield"]
    product: Annotated[str, Field(pattern=r"^product:[1-8]$")]


class LimitingExtentRecipe(_Record):
    kind: Literal["limiting_extent"]


class YieldAlternative(_Distractor):
    kind: Literal["yield_alternative"]
    method: Literal[
        "first_extent",
        "second_extent",
        "larger_extent",
        "sum_extents",
        "mean_extent",
        "ignore_reactant_coefficients",
        "invert_product_coefficient",
        "multiply_by_1000",
        "divide_by_1000",
    ]


class ChemistryYieldItemSpec(_Record):
    schema_version: Literal["chem-yield/0.1"]
    family: str = Field(min_length=1)
    parameters: list[
        Annotated[ReactionParameter | AmountParameter, Field(discriminator="name")]
    ] = Field(min_length=3, max_length=3)
    target: YieldTarget
    answer_recipe: LimitingExtentRecipe
    distractors: list[YieldAlternative] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )

    @model_validator(mode="after")
    def require_amount_axes(self) -> ChemistryYieldItemSpec:
        if {axis.name for axis in self.parameters} != {
            "reaction",
            "reactant_1_mmol",
            "reactant_2_mmol",
        }:
            raise ValueError(
                "yield requires one reaction axis and one amount axis per reactant"
            )
        return self


class ConceptParameter(_Record):
    name: Literal["context"]
    values: list[str] = Field(min_length=1, max_length=16)

    @field_validator("values")
    @classmethod
    def require_unique_contexts(cls, values: list[str]) -> list[str]:
        if len(values) != len(set(values)):
            raise ValueError("concept context ids must be unique")
        return values


class ConceptTarget(_Record):
    kind: Literal["concept"]


class ConceptKeyRecipe(_Record):
    kind: Literal["concept_key"]


class ConceptAlternative(_Record):
    kind: Literal["concept_alternative"]
    index: int = Field(ge=1, le=6)


class ChemistryConceptItemSpec(_Record):
    schema_version: Literal["chem-concept/0.1"]
    family: str = Field(min_length=1)
    parameters: list[ConceptParameter] = Field(min_length=1, max_length=1)
    target: ConceptTarget
    answer_recipe: ConceptKeyRecipe
    distractors: list[ConceptAlternative] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


class ChemistryUnsupportedItem(_Record):
    schema_version: Literal["chem-unsupported/0.1"]
    reason: str = Field(min_length=1, max_length=300)


ReactionItemSpec = ChemistryItemSpec | ChemistryYieldItemSpec
AuthoredChemistryItem = Annotated[
    ReactionItemSpec | ChemistryConceptItemSpec, Field(discriminator="schema_version")
]
ChemistryProposalItem = Annotated[
    ReactionItemSpec | ChemistryConceptItemSpec | ChemistryUnsupportedItem,
    Field(discriminator="schema_version"),
]


def reaction_ids(item: ReactionItemSpec) -> list[str]:
    """The declared values of the item's reaction parameter."""
    return next(
        parameter.values
        for parameter in item.parameters
        if isinstance(parameter, ReactionParameter)
    )


def item_slots(item: ChemistryItemSpec) -> list[str]:
    """Every concrete slot the item names, excluding ``asked``."""
    return [slot for slot in _named_slots(item) if slot != ASKED]


def _named_slots(item: ChemistryItemSpec) -> list[str]:
    """Every slot the item names in its parameters and recipes, ``asked`` included."""
    slots = [
        slot
        for parameter in item.parameters
        if isinstance(parameter, SpeciesParameter)
        for slot in parameter.values
    ]
    for recipe in item.distractors:
        if isinstance(recipe, PerturbCoefficient):
            slots.append(recipe.slot)
        elif isinstance(recipe, SwapCoefficients):
            slots.extend((recipe.slot_a, recipe.slot_b))
    return slots


def require_reactions_fit_item(
    item: ReactionItemSpec,
    reactions: list[ReactionSnapshot] | list[ReactionEntry],
) -> None:
    """Check the item against the reactions it expands over.

    Proposals are checked against the live catalogue. Candidates and saved
    artifacts are checked against their embedded snapshot, so a later catalogue
    edit never stops a saved template from loading.
    """
    ids = [reaction.id for reaction in reactions]
    if ids != reaction_ids(item):
        raise ValueError(
            "catalogue reactions must match the reaction parameter values in order"
        )
    for reaction in reactions:
        if reaction.family != item.family:
            raise ValueError(
                f"reaction {reaction.id!r} belongs to family "
                f"{reaction.family!r}, not {item.family!r}"
            )
        if isinstance(item, ChemistryYieldItemSpec) and len(reaction.reactants) != 2:
            raise ValueError(
                f"reaction {reaction.id!r} must have exactly two reactants for yield"
            )
        slots = (
            [item.target.product]
            if isinstance(item, ChemistryYieldItemSpec)
            else item_slots(item)
        )
        for slot in slots:
            if slot_formula(slot, reaction.reactants, reaction.products) is None:
                raise ValueError(
                    f"slot {slot!r} is out of range for family {item.family!r}"
                )
        for recipe in item.distractors:
            if (
                isinstance(recipe, SwapSpecies)
                and recipe.variant not in reaction.variants
            ):
                raise ValueError(
                    f"variant {recipe.variant!r} is not declared by "
                    f"reaction {reaction.id!r}"
                )


def require_family_fits_item(
    item: AuthoredChemistryItem, family: FamilySnapshot
) -> None:
    """The snapshot's family must be the family the item declares.

    Proposals carry no snapshot family, so they resolve the family from the live
    catalogue instead. Candidates and saved artifacts use this check so a
    snapshot can never describe one family while expanding another.
    """
    if family.id != item.family:
        raise ValueError(
            f"catalogue family {family.id!r} does not match item family {item.family!r}"
        )


def _catalogue_reactions(item: ReactionItemSpec) -> list[ReactionEntry]:
    """Resolve the proposal's reaction ids in the live catalogue."""
    catalogue = load_catalogue()
    try:
        catalogue.family(item.family)
    except KeyError as error:
        raise ValueError(f"unknown family {item.family!r}") from error
    reactions = []
    for reaction_id in reaction_ids(item):
        try:
            reactions.append(catalogue.reaction(reaction_id))
        except KeyError as error:
            raise ValueError(f"unknown reaction {reaction_id!r}") from error
    return reactions


class ReactionSnapshot(_Record):
    """A catalogue reaction copied into a template or artifact.

    Sizes are limited at the boundary so an oversized snapshot is refused as
    invalid input instead of failing later in the isolated worker.
    """

    id: str = Field(min_length=1, max_length=64)
    family: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=120)
    reactants: list[Formula] = Field(min_length=1, max_length=MAX_SPECIES)
    products: list[Formula] = Field(min_length=1, max_length=MAX_SPECIES)
    source: str = Field(min_length=1, max_length=300)
    variants: dict[str, SpeciesVariant] = Field(default_factory=dict, max_length=8)

    @model_validator(mode="after")
    def require_usable_variants(self) -> ReactionSnapshot:
        require_distinct_variants(self.reactants, self.products, self.variants)
        return self


class FamilySnapshot(_Record):
    """The curated family text a checked template embeds.

    The application, not the model, owns this text: it is the stem's context
    sentence and the relevance projection's family label.
    """

    id: str = Field(min_length=1, max_length=64)
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(min_length=1, max_length=200)


class CatalogueSnapshot(_Record):
    """The validated formula data a checked template embeds."""

    catalogue_version: str = Field(min_length=1, max_length=64)
    catalogue_sha256: str = Field(pattern=_SHARED_HEX_PATTERN)
    family: FamilySnapshot
    reactions: list[ReactionSnapshot] = Field(min_length=1, max_length=MAX_REACTIONS)


class ConceptCatalogueSnapshot(_Record):
    catalogue_version: str = Field(min_length=1, max_length=64)
    catalogue_sha256: str = Field(pattern=_SHARED_HEX_PATTERN)
    family: FamilySnapshot
    contexts: list[ConceptContext] = Field(min_length=1, max_length=16)


def _require_snapshot(
    item: AuthoredChemistryItem, snapshot: CatalogueSnapshot | ConceptCatalogueSnapshot
) -> None:
    require_family_fits_item(item, snapshot.family)
    if isinstance(item, ChemistryConceptItemSpec):
        if (
            not isinstance(snapshot, ConceptCatalogueSnapshot)
            or [x.id for x in snapshot.contexts] != item.parameters[0].values
        ):
            raise ValueError(
                "snapshot contexts must match the concept parameter in order"
            )
        if any(context.family != item.family for context in snapshot.contexts):
            raise ValueError("snapshot contexts must belong to the declared topic")
    elif isinstance(snapshot, CatalogueSnapshot):
        require_reactions_fit_item(item, snapshot.reactions)
    else:
        raise ValueError("reaction item requires a reaction catalogue snapshot")


class ChemistryTemplateSpec(_Record):
    """What the chemistry validation tools check."""

    item: AuthoredChemistryItem
    catalogue: CatalogueSnapshot | ConceptCatalogueSnapshot

    @model_validator(mode="after")
    def require_snapshot_fits_item(self) -> ChemistryTemplateSpec:
        _require_snapshot(self.item, self.catalogue)
        return self


class ChemistryTemplateContent(_Record):
    """What the model proposes, checked against the live catalogue."""

    item: ChemistryProposalItem

    @model_validator(mode="after")
    def require_catalogue_reactions(self) -> ChemistryTemplateContent:
        if isinstance(self.item, ChemistryUnsupportedItem):
            return self
        if isinstance(self.item, ChemistryConceptItemSpec):
            family = resolve_proposal_family(
                self.item.family, self.item.parameters[0].values
            )
            if family != self.item.family:
                self.item = self.item.model_copy(update={"family": family})
        else:
            require_reactions_fit_item(self.item, _catalogue_reactions(self.item))
        return self


class ResolvedChemistryTemplateContent(ChemistryTemplateContent):
    """Proposal schema for a request already resolved to vetted contexts."""

    item: Annotated[
        ChemistryConceptItemSpec | ChemistryUnsupportedItem,
        Field(discriminator="schema_version"),
    ]


class ChemistryTemplateCandidate(_Record):
    """Provider-neutral reusable chemistry template contract.

    It is checked against its embedded snapshot only, so saved templates do not
    depend on the current catalogue.
    """

    item: AuthoredChemistryItem
    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]*$")
    difficulty: Difficulty
    question_type: Literal["mcq"] = "mcq"
    catalogue: CatalogueSnapshot | ConceptCatalogueSnapshot

    @model_validator(mode="after")
    def require_snapshot_fits_item(self) -> ChemistryTemplateCandidate:
        if len(self.item.distractors) > MAX_DISTRACTORS:
            raise ValueError(
                f"A chemistry candidate allows up to {MAX_DISTRACTORS} distractors"
            )
        _require_snapshot(self.item, self.catalogue)
        return self

    def template_spec(self) -> ChemistryTemplateSpec:
        return ChemistryTemplateSpec(item=self.item, catalogue=self.catalogue)


class ChemistryValidationSummary(PropertyCheckSummary):
    """Sampled-domain evidence for a checked chemistry template."""

    validator_version: Literal["mcp-chemistry-template-v1"] = (
        CHEMISTRY_VALIDATOR_VERSION
    )
    checking_mode: Literal["property_based"] = CHEMISTRY_CHECKING_MODE
    catalogue_version: str = Field(min_length=1)
    catalogue_sha256: str = Field(pattern=_SHARED_HEX_PATTERN)


class ValidatedChemistryTemplate(ValidatedTemplateArtifact):
    """A chemistry template whose recipes passed property-based checks."""

    model_config = ConfigDict(extra="forbid", strict=True)

    format_version: Literal["1.0.0"] = CHEMISTRY_FORMAT_VERSION
    template: ChemistryTemplateCandidate
    validation: ChemistryValidationSummary


class EquationTerm(_Record):
    coefficient: int = Field(ge=1)
    formula: str = Field(min_length=1)


class StructuredEquation(_Record):
    reactants: list[EquationTerm]
    products: list[EquationTerm]


class ChemistryQuestionInstance(_Record):
    """A reproducible question expanded from a validated chemistry template."""

    template_id: str = Field(min_length=1)
    artifact_id: str | None = None
    seed: int
    parameters: dict[str, str]
    reaction_id: str = Field(min_length=1)
    question: str = Field(min_length=1)
    choices: list[str] = Field(min_length=2)
    correct_index: int = Field(ge=0)
    answer: str = Field(min_length=1)
    requires_manual_review: Literal[True] = True
    choices_structured: list[StructuredEquation] | None = None

    @model_validator(mode="after")
    def validate_choices(self) -> ChemistryQuestionInstance:
        if self.correct_index >= len(self.choices):
            raise ValueError("correct_index must identify one choice")
        if len(self.choices) != len(set(self.choices)):
            raise ValueError("choices must be distinct")
        if self.choices[self.correct_index] != self.answer:
            raise ValueError("answer must equal the choice at correct_index")
        if self.choices_structured is not None and len(self.choices_structured) != len(
            self.choices
        ):
            raise ValueError("choices_structured must match choices")
        return self


__all__ = [
    "BalancedEquationTarget",
    "CatalogueSnapshot",
    "ChemistryItemSpec",
    "ChemistryQuestionInstance",
    "ChemistryTarget",
    "ChemistryTemplateCandidate",
    "ChemistryTemplateContent",
    "ChemistryTemplateRequest",
    "ChemistryTemplateSpec",
    "ChemistryValidationSummary",
    "CoefficientTarget",
    "DistractorRecipe",
    "EquationTerm",
    "FamilySnapshot",
    "NormalisedCoefficientsRecipe",
    "Parameter",
    "PerturbCoefficient",
    "ReactionParameter",
    "ReactionSnapshot",
    "ScaleBalanced",
    "SkeletonCoefficients",
    "Slot",
    "SpeciesParameter",
    "SpeciesVariant",
    "StructuredEquation",
    "SwapCoefficients",
    "SwapSpecies",
    "ValidatedChemistryTemplate",
]
