"""Prove chemistry options on sampled inputs before choosing one recipe set."""

from collections.abc import Iterable, Iterator, Mapping

from edcraft_validator.domains.chemistry.balance import balance_equation
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    CatalogueSnapshot,
    ChemistryItemSpec,
    ChemistryTemplateSpec,
)
from edcraft_validator.domains.chemistry.extensions import evaluate_extension
from edcraft_validator.domains.chemistry.options import (
    OptionValue as ChemistryOption,
)
from edcraft_validator.domains.chemistry.options import (
    evaluate_recipe,
    format_equation,
    option_key,
    prove_option,
)
from edcraft_validator.validation.distractor_pool import (
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)


def select_chemistry_distractors(
    template: ChemistryTemplateSpec, required: int
) -> tuple[int, ...]:
    assignments = sample_assignments(
        {p.name: p.values for p in template.item.parameters}
    )
    return select_fixed_subset(
        _option_rows(template, assignments), required, assignments=assignments
    )


def _option_rows(
    template: ChemistryTemplateSpec, assignments: Iterable[Mapping[str, str | int]]
) -> Iterator[tuple[OptionValue, list[OptionValue | UnusableOption]]]:
    item = template.item
    if not isinstance(item, ChemistryItemSpec):
        for assignment in assignments:
            row = evaluate_extension(template, assignment)
            yield (
                row.key,
                [
                    option
                    if option is not None
                    else UnusableOption("is absent from this context")
                    for option in row.options
                ],
            )
        return
    assert isinstance(template.catalogue, CatalogueSnapshot)
    snapshots = {reaction.id: reaction for reaction in template.catalogue.reactions}
    for assignment in assignments:
        reaction = snapshots[str(assignment["reaction"])]
        species = assignment.get("species")
        slot = species if isinstance(species, str) else None
        coefficients = balance_equation(
            reaction.reactants, reaction.products
        ).coefficients
        key = _selection_value(
            evaluate_recipe(item.answer_recipe, reaction, coefficients, slot)
        )
        options: list[OptionValue | UnusableOption] = []
        for recipe in item.distractors:
            option = prove_option(recipe, reaction, coefficients, slot)
            if option.verdict == "wrong":
                options.append(_selection_value(option))
            else:
                options.append(
                    key
                    if option.verdict == "correct"
                    else UnusableOption(str(option.reason))
                )
        yield key, options


def _selection_value(option: ChemistryOption) -> OptionValue:
    identity = option_key(option)
    if identity is None or option.coefficients is None:
        raise ValueError("Chemistry option proof did not produce a value")
    display = (
        str(option.value)
        if option.value is not None
        else format_equation(option.reactants, option.products, option.coefficients)
    )
    return OptionValue(semantic=identity, display=display)
