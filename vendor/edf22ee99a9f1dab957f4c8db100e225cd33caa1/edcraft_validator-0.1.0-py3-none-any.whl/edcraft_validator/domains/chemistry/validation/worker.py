"""JSON-only entry point for isolated chemistry validation."""

from __future__ import annotations

import json
import sys
from typing import Any

from edcraft_validator.domains.chemistry.checks import (
    check_balance,
    check_content,
    check_options,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import ChemistryTemplateSpec
from edcraft_validator.domains.chemistry.distractor_selection import (
    select_chemistry_distractors,
)
from edcraft_validator.validation.distractor_pool import DistractorPoolError


def main() -> int:
    try:
        payload = json.load(sys.stdin)
        response = _run(payload)
    except Exception as exc:  # noqa: BLE001 - the boundary reports all failures
        json.dump(
            {"error": {"type": type(exc).__name__, "message": str(exc)}},
            sys.stdout,
        )
        return 0

    json.dump(response, sys.stdout, allow_nan=False)
    return 0


def _run(payload: dict[str, Any]) -> dict[str, Any]:
    operation = payload.get("operation")
    if operation not in {"balance", "content", "options", "select_distractors"}:
        raise ValueError(f"unknown validation operation {operation!r}")

    spec = ChemistryTemplateSpec.model_validate(payload["template"])
    if operation == "balance":
        return {"report": check_balance(spec)}
    if operation == "content":
        return {"report": check_content(spec)}
    if operation == "select_distractors":
        try:
            return {"indices": select_chemistry_distractors(spec, payload["required"])}
        except DistractorPoolError as error:
            return {"selection_error": str(error)}
    return {"report": check_options(spec)}


if __name__ == "__main__":
    raise SystemExit(main())
