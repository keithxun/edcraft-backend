"""JSON-only chemistry validation inside a disposable interpreter."""
