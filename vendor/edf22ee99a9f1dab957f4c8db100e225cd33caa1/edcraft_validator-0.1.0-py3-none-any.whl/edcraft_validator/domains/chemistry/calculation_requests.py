"""Recognise method-specific H2 calculation requests that the catalogue can satisfy."""

import re
from decimal import Decimal, InvalidOperation
from typing import Literal

from edcraft_validator.domains.chemistry.calculation_cases import (
    CELL_INPUTS,
    CONJUGATE_INPUTS,
    HALF_LIFE_CASES,
    KSP_INPUTS,
)
from edcraft_validator.domains.chemistry.chemistry_types import Difficulty
from edcraft_validator.domains.chemistry.elements import ELEMENT_SYMBOLS
from edcraft_validator.domains.chemistry.formula import FormulaError, parse_formula
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest

CELL_CASES = tuple(CELL_INPUTS)
PRECIPITATION_CASES = ("calc-precipitate-forms", "calc-precipitate-absent")
SOLUBILITY_CASES = (
    "calc-solubility-equal-ksp",
    "calc-solubility-equal-solubility",
    "calc-solubility-double-ksp",
    "calc-solubility-double-solubility",
)
DEFAULT_SOLUBILITY_CASES = (SOLUBILITY_CASES[0], SOLUBILITY_CASES[3])
REDUCTION_CASES = {
    difficulty: tuple(
        f"calc-reduction-{difficulty}-{target}" for target in ("step", "overall")
    )
    for difficulty in ("medium", "hard")
}
TABULATED_REDUCTION_CASES = {
    difficulty: tuple(case.replace("reduction-", "reduction-table-") for case in cases)
    for difficulty, cases in REDUCTION_CASES.items()
}
_CALCULATION_SKILLS = {
    "12.e-1": CELL_CASES,
    "12.i-2": (
        REDUCTION_CASES["medium"]
        + REDUCTION_CASES["hard"]
        + TABULATED_REDUCTION_CASES["medium"]
        + TABULATED_REDUCTION_CASES["hard"]
    ),
    "10.2.a-1": PRECIPITATION_CASES,
    "10.2.b-1": SOLUBILITY_CASES,
    "4.b-2": tuple(CONJUGATE_INPUTS),
    "8.a-3": HALF_LIFE_CASES,
}
_FIND = r"(?:calculate|calculating|compute|work out|find|determine|deduce|derive)"
_HALF_LIFE = r"(?:half[- ‐‑–]life|t½|t_?1/2)"
_KSP = r"(?:k_?\s*sp|solubility[- ]product)"
_STOICHIOMETRY_SUBSCRIPTS = str.maketrans("₀₁₂₃₄₅₆₇₈₉ₛₚ", "0123456789sp")
_NUMERICAL_SUPERSCRIPTS = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻−⁺", "0123456789--+")
_KSP_VALUE = re.compile(
    rf"(?P<symbol>\b{_KSP}\b)(?:\s+value)?"
    r"(?:\s+(?:for|of)\s+[a-z][a-z0-9]*(?:\s+[a-z][a-z0-9]*){0,3}?)?"
    r"[\s$`]*"
    r"(?:(?:=|:|\b(?:is(?: equal to)?|of|as|equals?|given as|set to)\b)[\s$`]*"
    r"|(?=[+-]?(?:\d+\.\d|\.\d|\d+e)))"
    r"(?P<mantissa>[+-]?(?:\d+(?:\.\d+)?|\.\d+))"
    r"(?:\s*(?:e|(?:[×x*]|\\times)\s*10\s*\^?)\s*\{?\s*"
    r"(?P<exponent>[+-]?\d+)\s*\}?)?(?![\w:]|\.\d)"
)
_SALT_NAME = re.compile(
    r"\b(?:ammonium|barium|calcium|caesium|cesium|strontium|magnesium|"
    r"sodium|potassium|lead|silver|aluminium|aluminum|lithium|copper|"
    r"iron|zinc|nickel|chromium|manganese|cobalt)(?:\s*\([ivx]+\))?"
    r"\s+[a-z]+(?:ide|ate|ite)\b"
)
_FORMULA = re.compile(r"\b(?:[A-Z][a-z]?\d*|\([A-Za-z0-9]+\)\d*){2,}\b")
_VOLTAGE = re.compile(
    r"(?<![\w.])([+−-]?(?:\d+(?:\.\d+)?|\.\d+))\s*(?:v|volts?)\b", re.I
)
_ION = re.compile(r"\b([A-Z][a-z]?)([⁰¹²³⁴⁵⁶⁷⁸⁹]*[⁺⁻]|\^?(?:\d+[+-]|\+))")
_ELECTRODE_SYMBOL = re.compile(
    r"\b([A-Z][a-z]?)\b(?=\s*(?:[/–—-]|and\b|electrodes?\b|couples?\b|\(s\)))"
    r"|[/–—-]\s*([A-Z][a-z]?)\b"
)
_ELECTRODE_NAMES = {
    "copper": "Cu",
    "zinc": "Zn",
    "silver": "Ag",
    "magnesium": "Mg",
    "iron": "Fe",
    "lead": "Pb",
    "aluminium": "Al",
    "aluminum": "Al",
    "nickel": "Ni",
    "tin": "Sn",
    "cobalt": "Co",
    "manganese": "Mn",
    "platinum": "Pt",
    "gold": "Au",
}


def calculation_skill_cases(skill_id: str) -> tuple[str, ...]:
    return _CALCULATION_SKILLS.get(skill_id, ())


def paired_calculation_case(context_id: str) -> bool:
    return context_id in (
        *REDUCTION_CASES["hard"],
        *TABULATED_REDUCTION_CASES["hard"],
        *PRECIPITATION_CASES,
    )


def requested_calculation_cases(
    prompt: str, difficulty: Difficulty, skill_id: str | None
) -> tuple[str, ...]:
    """Select calculation cases that preserve the supplied method and inputs."""
    if skill_id is not None and skill_id not in _CALCULATION_SKILLS:
        return ()
    prompt = re.sub(
        r"\b(?:rather than|instead of|as opposed to|not just|not simply|"
        r"not (?:predict|calculate|combine|asking about))\b[^,.!?;]*",
        " ",
        prompt.translate(_STOICHIOMETRY_SUBSCRIPTS),
        flags=re.IGNORECASE,
    )
    text = re.sub(r"\bk\s*_\s*\{\s*sp\s*\}", "ksp", prompt.casefold())
    foundational = _foundational_cases(prompt, text, skill_id)
    if foundational:
        return foundational
    ksp_mentioned = re.search(rf"\b{_KSP}\b", text)
    numerical_text = text.translate(_NUMERICAL_SUPERSCRIPTS)
    conversion = skill_id == "10.2.b-1" or (
        skill_id is None
        and ksp_mentioned
        and (
            re.search(r"\b(?:molar solubility|solubility in pure water)\b", text)
            or (
                re.search(r"\bsolubility\b(?![- ]product)", text)
                and _KSP_VALUE.search(numerical_text)
            )
        )
    )
    precipitate_mentioned = re.search(r"\bprecipitat\w*\b", text)
    ionic_product = re.search(r"\b(?:ionic product|ion product)\b", text)
    species = (
        _precipitation_species(prompt)
        if skill_id == "10.2.a-1" or (skill_id is None and precipitate_mentioned)
        else set()
    )
    precipitation = skill_id == "10.2.a-1" or (
        skill_id is None
        and (
            (ksp_mentioned and (precipitate_mentioned or ionic_product))
            or (ionic_product and precipitate_mentioned)
            or (
                species and re.search(r"\b(?:predict|determine|decide|whether)\b", text)
            )
        )
    )
    specified_ksp: set[Decimal] = set()
    if conversion or precipitation:
        specified_ksp = _specified_ksp(numerical_text)
        if specified_ksp:
            text = _KSP_VALUE.sub(r"\g<symbol> ", numerical_text)
    if not precipitation:
        species = set()
    if species - {"calcium fluoride", "CaF2"}:
        raise UnsupportedAuthoringRequest(
            "No verified precipitation case uses the specified precipitate."
        )

    direct_cell = skill_id == "12.e-1" or (
        skill_id is None
        and re.search(
            r"\b(?:standard )?cell (?:potential|voltage|emf)\b|\be°\s*cell\b",
            text,
        )
        and re.search(rf"\b(?:{_FIND}|subtract)\b", text)
        and not re.search(
            r"\b(?:gibbs|free[- ]energy|weighted|successive|consecutive|sequential|"
            r"hydrogen electrode)\b",
            text,
        )
    )
    if direct_cell:
        _check_direct_cell_conditions(text)
    # The direct-cell catalogue can check exact electrode data. Other task
    # types keep their existing route when teacher-supplied values are present.
    scope_text = _VOLTAGE.sub(" ", text) if direct_cell else text
    if re.search(
        r"\b(?:electrolysis|nernst|disproportionation|common[- ]ion|non[- ]?standard|"
        r"draw|titrate|titration|open[- ]ended|written explanation|"
        r"temperature dependence|equilibrium constant|no calculator)\b"
        r"|\b\d+(?:\.\d+)?\s*mol\b"
        r"|\b\d(?:\.\d+)?\s*(?:[×x]\s*10|e[−-]\d)",
        scope_text,
    ) or _VOLTAGE.search(scope_text):
        return _match_solubility_inputs((), specified_ksp, species)

    potentials = (
        r"\b(?:reduction|electrode|half[- ]cell) potentials?\b"
        r"|\b(?:half[- ]reactions?|redox couples?)\b|\be°"
    )
    weighted = skill_id == "12.i-2" or (
        skill_id is None
        and re.search(potentials, text)
        and re.search(
            r"\b(?:successive|consecutive|sequential|weighted|gibbs|free[- ]energy)\b",
            text,
        )
    )
    if weighted:
        reduction_cases = (
            TABULATED_REDUCTION_CASES
            if re.search(r"\b(?:tabulat\w*|table)\b", text)
            else REDUCTION_CASES
        )
        cases = reduction_cases.get(difficulty, ())
        if not cases:
            return ()
        step = bool(
            re.search(
                rf"\b(?:unknown|missing|individual|{_FIND})\b[^.!?;]{{0,40}}\bstep\b",
                text,
            )
        )
        overall = bool(
            re.search(
                rf"\b(?:{_FIND}|unknown|missing|ask(?:s|ing)? for)\b[^.!?;]{{0,36}}"
                r"\b(?:overall|combined|net)\s+(?:reduction\s+)?(?:potential|voltage)\b",
                text,
            )
        )
        if step != overall:
            # An explicit single numerical output takes precedence over a
            # difficulty label. The harder paired choice adds a cathode decision.
            if not re.search(r"\b(?:cathode|galvanic|electrode comparison)\b", text):
                cases = reduction_cases["medium"]
            return (cases[0] if step else cases[1],)
        return cases

    if direct_cell:
        if difficulty != "easy":
            return ()
        return _direct_cell_cases(prompt)

    solubility_cases: tuple[str, ...] = ()
    if conversion and not precipitation:
        solubility_cases = _solubility_cases(text)
    elif (
        precipitation
        and not conversion
        and difficulty == "medium"
        and not re.search(
            r"\b(?:mixing volumes?|dilution|minimum|threshold concentration)\b", text
        )
    ):
        solubility_cases = PRECIPITATION_CASES
    return _match_solubility_inputs(solubility_cases, specified_ksp, species)


def _foundational_cases(
    prompt: str, text: str, skill_id: str | None
) -> tuple[str, ...]:
    if (
        skill_id in {None, "4.b-2"}
        and re.search(r"\bconjugate base\b", text)
        and re.search(r"\b(?:of|indicated|stated|given|acid)\b", text)
        and not re.search(r"\b(?:buffers?|pka|pkb|ka|kb|conjugate acid)\b", text)
    ):
        normalized = text.translate(_NUMERICAL_SUPERSCRIPTS)
        specific = tuple(
            case
            for case, (_, _, aliases) in CONJUGATE_INPUTS.items()
            if any(
                re.search(rf"(?<!\w){re.escape(alias)}(?!\w)", normalized)
                for alias in aliases
            )
        )
        if not specific and (
            _precipitation_species(prompt) - {"H2O", "H3O"}
            or re.search(r"\bconjugate base of (?:the )?(?:water|h2o)\b", text)
            or re.search(
                r"\b(?:nitric|sul[fp]uric|phosphoric|citric|hydrochloric|carbonic|"
                r"methanoic|benzoic|lactic) acid\b",
                text,
            )
        ):
            raise UnsupportedAuthoringRequest(
                "No verified conjugate-base case uses the specified acid."
            )
        return specific or tuple(CONJUGATE_INPUTS)[:2]

    if (
        skill_id in {None, "8.a-3"}
        and re.search(
            rf"\b(?:{_FIND}|finding|deriving|infer|read|estimate|obtain)\s+"
            rf"(?:(?:an?|the|numerical|value of|first-order|reaction['’]s)\s+){{0,6}}"
            rf"{_HALF_LIFE}\b",
            text,
        )
        and re.search(r"\bconcentrations?\b", text)
        and re.search(r"\btime\b", text)
    ):
        if re.search(r"\b\d+(?:\.\d+)?\s*(?:s|seconds?|min(?:utes?)?|mol)\b", text):
            raise UnsupportedAuthoringRequest(
                "No verified half-life case can preserve the supplied measurements."
            )
        return HALF_LIFE_CASES
    return ()


def _check_direct_cell_conditions(text: str) -> None:
    cell_target = r"\b(?:cell (?:potential|voltage|emf)|e°\s*cell)\b"
    for target in re.finditer(cell_target, text):
        qualifier = re.match(
            r"(?:\s+value)?\s*(?:=|of\b|is\b|:)\s*", text[target.end() :]
        )
        if qualifier and _VOLTAGE.match(text, target.end() + qualifier.end()):
            raise UnsupportedAuthoringRequest(
                "The verified direct-cell cases calculate the cell potential from two "
                "reduction potentials. This request gives a supplied cell potential."
            )

    number = r"(?<![\w.])([+-]?(?:\d+(?:\.\d+)?|\.\d+))"
    temperatures = re.findall(rf"{number}\s*(°\s*c|k|kelvin)\b", text)
    concentrations = re.findall(
        rf"{number}\s*(mm|m|mol\s*(?:/\s*l|dm\s*\^?[⁻−-][³3]))\b", text
    )
    if any(
        Decimal(value)
        not in (
            {Decimal(298), Decimal("298.15")} if unit.startswith("k") else {Decimal(25)}
        )
        for value, unit in temperatures
    ) or any(
        Decimal(value) != (1000 if unit == "mm" else 1)
        for value, unit in concentrations
    ):
        raise UnsupportedAuthoringRequest(
            "No verified direct-cell case uses the specified cell conditions."
        )


def _direct_cell_cases(prompt: str) -> tuple[str, ...]:
    voltage_values = {
        Decimal(value.replace("−", "-")) for value in _VOLTAGE.findall(prompt)
    }
    prompt = _VOLTAGE.sub(" ", prompt)
    names = {
        symbol
        for spelling, symbol in _ELECTRODE_NAMES.items()
        if re.search(rf"\b(?:{spelling}|{symbol})\b", prompt, re.IGNORECASE)
    }
    names.update(
        symbol
        for left, right in _ELECTRODE_SYMBOL.findall(prompt)
        if (symbol := left or right) in ELEMENT_SYMBOLS
    )
    ions = {
        (symbol, _normalized_charge(charge))
        for symbol, charge in _ION.findall(prompt)
        if symbol in ELEMENT_SYMBOLS
    }

    matching = []
    for identifier, (cathode, cathode_e, anode, anode_e) in CELL_INPUTS.items():
        available_symbols = {cathode.split("/")[1], anode.split("/")[1]}
        available_ions = {
            (symbol, _normalized_charge(charge))
            for symbol, charge in _ION.findall(f"{cathode} {anode}")
        }
        if names <= available_symbols and ions <= available_ions:
            matching.append(
                (identifier, {Decimal(cathode_e) / 100, Decimal(anode_e) / 100})
            )
    if not matching:
        raise UnsupportedAuthoringRequest(
            "No verified cell case uses the specified electrode pair."
        )
    cases = tuple(
        identifier for identifier, values in matching if voltage_values <= values
    )
    if not cases:
        raise UnsupportedAuthoringRequest(
            "No verified cell case uses the specified voltage values."
        )
    return cases


def _normalized_charge(charge: str) -> str:
    normalized = charge.translate(_NUMERICAL_SUPERSCRIPTS).removeprefix("^")
    return normalized[1:] if normalized in {"1+", "1-"} else normalized


def _specified_ksp(text: str) -> set[Decimal]:
    try:
        return {
            Decimal(f"{match['mantissa']}E{match['exponent'] or '0'}")
            for match in _KSP_VALUE.finditer(text)
        }
    except InvalidOperation as error:
        raise UnsupportedAuthoringRequest(
            "The specified Ksp is outside the supported range."
        ) from error


def _precipitation_species(prompt: str) -> set[str]:
    species = set(_SALT_NAME.findall(prompt.casefold()))
    for token in _FORMULA.findall(prompt):
        if token == "KSP":
            continue
        try:
            if len(parse_formula(token)) >= 2:
                species.add(token)
        except FormulaError:
            continue
    return species


def _match_solubility_inputs(
    cases: tuple[str, ...], specified_ksp: set[Decimal], species: set[str]
) -> tuple[str, ...]:
    if specified_ksp:
        selected = tuple(
            case
            for case in cases
            if case in KSP_INPUTS and Decimal(KSP_INPUTS[case]) in specified_ksp
        )
        if {Decimal(KSP_INPUTS[case]) for case in selected} != specified_ksp:
            raise UnsupportedAuthoringRequest(
                "No verified case uses the specified Ksp."
            )
        return selected
    if species and not cases:
        raise UnsupportedAuthoringRequest(
            "No verified case preserves the specified precipitate and conditions."
        )
    return cases


def _solubility_cases(text: str) -> tuple[str, ...]:
    equal = bool(
        re.search(r"\b(?:1\s*:\s*1|equal numbers?|calcium sul[fp]ate|caso4)\b", text)
    )
    double = bool(
        re.search(
            r"\b(?:1\s*:\s*2|twice as many|unequal (?:ion )?coefficients|"
            r"non[- ]1[- ]to[- ]1|calcium fluoride|caf2)\b",
            text,
        )
    )
    forward = bool(
        re.search(
            rf"\b{_FIND}\s+(?:the\s+)?(?:numerical\s+)?{_KSP}\b"
            rf"|(?:molar )?solubility to (?:the )?{_KSP}\b"
            r"|from (?:the |given )?(?:molar )?solubility\b",
            text,
        )
    )
    inverse = bool(
        re.search(
            rf"\b{_FIND}\s+(?:the\s+)?(?:molar )?solubility\b(?! product)"
            rf"|from (?:the |given )?{_KSP}\b",
            text,
        )
    )
    if re.search(
        r"\b(?:barium|strontium|magnesium|sodium|potassium|lead|silver)\b|"
        r"\b2\s*:\s*1\b|\bcalcium (?:chloride|carbonate|hydroxide|phosphate)\b",
        text,
    ):
        return ()
    if forward and not inverse:
        return _solubility_ratio_cases(0, equal, double)
    if inverse and not forward:
        return _solubility_ratio_cases(1, equal, double)
    if equal != double:
        return SOLUBILITY_CASES[:2] if equal else SOLUBILITY_CASES[2:]
    return DEFAULT_SOLUBILITY_CASES


def _solubility_ratio_cases(
    target: Literal[0, 1], equal: bool, double: bool
) -> tuple[str, ...]:
    if equal == double:
        return (SOLUBILITY_CASES[target], SOLUBILITY_CASES[2 + target])
    return (SOLUBILITY_CASES[target if equal else 2 + target],)
