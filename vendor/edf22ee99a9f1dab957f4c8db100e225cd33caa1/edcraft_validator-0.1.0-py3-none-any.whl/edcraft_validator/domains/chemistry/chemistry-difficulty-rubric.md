# Provisional chemistry difficulty rubric

Rubric version: `chem-balance-v0.1`.
Assessment conditions version: `paper-no-calculator-v0.1`.

Use this rubric to check whether a reusable chemistry balancing MCQ template
matches the user's requested difficulty. Assess the typical concrete expansion
independently, then compare its estimated level with the request. Levels describe
EdCraft's provisional task-demand conventions under the conditions below. They
are uncalibrated and have no reference labels behind them. A match means the
template is consistent with this provisional rubric, so results stay advisory
evidence for educator review and never override failed correctness checks.

## Assessment conditions and scope

Use paper without a calculator, computer algebra system or AI assistant. No
periodic-table lookup is needed: every formula and every atom count comes from
the displayed equation. Assess an untimed practice question with the relevant
chemical prerequisites understood. There is no fixed learner cohort and no
measured learner performance. Record any aids, time limit or scaffolding as a
different assessment condition.

A template is rated on concrete expansions of its declared reaction and slot
family. Pick representative combinations that show the range of demand,
including the reactions the checks sample. Reactions can change the number of
species, the element counts or the first fractional intermediate, so rate the
range you reviewed and report substantial variation. A sampled match cannot
establish that every expansion matches.

Technical correctness, educational difficulty and question quality are separate.
Distinct wrong answers do not establish plausible distractors. A correctly
balanced template can still carry weak options or unclear wording. Record those
concerns separately. This rubric is provisional, uncalibrated and advisory.

## Dimensions and evidence to record

Rate each dimension `low`, `moderate` or `high`, or `unknown` when the evidence is
insufficient. These categories organise the explanation. Do not sum them or apply
a weighted formula to produce a difficulty score. Level boundaries here are
EdCraft conventions and they are not calibrated thresholds.

| Dimension | Low | Moderate | High |
| --- | --- | --- | --- |
| System size | Three species, two elements. | Four species, three elements. | Five or more species, or four or more elements. |
| Balancing procedure | Inspection in one pass. | Ordered inspection where one element appears in two species on a side. | A fractional intermediate that must be cleared by doubling, or back-tracking. |
| Formula structure | Simple subscripts. | One parenthesised group or a multi-digit subscript. | Several groups or a hydrate. |
| Answer discrimination | Options fall to one atom count. | Eliminating needs a full count of one element. | Plausible options need every element counted or the reduction rule. |

### System size and balancing procedure

Balance a correct solution for the chosen expansion and count each element on
both sides. State which element fixes the first coefficient and whether the
learner must revisit an earlier choice. The number of species and distinct
elements is evidence of the required work. Raw species count alone does not set
difficulty because a short equation can still need a fractional step.

Use `low` for inspection in one pass, `moderate` for ordered inspection where one
element appears in two species on a side, and `high` for a fractional
intermediate that must be cleared by doubling, or for back-tracking. Give the
deciding counts behind the rating.

### Formula structure

Identify the formula shapes the learner must read. Simple subscripts keep the
atom count routine. One parenthesised group or a multi-digit subscript adds a
step, and several groups or a hydrate adds more. Formula length alone does not
settle the rating: a long formula with one repeated group can stay moderate.

Use `low` for simple subscripts, `moderate` for one parenthesised group or a
multi-digit subscript, and `high` for several groups or a hydrate.

### Answer discrimination

For each distractor, explain the error rule the option hypothesis uses and the
rule that eliminates it. The misconception tag is a hypothesis. Without learner
data it is not proof that learners make that error. Assign the dimension from the
easiest defensible way to distinguish the correct answer from the actual
options. Unclear or misleading options need repair rather than a higher
difficulty label.

Here discrimination means option-distinguishing demand. Statistical item
discrimination needs learner data and is deferred with calibration.

## Overall levels and uncertainty

| Level | Anchor description |
| --- | --- |
| `easy` | Short inspection with small coefficients. Options fail a quick count. |
| `medium` | Ordered inspection over four species, coefficients up to about 5. |
| `hard` | Requires clearing a fraction or handling groups, with balanced but unreduced options. |

Choose the closest worked anchor and explain the similarities and the material
differences. A single high dimension does not force `hard`. A shortcut or weak
options can lower the complete MCQ's demand. Unknown evidence is not defaulted to
medium.

### Level names

The originating issue names the levels beginner, intermediate and advanced. They
correspond to `easy`, `medium` and `hard` here, and the shared difficulty
vocabulary of every EdCraft domain uses the same three names. The issue's wording
is a synonym table, not a second scale.

Record confidence from 0 to 1 in the selected level. It is a self-estimate and it
is uncalibrated. For missing essential information use `estimated_difficulty:
null` with an unable-to-assess reason and confidence 0. A technically failed
template is ineligible for difficulty assessment.

## Worked anchors

These examples are reviewer training material. They are not held-out reference
items. The levels illustrate the rubric and nobody has rated them independently.

### Easy synthesis

`N2 + H2 → NH3`. A: `1, 3, 2`, B: `1, 3, 1`, C: `2, 6, 4`, D: `1, 1, 1`.

Answer: A, `1, 3, 2`. Three species and two elements keep system size low, and one
pass of inspection finds the coefficients, so balancing procedure is low. The
subscripts are simple and answer discrimination is low because option B fails the
hydrogen count and the others are obviously scaled or the skeleton.

### Medium combustion

`C3H8 + O2 → CO2 + H2O`. A: `1, 5, 3, 4`, B: `1, 5, 3, 5`, C: `2, 10, 6, 8`,
D: `1, 1, 1, 1`.

Answer: A, `1, 5, 3, 4`. Carbon fixes the carbon dioxide coefficient, then hydrogen
fixes water, then oxygen is checked last because it appears in two products on the
right. System size is moderate at four species and three elements, and the order
matters, so balancing procedure is moderate. Formula structure stays low. Answer
discrimination is moderate because each option needs a full count of one element:
option B fails oxygen, option C is balanced but not reduced, and option D is the
skeleton.

### Hard combustion

`C2H6 + O2 → CO2 + H2O`. A: `2, 7, 4, 6`, B: `1, 7, 2, 3`, C: `4, 14, 8, 12`,
D: `2, 7, 4, 5`.

Answer: A, `2, 7, 4, 6`. Carbon and hydrogen first give `1, 7/2, 2, 3`, so oxygen
gives a fractional intermediate that must be cleared by doubling. System size is
moderate at four species and three elements, but balancing procedure is high.
Formula structure stays low. Answer discrimination is high because option B is
unbalanced in oxygen, option C is balanced but not reduced, and option D differs
from the answer by one water, so every plausible option needs a full count or the
reduction rule.

## Reviewer procedure and records

1. Confirm the checks passed and the stem is clear. Repair ineligible cases first.
2. Hide the requested difficulty, generator identity and other ratings. Show the
   conditions, the concrete MCQ and the verified answer.
3. Explain the solution and each distractor, then record dimension ratings, nearest
   anchor, overall level, confidence and quality concerns independently.
4. Reveal the requested difficulty and apply the comparison rule to the frozen
   assessment. A mismatch remains advisory and never requests automatic revision.

Store records in versioned files. Preserve the rubric and conditions versions, the
reviewed reactions and asked slots, the dimension ratings with reasons, the
closest anchor, the estimated level or null, confidence, quality concerns, the
unchanged requested level and the match result. Increment the rubric version when
dimensions, anchors, level decisions or conditions change. Code, formula or option
edits invalidate the previous concrete assessment.

## Validation plan

Target about 60 concrete questions from at least 20 template families across the
catalogue's reaction families and all three requested levels. Split by family
before tuning and keep variants of one family together. Use two or three
independent chemistry teachers or tutors, with the author disclosed separately.
Record ordinal Krippendorff's alpha for the overall level, per-dimension exact
agreement and a confusion matrix against the adjudicated reference. Report
bootstrap intervals that resample families and expect wide intervals. Calibration
against learner responses is deferred until response data exists. This rubric
carries no accepted accuracy threshold.
