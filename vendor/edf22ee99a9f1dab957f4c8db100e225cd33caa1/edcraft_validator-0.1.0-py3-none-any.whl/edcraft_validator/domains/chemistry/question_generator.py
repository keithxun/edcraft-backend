"""Deterministically expand approved chemistry templates into seeded questions.

Generation recomputes each balance from the embedded snapshot and evaluates the
approved recipes with :mod:`edcraft_validator.domains.chemistry.options`. It
needs no model, MCP or catalogue reads, so a saved artifact expands even after
the live catalogue changes.
"""

from __future__ import annotations

from math import prod

from edcraft_validator.domains.chemistry.balance import (
    BalanceError,
    balance_equation,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    CatalogueSnapshot,
    ChemistryItemSpec,
    ChemistryQuestionInstance,
    ChemistryTemplateCandidate,
    ReactionSnapshot,
    SpeciesParameter,
    StructuredEquation,
    ValidatedChemistryTemplate,
    reaction_ids,
)
from edcraft_validator.domains.chemistry.extensions import (
    ExtensionEvaluation,
    evaluate_extension,
)
from edcraft_validator.domains.chemistry.formula import FormulaError
from edcraft_validator.domains.chemistry.options import (
    OptionValue,
    evaluate_recipe,
    format_equation,
    option_key,
    prove_option,
    render_stem,
    structured_equation,
)
from edcraft_validator.domains.domain_support import seeded_index


class UnusableVariant(ValueError):
    """One reaction and asked slot cannot yield a sound question."""


def generate_chemistry_question(
    validated: ValidatedChemistryTemplate, seed: int
) -> ChemistryQuestionInstance:
    """Expand one approved template without AI calls, MCP or catalogue reads."""
    template = validated.template
    if not isinstance(template.item, ChemistryItemSpec):
        return _generate_extension(validated, seed)
    combinations = _combinations(template.item)
    if not combinations:
        raise ValueError("validated template has an empty parameter domain")

    start = seeded_index(
        template.template_id, seed, "parameter-combination", len(combinations)
    )

    for offset in range(len(combinations)):
        reaction_id, asked_slot = combinations[(start + offset) % len(combinations)]
        reaction = _reaction(template, reaction_id)
        try:
            return _build_instance(
                template, reaction, asked_slot, seed, validated.artifact_id
            )
        except (UnusableVariant, BalanceError, FormulaError):
            continue

    raise ValueError("Could not produce a usable question from this template")


def _generate_extension(
    validated: ValidatedChemistryTemplate, seed: int
) -> ChemistryQuestionInstance:
    template = validated.template
    axes = template.item.parameters
    size = prod(len(axis.values) for axis in axes)
    start = seeded_index(template.template_id, seed, "parameter-combination", size)
    spec = template.template_spec()
    for attempt in range(min(size, 32)):
        index = (start + attempt) % size
        inputs: dict[str, str | int] = {}
        for axis in reversed(axes):
            index, position = divmod(index, len(axis.values))
            inputs[axis.name] = axis.values[position]
        result = evaluate_extension(spec, inputs)
        rendered = render_extension_choices(result, template.template_id, seed)
        if rendered is None:
            continue
        choices, correct_index = rendered
        return ChemistryQuestionInstance(
            template_id=template.template_id,
            artifact_id=validated.artifact_id,
            seed=seed,
            parameters={axis.name: str(inputs[axis.name]) for axis in axes},
            reaction_id=result.context_id,
            question=result.question,
            choices=choices,
            correct_index=correct_index,
            answer=result.key.display,
        )
    raise UnusableVariant("Could not produce a usable H2 question from this template")


def render_extension_choices(
    result: ExtensionEvaluation, template_id: str, seed: int
) -> tuple[list[str], int] | None:
    """Render the saved wrong slots and place the key using the usual seed."""
    if any(verdict != "wrong" for verdict in result.verdicts()):
        return None
    choices = [option.display for option in result.options if option is not None]
    correct_index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
    choices.insert(correct_index, result.key.display)
    return choices, correct_index


def _combinations(item: ChemistryItemSpec) -> list[tuple[str, str | None]]:
    """Enumerate the declared grid in declaration order."""
    reactions = reaction_ids(item)
    species = [
        slot
        for parameter in item.parameters
        if isinstance(parameter, SpeciesParameter)
        for slot in parameter.values
    ]
    if item.target.kind == "coefficient":
        return [(reaction, slot) for reaction in reactions for slot in species]
    return [(reaction, None) for reaction in reactions]


def _reaction(
    template: ChemistryTemplateCandidate, reaction_id: str
) -> ReactionSnapshot:
    assert isinstance(template.catalogue, CatalogueSnapshot)
    for reaction in template.catalogue.reactions:
        if reaction.id == reaction_id:
            return reaction
    raise UnusableVariant(f"reaction {reaction_id!r} is missing from the snapshot")


def _build_instance(
    template: ChemistryTemplateCandidate,
    reaction: ReactionSnapshot,
    asked_slot: str | None,
    seed: int,
    artifact_id: str | None,
) -> ChemistryQuestionInstance:
    """Evaluate the approved recipes for one reaction and asked slot."""
    assert isinstance(template.item, ChemistryItemSpec)
    key = balance_equation(reaction.reactants, reaction.products).coefficients
    key_option = evaluate_recipe(template.item.answer_recipe, reaction, key, asked_slot)
    if key_option.verdict != "key":
        raise UnusableVariant("the answer recipe does not yield the key")

    seen = {option_key(key_option)}
    distractor_options: list[OptionValue] = []
    for recipe in template.item.distractors:
        option = prove_option(recipe, reaction, key, asked_slot)
        if option.verdict != "wrong":
            raise UnusableVariant(f"the distractor is {option.verdict}")
        identity = option_key(option)
        if identity is None or identity in seen:
            raise UnusableVariant("distractor choices are not distinct")
        seen.add(identity)
        distractor_options.append(option)

    if not distractor_options:
        raise UnusableVariant("the template declares no distractors")

    key_rendered, key_structured = _render(key_option, reaction, asked_slot)
    distractor_rendered: list[str] = []
    distractor_structured: list[StructuredEquation] = []
    for option in distractor_options:
        rendered, structured = _render(option, reaction, asked_slot)
        if rendered in distractor_rendered:
            raise UnusableVariant("distractor choices are not distinct")
        distractor_rendered.append(rendered)
        if structured is not None:
            distractor_structured.append(structured)

    if key_rendered in distractor_rendered:
        raise UnusableVariant("the key duplicates a distractor")

    correct_index = seeded_index(
        template.template_id, seed, "correct-index", len(distractor_options) + 1
    )
    choices = list(distractor_rendered)
    choices.insert(correct_index, key_rendered)

    structured_choices: list[StructuredEquation] | None = None
    if asked_slot is None:
        if key_structured is None:
            raise UnusableVariant("the key has no structured equation")
        structured_choices = list(distractor_structured)
        structured_choices.insert(correct_index, key_structured)

    parameters = {"reaction": reaction.id}
    if asked_slot is not None:
        parameters["species"] = asked_slot

    return ChemistryQuestionInstance(
        template_id=template.template_id,
        artifact_id=artifact_id,
        seed=seed,
        parameters=parameters,
        reaction_id=reaction.id,
        question=render_stem(
            template.item,
            reaction,
            asked_slot,
            template.catalogue.family.description,
        ),
        choices=choices,
        correct_index=correct_index,
        answer=key_rendered,
        choices_structured=structured_choices,
    )


def _render(
    option: OptionValue,
    reaction: ReactionSnapshot,
    asked_slot: str | None,
) -> tuple[str, StructuredEquation | None]:
    """Render one option as text, plus its structured equation when needed."""
    if asked_slot is not None:
        if option.value is None:
            raise UnusableVariant("the coefficient option has no value")
        return str(option.value), None

    if option.coefficients is None:
        raise UnusableVariant("the equation option has no coefficients")
    reactants = option.reactants or tuple(reaction.reactants)
    products = option.products or tuple(reaction.products)
    return (
        format_equation(reactants, products, option.coefficients),
        structured_equation(reactants, products, option.coefficients),
    )


__all__ = ["UnusableVariant", "generate_chemistry_question"]
