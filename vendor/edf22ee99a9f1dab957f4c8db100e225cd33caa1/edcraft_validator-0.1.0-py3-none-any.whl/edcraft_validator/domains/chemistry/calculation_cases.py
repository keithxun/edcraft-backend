"""Original calculation contexts with keys derived from their classroom data."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, localcontext
from fractions import Fraction
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from edcraft_validator.domains.chemistry.concept_catalogue import ConceptContext

_SUPERSCRIPT = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")
_SOLUBILITY_UNIT = " mol dm⁻³"
CELL_INPUTS = {
    "calc-cell-cu-zn": ("Cu²⁺/Cu", 34, "Zn²⁺/Zn", -76),
    "calc-cell-ag-cu": ("Ag⁺/Ag", 80, "Cu²⁺/Cu", 34),
}
KSP_INPUTS = {
    "calc-solubility-equal-solubility": "2.5e-5",
    "calc-solubility-double-solubility": "3.7e-11",
    "calc-precipitate-forms": "3.7e-11",
    "calc-precipitate-absent": "3.7e-11",
}
CONJUGATE_INPUTS = {
    "calc-conjugate-ammonium": ("NH₄⁺", "NH₃", ("nh4+", "ammonium")),
    "calc-conjugate-bicarbonate": (
        "HCO₃⁻",
        "CO₃²⁻",
        ("hco3-", "hydrogen carbonate", "bicarbonate"),
    ),
    "calc-conjugate-dihydrogen-phosphate": (
        "H₂PO₄⁻",
        "HPO₄²⁻",
        ("h2po4-", "dihydrogen phosphate"),
    ),
    "calc-conjugate-ethanoic": (
        "CH₃COOH",
        "CH₃COO⁻",
        ("ch3cooh", "ethanoic acid", "acetic acid"),
    ),
}
HALF_LIFE_CASES = ("calc-half-life-one-interval", "calc-half-life-two-intervals")


def _case(
    identifier: str,
    topic: Literal["12", "10.2", "4", "8"],
    stem: str,
    options: list[str],
) -> ConceptContext:
    from edcraft_validator.domains.chemistry.concept_catalogue import ConceptContext

    family, title = {
        "12": ("electrochemistry", "Electrochemistry"),
        "10.2": ("solubility_equilibria", "Solubility equilibria"),
        "4": ("acid_base_theories", "Acid and base theories"),
        "8": ("reaction_kinetics", "Reaction kinetics"),
    }[topic]
    answer, *alternatives = options
    return ConceptContext(
        id=identifier,
        family=family,
        topic=topic,
        topic_title=title,
        question=stem,
        answer=answer,
        alternatives=alternatives,
    )


def _volts(centivolts: Fraction | int) -> str:
    return f"{Fraction(centivolts, 100):+.2f} V".replace("-", "−")


@dataclass(frozen=True)
class SuccessiveReduction:
    element: str
    first_electrons: int
    second_electrons: int
    first_potential: int
    known_potential: int
    unknown: Literal["step", "overall"]
    comparison: tuple[str, int] | None = None

    def context(self, identifier: str, *, tabulated: bool = False) -> ConceptContext:
        first, second = self.first_electrons, self.second_electrons
        total = first + second
        initial = self.element + _charge(total)
        intermediate = self.element + _charge(second)
        metal = f"{self.element}(s)"
        half1 = f"{initial} + {_electrons(first)} → {intermediate}"
        half2 = f"{intermediate} + {_electrons(second)} → {metal}"
        overall = f"{initial} + {_electrons(total)} → {metal}"
        p1, given = self.first_potential, self.known_potential
        wrong: list[Fraction | int]
        if self.unknown == "step":
            tested = half2
            known_reaction = overall
            correct = Fraction(total * given - first * p1, second)
            wrong = [
                given - p1,
                2 * given - p1,
                Fraction(total * given - second * p1, first),
                Fraction(given + p1, 2),
                Fraction(total * given + first * p1, second),
                -correct,
            ]
        else:
            tested = overall
            known_reaction = half2
            correct = Fraction(first * p1 + second * given, total)
            wrong = [
                Fraction(p1 + given, 2),
                p1 - given,
                Fraction(second * p1 + first * given, total),
                p1 + given,
                Fraction(first * p1 + second * given, 2),
                -correct,
            ]
        stem = (
            f"For a hypothetical element the standard reduction data are "
            f"{half1} ({_volts(p1)}) and {known_reaction} ({_volts(given)})."
        )
        rows = [(half1, p1), (known_reaction, given)]
        if self.comparison is None:
            if tabulated:
                stem = _reduction_table(rows)
            return _case(
                identifier,
                "12",
                f"{stem} Find E° for {tested}.",
                [_volts(x) for x in (correct, *wrong)],
            )

        other, reference = self.comparison
        reference_half = f"{other}²⁺ + 2e⁻ → {other}(s)"
        cathode = self.element if correct > reference else other
        anode = other if cathode == self.element else self.element
        if tabulated:
            rows.append((reference_half, reference))
            stem = _reduction_table(rows) + f" The couple {tested} forms a standard "
            stem += f"galvanic cell with {reference_half}."
        else:
            stem += (
                f" The couple {tested} forms a standard galvanic cell with "
                f"{reference_half} ({_volts(reference)})."
            )
        stem += (
            " Select the target E° and identify which couple is reduced at the cathode."
        )
        # Both results matter. The first two wrong pairs retain one correct
        # component each and the third completes the two-by-two contrast.
        pairs = [
            (correct, cathode),
            (wrong[0], cathode),
            (correct, anode),
            (wrong[0], anode),
            (wrong[1], cathode),
            (wrong[1], anode),
            (wrong[2], anode),
        ]
        return _case(
            identifier,
            "12",
            stem,
            [f"{_volts(potential)}, {couple} couple" for potential, couple in pairs],
        )


def _charge(charge: int) -> str:
    return "⁺" if charge == 1 else str(charge).translate(_SUPERSCRIPT) + "⁺"


def _electrons(amount: int) -> str:
    return "e⁻" if amount == 1 else f"{amount}e⁻"


def _reduction_table(rows: list[tuple[str, int]]) -> str:
    header = (
        "Use the standard reduction data below.\n\n"
        "| Standard reduction half-equation | E° / V |\n"
        "| --- | --- |\n"
    )
    return (
        header
        + "\n".join(
            f"| {equation} | {_volts(potential).removesuffix(' V')} |"
            for equation, potential in rows
        )
        + "\n\n"
    )


def _cell(
    identifier: str, cathode: str, cathode_e: int, anode: str, anode_e: int
) -> ConceptContext:
    difference = cathode_e - anode_e
    stem = (
        f"The {cathode} electrode is the cathode with E°red = {_volts(cathode_e)}. "
        f"The {anode} electrode is the anode with E°red = {_volts(anode_e)}. "
        "What is the standard cell potential?"
    )
    return _case(
        identifier,
        "12",
        stem,
        [
            _volts(value)
            for value in (
                difference,
                -difference,
                cathode_e + anode_e,
                2 * difference,
                cathode_e,
                anode_e,
                Fraction(cathode_e + anode_e, 2),
            )
        ],
    )


@dataclass(frozen=True)
class Salt:
    solid: str
    cation: str
    anion: str
    anions: int

    @property
    def dissolution(self) -> str:
        coefficient = "" if self.anions == 1 else str(self.anions)
        return f"{self.solid}(s) ⇌ {self.cation}(aq) + {coefficient}{self.anion}(aq)"

    def solubility_case(
        self, identifier: str, given: str, target: Literal["ksp", "solubility"]
    ) -> ConceptContext:
        value = Decimal(given)
        power = 1 + self.anions
        factor = self.anions**self.anions
        stem = (
            f"For {self.dissolution}, assume pure water and use concentrations in "
            "place of activities. Ignore competing reactions."
        )
        with localcontext() as ctx:
            ctx.prec = 40
            if target == "ksp":
                stem += (
                    f" The molar solubility is {_scientific(value)}{_SOLUBILITY_UNIT}. "
                    "What is the numerical Ksp?"
                )
                concentration_power = value**power
                correct = factor * concentration_power
                wrong = [
                    value,
                    (self.anions + 1) * concentration_power,
                    correct * (self.anions + 2),
                    value ** (power + 1),
                    value / (self.anions + 1),
                    concentration_power / (self.anions + 1),
                ]
                unit = ""
            else:
                stem += (
                    f" The numerical Ksp is {_scientific(value)}. "
                    "What is the molar solubility?"
                )
                root = Decimal(1) / power
                correct = (value / factor) ** root
                wrong = [
                    value / (self.anions + 1),
                    (value / (factor * 2)) ** root,
                    correct * (self.anions + 2),
                    value ** (Decimal(1) / (power + 1)),
                    (value * factor * 2) ** root,
                    value,
                ]
                unit = _SOLUBILITY_UNIT
        return _case(
            identifier,
            "10.2",
            stem + " Give the answer to two significant figures.",
            [_scientific(option) + unit for option in (correct, *wrong)],
        )

    def precipitation_case(
        self, identifier: str, cation: str, anion: str, ksp: str
    ) -> ConceptContext:
        a, b, limit = Decimal(cation), Decimal(anion), Decimal(ksp)
        product = a * b**self.anions
        status = "precipitate forms" if product > limit else "no precipitation"
        opposite = "no precipitation" if product > limit else "precipitate forms"
        stem = (
            f"For {self.dissolution}, just after mixing the dissolved ion "
            f"concentrations are [{self.cation}] = {_scientific(a)} and "
            f"[{self.anion}] = {_scientific(b)} mol dm⁻³, before any precipitation. "
            f"The numerical Ksp is {_scientific(limit)}. Use concentrations "
            "in place of activities and ignore competing reactions. What are the "
            "numerical ionic product Q (two significant figures) and the prediction?"
        )
        options = [
            (product, status),
            (a * b, status),
            (product, opposite),
            (a * b, opposite),
            (a**self.anions * b, status),
            (a**self.anions * b, opposite),
            (a * (b * self.anions) ** self.anions, opposite),
        ]
        return _case(
            identifier,
            "10.2",
            stem,
            [f"{_scientific(q)}, {result}" for q, result in options],
        )


def _scientific(value: Decimal) -> str:
    with localcontext() as ctx:
        ctx.rounding = ROUND_HALF_UP
        mantissa, exponent = format(value, ".1e").split("e")
    return f"{mantissa} × 10{str(int(exponent)).translate(_SUPERSCRIPT)}"


def _successive_reduction_cases(*, tabulated: bool = False) -> list[ConceptContext]:
    prefix = "calc-reduction-table" if tabulated else "calc-reduction"
    step = SuccessiveReduction("X", 1, 2, 80, 20, "step")
    overall = SuccessiveReduction("Y", 2, 1, 62, -16, "overall")
    return [
        step.context(f"{prefix}-medium-step", tabulated=tabulated),
        overall.context(f"{prefix}-medium-overall", tabulated=tabulated),
        SuccessiveReduction("X", 1, 2, 80, 20, "step", ("R", 3)).context(
            f"{prefix}-hard-step", tabulated=tabulated
        ),
        SuccessiveReduction("Y", 2, 1, 62, -16, "overall", ("T", 34)).context(
            f"{prefix}-hard-overall", tabulated=tabulated
        ),
    ]


def _half_life_case(
    identifier: str, start: int, end: int, initial: str, final: str
) -> ConceptContext:
    ratio = Fraction(initial) / Fraction(final)
    halvings = ratio.numerator.bit_length() - 1
    if halvings not in {1, 2} or ratio != 2**halvings:
        raise ValueError("Expected one or two complete halvings in the supplied data")
    elapsed = end - start
    half_life = Fraction(elapsed, halvings)
    options = [
        half_life,
        start,
        end,
        Fraction(elapsed, 3 - halvings),
        half_life / 3,
        start + end,
        3 * elapsed,
    ]
    stem = (
        "The disappearance of A follows first-order kinetics. "
        f"At t = {start} s, [A] = {initial} mol dm⁻³. "
        f"At t = {end} s, [A] = {final} mol dm⁻³. What is the half-life?"
    )
    return _case(identifier, "8", stem, [f"{value:g} s" for value in options])


def assessment_cases() -> list[ConceptContext]:
    return [
        *(
            _case(
                identifier,
                "4",
                f"Consider {acid} + H₂O ⇌ {base} + H₃O⁺. "
                f"The indicated acid is {acid}. Which species is its conjugate base?",
                [base, acid, "H₃O⁺", "H₂O", "OH⁻", "H⁺", "Cl⁻"],
            )
            for identifier, (acid, base, _) in CONJUGATE_INPUTS.items()
        ),
        _half_life_case(HALF_LIFE_CASES[0], 10, 25, "0.80", "0.40"),
        _half_life_case(HALF_LIFE_CASES[1], 12, 48, "0.96", "0.24"),
        *_successive_reduction_cases(tabulated=True),
    ]


def calculation_cases() -> list[ConceptContext]:
    sulfate = Salt("CaSO₄", "Ca²⁺", "SO₄²⁻", 1)
    fluoride = Salt("CaF₂", "Ca²⁺", "F⁻", 2)
    return [
        *_successive_reduction_cases(),
        *(_cell(identifier, *inputs) for identifier, inputs in CELL_INPUTS.items()),
        sulfate.solubility_case("calc-solubility-equal-ksp", "0.0050", "ksp"),
        sulfate.solubility_case(
            "calc-solubility-equal-solubility",
            KSP_INPUTS["calc-solubility-equal-solubility"],
            "solubility",
        ),
        fluoride.solubility_case("calc-solubility-double-ksp", "0.00024", "ksp"),
        fluoride.solubility_case(
            "calc-solubility-double-solubility",
            KSP_INPUTS["calc-solubility-double-solubility"],
            "solubility",
        ),
        fluoride.precipitation_case(
            "calc-precipitate-forms",
            "0.00020",
            "0.00050",
            KSP_INPUTS["calc-precipitate-forms"],
        ),
        fluoride.precipitation_case(
            "calc-precipitate-absent",
            "0.00010",
            "0.00020",
            KSP_INPUTS["calc-precipitate-absent"],
        ),
    ]
