"""Versioned, application-owned H2 textbook contexts and misconception choices."""

import hashlib
import json
import re
from functools import lru_cache
from importlib import resources
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from edcraft_validator.domains.chemistry.calculation_cases import (
    assessment_cases,
    calculation_cases,
)
from edcraft_validator.domains.chemistry.calculation_requests import (
    calculation_skill_cases,
)
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest

CONCEPT_CATALOGUE_VERSION = "chem-h2-9476-concepts/0.1"
SKILL_CATALOGUE_VERSION = "chem-h2-9476-concepts/0.2"
CALCULATION_CATALOGUE_VERSION = "chem-h2-9476-concepts/0.3"
ASSESSMENT_CATALOGUE_VERSION = "chem-h2-9476-concepts/0.4"
CONCEPT_CATALOGUE_VERSIONS = frozenset(
    {
        CONCEPT_CATALOGUE_VERSION,
        SKILL_CATALOGUE_VERSION,
        CALCULATION_CATALOGUE_VERSION,
        ASSESSMENT_CATALOGUE_VERSION,
    }
)
_Text = Annotated[str, Field(min_length=1, max_length=500)]
_SKILL_REQUEST = re.compile(
    r"^\s*(?:Singapore\s+)?H2\s+skill\s+(\d+[a-z0-9.-]*-\d+)\b", re.I
)


def answer_identity(value: str) -> str:
    return " ".join(value.casefold().replace("−", "-").rstrip(".").split())


class ConceptContext(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    id: str = Field(pattern=r"^[a-z0-9-]+$", max_length=64)
    family: str = Field(pattern=r"^[a-z0-9_]+$", max_length=64)
    topic: str = Field(pattern=r"^\d+(\.\d+)?$")
    topic_title: _Text
    question: _Text
    answer: _Text
    alternatives: list[_Text] = Field(min_length=3, max_length=6)

    @model_validator(mode="after")
    def require_distinct_choices(self) -> "ConceptContext":
        identities = {
            answer_identity(value) for value in (self.answer, *self.alternatives)
        }
        if "" in identities or len(identities) != len(self.alternatives) + 1:
            raise ValueError("concept catalogue choices must be nonempty and distinct")
        return self


class ConceptSkill(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    id: str = Field(pattern=r"^[a-z0-9.-]+$", max_length=64)
    reference: str = Field(pattern=r"^[a-z0-9.-]+$", max_length=64)
    family: str = Field(pattern=r"^[a-z0-9_]+$", max_length=64)
    label: _Text
    mode: Literal["selection", "performance", "umbrella"]
    scope: _Text
    limitation: str = Field(max_length=500)
    contexts: list[str] = Field(max_length=2)

    @model_validator(mode="after")
    def check_assessment_mode(self) -> "ConceptSkill":
        if self.mode == "selection" and len(set(self.contexts)) != 2:
            raise ValueError(f"skill {self.id!r} needs two different contexts")
        if self.mode != "selection" and self.contexts:
            raise ValueError(f"skill {self.id!r} does not directly generate an MCQ")
        return self


class SkillCatalogue(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    skills: list[ConceptSkill]
    contexts: list[ConceptContext]

    @model_validator(mode="after")
    def check_skill_contexts(self) -> "SkillCatalogue":
        ids = [skill.id for skill in self.skills]
        if len(ids) != len(set(ids)):
            raise ValueError("skill IDs must be unique")
        expected = [
            (context_id, skill.family)
            for skill in self.skills
            for context_id in skill.contexts
        ]
        actual = [(context.id, context.family) for context in self.contexts]
        if sorted(expected) != sorted(actual) or len(
            {context_id for context_id, _ in actual}
        ) != len(actual):
            raise ValueError(
                "each skill context must belong to one declared family and skill"
            )
        return self


@lru_cache(maxsize=1)
def load_skill_catalogue() -> tuple[SkillCatalogue, bytes]:
    payload = resources.files(__package__).joinpath("skill_bank.json").read_bytes()
    return SkillCatalogue.model_validate_json(payload), payload


@lru_cache(maxsize=4)
def load_concepts(
    version: str = CONCEPT_CATALOGUE_VERSION,
) -> tuple[dict[str, ConceptContext], str]:
    from pydantic import TypeAdapter

    payload = resources.files(__package__).joinpath("concepts.json").read_bytes()
    records = TypeAdapter(list[ConceptContext]).validate_json(payload)
    if version not in CONCEPT_CATALOGUE_VERSIONS:
        raise ValueError(f"Unknown concept catalogue version {version!r}")
    digest = hashlib.sha256(payload)
    if version != CONCEPT_CATALOGUE_VERSION:
        bank, extension = load_skill_catalogue()
        records += bank.contexts
        digest.update(b"\0" + extension)
    if version in {CALCULATION_CATALOGUE_VERSION, ASSESSMENT_CATALOGUE_VERSION}:
        calculated = calculation_cases()
        records += calculated
        digest.update(concept_snapshot_digest(version, calculated).encode())
    if version == ASSESSMENT_CATALOGUE_VERSION:
        assessed = assessment_cases()
        records += assessed
        digest.update(b"\0" + concept_snapshot_digest(version, assessed).encode())
    entries = {record.id: record for record in records}
    if len(entries) != len(records):
        raise ValueError("concept context ids must be unique")
    return entries, digest.hexdigest()


def resolve_contexts(family: str, ids: list[str]) -> list[ConceptContext]:
    catalogue, _ = load_concepts(ASSESSMENT_CATALOGUE_VERSION)
    contexts = []
    for context_id in ids:
        entry = catalogue.get(context_id)
        if entry is None or entry.family != family:
            raise ValueError(
                f"Unknown concept context {context_id!r} for family {family!r}"
            )
        contexts.append(entry)
    return contexts


def _skill_by_id(skill_id: str) -> ConceptSkill | None:
    bank, _ = load_skill_catalogue()
    return next((skill for skill in bank.skills if skill.id == skill_id), None)


def resolve_proposal_family(family: str, ids: list[str]) -> str:
    """Accept an exact selectable skill ID as an alias on a new proposal."""
    skill = _skill_by_id(family)
    if skill is not None:
        eligible = set(skill.contexts) | set(calculation_skill_cases(skill.id))
        if skill.mode != "selection" or not set(ids) <= eligible:
            raise ValueError(
                f"Concept proposal contexts must belong to skill {family!r}"
            )
        family = skill.family
    resolve_contexts(family, ids)
    return family


def concept_catalogue_version(ids: list[str]) -> str:
    legacy, _ = load_concepts()
    if all(context_id in legacy for context_id in ids):
        return CONCEPT_CATALOGUE_VERSION
    skill_cases, _ = load_concepts(SKILL_CATALOGUE_VERSION)
    if all(context_id in skill_cases for context_id in ids):
        return SKILL_CATALOGUE_VERSION
    calculated, _ = load_concepts(CALCULATION_CATALOGUE_VERSION)
    if all(context_id in calculated for context_id in ids):
        return CALCULATION_CATALOGUE_VERSION
    return ASSESSMENT_CATALOGUE_VERSION


def concept_snapshot_digest(version: str, contexts: list[ConceptContext]) -> str:
    if version == CONCEPT_CATALOGUE_VERSION:
        return load_concepts()[1]
    if version not in CONCEPT_CATALOGUE_VERSIONS:
        raise ValueError(f"Unknown concept catalogue version {version!r}")
    # Adding unrelated questions must not change an existing artifact's identity.
    payload = json.dumps(
        [context.model_dump(mode="json") for context in contexts],
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def requested_skill(prompt: str) -> ConceptSkill | None:
    match = _SKILL_REQUEST.match(prompt)
    if match is None:
        return None
    skill_id = match[1].lower().rstrip(".")
    skill = _skill_by_id(skill_id)
    if skill is None:
        raise ValueError(f"Unknown 9476 skill {skill_id!r}")
    if skill.mode == "umbrella":
        raise ValueError(f"Choose a specific skill under {skill.reference}.")
    if skill.mode != "selection":
        raise UnsupportedAuthoringRequest(
            f"Skill {skill_id!r} needs assessment beyond this MCQ. {skill.limitation}"
        )
    return skill
