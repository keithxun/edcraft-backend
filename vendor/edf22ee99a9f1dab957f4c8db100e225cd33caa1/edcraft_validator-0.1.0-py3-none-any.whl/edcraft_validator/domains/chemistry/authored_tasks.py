"""Model-authored chemistry tasks over explicit formula and reaction data."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from typing import Annotated, Any, Literal

from fastmcp import FastMCP
from pydantic import BaseModel, BeforeValidator, ConfigDict, Field

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domain_types import MAX_DISTRACTORS, Difficulty
from edcraft_validator.domains.chemistry.balance import BalanceError, balance_equation
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    ChemistryQuestionInstance,
    StructuredEquation,
)
from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_COEFFICIENT,
    MAX_FORMULA_LENGTH,
    MAX_SPECIES,
    MAX_SUBSCRIPT,
)
from edcraft_validator.domains.chemistry.difficulty import (
    CHEMISTRY_H2_DIFFICULTY_RUBRIC_ID,
)
from edcraft_validator.domains.chemistry.elements import ELEMENT_SYMBOLS
from edcraft_validator.domains.chemistry.formula import (
    FormulaError,
    canonical_formula,
    parse_formula,
)
from edcraft_validator.domains.chemistry.options import (
    format_equation,
    structured_equation,
)
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    TemplateRequest,
    build_review_view,
    build_template_id,
    content_sha256,
    require_checked,
    require_type,
    save_checked_evidence,
    seeded_index,
)
from edcraft_validator.domains.operation_intent import require_operation_intent
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.mcp.tool_dependencies import ToolDependencies
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.property_summary import (
    PropertyCheckSummary,
    property_details,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

TOOL = "chemistry_verify_authored_task"
TOOL_SCOPE = "chemistry-authored"
VERSION: Literal["chemistry-authored/1.0"] = "chemistry-authored/1.0"
CHECK_VERSION = "1.1.0"
MAX_GENERATION_TRIES = 32
MAX_RECIPES = MAX_DISTRACTORS + SURPLUS_RECIPES
Formula = Annotated[str, Field(min_length=1, max_length=MAX_FORMULA_LENGTH)]
Coefficient = Annotated[int, Field(ge=1, le=MAX_COEFFICIENT)]
Coefficients = Annotated[list[Coefficient], Field(min_length=2, max_length=MAX_SPECIES)]
AtomCount = Annotated[int, Field(ge=0, le=10_000_000)]
Amount = Annotated[str, Field(pattern=r"^(0|[1-9][0-9]{0,4})(\.[0-9]{1,3})?$")]
Assignment = dict[str, int | str]

_OPERATION_NAMES = {
    "balance_equation": "equation balancing",
    "parameterized_balance_equation": "equation balancing",
    "atom_count": "atom counting",
    "theoretical_yield": "theoretical yield",
}
_REQUEST_CUES = {
    "equation balancing": (
        r"\b(?:balance|balancing)\b[^.!?]{0,55}\b(?:equation|reaction)\b"
    ),
    "atom counting": r"\b(?:how many [A-Za-z ]{0,35}atoms|count(?:ing)? atoms)\b",
    "theoretical yield": r"\b(?:theoretical|product) yield\b",
}
_SOURCE_CUES = _REQUEST_CUES | {
    "equation balancing": (
        _REQUEST_CUES["equation balancing"]
        + r"|\b(?:equation balancing|balancing equations|conserv(?:e|ation of) "
        r"[^.!?]{0,40}atoms|complete combustion)\b"
    ),
    "atom counting": (
        _REQUEST_CUES["atom counting"] + r"|\b(?:counting atoms|atom count(?:ing)?)\b"
    ),
    "theoretical yield": r"\b(?:theoretical yield|limiting (?:reagent|reactant))\b",
}

_AUTHORING_PROMPT = """\
Author a reusable chemistry MCQ from explicit data you supply. The application
renders the givens and target and independently checks the proposed answer and
each distractor. Do not select a prewritten reaction or question family.

New templates must produce at least two visibly different problems across seeds.
For a general balancing request use parameterized_balance_equation. A single fixed
skeleton by itself cannot meet this requirement. If the teacher fixes all species
and requires that exact same balancing task, explain this limit.

For balance_equation, provide the neutral reactant and product formulas in order
without charges or state symbols, a proposed coefficient vector, and one vector per
candidate distractor. The stem presents a formal skeleton and asks for the smallest
positive whole-number coefficients. It makes no claim that the reaction occurs.

For parameterized_balance_equation, supply formula constructions and a repeat
count axis to make distinct skeletons from a single rule. Each formula is a list
of fixed text fragments and computed subscripts. A fixed formula such as O2 can
also be supplied as a string. Each coefficient or computed
subscript is (factor * repeat_count + offset) / divisor and must be a positive
integer. A computed subscript of 1 is omitted in the displayed formula. Use this
operation when the request allows homologous or structurally variable skeletons.
Provide one coefficient recipe per species in each option, in display order.

For atom_count, supply the neutral formula, element symbol and formula-unit count
values. Provide the proposed and wrong element counts per formula unit. The app
multiplies each by the displayed count. Vary counts when the request permits.

For theoretical_yield, provide exactly two neutral reactants, the products, the
balanced coefficients in display order, and a one-based product index. The stem
shows the equation, initial reactant amounts, and assumes completion without side
reactions. Supply decimal-string amount axes in one unit (mol or mmol). Each
recipe divides the two amounts by first_divisor and second_divisor, combines the
results using extent, multiplies by multiplier, then adds offset. Use minimum,
the balanced reactant coefficients as divisors, the product coefficient as
multiplier, and offset 0 for the proposed key. Wrong choices must remain wrong
at the displayed precision as the limiting reagent changes and at tied extents.

Preserve the teacher's required inputs, conditions and target. When the task
requires a reaction-feasibility claim, another chemistry operation, a diagram,
or a response format these operations cannot express, return kind unsupported.
Name the missing independent check in one sentence under 300 characters.
"""


class _Record(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class BalanceTask(_Record):
    kind: Literal["balance_equation"]
    reactants: list[Formula] = Field(min_length=1, max_length=MAX_SPECIES - 1)
    products: list[Formula] = Field(min_length=1, max_length=MAX_SPECIES - 1)
    proposed_coefficients: Coefficients
    distractor_coefficients: list[Coefficients] = Field(
        min_length=1, max_length=MAX_RECIPES
    )


class IntegerRecipe(_Record):
    factor: int = Field(ge=-99, le=99)
    offset: int = Field(ge=-999, le=999)
    divisor: Coefficient

    def evaluate(self, repeat: int, *, maximum: int) -> int:
        value = Fraction(self.factor * repeat + self.offset, self.divisor)
        if value.denominator != 1 or not 1 <= value <= maximum:
            raise ValidationFailure(
                f"Recipe gives {value} at repeat count {repeat}; expected a positive "
                f"integer at most {maximum}.",
                code="CHEM_AUTHORED_RECIPE_DOMAIN",
            )
        return int(value)


FormulaPart = (
    Annotated[str, Field(min_length=1, max_length=MAX_FORMULA_LENGTH)] | IntegerRecipe
)
FormulaParts = Annotated[list[FormulaPart], Field(min_length=1, max_length=8)]


def _formula_parts(value: object) -> object:
    """Store a fixed formula and a parameterized formula in the same representation."""
    return [value] if isinstance(value, str) else value


ConstructedFormula = Annotated[
    FormulaParts,
    BeforeValidator(_formula_parts, json_schema_input_type=Formula | FormulaParts),
]
CoefficientRecipes = Annotated[
    list[IntegerRecipe], Field(min_length=2, max_length=MAX_SPECIES)
]


class ParameterizedBalanceTask(_Record):
    kind: Literal["parameterized_balance_equation"]
    reactants: list[ConstructedFormula] = Field(
        min_length=1, max_length=MAX_SPECIES - 1
    )
    products: list[ConstructedFormula] = Field(min_length=1, max_length=MAX_SPECIES - 1)
    repeat_counts: list[Annotated[int, Field(ge=1, le=50)]] = Field(
        min_length=2, max_length=24
    )
    proposed_coefficients: CoefficientRecipes
    distractor_coefficients: list[CoefficientRecipes] = Field(
        min_length=1, max_length=MAX_RECIPES
    )


class AtomCountTask(_Record):
    kind: Literal["atom_count"]
    formula: Formula
    element: str = Field(pattern=r"^[A-Z][a-z]?$")
    molecule_counts: list[Annotated[int, Field(ge=1, le=1_000_000)]] = Field(
        min_length=1, max_length=32
    )
    proposed_atoms_per_molecule: AtomCount
    distractor_atoms_per_molecule: list[AtomCount] = Field(
        min_length=1, max_length=MAX_RECIPES
    )


class YieldRecipe(_Record):
    extent: Literal["minimum", "maximum", "first", "second", "sum"]
    first_divisor: Coefficient
    second_divisor: Coefficient
    multiplier: Amount
    offset: Amount

    def evaluate(self, first: Fraction, second: Fraction) -> Fraction:
        a, b = first / self.first_divisor, second / self.second_divisor
        extent = {
            "minimum": min(a, b),
            "maximum": max(a, b),
            "first": a,
            "second": b,
            "sum": a + b,
        }
        return extent[self.extent] * Fraction(self.multiplier) + Fraction(self.offset)


class YieldTask(_Record):
    kind: Literal["theoretical_yield"]
    reactants: list[Formula] = Field(min_length=2, max_length=2)
    products: list[Formula] = Field(min_length=1, max_length=MAX_SPECIES - 2)
    proposed_balanced_coefficients: Coefficients
    product_index: int = Field(ge=1, le=MAX_SPECIES - 2)
    first_amounts: list[Amount] = Field(min_length=1, max_length=24)
    second_amounts: list[Amount] = Field(min_length=1, max_length=24)
    unit: Literal["mol", "mmol"]
    decimals: int = Field(ge=0, le=6)
    proposed_answer: YieldRecipe
    distractors: list[YieldRecipe] = Field(min_length=1, max_length=MAX_RECIPES)


class UnsupportedTask(_Record):
    kind: Literal["unsupported"]
    reason: str = Field(min_length=1, max_length=400)


Task = Annotated[
    BalanceTask | ParameterizedBalanceTask | AtomCountTask | YieldTask,
    Field(discriminator="kind"),
]


class ChemistryTaskProposal(_Record):
    item: Annotated[
        BalanceTask
        | ParameterizedBalanceTask
        | AtomCountTask
        | YieldTask
        | UnsupportedTask,
        Field(discriminator="kind"),
    ]


class ChemistryTaskCandidate(_Record):
    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]*$")
    difficulty: Difficulty
    question_type: Literal["mcq"] = "mcq"
    item: Task


class ValidatedChemistryTask(ValidatedTemplateArtifact):
    model_config = ConfigDict(extra="forbid", strict=True)

    format_version: Literal["chemistry-authored/1.0"] = VERSION
    template: ChemistryTaskCandidate
    validation: PropertyCheckSummary


class ChemistryTaskDomain:
    name = "chemistry"
    tool_scope = TOOL_SCOPE
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )
    request_model = TemplateRequest
    candidate_model = ChemistryTaskCandidate
    validated_model = ValidatedChemistryTask
    question_model = ChemistryQuestionInstance
    template_language = None
    requires_visible_variants = True

    def register_tools(self, server: FastMCP, dependencies: ToolDependencies) -> None:
        register_authored_chemistry_tool(server)

    def generation_request(self, request: BaseModel) -> StructuredGenerationRequest:
        request = require_type(request, TemplateRequest)
        return StructuredGenerationRequest(
            messages=[
                {
                    "role": "system",
                    "content": (
                        _AUTHORING_PROMPT + f"\nSelect {TOOL} with empty arguments."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Author request: {request.prompt}\n"
                        f"Requested difficulty: {request.difficulty}\n"
                        f"Author exactly {request.num_distractors + SURPLUS_RECIPES} "
                        "candidate distractor recipes. "
                        f"The app selects {request.num_distractors}."
                    ),
                },
            ],
            response_model=PlannedGenerationResponse[ChemistryTaskProposal],
            prompt_version="chemistry-authored-task-v1",
            schema_name="template_proposal_and_check_plan",
            revise_from_authored_pool=True,
        )

    def build_candidate(
        self, request: BaseModel, proposal: BaseModel
    ) -> ChemistryTaskCandidate:
        request = require_type(request, TemplateRequest)
        proposal = require_type(proposal, ChemistryTaskProposal)
        if isinstance(proposal.item, UnsupportedTask):
            raise UnsupportedAuthoringRequest(proposal.item.reason)
        require_operation_intent(
            request,
            _OPERATION_NAMES[proposal.item.kind],
            request_cues=_REQUEST_CUES,
            source_cues=_SOURCE_CUES,
        )
        item = _select_distractors(proposal.item, request.num_distractors)
        return ChemistryTaskCandidate(
            template_id=build_template_id(self.name, request, proposal),
            difficulty=request.difficulty,
            item=item,
        )

    def tool_bindings(
        self, request: BaseModel, candidate: BaseModel, tool_name: str
    ) -> dict[str, Any]:
        candidate = require_type(candidate, ChemistryTaskCandidate)
        request = require_type(request, TemplateRequest)
        if tool_name in {TEMPLATE_RELEVANCE_CHECK, TEMPLATE_DIFFICULTY_CHECK}:
            inputs, _, choices, _, _ = _seeded_variant(candidate, seed=31)
            question = _question(candidate.item, inputs)
            digest = content_sha256(candidate)
            if tool_name == TEMPLATE_DIFFICULTY_CHECK:
                return {
                    "rubric_id": CHEMISTRY_H2_DIFFICULTY_RUBRIC_ID,
                    "question_payload": json.dumps(
                        {"template": {"question": question, "choices": choices}}
                    ),
                    "distractor_count": len(choices) - 1,
                    "requested_difficulty": candidate.difficulty,
                    "subject_sha256": digest,
                }
            return {
                "author_request": request.prompt,
                "question_text": question,
                "subject_sha256": digest,
            }
        return {
            "candidate": candidate.model_dump(mode="json"),
            "num_distractors": request.num_distractors,
        }

    def distractor_count(self, candidate: BaseModel) -> int:
        return _number_of_distractors(
            require_type(candidate, ChemistryTaskCandidate).item
        )

    def required_checks(self, candidate: BaseModel) -> frozenset[str]:
        return frozenset({TOOL})

    def finalize_checked_template(
        self,
        candidate: BaseModel,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> ValidatedChemistryTask:
        candidate = require_type(candidate, ChemistryTaskCandidate)
        require_checked(
            evidence,
            required=self.required_checks(candidate),
            advisory_checks=advisory_checks,
        )
        digest = content_sha256(candidate)
        authority = next(item for item in evidence if item.tool == TOOL)
        if authority.details.get("subject_sha256") != digest:
            raise ValueError(
                "The verification evidence belongs to a different Chemistry draft"
            )
        saved = []
        for item in evidence:
            row = save_checked_evidence(item, digest, advisory_checks=advisory_checks)
            if item.tool == TOOL:
                row.details.update(
                    subject_sha256=digest,
                    operation=item.details["operation"],
                    method=item.details["method"],
                    boundary_cases=item.details["boundary_cases"],
                )
            saved.append(row)
        return ValidatedChemistryTask(
            template=candidate,
            validation=PropertyCheckSummary(
                **property_details(authority.details), evidence=saved
            ),
        )

    def checked_tool_bindings(
        self,
        request: BaseModel,
        candidate: BaseModel,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, Any]:
        return self.tool_bindings(request, candidate, tool_name)

    def review_view(
        self, artifact: ValidatedTemplateArtifact
    ) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=self.template_language)
        if view is not None and isinstance(artifact, ValidatedChemistryTask):
            preview = self.generate_question(artifact, seed=0)
            view.case_previews = [
                ReviewCasePreview(
                    case_id=preview.reaction_id,
                    question=preview.question,
                    answer=preview.answer,
                    choices=preview.choices,
                    seed=0,
                )
            ]
        return view

    def generate_question(
        self, validated: BaseModel, *, seed: int
    ) -> ChemistryQuestionInstance:
        artifact = require_type(validated, ValidatedChemistryTask)
        template_id = artifact.template.template_id
        item = artifact.template.item
        inputs, key, choices, correct_index, structured = _seeded_variant(
            artifact.template, seed
        )
        return ChemistryQuestionInstance(
            template_id=template_id,
            artifact_id=artifact.artifact_id,
            seed=seed,
            parameters={name: str(value) for name, value in inputs.items()},
            reaction_id=item.kind,
            question=_question(item, inputs),
            choices=choices,
            correct_index=correct_index,
            answer=key,
            choices_structured=structured,
        )


def register_authored_chemistry_tool(server: FastMCP) -> None:
    @server.tool(
        name=TOOL,
        version=CHECK_VERSION,
        tags={f"domain:{TOOL_SCOPE}", "validation:content", "validation:options"},
        annotations={"readOnlyHint": True, "openWorldHint": False},
        description=(
            "Independently derive an authored chemistry answer from the displayed "
            "formulas and givens using atom conservation, exact composition or "
            "limiting extent. Compare the proposed key and each distractor."
        ),
    )
    async def verify_authored_task(
        candidate: ChemistryTaskCandidate, num_distractors: int
    ) -> ToolEvidence:
        return _verify_task(candidate, num_distractors)


def _seeded_variant(
    candidate: ChemistryTaskCandidate, seed: int
) -> tuple[Assignment, str, list[str], int, list[StructuredEquation] | None]:
    item, template_id = candidate.item, candidate.template_id
    axes = _axes(item)
    for attempt in range(MAX_GENERATION_TRIES if axes else 1):
        inputs = {
            name: values[
                seeded_index(template_id, seed, f"{name}/{attempt}", len(values))
            ]
            for name, values in axes.items()
        }
        try:
            key, choices, structured = _evaluate(item, inputs)
        except (BalanceError, FormulaError, ValidationFailure):
            continue
        index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
        choices.insert(index, key)
        if structured is not None:
            structured.insert(index, structured.pop(0))
        return inputs, key, choices, index, structured
    raise ValueError(
        "No independently valid Chemistry question was found for this seed."
    )


def _axes(item: Task) -> dict[str, list[int | str]]:
    if isinstance(item, ParameterizedBalanceTask):
        return {"repeat_count": sorted(item.repeat_counts)}
    if isinstance(item, AtomCountTask):
        return {"molecule_count": sorted(item.molecule_counts)}
    if isinstance(item, YieldTask):
        return {
            "first_amount": sorted(item.first_amounts, key=Fraction),
            "second_amount": sorted(item.second_amounts, key=Fraction),
        }
    return {}


def _distractor_field(item: Task) -> str:
    if isinstance(item, BalanceTask | ParameterizedBalanceTask):
        return "distractor_coefficients"
    if isinstance(item, AtomCountTask):
        return "distractor_atoms_per_molecule"
    return "distractors"


def _number_of_distractors(item: Task) -> int:
    return len(getattr(item, _distractor_field(item)))


def _select_distractors(item: Task, requested: int) -> Task:
    field = _distractor_field(item)
    recipes = getattr(item, field)
    if len(recipes) != requested + SURPLUS_RECIPES:
        raise DistractorPoolError(
            f"Author exactly {requested + SURPLUS_RECIPES} distractor recipes."
        )

    def row(
        inputs: Assignment,
    ) -> tuple[OptionValue, list[OptionValue | UnusableOption]]:
        key, _, wrong = _answer_values(item, inputs)
        return key, wrong

    try:
        axes = _axes(item)
        _check_parameters(item, axes)
        assignments = sample_assignments(axes)
        chosen = select_fixed_subset(
            (row(inputs) for inputs in assignments), requested, assignments=assignments
        )
    except (BalanceError, FormulaError, ValidationFailure):
        # Let the required check explain invalid formulas and amounts.
        chosen = tuple(range(requested))
    return item.model_copy(update={field: [recipes[index] for index in chosen]})


def _check_parameters(item: Task, axes: dict[str, list[int | str]]) -> None:
    if any(len(set(map(Fraction, values))) != len(values) for values in axes.values()):
        raise ValidationFailure(
            "Declare distinct numeric parameter values.",
            code="CHEM_AUTHORED_PARAMETER_DUPLICATE",
        )

    if isinstance(item, ParameterizedBalanceTask) and not any(
        isinstance(part, IntegerRecipe) and part.factor
        for formula in [*item.reactants, *item.products]
        for part in formula
    ):
        raise ValidationFailure(
            "At least one displayed formula must vary with the repeat count.",
            code="CHEM_AUTHORED_UNUSED_PARAMETER",
        )


def _question(item: Task, inputs: Assignment) -> str:
    if isinstance(item, BalanceTask | ParameterizedBalanceTask):
        reactants, products = _reaction(item, inputs)
        skeleton = format_equation(
            reactants, products, [1] * (len(reactants) + len(products))
        )
        return (
            f"Treat {skeleton} as a reaction skeleton with the species shown. Which "
            "equation balances it using the smallest positive whole-number "
            "coefficients?"
        )
    if isinstance(item, YieldTask):
        equation = format_equation(
            item.reactants, item.products, item.proposed_balanced_coefficients
        )
        first, second = map(canonical_formula, item.reactants)
        product = canonical_formula(item.products[item.product_index - 1])
        places = "place" if item.decimals == 1 else "places"
        return (
            f"Suppose a reaction follows the balanced equation {equation}. "
            f"Initially there are {inputs['first_amount']} {item.unit} of {first} and "
            f"{inputs['second_amount']} {item.unit} of {second}. Assume the reaction "
            "goes to completion with no side reactions. What is the theoretical amount "
            f"of {product} formed? Give your answer in {item.unit} to "
            f"{item.decimals} decimal {places}."
        )
    count = inputs["molecule_count"]
    formula = canonical_formula(item.formula)
    if count == 1:
        return f"How many {item.element} atoms are in one formula unit of {formula}?"
    return f"How many {item.element} atoms are in {count} formula units of {formula}?"


def _verify_task(
    candidate: ChemistryTaskCandidate, requested_distractors: int
) -> ToolEvidence:
    started = time.perf_counter()
    item = candidate.item
    axes = _axes(item)
    minima = {name: values[0] for name, values in axes.items()}
    maxima = {name: values[-1] for name, values in axes.items()}
    boundaries = [
        minima,
        maxima,
        *(minima | {name: value} for name, value in maxima.items()),
    ]
    boundary = list({tuple(row.items()): row for row in boundaries}.values())
    run = PropertyCheckRun(
        PropertyCheckSettings(
            timeout_seconds=5,
            max_examples=PropertyCheckSettings().max_examples - len(boundary),
        )
    )
    method = {
        "balance_equation": "Unique positive primitive integer atom balance",
        "parameterized_balance_equation": (
            "Expanded formulas and exact primitive atom balance"
        ),
        "atom_count": "Parsed element count times the displayed formula-unit count",
        "theoretical_yield": (
            "Verified equation and minimum reactant extent times product coefficient"
        ),
    }[item.kind]

    def check(inputs: Assignment, budget: PropertyCheckRun) -> None:
        budget.reserve_execution()
        try:
            if _number_of_distractors(item) != requested_distractors:
                raise ValidationFailure(
                    f"Author exactly {requested_distractors} distractors.",
                    code="CHEM_AUTHORED_DISTRACTOR_COUNT",
                )
            _evaluate(item, inputs)
            _question(item, inputs)
        except (BalanceError, FormulaError) as exc:
            raise ValidationFailure(
                str(exc), code=exc.code, context={"inputs": inputs}
            ) from exc
        except ValidationFailure as exc:
            exc.context["inputs"] = inputs
            raise

    status: Literal["passed", "failed", "error"] = "passed"
    findings = []
    failure_context: dict[str, Any] = {}
    try:
        _check_parameters(item, axes)
        run.check(axes, boundary, check)
    except ValidationFailure as exc:
        status = "error" if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" else "failed"
        findings.append(ToolFinding(code=exc.code, message=str(exc)))
        failure_context = exc.context
    return ToolEvidence(
        tool=TOOL,
        version=CHECK_VERSION,
        status=status,
        details={
            **run.details(),
            "subject_sha256": content_sha256(candidate),
            "operation": item.kind,
            "method": method,
            "boundary_cases": boundary,
            "failure_context": failure_context,
        },
        findings=findings,
        duration_ms=(time.perf_counter() - started) * 1000,
    )


def _answer_values(
    item: Task, inputs: Assignment
) -> tuple[
    OptionValue, int | tuple[int, ...] | Fraction, list[OptionValue | UnusableOption]
]:
    if isinstance(item, AtomCountTask):
        if item.element not in ELEMENT_SYMBOLS:
            raise ValidationFailure(
                f"Unknown element symbol {item.element!r}.",
                code="CHEM_FORMULA_UNKNOWN_ELEMENT",
            )
        count = int(inputs["molecule_count"])
        canonical = parse_formula(item.formula).get(item.element, 0) * count
        proposed = item.proposed_atoms_per_molecule * count
        options = [answer * count for answer in item.distractor_atoms_per_molecule]
        return (
            OptionValue(canonical, str(canonical)),
            proposed,
            [OptionValue(n, str(n)) for n in options],
        )

    reactants, products = _reaction(item, inputs)
    canonical_vector = balance_equation(reactants, products).coefficients
    if isinstance(item, YieldTask):
        return _yield_values(item, inputs, canonical_vector)

    def equation(
        recipe: list[int] | list[IntegerRecipe],
    ) -> OptionValue | UnusableOption:
        if len(recipe) != len(canonical_vector):
            return UnusableOption(
                "requires exactly one coefficient per displayed species"
            )
        try:
            coefficients = _expand_coefficients(recipe, inputs)
        except ValidationFailure as error:
            return UnusableOption(str(error))
        return OptionValue(
            coefficients, format_equation(reactants, products, coefficients)
        )

    key = OptionValue(
        canonical_vector,
        format_equation(reactants, products, canonical_vector),
    )
    wrong = [equation(recipe) for recipe in item.distractor_coefficients]
    return key, _expand_coefficients(item.proposed_coefficients, inputs), wrong


def _reaction(
    item: BalanceTask | ParameterizedBalanceTask | YieldTask, inputs: Assignment
) -> tuple[list[str], list[str]]:
    if not isinstance(item, ParameterizedBalanceTask):
        return item.reactants, item.products
    repeat_count = int(inputs["repeat_count"])

    def expand(formula: list[FormulaPart]) -> str:
        text = []
        for part in formula:
            if isinstance(part, str):
                text.append(part)
            else:
                count = part.evaluate(repeat_count, maximum=MAX_SUBSCRIPT)
                if count != 1:
                    text.append(str(count))
        return "".join(text)

    return [expand(formula) for formula in item.reactants], [
        expand(formula) for formula in item.products
    ]


def _expand_coefficients(
    recipe: list[int] | list[IntegerRecipe], inputs: Assignment
) -> tuple[int, ...]:
    return tuple(
        value
        if isinstance(value, int)
        else value.evaluate(int(inputs["repeat_count"]), maximum=MAX_COEFFICIENT)
        for value in recipe
    )


def _yield_values(
    item: YieldTask, inputs: Assignment, coefficients: tuple[int, ...]
) -> tuple[OptionValue, Fraction, list[OptionValue | UnusableOption]]:
    if tuple(item.proposed_balanced_coefficients) != coefficients:
        raise ValidationFailure(
            f"The displayed balanced coefficients must be {coefficients}.",
            code="CHEM_AUTHORED_EQUATION_MISMATCH",
        )
    if item.product_index > len(item.products):
        raise ValidationFailure(
            "The product index is out of bounds.", code="CHEM_AUTHORED_PRODUCT_INDEX"
        )
    a, b = (Fraction(inputs[name]) for name in ("first_amount", "second_amount"))
    if a <= 0 or b <= 0:
        raise ValidationFailure(
            "Both starting amounts must be positive.",
            code="CHEM_AUTHORED_AMOUNT_DOMAIN",
        )
    canonical = (
        min(a / coefficients[0], b / coefficients[1])
        * coefficients[1 + item.product_index]
    )

    def option(value: Fraction) -> OptionValue:
        scale = 10**item.decimals
        rounded = int(value * scale + Fraction(1, 2))
        whole, fractional = divmod(rounded, scale)
        number = (
            f"{whole}.{fractional:0{item.decimals}d}" if item.decimals else str(whole)
        )
        return OptionValue(value, f"{number} {item.unit}")

    wrong: list[OptionValue | UnusableOption] = [
        option(recipe.evaluate(a, b)) for recipe in item.distractors
    ]
    return option(canonical), item.proposed_answer.evaluate(a, b), wrong


def _evaluate(
    item: Task, inputs: Assignment
) -> tuple[str, list[str], list[StructuredEquation] | None]:
    key, proposed, distractors = _answer_values(item, inputs)
    if proposed != key.semantic:
        raise ValidationFailure(
            f"The proposed answer {proposed} differs from the independently "
            f"derived {key.semantic}.",
            code="CHEM_AUTHORED_KEY_MISMATCH",
        )
    options = [key]
    for wrong in distractors:
        if isinstance(wrong, UnusableOption):
            raise ValidationFailure(
                wrong.reason, code="CHEM_AUTHORED_DISTRACTOR_UNUSABLE"
            )
        if wrong.semantic == key.semantic or wrong.display == key.display:
            raise ValidationFailure(
                "A distractor is correct.", code="CHEM_AUTHORED_DISTRACTOR_EQUIVALENT"
            )
        if any(
            wrong.semantic == prior.semantic or wrong.display == prior.display
            for prior in options[1:]
        ):
            raise ValidationFailure(
                "Two distractors are equivalent.",
                code="CHEM_AUTHORED_DISTRACTOR_DUPLICATE",
            )
        options.append(wrong)
    structured = None
    if isinstance(item, BalanceTask | ParameterizedBalanceTask):
        reactants, products = _reaction(item, inputs)
        structured = [
            structured_equation(reactants, products, option.semantic)
            for option in options
        ]
    return key.display, [option.display for option in options[1:]], structured
