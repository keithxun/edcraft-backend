"""Pure recipe evaluation, option proof and rendering for chemistry.

Everything here is deterministic and free of property-check, catalogue and MCP
concerns: the checks, the seeded question generator and the tests all evaluate
the same recipes through these functions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import gcd
from typing import Any, Literal

from edcraft_validator.domains.chemistry.balance import (
    balance_equation,
    first_unbalanced_element,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    ChemistryItemSpec,
    EquationTerm,
    NormalisedCoefficientsRecipe,
    PerturbCoefficient,
    ReactionSnapshot,
    ScaleBalanced,
    SkeletonCoefficients,
    StructuredEquation,
    SwapCoefficients,
    SwapSpecies,
)
from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_COEFFICIENT,
    STEM_INSTRUCTION,
)
from edcraft_validator.domains.chemistry.formula import (
    canonical_formula,
    parse_formula,
)
from edcraft_validator.domains.chemistry.slots import (
    ASKED,
    parse_slot,
    slot_formula,
    slot_index,
)

Verdict = Literal["key", "wrong", "correct", "unusable", "duplicate"]

Recipe = (
    NormalisedCoefficientsRecipe
    | PerturbCoefficient
    | ScaleBalanced
    | SkeletonCoefficients
    | SwapCoefficients
    | SwapSpecies
)

OptionKey = tuple[tuple[int, str], ...] | int

_DUPLICATE_REASON: dict[str, Any] = {"code": "DUPLICATE_OPTION"}


@dataclass(frozen=True)
class OptionValue:
    """One concrete MCQ option and the deterministic verdict it earned.

    ``evaluate_recipe`` fills in ``coefficients``/``reactants``/``products`` or
    ``value`` and marks recipes that cannot yield a well-formed option. A
    provisional ``wrong`` verdict means "not the key yet still to be proved";
    ``prove_option`` turns it into the final verdict and reason.
    """

    verdict: Verdict
    reason: dict[str, Any] = field(default_factory=dict)
    coefficients: tuple[int, ...] | None = None
    reactants: tuple[str, ...] = ()
    products: tuple[str, ...] = ()
    value: int | None = None


def evaluate_recipe(
    recipe: Recipe,
    reaction: ReactionSnapshot,
    key: tuple[int, ...],
    asked_slot: str | None,
) -> OptionValue:
    """Return the concrete option a recipe yields for one reaction.

    The answer recipe yields the key. Recipes that cannot produce a well-formed
    option (a coefficient outside 1..99, or a ``swap_species`` equation without
    a unique balance) are ``unusable``. Every other option starts as a
    provisional ``wrong`` verdict for :func:`prove_option` to settle.
    """
    reactants = tuple(reaction.reactants)
    products = tuple(reaction.products)

    if isinstance(recipe, NormalisedCoefficientsRecipe):
        return OptionValue(
            verdict="key",
            coefficients=tuple(key),
            reactants=reactants,
            products=products,
            value=_asked_value(key, asked_slot, len(reactants)),
        )

    if isinstance(recipe, SwapSpecies):
        return _evaluate_swap_species(recipe, reaction)

    coefficients = _recipe_coefficients(recipe, key, asked_slot, len(reactants))
    return _from_coefficients(coefficients, reactants, products, asked_slot)


def prove_option(
    recipe: Recipe,
    reaction: ReactionSnapshot,
    key: tuple[int, ...],
    asked_slot: str | None,
) -> OptionValue:
    """Evaluate ``recipe`` and prove the verdict against the reaction key."""
    option = evaluate_recipe(recipe, reaction, key, asked_slot)
    if option.verdict in {"key", "unusable"}:
        return option
    if asked_slot is not None:
        return _prove_coefficient(option, key, asked_slot, len(reaction.reactants))
    return _prove_equation(option, reaction, key)


def option_key(option: OptionValue) -> OptionKey | None:
    """Return the canonical identity used to detect duplicate options."""
    if option.value is not None:
        return option.value
    if option.coefficients is None:
        return None
    # Identify species by composition so a respelling such as ``(O)`` for ``O``
    # cannot make two choices that state the same equation look distinct.
    formulas = [*option.reactants, *option.products]
    return tuple(
        (coefficient, _composition_key(formula))
        for coefficient, formula in zip(option.coefficients, formulas, strict=True)
    )


def _composition_key(formula: str) -> str:
    return ",".join(
        f"{element}{count}" for element, count in parse_formula(formula).items()
    )


def duplicate_reason() -> dict[str, Any]:
    """Return a fresh reason payload for an option duplicated by another."""
    return dict(_DUPLICATE_REASON)


def format_equation(
    reactants: tuple[str, ...] | list[str],
    products: tuple[str, ...] | list[str],
    coefficients: tuple[int, ...] | list[int],
) -> str:
    """Render ``CH4 + 2 O2 → CO2 + 2 H2O`` with canonical formulas."""
    if len(coefficients) != len(reactants) + len(products):
        raise ValueError("every species needs exactly one coefficient")
    reactant_count = len(reactants)
    left = _format_side(reactants, coefficients[:reactant_count])
    right = _format_side(products, coefficients[reactant_count:])
    return f"{left} \u2192 {right}"


def structured_equation(
    reactants: tuple[str, ...] | list[str],
    products: tuple[str, ...] | list[str],
    coefficients: tuple[int, ...] | list[int],
) -> StructuredEquation:
    """Return the model-shaped equation for a rendered option."""
    if len(coefficients) != len(reactants) + len(products):
        raise ValueError("every species needs exactly one coefficient")
    reactant_count = len(reactants)
    return StructuredEquation(
        reactants=[
            EquationTerm(coefficient=coefficient, formula=canonical_formula(formula))
            for formula, coefficient in zip(
                reactants, coefficients[:reactant_count], strict=True
            )
        ],
        products=[
            EquationTerm(coefficient=coefficient, formula=canonical_formula(formula))
            for formula, coefficient in zip(
                products, coefficients[reactant_count:], strict=True
            )
        ],
    )


def render_stem(
    spec_item: ChemistryItemSpec,
    reaction: ReactionSnapshot,
    asked_slot: str | None,
    description: str,
) -> str:
    """Render the question stem for one reaction and target.

    ``description`` is the family's curated context sentence from the catalogue
    snapshot. The model never authors learner-facing prose.
    """
    skeleton = format_equation(
        reaction.reactants,
        reaction.products,
        [1] * (len(reaction.reactants) + len(reaction.products)),
    )

    if spec_item.target.kind == "balanced_equation":
        return f"{description} Balance the equation {skeleton}. {STEM_INSTRUCTION}"

    if asked_slot is None:
        raise ValueError("a coefficient target requires an asked slot")
    formula = canonical_formula(_formula_for_slot(reaction, asked_slot))
    return (
        f"{description} When the equation {skeleton} is balanced using the "
        f"smallest whole-number coefficients, what is the coefficient of "
        f"{formula}?"
    )


def _recipe_coefficients(
    recipe: Recipe,
    key: tuple[int, ...],
    asked_slot: str | None,
    reactant_count: int,
) -> tuple[int, ...]:
    """Return the coefficient vector a recipe builds from the key."""
    coefficients = list(key)
    if isinstance(recipe, PerturbCoefficient):
        slot = _resolve_slot(recipe.slot, asked_slot)
        coefficients[slot_index(slot, reactant_count)] += recipe.delta
    elif isinstance(recipe, ScaleBalanced):
        coefficients = [value * recipe.factor for value in coefficients]
    elif isinstance(recipe, SkeletonCoefficients):
        coefficients = [1] * len(coefficients)
    elif isinstance(recipe, SwapCoefficients):
        first = slot_index(_resolve_slot(recipe.slot_a, asked_slot), reactant_count)
        second = slot_index(_resolve_slot(recipe.slot_b, asked_slot), reactant_count)
        coefficients[first], coefficients[second] = (
            coefficients[second],
            coefficients[first],
        )
    else:  # pragma: no cover - the recipe union is closed
        raise ValueError(f"unsupported chemistry recipe {type(recipe).__name__}")
    return tuple(coefficients)


def _evaluate_swap_species(
    recipe: SwapSpecies,
    reaction: ReactionSnapshot,
) -> OptionValue:
    """Replace one formula, then balance the changed equation exactly."""
    variant = reaction.variants.get(recipe.variant)
    if variant is None:
        raise ValueError(
            f"reaction {reaction.id!r} declares no variant {recipe.variant!r}"
        )

    reactants = list(reaction.reactants)
    products = list(reaction.products)
    side, position = parse_slot(variant.slot)
    formulas = reactants if side == "reactant" else products
    if position > len(formulas):
        raise ValueError(f"variant slot {variant.slot!r} is out of range")
    formulas[position - 1] = variant.formula

    changed_reactants = tuple(reactants)
    changed_products = tuple(products)
    try:
        result = balance_equation(changed_reactants, changed_products)
    except ValueError as error:
        return OptionValue(
            verdict="unusable",
            reason={
                "code": getattr(error, "code", "CHEM_NO_BALANCE"),
                "message": str(error),
            },
            reactants=changed_reactants,
            products=changed_products,
        )

    return _from_coefficients(
        result.coefficients,
        changed_reactants,
        changed_products,
        asked_slot=None,
    )


def _from_coefficients(
    coefficients: tuple[int, ...],
    reactants: tuple[str, ...],
    products: tuple[str, ...],
    asked_slot: str | None,
) -> OptionValue:
    """Build the option, rejecting coefficients outside 1..99."""
    value = _asked_value(coefficients, asked_slot, len(reactants))
    if asked_slot is not None:
        limit_value = (
            value if value is not None and not 1 <= value <= MAX_COEFFICIENT else None
        )
    else:
        limit_value = _first_out_of_range(coefficients)
    if limit_value is not None:
        return OptionValue(
            verdict="unusable",
            reason={"code": "COEFFICIENT_UNUSABLE", "coefficient": limit_value},
            coefficients=tuple(coefficients),
            reactants=reactants,
            products=products,
            value=value,
        )
    return OptionValue(
        verdict="wrong",
        coefficients=tuple(coefficients),
        reactants=reactants,
        products=products,
        value=value,
    )


def _prove_coefficient(
    option: OptionValue,
    key: tuple[int, ...],
    asked_slot: str,
    reactant_count: int,
) -> OptionValue:
    """A coefficient option is either the key entry or a different number."""
    expected = key[slot_index(asked_slot, reactant_count)]
    if option.value == expected:
        return OptionValue(
            verdict="correct",
            coefficients=option.coefficients,
            reactants=option.reactants,
            products=option.products,
            value=option.value,
        )
    return OptionValue(
        verdict="wrong",
        reason={
            "code": "COEFFICIENT_DIFFERS",
            "expected": expected,
            "actual": option.value,
        },
        coefficients=option.coefficients,
        reactants=option.reactants,
        products=option.products,
        value=option.value,
    )


def _prove_equation(
    option: OptionValue,
    reaction: ReactionSnapshot,
    key: tuple[int, ...],
) -> OptionValue:
    """Prove an equation option: species, then balance, then reduction."""
    if option.coefficients is None:  # pragma: no cover - evaluate_recipe guards this
        return option

    changed = _species_change(option, reaction)
    if changed is not None:
        return OptionValue(
            verdict="wrong",
            reason=changed,
            coefficients=option.coefficients,
            reactants=option.reactants,
            products=option.products,
        )

    unbalanced = first_unbalanced_element(
        option.reactants,
        option.products,
        option.coefficients,
    )
    if unbalanced is not None:
        element, left, right = unbalanced
        return OptionValue(
            verdict="wrong",
            reason={
                "code": "ELEMENT_UNBALANCED",
                "element": element,
                "left": left,
                "right": right,
            },
            coefficients=option.coefficients,
            reactants=option.reactants,
            products=option.products,
        )

    divisor = gcd(*option.coefficients)
    if divisor > 1:
        return OptionValue(
            verdict="wrong",
            reason={"code": "NOT_REDUCED", "divisor": divisor},
            coefficients=option.coefficients,
            reactants=option.reactants,
            products=option.products,
        )

    # Same species, balanced, positive and reduced: this is a correct answer.
    # With a unique balance it equals the key, and if it ever did not it would
    # be a second correct answer, so it must never count as wrong.
    return OptionValue(
        verdict="correct",
        coefficients=option.coefficients,
        reactants=option.reactants,
        products=option.products,
    )


def _species_change(
    option: OptionValue, reaction: ReactionSnapshot
) -> dict[str, Any] | None:
    """Return the first slot whose formula differs from the skeleton."""
    expected = [
        *(
            (f"reactant:{index}", formula)
            for index, formula in enumerate(reaction.reactants, start=1)
        ),
        *(
            (f"product:{index}", formula)
            for index, formula in enumerate(reaction.products, start=1)
        ),
    ]
    actual = [*option.reactants, *option.products]
    for (slot, original), formula in zip(expected, actual, strict=True):
        # Compare composition, not spelling: ``(O2)`` is still oxygen.
        if parse_formula(original) != parse_formula(formula):
            return {
                "code": "SPECIES_CHANGED",
                "slot": slot,
                "expected": canonical_formula(original),
                "actual": canonical_formula(formula),
            }
    return None


def _format_side(
    formulas: tuple[str, ...] | list[str],
    coefficients: tuple[int, ...] | list[int],
) -> str:
    parts = []
    for formula, coefficient in zip(formulas, coefficients, strict=True):
        rendered = canonical_formula(formula)
        parts.append(rendered if coefficient == 1 else f"{coefficient} {rendered}")
    return " + ".join(parts)


def _asked_value(
    coefficients: tuple[int, ...], asked_slot: str | None, reactant_count: int
) -> int | None:
    if asked_slot is None:
        return None
    index = slot_index(asked_slot, reactant_count)
    if index >= len(coefficients):
        return None
    return coefficients[index]


def _first_out_of_range(coefficients: tuple[int, ...]) -> int | None:
    for coefficient in coefficients:
        if not 1 <= coefficient <= MAX_COEFFICIENT:
            return coefficient
    return None


def _resolve_slot(slot: str, asked_slot: str | None) -> str:
    if slot == ASKED:
        if asked_slot is None:
            raise ValueError("this recipe asks for the asked slot but has none")
        return asked_slot
    return slot


def _formula_for_slot(reaction: ReactionSnapshot, slot: str) -> str:
    formula = slot_formula(slot, reaction.reactants, reaction.products)
    if formula is None:
        raise ValueError(f"slot {slot!r} is out of range")
    return formula


__all__ = [
    "OptionKey",
    "OptionValue",
    "Recipe",
    "Verdict",
    "duplicate_reason",
    "evaluate_recipe",
    "format_equation",
    "option_key",
    "prove_option",
    "render_stem",
    "slot_index",
    "structured_equation",
]
