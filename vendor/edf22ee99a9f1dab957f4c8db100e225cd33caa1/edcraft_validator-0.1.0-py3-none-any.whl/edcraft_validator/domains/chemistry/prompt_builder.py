"""Build chemistry-domain prompts and the structured LLM request."""

from __future__ import annotations

import json
import re
from collections import Counter

from edcraft_validator.domains.chemistry.calculation_requests import (
    paired_calculation_case,
    requested_calculation_cases,
)
from edcraft_validator.domains.chemistry.catalogue import Catalogue, load_catalogue
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    ChemistryTemplateContent,
    ChemistryTemplateRequest,
    ResolvedChemistryTemplateContent,
)
from edcraft_validator.domains.chemistry.chemistry_types import (
    MAX_DISTRACTORS,
    MAX_REACTIONS,
    MIN_DISTRACTORS,
)
from edcraft_validator.domains.chemistry.concept_catalogue import (
    ASSESSMENT_CATALOGUE_VERSION,
    load_concepts,
    load_skill_catalogue,
    requested_skill,
)
from edcraft_validator.domains.chemistry.options import format_equation
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

CHEMISTRY_TEMPLATE_PROMPT_VERSION = "chemistry-template-v11"
_WORDS = re.compile(r"[a-z]{3,}")
_NON_SKILL_WORDS = frozenset(
    "and both can case cases chemistry classroom contexts create different examples "
    "form four from generate given include make option options practice provided "
    "question questions regenerate reusable same singapore skill stated supplied that "
    "the two "
    "use using variants vetted which with".split()
)

CHEMISTRY_TEMPLATE_SYSTEM_PROMPT = """\
Generate one reusable Singapore H2 chemistry MCQ template and recommend its fixed
validation checks in the same structured response. Do not generate one concrete
question. The local application derives identity, difficulty and question type;
you author the reusable task and its wrong choices.

Return one item in the `item` field.

ITEM KINDS
- For balancing or finding one coefficient use `schema_version: chem-balance/0.1`
  and follow the balancing instructions below.
- For theoretical product amount in mmol from two reactant amounts use
  `schema_version: chem-yield/0.1`. Set the target to
  {"kind":"theoretical_yield","product":"product:1"} (use the requested product
  slot). The answer recipe is {"kind":"limiting_extent"}. Declare reaction IDs
  with exactly two reactants, and two independent integer axes `reactant_1_mmol`
  and `reactant_2_mmol`, each with unique values between 1 and 1000. Every option
  uses mmol to two decimal places. Specify each distractor as
  {"kind":"yield_alternative","method":...}. Allowed methods are `first_extent`,
  `second_extent`, `larger_extent`, `sum_extents`, `mean_extent`,
  `ignore_reactant_coefficients`, `invert_product_coefficient`, `multiply_by_1000`
  and `divide_by_1000`. Ties and rounding can make some recipes equal the key.
  Include `sum_extents`, `multiply_by_1000` and `divide_by_1000` as candidates.
  Keep all requested axis values. Extent recipes based on a single side can
  equal the key whenever that side limits the reaction, and either side can
  limit it when the teacher asks for independent varying amounts.
- For any matching vetted classroom context, use `schema_version: chem-concept/0.1`.
  This includes numeric answers in curated calculation contexts. For example,
  use the listed gas molar-mass contexts for calculations from gas mass, volume,
  pressure and temperature. A context supplies the numbers, stem, key and options.
  Copy one listed context family and put its matching IDs in the `values` array
  of a single `context` parameter. Set target to {"kind":"concept"} and answer
  recipe to {"kind":"concept_key"}. Candidate
  distractors are {"kind":"concept_alternative","index":1} and so on up to 6.
  Include indices 1, 2 and 3 when three distractors are requested. Additional
  indices may be unavailable in some contexts. Select two matching contexts
  when the educator requests general practice. Use one for a specific scenario.
- Prefer the syllabus skill that assesses the requested calculation, reasoning
  or interpretation. A matching topic alone is insufficient. Copy the supplied
  `family` ID exactly. The skill ID is a reference and the context IDs belong
  only in `parameters[0].values`. Use both reviewed contexts if requested.
  An explicit `H2 skill` ID limits the choices to that skill.
- If the requested subject or response is unsupported, use
  `schema_version: chem-unsupported/0.1` with `reason` at most 300 characters.
  Look for matching vetted contexts before declining a calculation request.
  Preserve the intended assessment, including practical performance, open-written
  reasoning or drawing when requested. Offer an MCQ only if it meets the request.

REACTION CATALOGUE FOR chem-balance/0.1 AND chem-yield/0.1
- Choose one family and 1 to 16 reaction ids ONLY from the catalogue listed
  in the user message. Never invent species or formulas, and never use a
  reaction from another family.
- `item.family` is the chosen family id. The `reaction` parameter's values are
  the chosen reaction ids in the order they should be expanded.
- Give the template variety. Each generated question uses one reaction from the
  list, so a template with one reaction repeats the same question for every
  seed. When the family lists several reactions that fit the request and the
  requested difficulty, declare several of them (at least three where the family
  has them, and all suitable ones is fine). Declare a single reaction only when
  the request names one specific reaction. Every listed reaction must still
  suit the request, and the pool must support one fixed set of distractors that
  works for all of them.
- The application recomputes the balance of every listed reaction from the
  embedded catalogue snapshot, so your recipes never supply coefficients or
  species.
- The application adds the chosen family's curated description as the context
  sentence before the question. You do not write that sentence or any other
  learner-facing prose.

TARGETS
- For `chem-balance/0.1`, `item.target.kind` is `balanced_equation` or `coefficient`.
- `balanced_equation` asks the learner to balance the whole equation. It declares
  only the `reaction` parameter.
- `coefficient` asks for one coefficient. It declares the `reaction` parameter
  and exactly one `species` parameter whose values are slots such as
  `reactant:2` or `product:1`.
- Slots are one-indexed: `reactant:N` on the left and `product:N` on the right.
  Every slot you name, in parameters or recipes, must exist in every reaction of
  the family.
- The value `asked` is allowed only for the coefficient target and refers to the
  slot declared by the `species` parameter.

DISTRACTOR RECIPES
- For `chem-balance/0.1` the answer recipe is {"kind": "normalised_coefficients"}.
- Provide exactly the stated number of candidate distractor recipes, including
  the surplus alternatives. Order them by plausible misconceptions. Each has
  one closed recipe kind, a
  `misconception` tag and an optional short `reason` for balancing:
  - `perturb_coefficient`: `slot` (a slot or `asked`) and `delta` in
    -2, -1, 1, 2. Misconception `unbalanced_element`.
  - `scale_balanced`: `factor` 2 or 3. Misconception
    `non_reduced_coefficients`.
  - `skeleton_coefficients`: no arguments. Misconception `unbalanced_skeleton`.
  - `swap_coefficients`: `slot_a` and `slot_b` (slots or `asked`, and they must
    differ). Misconception `misassigned_coefficients`.
  - `swap_species`: `variant`, one of the variants declared by every reaction in
    the domain. Misconception `wrong_species`.
- `swap_species` is available only for the equation target. Every reaction in the
  domain must declare the named variant.
- The application selects one fixed set of the requested size. Make sure that
  enough candidate recipes yield wrong and distinct options for every reaction
  and asked slot. Offer alternatives for recipes that may collide. For example, avoid
  `skeleton_coefficients` when a skeleton is already the reduced balance, and
  avoid perturbations that can reach zero or duplicate another option.

RENDERING
- The application supplies the complete stem for each item kind. For balancing
  it includes the instruction "Use the smallest whole-number coefficients."

CHECK PLAN
- Select a nonempty fixed subset of the available MCP tools using their supplied
  descriptions. Use each tool name at most once and do not invent names. Supply
  each selected check's model-owned arguments using its planning schema; use {}
  for checks without model-owned arguments.
- The application always runs chemistry_verify_options and the matching
  authority check, chemistry_verify_content for concepts or
  chemistry_verify_balance for reaction items.
- Select assess_template_difficulty and assess_template_relevance. They are
  advisory evidence for educator review and never block a technically checked
  template. The difficulty rubric is provisional and uncalibrated.
"""

RESPONSE_GUIDANCE = """\
Use native JSON values. Reaction values are catalogue ids such as "comb.methane".
Distractors are objects such as {"kind": "scale_balanced", "factor": 2,
"misconception": "non_reduced_coefficients"}.
"""

_RESOLVED_CALCULATION_SYSTEM_PROMPT = """\
Return one reusable H2 Chemistry concept template and its fixed validation checks.
Use proposal.item with schema_version "chem-concept/0.1". Copy the supplied family
and context parameters. Set target to {"kind":"concept"} and answer_recipe to
{"kind":"concept_key"}. Submit the listed indices, each in a
{"kind":"concept_alternative","index":...} distractor object.
The checked catalogue supplies each whole question, key and choices.
Keep all required contexts in the proposal.

Recommend chemistry_verify_content, chemistry_verify_options,
assess_template_difficulty and assess_template_relevance once each in checks.
Use {} for each check's planning arguments. Difficulty and relevance are advisory.
The application independently checks the required contexts, key and options.
"""

type ChemistryGenerationResponse = (
    PlannedGenerationResponse[ChemistryTemplateContent]
    | PlannedGenerationResponse[ResolvedChemistryTemplateContent]
)


def build_chemistry_generation_request(
    request: ChemistryTemplateRequest,
) -> StructuredGenerationRequest[ChemistryGenerationResponse]:
    """Return the provider-independent chemistry proposal contract."""
    skill = requested_skill(request.prompt)
    calculation = requested_calculation_cases(
        request.prompt, request.difficulty, skill.id if skill else None
    )
    if calculation:
        return _resolved_calculation_request(request, calculation)
    if skill is None:
        catalogue = load_catalogue()
        offer = (
            f"Catalogue version: {catalogue.catalogue_version}\n\n"
            "Potentially relevant syllabus skills (review the actual questions):\n"
            f"{render_skill_matches(request.prompt)}\n\n"
            "Syllabus skill index (skill ID | family | skill | two context IDs):\n"
            f"{render_skill_index()}\n\n"
            f"Families and reactions (choose 1 to {MAX_REACTIONS} from one family):\n"
            f"{render_catalogue(catalogue)}\n\n"
            "Other concept contexts (family | context ID | question):\n"
            f"{render_concepts()}"
        )
    else:
        fields = {
            "family": skill.family,
            "parameters": [{"name": "context", "values": skill.contexts}],
        }
        offer = (
            f"Requested 9476 skill {skill.id}: {skill.label}\n"
            f"Use these fields inside the concept item: {json.dumps(fields)}\n"
            "Use only these contexts for the skill (context ID | question).\n"
            + render_concepts(skill.contexts)
        )
    user_prompt = f"""\
Author request (preserve its meaning):
{request.prompt}

Requested difficulty: {request.difficulty}
Required usable distractors: {request.num_distractors}
Candidate distractor recipes to supply: {request.num_distractors + SURPLUS_RECIPES}
Supported distractor range: {MIN_DISTRACTORS} to {MAX_DISTRACTORS}

{offer}
"""

    return StructuredGenerationRequest(
        revise_from_authored_pool=True,
        messages=[
            {"role": "system", "content": CHEMISTRY_TEMPLATE_SYSTEM_PROMPT},
            {"role": "user", "content": f"{user_prompt}\n{RESPONSE_GUIDANCE}"},
        ],
        response_model=PlannedGenerationResponse[ChemistryTemplateContent],
        prompt_version=f"{CHEMISTRY_TEMPLATE_PROMPT_VERSION}+response-v1",
        schema_name="template_proposal_and_check_plan",
        check_argument_models=(),
    )


def _resolved_calculation_request(
    request: ChemistryTemplateRequest, calculation: tuple[str, ...]
) -> StructuredGenerationRequest[ChemistryGenerationResponse]:
    paired = any(paired_calculation_case(case) for case in calculation)
    if request.num_distractors > 3 or (paired and request.num_distractors < 2):
        raise UnsupportedAuthoringRequest(
            "These calculation cases support "
            + ("two or three" if paired else "one to three")
            + " distractors with the required candidate surplus."
        )
    contexts, _ = load_concepts(ASSESSMENT_CATALOGUE_VERSION)
    fields = {
        "family": contexts[calculation[0]].family,
        "parameters": [{"name": "context", "values": list(calculation)}],
    }
    indices = list(range(1, request.num_distractors + SURPLUS_RECIPES + 1))
    user = (
        f"Author request:\n{request.prompt}\n\n"
        f"Requested difficulty: {request.difficulty}\n"
        f"Required usable distractors: {request.num_distractors}\n\n"
        "Required vetted calculation cases. Use all listed contexts.\n"
        f"Copy these proposal.item fields: {json.dumps(fields)}\n"
        f"Use the distinct concept_alternative indices {indices}.\n"
        + render_concepts(list(calculation))
    )
    return StructuredGenerationRequest(
        revise_from_authored_pool=True,
        messages=[
            {"role": "system", "content": _RESOLVED_CALCULATION_SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
        response_model=PlannedGenerationResponse[ResolvedChemistryTemplateContent],
        prompt_version=f"{CHEMISTRY_TEMPLATE_PROMPT_VERSION}-resolved-v1+response-v1",
        schema_name="chemistry_concept_proposal_and_check_plan",
    )


def render_catalogue(catalogue: Catalogue) -> str:
    """List every family and reaction so the model can only copy real ids."""
    lines: list[str] = []
    for family in catalogue.families:
        reactions = [
            reaction for reaction in catalogue.reactions if reaction.family == family.id
        ]
        lines.append(
            f"- {family.id} — {family.title} "
            f"({family.reactant_count} reactants -> "
            f"{family.product_count} products)"
        )
        for reaction in reactions:
            variants = ", ".join(sorted(reaction.variants)) or "none"
            skeleton = format_equation(
                reaction.reactants,
                reaction.products,
                [1] * (len(reaction.reactants) + len(reaction.products)),
            )
            lines.append(f"  - {reaction.id}: {skeleton} (variants: {variants})")
    return "\n".join(lines)


def render_concepts(ids: list[str] | None = None) -> str:
    if ids is not None:
        concepts, _ = load_concepts(ASSESSMENT_CATALOGUE_VERSION)
        return "\n".join(
            f"{context_id} | {concepts[context_id].question}" for context_id in ids
        )
    concepts, _ = load_concepts()
    return "\n".join(
        f"{context.family} | {context.id} | {context.question}"
        for context in concepts.values()
    )


def render_skill_index() -> str:
    bank, _ = load_skill_catalogue()
    return "\n".join(
        f"{skill.id} | {skill.family} | {skill.label} | {', '.join(skill.contexts)}"
        for skill in bank.skills
        if skill.mode == "selection"
    )


def render_skill_matches(prompt: str) -> str:
    """Expose full stems for nearby skill matches while retaining the full index."""
    bank, _ = load_skill_catalogue()
    skills = [skill for skill in bank.skills if skill.mode == "selection"]
    query = set(_WORDS.findall(prompt.casefold())) - _NON_SKILL_WORDS
    matches = {
        skill.id: query & set(_WORDS.findall(f"{skill.label} {skill.scope}".casefold()))
        for skill in skills
    }
    frequencies = Counter(word for words in matches.values() for word in words)
    ranked = sorted(
        skills,
        key=lambda skill: sum(
            1 / frequencies[word] for word in sorted(matches[skill.id])
        ),
        reverse=True,
    )
    return "\n".join(
        f"{skill.id} | family {skill.family} | {skill.label}\n"
        f"{render_concepts(skill.contexts)}"
        for skill in ranked[:8]
        if matches[skill.id]
    )


__all__ = [
    "CHEMISTRY_TEMPLATE_PROMPT_VERSION",
    "CHEMISTRY_TEMPLATE_SYSTEM_PROMPT",
    "RESPONSE_GUIDANCE",
    "build_chemistry_generation_request",
    "render_catalogue",
]
