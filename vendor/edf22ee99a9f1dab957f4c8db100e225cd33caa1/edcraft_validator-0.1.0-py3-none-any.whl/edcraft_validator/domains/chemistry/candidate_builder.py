"""Build chemistry template candidates from model-authored proposals.

The builder embeds a catalogue snapshot and selects one fixed set of wrong
choices from the authored pool before the required template checks run.
"""

from __future__ import annotations

from edcraft_validator.domains.chemistry.calculation_requests import (
    paired_calculation_case,
    requested_calculation_cases,
)
from edcraft_validator.domains.chemistry.catalogue import (
    ReactionEntry,
    catalogue_sha256,
    load_catalogue,
)
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    AuthoredChemistryItem,
    CatalogueSnapshot,
    ChemistryConceptItemSpec,
    ChemistryTemplateCandidate,
    ChemistryTemplateContent,
    ChemistryTemplateRequest,
    ChemistryTemplateSpec,
    ChemistryUnsupportedItem,
    ConceptCatalogueSnapshot,
    FamilySnapshot,
    ReactionSnapshot,
    reaction_ids,
)
from edcraft_validator.domains.chemistry.concept_catalogue import (
    concept_catalogue_version,
    concept_snapshot_digest,
    requested_skill,
    resolve_contexts,
)
from edcraft_validator.domains.chemistry.validation.isolation import run_isolated
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    build_template_id,
    content_sha256,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
)


def build_chemistry_candidate(
    request: ChemistryTemplateRequest, proposal: ChemistryTemplateContent
) -> ChemistryTemplateCandidate:
    """Build the canonical chemistry template from the model proposal."""
    item = proposal.item
    skill = requested_skill(request.prompt)
    calculation = requested_calculation_cases(
        request.prompt, request.difficulty, skill.id if skill else None
    )
    context_ids = (
        item.parameters[0].values if isinstance(item, ChemistryConceptItemSpec) else []
    )
    if calculation:
        if set(context_ids) != set(calculation):
            raise DistractorPoolError(
                "Use all required calculation cases for this request: "
                + ", ".join(calculation)
                + "."
            )
    elif any(case.startswith("calc-") for case in context_ids):
        raise DistractorPoolError(
            "These calculation cases do not assess the requested task."
        )
    if isinstance(item, ChemistryUnsupportedItem):
        raise UnsupportedAuthoringRequest(
            f"Unsupported chemistry request: {item.reason}"
        )
    if (
        skill is not None
        and not calculation
        and (
            not isinstance(item, ChemistryConceptItemSpec)
            or not set(item.parameters[0].values) <= set(skill.contexts)
        )
    ):
        raise DistractorPoolError(
            f"Use only the listed contexts for the requested 9476 skill {skill.id}."
        )
    required = request.num_distractors
    expected = required + SURPLUS_RECIPES
    if len(item.distractors) != expected:
        raise DistractorPoolError(
            f"Expected exactly {expected} candidate recipes for "
            f"{required} distractors. Received {len(item.distractors)}."
        )

    if calculation and isinstance(item, ChemistryConceptItemSpec):
        options = {recipe.index for recipe in item.distractors}
        if len(options) != expected:
            raise DistractorPoolError(
                "Use distinct calculation candidate indices between 1 and 6."
            )
        paired = any(paired_calculation_case(case) for case in calculation)
        if paired:
            if required < 2:
                raise UnsupportedAuthoringRequest(
                    "These paired calculations require two or three distractors."
                )
            if not set(range(1, required + 1)) <= options:
                raise DistractorPoolError(
                    "Include the leading indices that distinguish both results."
                )
            item = item.model_copy(
                update={
                    "distractors": sorted(
                        item.distractors, key=lambda recipe: recipe.index
                    )
                }
            )

    snapshot = _catalogue_snapshot(item)
    selection = run_isolated(
        {
            "operation": "select_distractors",
            "template": ChemistryTemplateSpec(item=item, catalogue=snapshot).model_dump(
                mode="json"
            ),
            "required": required,
        }
    )
    failure = selection.get("selection_error")
    if isinstance(failure, str):
        raise DistractorPoolError(failure)
    indices = selection.get("indices")
    if (
        not isinstance(indices, list)
        or len(indices) != required
        or any(type(index) is not int or not 0 <= index < expected for index in indices)
        or indices != sorted(set(indices))
    ):
        raise ValueError("Chemistry worker returned an invalid distractor selection")
    item = item.model_copy(
        update={"distractors": [item.distractors[index] for index in indices]}
    )

    return ChemistryTemplateCandidate(
        template_id=build_template_id("chemistry", request, proposal),
        difficulty=request.difficulty,
        item=item,
        question_type="mcq",
        catalogue=snapshot,
    )


def template_sha256(candidate: ChemistryTemplateCandidate) -> str:
    """Identify the exact reusable content independently of any assessment."""
    return content_sha256(candidate)


def _catalogue_snapshot(
    item: AuthoredChemistryItem,
) -> CatalogueSnapshot | ConceptCatalogueSnapshot:
    if isinstance(item, ChemistryConceptItemSpec):
        contexts = resolve_contexts(item.family, item.parameters[0].values)
        version = concept_catalogue_version(item.parameters[0].values)
        return ConceptCatalogueSnapshot(
            catalogue_version=version,
            catalogue_sha256=concept_snapshot_digest(version, contexts),
            family=FamilySnapshot(
                id=item.family,
                title=contexts[0].topic_title,
                description=f"H2 Chemistry 9476 topic {contexts[0].topic}.",
            ),
            contexts=contexts,
        )
    catalogue = load_catalogue()
    family = catalogue.family(item.family)
    reactions = [catalogue.reaction(reaction_id) for reaction_id in reaction_ids(item)]
    return CatalogueSnapshot(
        catalogue_version=catalogue.catalogue_version,
        catalogue_sha256=catalogue_sha256(),
        family=FamilySnapshot(
            id=family.id, title=family.title, description=family.description
        ),
        reactions=[_snapshot(reaction) for reaction in reactions],
    )


def _snapshot(reaction: ReactionEntry) -> ReactionSnapshot:
    """Copy one catalogue reaction into the model-free snapshot shape."""
    return ReactionSnapshot.model_validate(reaction.model_dump())


__all__ = [
    "build_chemistry_candidate",
    "template_sha256",
]
