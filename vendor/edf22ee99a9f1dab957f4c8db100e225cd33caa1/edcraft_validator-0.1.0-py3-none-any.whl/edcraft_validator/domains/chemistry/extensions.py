"""Evaluate the H2 concept and theoretical-yield item families."""

from collections.abc import Mapping
from dataclasses import dataclass
from fractions import Fraction

from edcraft_validator.domains.chemistry.balance import balance_equation
from edcraft_validator.domains.chemistry.chemistry_schemas import (
    CatalogueSnapshot,
    ChemistryConceptItemSpec,
    ChemistryTemplateSpec,
    ChemistryYieldItemSpec,
    ConceptCatalogueSnapshot,
)
from edcraft_validator.domains.chemistry.concept_catalogue import answer_identity
from edcraft_validator.domains.chemistry.options import format_equation
from edcraft_validator.domains.chemistry.slots import slot_index
from edcraft_validator.validation.distractor_pool import OptionValue


@dataclass(frozen=True)
class ExtensionEvaluation:
    context_id: str
    question: str
    key: OptionValue
    options: tuple[OptionValue | None, ...]

    def verdicts(self) -> tuple[str, ...]:
        verdicts = []
        seen_semantics = {self.key.semantic}
        seen_display = {self.key.display}
        for option in self.options:
            if option is None:
                verdicts.append("unusable")
                continue
            if (
                option.semantic == self.key.semantic
                or option.display == self.key.display
            ):
                verdicts.append("correct")
            elif option.semantic in seen_semantics or option.display in seen_display:
                verdicts.append("duplicate")
            else:
                verdicts.append("wrong")
            seen_semantics.add(option.semantic)
            seen_display.add(option.display)
        return tuple(verdicts)


def evaluate_extension(
    spec: ChemistryTemplateSpec, inputs: Mapping[str, str | int]
) -> ExtensionEvaluation:
    item, catalogue = spec.item, spec.catalogue
    if isinstance(item, ChemistryConceptItemSpec) and isinstance(
        catalogue, ConceptCatalogueSnapshot
    ):
        context = next(
            context for context in catalogue.contexts if context.id == inputs["context"]
        )
        choices = [_text_value(value) for value in context.alternatives]
        return ExtensionEvaluation(
            context.id,
            context.question,
            _text_value(context.answer),
            tuple(
                choices[recipe.index - 1] if recipe.index <= len(choices) else None
                for recipe in item.distractors
            ),
        )

    if not isinstance(item, ChemistryYieldItemSpec) or not isinstance(
        catalogue, CatalogueSnapshot
    ):
        raise TypeError("expected a chemistry concept or yield item")
    reaction = next(
        reaction
        for reaction in catalogue.reactions
        if reaction.id == inputs["reaction"]
    )
    a, b = int(inputs["reactant_1_mmol"]), int(inputs["reactant_2_mmol"])
    coefficients = balance_equation(reaction.reactants, reaction.products).coefficients
    product_index = slot_index(item.target.product, 2)
    product = reaction.products[product_index - 2]
    reactant_a, reactant_b = reaction.reactants
    first, second = Fraction(a, coefficients[0]), Fraction(b, coefficients[1])
    extent = min(first, second)
    multiplier = coefficients[product_index]
    correct = extent * multiplier
    alternatives = {
        "first_extent": first * multiplier,
        "second_extent": second * multiplier,
        "larger_extent": max(first, second) * multiplier,
        "sum_extents": (first + second) * multiplier,
        "mean_extent": (first + second) * multiplier / 2,
        "ignore_reactant_coefficients": Fraction(min(a, b) * multiplier),
        "invert_product_coefficient": extent / multiplier,
        "multiply_by_1000": correct * 1000,
        "divide_by_1000": correct / 1000,
    }
    equation = format_equation(reaction.reactants, reaction.products, coefficients)
    question = (
        f"Consider the balanced equation {equation}. Initially there are {a} mmol of "
        f"{reactant_a} and {b} mmol of {reactant_b}. Assuming the reaction goes to "
        "completion with no side reactions, what is the theoretical amount of "
        f"{product} formed? Give your answer in mmol to two decimal places."
    )
    return ExtensionEvaluation(
        reaction.id,
        question,
        _amount_value(correct),
        tuple(
            _amount_value(alternatives[recipe.method]) for recipe in item.distractors
        ),
    )


def _text_value(text: str) -> OptionValue:
    return OptionValue(answer_identity(text), text)


def _amount_value(amount: Fraction) -> OptionValue:
    hundredths = int(amount * 100 + Fraction(1, 2))
    whole, decimal = divmod(hundredths, 100)
    return OptionValue(amount, f"{whole}.{decimal:02d} mmol")
