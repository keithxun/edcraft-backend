"""Match recorded answer checks to the exact embedded concept context."""

from functools import lru_cache
from importlib import resources

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from edcraft_validator.domains.chemistry.concept_catalogue import ConceptContext
from edcraft_validator.domains.domain_support import (
    ReviewCaseKeyEvidence,
    content_sha256,
)


class _EvidenceEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sources: list[ReviewCaseKeyEvidence] = Field(min_length=1)


@lru_cache(maxsize=1)
def _manifest() -> dict[str, _EvidenceEntry]:
    payload = resources.files(__package__).joinpath("key_evidence.json").read_bytes()
    return TypeAdapter(dict[str, _EvidenceEntry]).validate_json(payload)


def concept_key_evidence(context: ConceptContext) -> list[ReviewCaseKeyEvidence] | None:
    entry = _manifest().get(context.id)
    if entry is None or entry.sha256 != content_sha256(context):
        return None
    return list(entry.sources)
