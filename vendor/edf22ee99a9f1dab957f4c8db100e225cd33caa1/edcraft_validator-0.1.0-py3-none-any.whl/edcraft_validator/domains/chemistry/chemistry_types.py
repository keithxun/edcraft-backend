"""Small constants and type aliases for the chemistry domain."""

from __future__ import annotations

from typing import Literal

from edcraft_validator.domain_types import (
    MAX_DISTRACTORS as MAX_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    MIN_DISTRACTORS as MIN_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    Difficulty as Difficulty,
)

CHEMISTRY_SCHEMA_VERSION: Literal["chem-balance/0.1"] = "chem-balance/0.1"
CHEMISTRY_BALANCE_TOOL = "chemistry_verify_balance"
CHEMISTRY_CONTENT_TOOL = "chemistry_verify_content"
CHEMISTRY_OPTIONS_TOOL = "chemistry_verify_options"
CHEMISTRY_TOOL_VERSION = "0.1.0"
CHEMISTRY_VALIDATOR_VERSION: Literal["mcp-chemistry-template-v1"] = (
    "mcp-chemistry-template-v1"
)
CHEMISTRY_CHECKING_MODE: Literal["property_based"] = "property_based"
CHEMISTRY_FORMAT_VERSION: Literal["1.0.0"] = "1.0.0"

MAX_FORMULA_LENGTH = 64
MAX_SUBSCRIPT = 999
MAX_GROUP_DEPTH = 3
MAX_SPECIES = 8
MAX_ELEMENTS = 10
MAX_COEFFICIENT = 99
MAX_REACTIONS = 16

STEM_INSTRUCTION = "Use the smallest whole-number coefficients."
