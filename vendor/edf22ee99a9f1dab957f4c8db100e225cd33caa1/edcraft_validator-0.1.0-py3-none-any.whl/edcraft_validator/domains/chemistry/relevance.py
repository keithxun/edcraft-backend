"""Learner-facing text projection for shared template relevance.

The measurement, threshold and verdict live in the shared classifier. This
module only renders what a learner would actually see, so the same relevance
policy can judge a chemistry template without knowing anything about balancing.
The family text comes from the embedded snapshot, never the live catalogue.
"""

from __future__ import annotations

from edcraft_validator.domains.chemistry.chemistry_schemas import (
    ChemistryTemplateCandidate,
    ChemistryYieldItemSpec,
    ConceptCatalogueSnapshot,
)
from edcraft_validator.domains.chemistry.options import format_equation


def template_relevance_text(candidate: ChemistryTemplateCandidate) -> str:
    """Render the reusable task without answers, coefficients or distractors."""
    item = candidate.item
    family = candidate.catalogue.family
    if isinstance(candidate.catalogue, ConceptCatalogueSnapshot):
        questions = "\n".join(
            f"- {context.question}" for context in candidate.catalogue.contexts
        )
        return (
            f"H2 Chemistry multiple-choice template\nTopic: {family.title}\n{questions}"
        )
    if isinstance(item, ChemistryYieldItemSpec):
        skeletons = "; ".join(
            " + ".join(reaction.reactants) + " → " + " + ".join(reaction.products)
            for reaction in candidate.catalogue.reactions
        )
        return (
            "Calculate theoretical product amount in mmol from two reactant amounts. "
            f"Product slot: {item.target.product}. Reactions: {skeletons}"
        )
    target = (
        "balanced equation"
        if item.target.kind == "balanced_equation"
        else "single coefficient"
    )
    skeletons = "\n".join(
        "- "
        + format_equation(
            reaction.reactants,
            reaction.products,
            [1] * (len(reaction.reactants) + len(reaction.products)),
        )
        for reaction in candidate.catalogue.reactions
    )

    return (
        "Chemistry multiple-choice question template\n\n"
        f"Family: {family.title}\n"
        f"Family description: {family.description}\n"
        f"Target: {target}\n"
        f"Reaction skeletons:\n{skeletons}\n"
        "Each generated question uses one reaction from this list.\n"
    )


__all__ = ["template_relevance_text"]
