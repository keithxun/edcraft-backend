"""Typed count-table proposals for school Biology goodness-of-fit questions."""

from __future__ import annotations

from fractions import Fraction
from typing import Annotated, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

Count = Annotated[int, Field(ge=0, le=10_000)]
Statistic = Annotated[str, Field(pattern=r"^[0-9]+(?:\.[0-9]+)?$", max_length=20)]
Decision = Literal["reject", "fail_to_reject"]


class FitRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class PlantCategory(FitRecord):
    label: str = Field(pattern=r"^[A-Za-z]+(?:[ -][A-Za-z]+)*$", max_length=40)
    observed: list[Count] = Field(min_length=1, max_length=8)
    expected_weight: int = Field(ge=1, le=1_000)

    @model_validator(mode="after")
    def distinct_counts(self) -> Self:
        if len(set(self.observed)) != len(self.observed):
            raise ValueError("observed counts on each axis must be distinct")
        return self


class FitClaim(FitRecord):
    observed: list[Count] = Field(min_length=2, max_length=6)
    statistic: Statistic
    decision: Decision | None = None


class FitDistractor(FitRecord):
    rule: Literal[
        "observed_denominator",
        "unweighted_squared_error",
        "omit_category",
        "divide_by_total",
        "largest_contribution",
        "reverse_decision",
        "fixed_value",
    ]
    misconception: str = Field(min_length=1, max_length=200)
    category: int | None = Field(default=None, ge=1, le=6)
    statistic: Statistic | None = None
    decision: Decision | None = None

    @model_validator(mode="after")
    def option_shape(self) -> Self:
        if (self.rule == "omit_category") != (self.category is not None):
            raise ValueError("omit_category alone requires a one-based category number")
        if self.rule == "fixed_value":
            if self.statistic is None:
                raise ValueError("a fixed-value option requires a statistic")
        elif self.statistic is not None or self.decision is not None:
            raise ValueError(
                "only a fixed-value option can give a statistic or decision"
            )
        return self


class GoodnessOfFitTemplate(FitRecord):
    """A finite count grid, one expected ratio and an optional decision threshold."""

    schema_version: Literal["bio-fit/0.1"]
    topic: str = Field(pattern=r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$")
    categories: list[PlantCategory] = Field(min_length=2, max_length=6)
    expected_display: Literal["ratio", "counts"] = "ratio"
    critical_value: Statistic | None = None
    claimed_examples: list[FitClaim] = Field(min_length=1, max_length=3)
    distractors: list[FitDistractor] = Field(max_length=13)

    @model_validator(mode="after")
    def reusable_categories(self) -> Self:
        if self.critical_value is not None and Fraction(self.critical_value) == 0:
            raise ValueError("a chi-square critical value must be positive")
        if len({category.label.casefold() for category in self.categories}) != len(
            self.categories
        ):
            raise ValueError("category labels must be distinct")
        if not any(len(category.observed) > 1 for category in self.categories):
            raise ValueError("vary at least one visible count across questions")
        return self
