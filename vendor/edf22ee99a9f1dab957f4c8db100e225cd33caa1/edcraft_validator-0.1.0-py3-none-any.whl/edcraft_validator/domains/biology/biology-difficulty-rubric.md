# Provisional biology difficulty rubric

Rubric version: `bio-mono-v0.1`.
Assessment conditions version: `paper-no-calculator-v0.1`.

Use this rubric to check whether a reusable monohybrid inheritance MCQ template
matches the user's requested difficulty. Assess the typical concrete expansion
independently, then compare its estimated level with the request. Levels describe
EdCraft's provisional task-demand conventions under the conditions below. They are
uncalibrated and have no reference labels behind them. A match means the template
is consistent with this provisional rubric, so results stay advisory evidence for
educator review and never override failed correctness checks.

The source issue names the levels beginner, intermediate and advanced. EdCraft
shares one vocabulary across domains, so this rubric uses `easy` for beginner,
`medium` for intermediate and `hard` for advanced.

## Assessment conditions and scope

Use paper without a calculator or AI assistant. Assess an untimed practice
question for a learner who knows Mendelian segregation, complete dominance and how
to draw a Punnett square. There is no fixed learner cohort and no measured learner
performance. Record any aids, time limit or scaffolding as a different assessment
condition.

The pilot covers one autosomal gene with two alleles and complete dominance. A
template is rated on concrete expansions of its declared parameter family. Pick
representative crosses that show the range of demand, including the boundary
values that the checks sample. A parameter can change the cross, so rate the range
you reviewed and report substantial variation. A sampled match cannot establish
that every expansion matches.

Technical correctness, educational difficulty and question quality are separate.
Distinct wrong answers do not establish plausible distractors. A correct template
can still carry weak options or unclear wording. Record those concerns separately.

## Dimensions and evidence to record

Rate each dimension `low`, `moderate` or `high`, or `unknown` when the evidence is
insufficient. These categories organise the explanation. Do not sum them or apply a
weighted formula to produce a difficulty score. Level boundaries here are EdCraft
conventions and they are not calibrated thresholds.

| Dimension | Low | Moderate | High |
| --- | --- | --- | --- |
| Cross complexity | At least one homozygous parent with a single outcome class. | One heterozygous parent. | Both parents heterozygous. |
| Mapping steps | Read a genotype probability from the square. | Map genotypes to phenotypes or scale to a count. | Restrict the sample space, then map and scale. |
| Conceptual demand | Direct segregation. | Dominance hides a genotype. | Conditional reasoning on a phenotype. |
| Answer discrimination | Wrong options fall to a sum-to-one check. | One rule separates them. | Options encode competing conditioning errors. |

### Cross complexity and mapping steps

Describe a correct solution for the chosen expansion. State the gametes, the
Punnett square and each step from the square to the answer. Crossing two
heterozygotes produces three genotype classes in unequal proportions, which is the
main source of cross complexity. Mapping steps count the moves after the square:
reading a cell proportion, grouping genotypes into phenotypes, scaling a
probability to an expected count, and restricting the sample space to a given
phenotype.

### Conceptual demand

Identify the ideas that shape the solution. Reading a genotype proportion is direct
segregation. Recognising that a dominant phenotype covers two genotypes is a
connection. Conditioning on a phenotype ("of the purple offspring") changes the
denominator and is the main high-demand idea in this pilot.

### Answer discrimination

For each distractor, explain the error rule the option hypothesis uses and the rule
that eliminates it. The misconception tag is a hypothesis. Without learner data it
is not proof that learners make that error. Assign the dimension from the easiest
defensible way to distinguish the correct answer from the actual options. Unclear or
misleading options need repair rather than a higher difficulty label.

## Overall levels and uncertainty

| Level | Anchor description |
| --- | --- |
| `easy` | A single reading from a simple square, usually with a homozygous parent. At most one dimension is moderate. Options fall to a basic check. |
| `medium` | A genotype-to-phenotype mapping or a scaled count from a heterozygous cross. Eliminating options needs a specific rule. |
| `hard` | Conditional reasoning on a phenotype, often scaled to a count, with options that encode competing conditioning errors. |

Choose the closest worked anchor and explain the similarities and the material
differences. A single high dimension does not force `hard`. A shortcut or weak
options can lower the complete MCQ's demand. Unknown evidence is not defaulted to
medium.

Record confidence from 0 to 1 in the selected level. It is a self-estimate and it is
uncalibrated. For missing essential information use `estimated_difficulty: null`
with an unable-to-assess reason and confidence 0. A technically failed template is
ineligible for difficulty assessment.

## Worked anchors

These examples are reviewer training material. They are not held-out reference
items. The levels illustrate the rubric and nobody has rated them independently.

### Easy single heterozygote cross

In a hypothetical plant, purple petals (P) are completely dominant over white (p).
A `Pp` plant is crossed with a `pp` plant. What is the probability that an offspring
is `pp`? A: `1/2`, B: `1/4`, C: `3/4`, D: `1`.

Answer: A, `1/2`. Half of the gametes of the heterozygous parent carry `p` and every
gamete of the other parent does. Cross complexity is moderate and the other
dimensions are low. The distractors recall the `Pp` by `Pp` result (1/4), give the
dominant share of that cross (3/4) and ignore segregation (1).

### Medium phenotype probability

A `Pp` plant is crossed with a `Pp` plant. What is the probability that an offspring
has purple petals? A: `3/4`, B: `1/4`, C: `2/3`, D: `1/2`.

Answer: A, `3/4`. Both parents are heterozygous and the learner must group `PP` and
`Pp` into one phenotype, so cross complexity is high and mapping and conceptual
demand are moderate. The distractors forget the heterozygote (1/4), treat the three
genotype classes as equally likely (2/3) and give the `Pp` probability instead of the
phenotype (1/2).

### Hard conditional genotype

A `Pp` plant is crossed with a `Pp` plant. Of the offspring with purple petals, what
fraction are expected to be `Pp`? A: `2/3`, B: `1/2`, C: `1`, D: `1/3`.

Answer: A, `2/3`. The learner must restrict the sample space to purple offspring,
so mapping steps and conceptual demand are high. Answer discrimination is high
because the distractors encode competing conditioning errors: the unconditioned
probability (1/2), the reversed condition (1, every `Pp` plant is purple) and the
complementary class (1/3).

## Reviewer procedure and records

1. Confirm the checks passed and the stem is clear. Repair ineligible cases first.
2. Hide the requested difficulty, generator identity and other ratings. Show the
   conditions, the concrete MCQ and the verified answer.
3. Explain the solution and each distractor, then record dimension ratings, nearest
   anchor, overall level, confidence and quality concerns independently.
4. Reveal the requested difficulty and apply the comparison rule to the frozen
   assessment. A mismatch remains advisory and never requests automatic revision.

Store records in versioned files. Preserve the rubric and conditions versions, the
reviewed parameter combinations, the dimension ratings with reasons, the closest
anchor, the estimated level or null, confidence, quality concerns, the unchanged
requested level and the match result. Increment the rubric version when dimensions,
anchors, level decisions or conditions change. Template edits invalidate the
previous concrete assessment.

## Validation plan

The planned protocol follows the mathematics rubric. Target about 36 concrete
questions from 12 template families across probability, expected count and ratio
questions and all three requested levels. Split by family before tuning and keep
variants of one family together. Use two or three independent biology teachers or
tutors, with the author disclosed separately. Record ordinal Krippendorff's alpha
for the overall level, per-dimension exact agreement and a confusion matrix against
the adjudicated reference. Report bootstrap intervals that resample families and
expect wide intervals. Calibration against learner responses is deferred until
response data exists. This rubric carries no accepted accuracy threshold.
