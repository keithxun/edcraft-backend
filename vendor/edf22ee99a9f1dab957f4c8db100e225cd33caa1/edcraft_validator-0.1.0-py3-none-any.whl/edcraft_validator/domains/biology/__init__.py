"""Biology question domain: exact monohybrid genetics for the first slice."""
