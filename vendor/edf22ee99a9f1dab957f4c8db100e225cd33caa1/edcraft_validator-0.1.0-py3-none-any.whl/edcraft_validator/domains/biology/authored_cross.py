"""Render the premises and result of a model-authored inheritance problem."""

from edcraft_validator.domains.biology.biology_schemas import (
    CROSS_LABEL_PATTERN,
    AuthoredCross,
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.h2_task_scope import requested
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.domains.operation_intent import require_lecture_support

_CROSS_CUES = (
    r"\b(?:monohybrid|single.gene|one.gene|mendel\w*|alleles?|"
    r"inheritan\w*|genotypes?|phenotypes?|punnett|heterozyg\w*|homozyg\w*)\b"
)
_FIT_CUE = r"\b(?:chi.squared?|χ²|χ2)\b"
_UNSUPPORTED = (
    (
        r"\b(?:grade|observe|watch)\b[^.!?]{0,100}"
        r"\b(?:mount(?:ing)? slides?|focus(?:ing)? a microscope|hands.on)\b",
        "The request requires observing or assessing hands-on practical work.",
    ),
    (
        r"\b(?:essay|constructed.response|open.ended written response)\b",
        "The request requires an original written response.",
    ),
    (
        r"\b(?:own|original) (?:drawing|diagram|sketch)\b|\bdraw from scratch\b"
        r"|\b(?:draw|sketch|annotate)\b[^.!?]{0,40}\btheir own\b",
        "The request requires a learner to produce an original drawing.",
    ),
    (
        r"\b(?:dihybrid|codominan\w*|incomplete dominance|sex.linked|two.genes?|"
        r"epistasis|pedigree)\b",
        "The available Biology checker requires a one-gene autosomal cross "
        "with complete dominance.",
    ),
    (
        r"\b(?:micrographs?|electron transport|enzyme kinetics)\b",
        "The requested Biology task needs a different independent check from "
        "the available one-gene inheritance calculation.",
    ),
)


def explicit_limitation(prompt: str) -> str | None:
    if fit_requested(prompt) and requested(
        r"\b(?:degrees of freedom|two.locus|dihybrid|derive\b[^.!?]*\bfrom a cross)\b",
        prompt,
    ):
        return (
            "The chi-square checker uses plant counts and a supplied expected ratio "
            "or totals. It supports a decision when a critical value is supplied."
        )
    return next(
        (reason for cue, reason in _UNSUPPORTED if requested(cue, prompt)), None
    )


def fit_requested(prompt: str) -> bool:
    return requested(_FIT_CUE, prompt)


def require_biology_source(request: TemplateRequest, *, fit: bool) -> None:
    cross = "single-gene inheritance"
    statistic = "chi-square goodness of fit"
    require_lecture_support(
        request,
        statistic if fit else cross,
        {
            cross: (
                r"\b(?:monohybrid|single.gene|one.gene|autosomal|mendel\w*|"
                r"punnett|heterozyg\w*|homozyg\w*|complete dominance)\b"
            ),
            statistic: _FIT_CUE + r"|\bgoodness.of.fit\b",
        },
    )


def require_cross_scope(prompt: str, *, has_materials: bool) -> None:
    limitation = explicit_limitation(prompt)
    if limitation is not None:
        raise UnsupportedAuthoringRequest(limitation)
    if not has_materials and not requested(_CROSS_CUES, prompt):
        raise UnsupportedAuthoringRequest(
            "Biology can independently check offspring probabilities, expected "
            "counts and ratios for a one-gene Mendelian cross with complete "
            "dominance. The requested task needs a different biological check."
        )


def require_cross_output(prompt: str, item: AuthoredCross) -> None:
    question = item.question
    for cue, quantity, label in (
        (
            r"\b(?:expected[ -](?:count|number)|how many\b[^.!?]*\bexpect\w*)\b",
            "expected_count",
            "expected count",
        ),
        (r"\b(?:genotype|genotypic|phenotype|phenotypic) ratio\b", "ratio", "ratio"),
        (
            r"\b(?:probability|proportion|fraction) of offspring\b"
            r"|\boffspring (?:phenotype |genotype )?probability\b",
            "probability",
            "probability",
        ),
    ):
        if requested(cue, prompt):
            if question.quantity != quantity:
                raise UnsupportedAuthoringRequest(
                    f"The authored cross must ask for the requested {label}."
                )
            break

    for role in ("dominant", "recessive"):
        if not requested(
            r"\b(?:count|number|probability|proportion|fraction) "
            r"of (?:the )?offspring "
            rf"(?:with|showing|that show) (?:the )?{role} phenotype\b"
            rf"|\bexpected to (?:show|have) (?:the )?{role} phenotype\b",
            prompt,
        ):
            continue
        target = question.target
        if target is not None and target.kind == "phenotype":
            axis = next(axis for axis in item.parameters if axis.name == target.param)
            if axis.values == [role]:
                continue
        raise UnsupportedAuthoringRequest(
            f"The authored cross must target offspring with the {role} phenotype."
        )

    conditional = requested(
        r"\bconditional\b|\bgiven that\b"
        r"|\bamong\s+(?:the\s+)?[\w -]{1,30}\s+offspring\b"
        r"|\bamong (?:the )?offspring (?:with|showing)\b",
        prompt,
    )
    if conditional and question.given is None:
        raise UnsupportedAuthoringRequest("Include the requested offspring condition.")
    if not any(len(axis.values) > 1 for axis in item.parameters):
        raise UnsupportedAuthoringRequest(
            "Vary a visible parent genotype, target or offspring count to produce "
            "more than one reusable question."
        )


def cross_wording(item: AuthoredCross) -> str:
    question = item.question
    symbol = item.gene.symbol
    stem = (
        "In a hypothetical organism called {organism}, {trait} follows single-gene "
        "autosomal Mendelian inheritance. "
        f"Allele {symbol} ({{dominant_phenotype}}) is completely dominant over "
        f"{symbol.lower()} ({{recessive_phenotype}}). "
        f"The parent genotypes are {{{item.cross.parent1}}} "
        f"and {{{item.cross.parent2}}}. "
    )
    if question.quantity == "ratio":
        return (
            stem
            + f"What is the expected {question.ratio_kind} ratio among the offspring?"
        )
    assert question.target is not None
    target = f"{question.target.kind} {{{question.target.param}}}"
    group = (
        "offspring with the {given_phenotype} phenotype"
        if question.given
        else "offspring"
    )
    if question.quantity == "expected_count":
        return (
            stem + f"Among {{{question.offspring_count}}} {group}, "
            f"how many are expected to have {target}?"
        )
    return (
        stem + f"Among the {group}, what is the probability that a randomly chosen "
        f"individual has {target}?"
    )


def uses_checked_cross_wording(item: MonohybridTemplateSpec) -> bool:
    return (
        item.text.template == cross_wording(item)
        and CROSS_LABEL_PATTERN.fullmatch(item.organism) is not None
        and CROSS_LABEL_PATTERN.fullmatch(item.trait) is not None
    )


def checked_cross(item: AuthoredCross) -> MonohybridTemplateSpec:
    return MonohybridTemplateSpec.model_validate(
        {
            **item.model_dump(),
            "text": {"template": cross_wording(item)},
        }
    )
