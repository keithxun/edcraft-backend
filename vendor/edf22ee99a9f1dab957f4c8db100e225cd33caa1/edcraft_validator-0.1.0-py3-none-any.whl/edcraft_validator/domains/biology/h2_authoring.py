"""Check and expand closed H2 biology case selections."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Literal

from edcraft_validator.domains.biology.biology_schemas import (
    H2BiologyQuestionInstance,
    H2TemplateSpec,
    ValidatedBiologyTemplate,
)
from edcraft_validator.domains.biology.checking import CheckReport
from edcraft_validator.domains.biology.cross import BiologyCheckError
from edcraft_validator.domains.biology.h2_cases import (
    CHEMIOSMOSIS_CONTRASTS,
    SYLLABUS_URL,
    H2Case,
    cases_sha256,
    resolve_h2_cases,
)
from edcraft_validator.domains.biology.h2_task_scope import (
    CAPABILITIES,
    CHI_MISCONCEPTIONS,
)
from edcraft_validator.domains.domain_support import seeded_index
from edcraft_validator.validation.check_contracts import ToolFinding
from edcraft_validator.validation.distractor_pool import (
    DistractorPoolError,
    OptionValue,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure


def _misconceptions_by_slot(case_id: str) -> dict[int, str]:
    if contrasts := CHEMIOSMOSIS_CONTRASTS.get(case_id):
        return dict(enumerate(contrasts, start=1))
    capability = CAPABILITIES.get(case_id)
    return CHI_MISCONCEPTIONS.get(capability, {}) if capability is not None else {}


def select_h2_distractors(item: H2TemplateSpec, required: int) -> H2TemplateSpec:
    """Select one fixed slot set across the entire declared case family."""
    if required > 6:
        raise DistractorPoolError("H2 catalogue cases support up to six distractors")
    try:
        cases = resolve_h2_cases(item, require_digest=False)
    except BiologyCheckError as exc:
        raise DistractorPoolError(f"{exc.code}: {exc.message}") from None
    slots = item.distractors
    if any(_misconceptions_by_slot(case.id) for case in cases):
        # For these closed families the author does not supply misconception evidence.
        # Prefer the independent checks before considering compound errors.
        slots = [index % 6 + 1 for index in range(len(slots))]
    rows = [
        (
            OptionValue(0, case.answer),
            [OptionValue(slot, case.choice(slot)) for slot in slots],
        )
        for case in cases
    ]
    indexes = select_fixed_subset(
        rows,
        required,
        assignments=[{"case": case.id} for case in cases],
    )
    return item.model_copy(
        update={
            "distractors": [slots[index] for index in indexes],
            "catalogue_sha256": cases_sha256(cases),
        }
    )


def h2_choices(case: H2Case, item: H2TemplateSpec) -> list[str]:
    """Resolve approved distractor slots, also rejecting corrupt artifacts."""
    if 0 in item.distractors:
        raise BiologyCheckError(
            "DISTRACTOR_EQUALS_KEY", "Slot zero is the correct answer"
        )
    if len(item.distractors) != len(set(item.distractors)):
        raise BiologyCheckError(
            "DISTRACTORS_NOT_DISTINCT", "A distractor slot was selected more than once"
        )
    return [case.choice(slot) for slot in item.distractors]


def check_h2_template(
    item: H2TemplateSpec,
    settings: PropertyCheckSettings | None,
    *,
    aspect: Literal["cross", "options", "fidelity"],
) -> CheckReport:
    """Verify every case in the declared selection against the pinned catalogue."""
    run = PropertyCheckRun(settings or PropertyCheckSettings())
    variants = []

    try:
        cases = resolve_h2_cases(item)
        by_id = {case.id: case for case in cases}

        def check(values: dict[str, str], budget: PropertyCheckRun) -> dict[str, Any]:
            budget.reserve_execution()
            case = by_id[values["case"]]
            record: dict[str, Any] = {"case": case.id, "outcome": case.outcome}
            capability = CAPABILITIES.get(case.id)
            if capability is not None:
                record["task_capability"] = asdict(capability)
            if aspect == "cross":
                record["answer"] = case.answer
                record["explanation"] = case.explanation
            elif aspect == "options":
                record["option_values"] = h2_choices(case, item)
                misconceptions = _misconceptions_by_slot(case.id)
                if misconceptions:
                    record["misconceptions_tested"] = [
                        label
                        for slot, label in misconceptions.items()
                        if slot in item.distractors
                    ]
                    record["misconceptions_omitted"] = [
                        label
                        for slot, label in misconceptions.items()
                        if slot not in item.distractors
                    ]
            else:
                record["question"] = case.question
                record["rendering"] = "canonical_catalogue"
                if case.figure is not None:
                    record["figure_alt"] = case.figure.alt
            variants.append(record)
            return record

        run.check(
            {"case": list(by_id)},
            [{"case": case.id} for case in cases],
            check,
            cover_small_domain=True,
        )
    except (BiologyCheckError, ValidationFailure) as exc:
        status: Literal["error", "failed"] = (
            "error" if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" else "failed"
        )
        return CheckReport(
            status=status,
            findings=[ToolFinding(code=exc.code, message=str(exc))],
            details=run.details() if run.declared_domain_size else {},
        )
    run.whole_domain = len(variants) == len(cases)
    return CheckReport(
        status="passed",
        findings=[],
        details={
            **run.details(),
            "variants": variants,
            "variants_truncated": False,
            "catalogue_sha256": item.catalogue_sha256,
            "syllabus_url": SYLLABUS_URL,
        },
    )


def generate_h2_question(
    validated: ValidatedBiologyTemplate, item: H2TemplateSpec, seed: int
) -> H2BiologyQuestionInstance:
    cases = resolve_h2_cases(item)
    template_id = validated.template.template_id
    case = cases[seeded_index(template_id, seed, "case", len(cases))]
    choices = h2_choices(case, item)
    correct_index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
    choices.insert(correct_index, case.answer)
    return H2BiologyQuestionInstance(
        template_id=template_id,
        artifact_id=validated.artifact_id,
        seed=seed,
        parameters={"case": case.id},
        question=case.question,
        choices=choices,
        correct_index=correct_index,
        answer=case.answer,
        topic=case.topic,
        case_id=case.id,
        explanation=case.explanation,
        figure=case.figure,
    )
