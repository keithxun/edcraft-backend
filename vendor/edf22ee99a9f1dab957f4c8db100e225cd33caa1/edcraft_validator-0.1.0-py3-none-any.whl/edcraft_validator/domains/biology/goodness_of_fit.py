"""Calculate, render and check authored plant-count goodness-of-fit questions."""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any

from edcraft_validator.domains.biology.biology_schemas import (
    BiologyFitQuestionInstance,
    ValidatedBiologyTemplate,
)
from edcraft_validator.domains.biology.checking import Aspect, CheckReport
from edcraft_validator.domains.biology.fit_schema import (
    Decision,
    FitDistractor,
    GoodnessOfFitTemplate,
)
from edcraft_validator.domains.domain_support import seeded_index
from edcraft_validator.validation.check_contracts import ToolFinding
from edcraft_validator.validation.distractor_pool import (
    DistractorPoolError,
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure


@dataclass(frozen=True)
class CountRow:
    observed: int
    expected: Fraction

    @property
    def squared_difference(self) -> Fraction:
        return (self.observed - self.expected) ** 2

    @property
    def contribution(self) -> Fraction:
        return self.squared_difference / self.expected


@dataclass(frozen=True)
class FitAnswer:
    hundredths: int
    decision: Decision | None

    @property
    def display(self) -> str:
        whole, decimal = divmod(self.hundredths, 100)
        suffix = {
            None: "",
            "reject": ". Reject the model.",
            "fail_to_reject": ". Fail to reject the model.",
        }[self.decision]
        return f"χ² = {whole}.{decimal:02d}{suffix}"

    def option(self) -> OptionValue:
        return OptionValue(self, self.display)


def _axes(item: GoodnessOfFitTemplate) -> dict[str, list[int]]:
    return {
        f"category_{index}": category.observed
        for index, category in enumerate(item.categories, start=1)
    }


def _count_rows(item: GoodnessOfFitTemplate, values: dict[str, int]) -> list[CountRow]:
    total = sum(values.values())
    weights = [category.expected_weight for category in item.categories]
    rows = [
        CountRow(values[name], Fraction(total * weight, sum(weights)))
        for name, weight in zip(_axes(item), weights, strict=True)
    ]
    if any(row.expected < 5 for row in rows):
        raise ValidationFailure(
            "Every expected count must be at least 5. Increase the sample size "
            "or change the expected proportions.",
            code="FIT_EXPECTED_COUNT_TOO_SMALL",
            context={"observed": values},
        )
    return rows


def _rounded_answer(statistic: Fraction, decision: Decision | None) -> FitAnswer:
    return FitAnswer(int(statistic * 100 + Fraction(1, 2)), decision)


def _answer(item: GoodnessOfFitTemplate, statistic: Fraction) -> FitAnswer:
    decision: Decision | None = None
    if item.critical_value is not None:
        decision = (
            "reject" if statistic > Fraction(item.critical_value) else "fail_to_reject"
        )
    return _rounded_answer(statistic, decision)


def _key(item: GoodnessOfFitTemplate, rows: list[CountRow]) -> FitAnswer:
    return _answer(item, sum((row.contribution for row in rows), Fraction()))


def _distractor(
    item: GoodnessOfFitTemplate,
    rule: FitDistractor,
    rows: list[CountRow],
    key: FitAnswer,
) -> FitAnswer:
    match rule.rule:
        case "observed_denominator":
            wrong = sum(
                (row.squared_difference / row.observed for row in rows), Fraction()
            )
        case "unweighted_squared_error":
            wrong = sum((row.squared_difference for row in rows), Fraction())
        case "omit_category":
            wrong = sum(
                (
                    row.contribution
                    for index, row in enumerate(rows, start=1)
                    if index != rule.category
                ),
                Fraction(),
            )
        case "divide_by_total":
            wrong = sum((row.contribution for row in rows), Fraction()) / sum(
                row.observed for row in rows
            )
        case "largest_contribution":
            wrong = max(row.contribution for row in rows)
        case "reverse_decision":
            return FitAnswer(
                key.hundredths,
                "fail_to_reject" if key.decision == "reject" else "reject",
            )
        case "fixed_value":
            assert rule.statistic is not None
            return _rounded_answer(Fraction(rule.statistic), rule.decision)
    return _answer(item, wrong)


def _declared_claims(
    item: GoodnessOfFitTemplate, axes: dict[str, list[int]]
) -> dict[tuple[int, ...], list[FitAnswer]]:
    claims: dict[tuple[int, ...], list[FitAnswer]] = {}
    for claim in item.claimed_examples:
        if len(claim.observed) != len(axes) or any(
            value not in domain
            for value, domain in zip(claim.observed, axes.values(), strict=True)
        ):
            raise ValidationFailure(
                "A claimed example must provide one declared count per category.",
                code="FIT_CLAIM_NOT_DECLARED",
            )
        claims.setdefault(tuple(claim.observed), []).append(
            _rounded_answer(Fraction(claim.statistic), claim.decision)
        )
    return claims


def _check_rule_shapes(item: GoodnessOfFitTemplate) -> None:
    decision = item.critical_value is not None
    for rule in item.distractors:
        if (
            (rule.category is not None and rule.category > len(item.categories))
            or (rule.rule == "reverse_decision" and not decision)
            or (rule.rule == "fixed_value" and (rule.decision is not None) != decision)
        ):
            raise ValidationFailure(
                f"The {rule.rule} recipe does not match this table or answer format.",
                code="FIT_INAPPLICABLE_DISTRACTOR",
                field="distractors",
            )


def _checked_options(
    item: GoodnessOfFitTemplate, rows: list[CountRow], key: FitAnswer
) -> list[FitAnswer]:
    if not item.distractors:
        raise ValidationFailure("Provide distractor recipes.", code="NO_OPTIONS")
    try:
        options = [_distractor(item, rule, rows, key) for rule in item.distractors]
    except ZeroDivisionError as exc:
        raise ValidationFailure(
            "An option uses an observed count of zero as a divisor.",
            code="FIT_UNDEFINED_DISTRACTOR",
        ) from exc
    if len({key, *options}) != len(options) + 1:
        raise ValidationFailure(
            "A displayed option equals the key or another option.",
            code="FIT_OPTION_COLLISION",
        )
    return options


def choose_fit_distractors(
    item: GoodnessOfFitTemplate, required: int
) -> list[FitDistractor]:
    """Find one set of recipes that survives the declared inputs sampled here."""
    try:
        _check_rule_shapes(item)
    except ValidationFailure as exc:
        raise DistractorPoolError(str(exc)) from exc
    axes = _axes(item)
    assignments = sample_assignments(axes)

    def options(values):
        try:
            rows = _count_rows(item, values)
        except ValidationFailure as exc:
            raise DistractorPoolError(str(exc)) from exc
        key = _key(item, rows)
        candidates = []
        for rule in item.distractors:
            try:
                candidates.append(_distractor(item, rule, rows, key).option())
            except ZeroDivisionError:
                candidates.append(UnusableOption("an observed count is zero"))
        return key.option(), candidates

    indices = select_fixed_subset(
        map(options, assignments), required, assignments=assignments
    )
    return [item.distractors[index] for index in indices]


def check_fit_template(
    item: GoodnessOfFitTemplate,
    settings: PropertyCheckSettings | None,
    *,
    aspect: Aspect,
) -> CheckReport:
    """Re-derive exact values on boundaries, claims and a bounded property sample."""
    axes = _axes(item)
    run = PropertyCheckRun(settings or PropertyCheckSettings())

    def check(values: dict[str, int], budget: PropertyCheckRun) -> dict[str, Any]:
        budget.reserve_execution()
        rows = _count_rows(item, values)
        key = _key(item, rows)
        for claim in claims.get(tuple(values[name] for name in axes), []):
            if claim != key:
                raise ValidationFailure(
                    f"The claimed answer {claim.display!r} differs from {key.display!r}"
                    " "
                    f"for observed counts {list(values.values())}.",
                    code="FIT_CLAIM_MISMATCH",
                    field="claimed_examples",
                )
        options = _checked_options(item, rows, key) if aspect == "options" else []
        return {
            "observed": values,
            "expected": [str(row.expected) for row in rows],
            "chi_square_exact": str(
                sum((row.contribution for row in rows), Fraction())
            ),
            "key": key.display,
            "option_values": [option.display for option in options],
        }

    try:
        claims = _declared_claims(item, axes)
        if aspect == "options":
            _check_rule_shapes(item)
        first = {name: values[0] for name, values in axes.items()}
        boundary = [
            first,
            {name: values[-1] for name, values in axes.items()},
            {name: min(values) for name, values in axes.items()},
            {name: max(values) for name, values in axes.items()},
            *(
                first | {name: edge}
                for name, values in axes.items()
                for edge in (min(values), max(values))
            ),
            *(dict(zip(axes, observed, strict=True)) for observed in claims),
        ]
        variants = run.check(axes, boundary, check, cover_small_domain=True)
    except ValidationFailure as exc:
        return CheckReport(
            status="failed",
            findings=[ToolFinding(code=exc.code, message=str(exc), field=exc.field)],
            details=run.details(),
        )
    return CheckReport(
        status="passed", findings=[], details={**run.details(), "variants": variants}
    )


def render_fit_table(item: GoodnessOfFitTemplate, values: dict[str, int]) -> str:
    rows = _count_rows(item, values)
    counts = item.expected_display == "counts"
    lines = ["A random sample of hypothetical plants gave these phenotype counts."]
    if counts:
        lines[0] = (
            "Observed and expected phenotype counts for a random sample of "
            "hypothetical plants:"
        )
    for category, row in zip(item.categories, rows, strict=True):
        expected = f" (expected {row.expected})" if counts else ""
        lines.append(f"{category.label}: {row.observed}{expected}")
    if not counts:
        ratio = ":".join(str(category.expected_weight) for category in item.categories)
        lines.append(f"Expected phenotype ratio is {ratio} in the listed order.")
    lines.append(
        "Calculate the chi-square goodness-of-fit statistic to two decimal places."
    )
    if item.critical_value is not None:
        lines.append(
            f"The critical value is {item.critical_value}. Decide whether to reject "
            "the model. Compare the unrounded statistic and reject if it exceeds "
            "the critical value."
        )
    return "\n".join(lines)


def fit_relevance_text(item: GoodnessOfFitTemplate) -> str:
    return render_fit_table(
        item, {name: values[0] for name, values in _axes(item).items()}
    )


def generate_fit_question(
    artifact: ValidatedBiologyTemplate, item: GoodnessOfFitTemplate, seed: int
) -> BiologyFitQuestionInstance:
    template_id = artifact.template.template_id
    assignments = sample_assignments(_axes(item), budget=100, seed=seed)
    start = seeded_index(template_id, seed, "fit-variant", len(assignments))
    for offset in range(len(assignments)):
        values = assignments[(start + offset) % len(assignments)]
        try:
            rows = _count_rows(item, values)
            key = _key(item, rows)
            wrong = _checked_options(item, rows, key)
        except ValidationFailure:
            continue
        choices = [option.display for option in wrong]
        index = seeded_index(template_id, seed, "fit-correct-index", len(choices) + 1)
        choices.insert(index, key.display)
        return BiologyFitQuestionInstance(
            template_id=template_id,
            artifact_id=artifact.artifact_id,
            operation="chi_square_goodness_of_fit",
            seed=seed,
            parameters={name: str(value) for name, value in values.items()},
            question=render_fit_table(item, values),
            choices=choices,
            correct_index=index,
            answer=key.display,
            topic=item.topic,
        )
    raise ValueError("Could not produce a checked chi-square count table for this seed")
