"""Select and constrain the question formats and cases offered to the author."""

import math
import re
from collections import Counter
from dataclasses import dataclass
from functools import cache, lru_cache, reduce
from operator import or_
from typing import Literal

from pydantic import Field, create_model

from edcraft_validator.domain_types import Difficulty
from edcraft_validator.domains.biology.biology_schemas import (
    BiologyAuthorProposal,
    BiologyUnsupportedSpec,
    H2CaseSelection,
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.h2_cases import FigureKind, H2Case, h2_catalogue
from edcraft_validator.domains.biology.h2_task_scope import (
    CAPABILITIES,
    TaskCapability,
    hard_task_note,
    task_scope,
)
from edcraft_validator.domains.biology.h2_task_scope import (
    requested as _requested,
)

_OFFER_LIMIT = 12
_MC_FORMAT = re.compile(
    r"\b(?:mcqs?|multiple[- ]choice|single[- ]best[- ]answer)\b", re.I
)
_COMPARISON = re.compile(
    r"\b(?:compar\w*|contrast\w*|distinguish\w*|versus|vs)\b", re.I
)
_WRITTEN_WORK = re.compile(
    r"\b(?:essay|free[- ](?:form|response)|open[- ]ended|"
    r"constructed[- ]response|extended[- ]response)\b",
    re.I,
)
_OWN_DIAGRAM = re.compile(
    r"\b(?:draw|sketch|annotate|construct)\b[^.!?]{0,100}"
    r"\b(?:from scratch|their own|original|unaided)\b"
    r"|\b(?:their|learner|student)'?s?\s+(?:own|original)\s+(?:drawing|diagram|sketch)",
    re.I,
)
_BENCH_OBSERVATION = re.compile(
    r"\b(?:watch(?:ing)?|observ(?:e|ing)|grad(?:e|ing))\b[^.!?]{0,125}"
    r"\b(?:mount(?:ing)?[^.!?]{0,32}\bslides?|focus(?:ing)?[^.!?]{0,36}\bmicroscope|"
    r"hands[- ]on|pipett(?:e|ing)|"
    r"(?:original|own)\s+(?:graticule\s+)?(?:readings|measurements))\b",
    re.I,
)
_STOP = frozenset(
    "a an and are as assess at be biology by create for from give h2 in is it "
    "make mcq of on or question should students that the to use using what "
    "which who with write singapore".split()
)


@dataclass(frozen=True)
class BiologyAuthorOffer:
    cases: tuple[H2Case, ...]
    allows_monohybrid: bool
    scope_note: str = ""
    task: TaskCapability | None = None
    difficulty_note: str = ""


def _unsupported_format(prompt: str) -> str:
    if _requested(_MC_FORMAT, prompt):
        return ""
    if _requested(_BENCH_OBSERVATION, prompt):
        return "The request requires observing or assessing hands-on practical work."
    if _requested(_WRITTEN_WORK, prompt):
        return "The request requires an original written response."
    if _requested(_OWN_DIAGRAM, prompt):
        return "The request requires a learner to produce an original drawing."
    return ""


def _required_visual(prompt: str) -> frozenset[FigureKind]:
    if _requested(
        r"\b(?:tem|transmission electron micro(?:graphs?|scop\w+))\b", prompt
    ):
        return frozenset({"transmission electron micrograph"})
    if _requested(r"\b(?:sem|scanning electron micro(?:graphs?|scop\w+))\b", prompt):
        return frozenset({"scanning electron micrograph"})
    if _requested(r"\belectron micrographs?\b", prompt):
        return frozenset(
            {"transmission electron micrograph", "scanning electron micrograph"}
        )
    if _requested(r"\b(?:light micrographs?|photomicrographs?)\b", prompt):
        return frozenset({"light photomicrograph"})
    if _requested(r"\bmicrographs?\b", prompt):
        return frozenset(
            {
                "transmission electron micrograph",
                "scanning electron micrograph",
                "light photomicrograph",
            }
        )
    if _requested(r"\b(?:schematic|diagrammatic)\b", prompt):
        return frozenset({"schematic"})
    return frozenset()


def _normalize_terms(text: str) -> str:
    return re.sub(r"\bnon[ -](?=[a-z])", "non", text.lower())


def _terms(text: str) -> frozenset[str]:
    text = _normalize_terms(text)
    return frozenset(
        word.removesuffix("s")
        for word in re.findall(r"[a-z]+", text)
        if len(word) > 1 and word not in _STOP
    )


@cache
def _case_vocabulary() -> dict[str, frozenset[str]]:
    return {
        case.id: _terms(
            f"{case.id} {case.topic} {case.learner_context()} {case.answer}"
        )
        for case in h2_catalogue().values()
    }


@cache
def _catalogue_contrasts() -> dict[tuple[str, str], tuple[H2Case, ...]]:
    # Recognize a term and its non-prefixed counterpart only when the
    # catalogue itself assesses both in the same family. Ignore distractors and
    # explanations, which often mention the term the item is contrasting.
    cases = tuple(h2_catalogue().values())
    primary_terms = {
        case.id: _terms(f"{case.question} {case.answer}") for case in cases
    }
    contrasts = {}
    for case in cases:
        label = case.id.rsplit(".", 1)[-1]
        counterpart = label.removeprefix("non")
        if label == counterpart or label not in primary_terms[case.id]:
            continue
        siblings = tuple(sibling for sibling in cases if sibling.topic == case.topic)
        direct = tuple(
            sibling
            for sibling in siblings
            if counterpart in primary_terms[sibling.id]
            and label not in primary_terms[sibling.id]
        )
        if direct:
            contrasts[counterpart, label] = direct
            contrasts[label, counterpart] = tuple(
                sibling
                for sibling in siblings
                if label in primary_terms[sibling.id]
                and counterpart not in primary_terms[sibling.id]
            )
    return contrasts


def _single_contrast(prompt: str) -> tuple[H2Case, ...]:
    if _COMPARISON.search(prompt):
        return ()
    normalized = _normalize_terms(prompt)
    matches = [
        cases
        for (focus, counterpart), cases in _catalogue_contrasts().items()
        if _requested(rf"\b{re.escape(focus)}\b", normalized)
        and not _requested(rf"\b{re.escape(counterpart)}\b", normalized)
    ]
    return matches[0] if len(matches) == 1 else ()


def biology_author_offer(
    prompt: str, difficulty: Difficulty = "medium"
) -> BiologyAuthorOffer:
    """Offer only qualifying case IDs for known learner actions and formats."""
    unsupported = _unsupported_format(prompt)
    if unsupported:
        return BiologyAuthorOffer((), False, unsupported)

    visual = _required_visual(prompt)
    cases = tuple(
        case
        for case in h2_catalogue().values()
        if not visual or case.figure_kind in visual
    )
    if visual and not cases:
        return BiologyAuthorOffer((), False, "The requested image type is unavailable.")
    identifiers = set(re.findall(r"[a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+", prompt.lower()))
    explicit = tuple(case for case in cases if {case.topic, case.id} & identifiers)
    scope = task_scope(prompt, difficulty)
    if scope is not None:
        required = scope.capability
        if required is None:
            return BiologyAuthorOffer((), False, scope.note)
        matched = tuple(
            case
            for case in (explicit or cases)
            if (capability := CAPABILITIES.get(case.id)) is not None
            and capability.satisfies(required)
        )
        if not matched:
            label = " and ".join(required.actions)
            return BiologyAuthorOffer(
                (),
                False,
                f"No verified catalogue case can {label} "
                "with the requested givens and format.",
                task=required,
            )
        return BiologyAuthorOffer(
            matched,
            False,
            task=required,
            difficulty_note=hard_task_note(
                tuple(case.id for case in matched), difficulty
            ),
        )
    if visual:
        kinds = " or ".join(sorted(visual))
        return BiologyAuthorOffer(cases, False, f"Use an actual {kinds}.")

    direct = _single_contrast(prompt)
    if direct:
        return BiologyAuthorOffer(direct, False)
    if explicit:
        return BiologyAuthorOffer(explicit, True)

    vocabulary = _case_vocabulary()
    counts = Counter(term for case in cases for term in vocabulary[case.id])
    required = _terms(prompt)

    def score(case: H2Case) -> float:
        return sum(
            math.log1p(len(cases) / counts[term])
            for term in sorted(required & vocabulary[case.id])
        )

    ranked = sorted(cases, key=lambda case: (-score(case), case.id))
    selected = tuple(case for case in ranked[:_OFFER_LIMIT] if score(case) > 0)
    return BiologyAuthorOffer(selected, True)


@lru_cache(maxsize=128)
def biology_author_proposal_type(
    case_ids: tuple[str, ...], allows_monohybrid: bool
) -> type[BiologyAuthorProposal]:
    # Narrow the author schema only. Persisted templates keep the original
    # schema and digest checking independent of the per-request offer.
    item_types = [BiologyUnsupportedSpec]
    if allows_monohybrid:
        item_types.append(MonohybridTemplateSpec)
    if case_ids:
        item_types.append(
            create_model(
                "OfferedH2BiologyCases",
                __base__=H2CaseSelection,
                cases=(list[Literal[case_ids]], Field(min_length=1, max_length=32)),
            )
        )
    return create_model(
        "OfferedBiologyProposal",
        __base__=BiologyAuthorProposal,
        item=(reduce(or_, item_types), ...),
    )
