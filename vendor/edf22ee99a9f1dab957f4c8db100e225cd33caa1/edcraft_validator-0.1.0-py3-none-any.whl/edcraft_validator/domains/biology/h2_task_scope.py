"""Closed task capabilities for the H2 topics with deterministic routing."""

import re
from dataclasses import dataclass
from decimal import Decimal

from edcraft_validator.domain_types import Difficulty
from edcraft_validator.domains.biology.h2_cases import CHEMIOSMOSIS_CONTRASTS

_EXCLUDED = re.compile(
    r"\b(?:no|not|without|avoid|exclude|instead of|rather than)\s+"
    r"(?:(?:a|an|the|any|actual|real|using|asking|about|on|transmission|"
    r"scanning|electron|light|micrographs?|photomicrographs?|schematics?|"
    r"essays?|or|nor|and)\s+){0,8}$",
    re.I,
)


@dataclass(frozen=True)
class TaskCapability:
    givens: tuple[str, ...]
    actions: tuple[str, ...]
    constraints: tuple[str, ...]
    answer_form: str

    def satisfies(self, required: "TaskCapability") -> bool:
        return (
            self.answer_form == required.answer_form
            and set(self.givens).issuperset(required.givens)
            and set(self.actions).issuperset(required.actions)
            and set(self.constraints).issuperset(required.constraints)
        )


@dataclass(frozen=True)
class ScopedTask:
    capability: TaskCapability | None
    note: str = ""


MITOSIS_ROLES = TaskCapability(
    ("mitotic daughter cells",),
    ("explain the roles of mitosis",),
    ("growth, repair and asexual reproduction", "chromosome complement preserved"),
    "causal explanation",
)
MITOSIS_STAGES = TaskCapability(
    ("described events of animal mitosis",),
    ("order stages",),
    ("typical mitotic division",),
    "ordered events",
)
ANAPHASE_ONSET = TaskCapability(
    ("mitotic anaphase",),
    ("identify its onset event",),
    ("typical mitotic division",),
    "named event",
)
BIRD_FOOD_MISMATCH = TaskCapability(
    ("temperature-driven earlier insect peak", "unchanged bird arrival"),
    ("predict insect prey availability for breeding birds",),
    ("insect peak and bird arrival become less aligned",),
    "consequence for consumer food supply",
)
POLLINATION_MISMATCH = TaskCapability(
    ("temperature-driven earlier flowering", "unchanged pollinator emergence"),
    ("predict pollination and fruit set",),
    ("flowering and pollinator emergence become less aligned",),
    "consequence for plant reproduction",
)
CHEMIOSMOSIS_COMPARE = TaskCapability(
    ("thylakoid membrane", "inner mitochondrial membrane"),
    ("compare proton accumulation and ATP formation sites",),
    ("both organelles",),
    "paired compartment assignments",
)
RESPIRATORY_OXYGEN = TaskCapability(
    ("respiratory electron transport chain", "oxygen as terminal acceptor"),
    ("link electron acceptance to sustained ATP synthesis",),
    ("mitochondrial respiration",),
    "causal explanation",
)
CHI_LEGACY_DECISION = TaskCapability(
    ("observed counts", "expected counts", "one supplied critical value"),
    ("calculate chi-square", "decide whether to reject"),
    ("inheritance goodness of fit", "5% significance"),
    "decision from counts",
)
CHI_SUPPLIED_COUNTS = TaskCapability(
    CHI_LEGACY_DECISION.givens,
    (*CHI_LEGACY_DECISION.actions, "report the numerical chi-square statistic"),
    CHI_LEGACY_DECISION.constraints,
    "statistic and decision",
)
CHI_MODEL = TaskCapability(
    ("observed counts", "parental cross and phenotype rules", "critical value table"),
    (
        "derive grouped expected counts",
        "determine degrees of freedom",
        "calculate chi-square",
        "decide whether to reject",
    ),
    ("inheritance goodness of fit", "5% significance"),
    "expected counts, degrees of freedom and decision",
)
CHI_DECISION = TaskCapability(
    ("supplied chi-square statistic", "one supplied critical value"),
    ("decide whether to reject", "interpret evidence for the model"),
    ("inheritance goodness of fit", "5% significance"),
    "decision and interpretation",
)
CHI_DF = TaskCapability(
    ("four observed offspring categories", "fixed class proportions"),
    ("determine degrees of freedom",),
    ("inheritance goodness of fit", "no fitted parameters"),
    "degrees of freedom",
)
CHI_EXPECTED = TaskCapability(
    ("offspring total", "predicted four-class ratio"),
    ("convert ratio to expected counts",),
    ("inheritance goodness of fit",),
    "expected counts",
)

CAPABILITIES = {
    "skill.genetic.mitosis_roles": MITOSIS_ROLES,
    "skill.genetic.mitotic_stages": MITOSIS_STAGES,
    "genetics.mitosis": ANAPHASE_ONSET,
    "skill.climate.food_chains": BIRD_FOOD_MISMATCH,
    "climate.food": POLLINATION_MISMATCH,
    "skill.energy.chemiosmosis_compare": CHEMIOSMOSIS_COMPARE,
    **dict.fromkeys(CHEMIOSMOSIS_CONTRASTS, CHEMIOSMOSIS_COMPARE),
    "energy.chemiosmosis": RESPIRATORY_OXYGEN,
    "genetics.chi_square": CHI_LEGACY_DECISION,
    "genetics.chi_square_reject": CHI_LEGACY_DECISION,
    "genetics.chi_statistic_below": CHI_SUPPLIED_COUNTS,
    "genetics.chi_statistic_above": CHI_SUPPLIED_COUNTS,
    "genetics.chi_model_petal": CHI_MODEL,
    "genetics.chi_model_leaf": CHI_MODEL,
    "genetics.chi_interpret_petal": CHI_DECISION,
    "genetics.chi_interpret_leaf": CHI_DECISION,
    "skill.genetic.chi_df": CHI_DF,
    "skill.genetic.chi_expected": CHI_EXPECTED,
}

CHI_MISCONCEPTIONS = {
    CHI_MODEL: {
        1: "misgroup two-locus phenotype classes",
        2: "use the wrong number of observed classes",
        3: "reverse the critical-value decision",
    },
    CHI_SUPPLIED_COUNTS: {
        1: "divide by observed instead of expected counts",
        2: "reverse the critical-value decision",
        3: "skip the most abundant offspring class",
    },
}

_HARD_ALTERNATIVES = {
    MITOSIS_ROLES: "infer how a segregation error affects chromosome number and growth",
    MITOSIS_STAGES: "infer mitotic stages from chromosome and spindle observations",
    ANAPHASE_ONSET: "interpret a sequence of chromosome and spindle observations",
    BIRD_FOOD_MISMATCH: "compare seasonal prey abundance and bird breeding demand",
    POLLINATION_MISMATCH: "predict fruit set from flowering and pollinator activity",
    CHEMIOSMOSIS_COMPARE: "infer how loss of each gradient changes ATP production",
    RESPIRATORY_OXYGEN: "interpret ATP measurements after a change in oxygen supply",
    CHI_LEGACY_DECISION: "derive expected counts from a cross before testing fit",
    CHI_SUPPLIED_COUNTS: (
        "derive expected counts and select a critical value "
        "from degrees of freedom before testing fit"
    ),
    CHI_DECISION: "derive expected counts and a statistic before deciding model fit",
    CHI_DF: "determine degrees of freedom after grouping observed phenotypes",
    CHI_EXPECTED: "derive expected counts from a cross and use them to test model fit",
}


def requested(pattern: str | re.Pattern[str], prompt: str) -> bool:
    compiled = re.compile(pattern, re.I) if isinstance(pattern, str) else pattern
    return any(
        not _EXCLUDED.search(prompt[: match.start()])
        for match in compiled.finditer(prompt)
    )


def hard_task_note(case_ids: tuple[str, ...], difficulty: Difficulty) -> str:
    if difficulty != "hard" or not case_ids:
        return ""
    capability = CAPABILITIES.get(case_ids[0])
    if capability is None or any(
        CAPABILITIES.get(case) != capability for case in case_ids
    ):
        return ""
    alternative = _HARD_ALTERNATIVES.get(capability)
    if alternative is None:
        return ""
    return (
        "The requested task is available as a routine question. "
        f"A harder task would ask students to {alternative}. "
        "That change would require teacher approval."
    )


def _chi_square_task(prompt: str, difficulty: Difficulty) -> ScopedTask:
    alpha = re.findall(r"\b\d+(?:\.\d+)?\s*%", prompt)
    exact_counts = re.search(r"\b\d+\s*[,;:/]\s*\d+\s*[,;:/]\s*\d+\b", prompt)
    named_counts = requested(
        r"\b(?:observed|expected)\b(?:\s+(?:offspring|phenotype|class))?"
        r"(?:\s+(?:counts?|frequencies|numbers))?"
        r"\s*(?:(?:of|are|were|is)\b|[:=])?\s*"
        r"[\[(]?\s*\d+(?:\s+[a-z]+){0,3}\s*(?:[,;:/]|\band\b)\s*\d+\b",
        prompt,
    )
    threshold = re.search(
        r"\bcritical (?:chi[- ]squared? |χ² )?value\s*(?:of|is|=|:)?\s*"
        r"(\d+(?:\.\d+)?)\b",
        prompt,
        re.I,
    )
    if (
        exact_counts
        or named_counts
        or (threshold and Decimal(threshold[1]) != Decimal("5.99"))
    ):
        return ScopedTask(
            None,
            "The verified chi-square cases cannot use those supplied data. "
            "They use prepared counts and critical values.",
        )
    if any(float(value.rstrip("%")) != 5 for value in alpha):
        return ScopedTask(None, "The verified chi-square cases use 5% significance.")
    if requested(
        r"\b(?:two|2)[- ](?:(?:offspring|phenotyp\w*|observed|expected)\s+){0,2}"
        r"(?:class(?:es)?|categor(?:y|ies)|groups)\b",
        prompt,
    ):
        return ScopedTask(
            None, "The verified chi-square cases need more than two classes."
        )

    expected_supplied = requested(
        r"\b(?:from|given|provid\w+|suppl\w+)\s+(?:the\s+)?"
        r"(?:observed\s+and\s+)?expected (?:offspring )?counts\b"
        r"|\bexpected (?:offspring )?counts (?:are )?(?:supplied|given|provided)\b",
        prompt,
    )
    critical_supplied = requested(
        r"\b(?:supplied|given|provided|give|provide)\s+(?:a\s+|the\s+)?"
        r"(?:5\s*%\s+)?critical (?:χ² |chi.square )?value\b",
        prompt,
    ) and not requested(r"\bcritical (?:value|values) table\b", prompt)
    df = requested(r"\b(?:degrees? of freedom|df)\b", prompt)
    decision = requested(
        r"\b(?:decision|reject\w*|interpret\w*|fit\w*|conclu\w*)\b", prompt
    )
    deriving = requested(
        r"\b(?:deriv\w*|infer\w*|work out|obtain\w*)\s+(?:the\s+)?"
        r"(?:grouped\s+)?expected (?:offspring )?counts\b",
        prompt,
    )
    computing = requested(
        r"\b(?:calculat\w*|comput\w*|work out)\s+(?:only\s+|just\s+)?"
        r"(?:the\s+)?(?:numeric(?:al)?\s+)?"
        r"(?:chi[ -]?squar\w*|χ²|test statistic)(?!\w)",
        prompt,
    )
    statistic_label = (
        r"(?:chi[ -]?square(?:d)?\s+(?:statistic|value)|test statistic"
        r"|χ²(?:\s+(?:statistic|value))?)"
    )
    given_statistic = requested(
        rf"\b(?:supplied|given|provided)\s+(?:a\s+|the\s+)?{statistic_label}"
        rf"|(?<!\w){statistic_label}\s+(?:is\s+)?(?:supplied|given|provided)\b",
        prompt,
    )
    report_statistic = requested(
        r"\b(?:report|state|give|select|asks? for)\s+(?:both\s+)?(?:(?:a|the)\s+)?"
        rf"(?:numeric(?:al)?\s+)?{statistic_label}"
        rf"|(?<!\w)(?:numeric(?:al)?\s+)?{statistic_label},?"
        r"\s+and\s+(?:the\s+)?(?:test\s+)?(?:decision|conclusion|whether to reject)",
        prompt,
    )

    statistic_only = re.search(
        r"\b(?:only|just)\s+(?:(?:ask (?:them )?to|ask for|calculat\w*|comput\w*|"
        r"report|state|give|select|work out)\s+)*(?:the\s+)?(?:numeric(?:al)?\s+)?"
        rf"{statistic_label}|(?<!\w){statistic_label}\s+(?:only|alone)\b",
        prompt,
        re.I,
    )
    excludes_decision = re.search(
        r"\b(?:without|no|omit|exclude|skip|do not|don't)\s+"
        r"(?:(?:need to|mak\w+|draw\w*|provide|report|ask for|include|"
        r"requir\w*|stat\w*|a|the|any|test|statistical)\s+){0,6}"
        r"(?:decid\w*|reject\w*|decisions?|conclu\w*|interpret\w*)\b",
        prompt,
        re.I,
    )
    if statistic_only or (excludes_decision and (computing or report_statistic)):
        return ScopedTask(
            None,
            "The verified cases that ask for a statistic also ask for a test "
            "decision. A question asking for a statistic alone needs a different case.",
        )

    if (deriving and expected_supplied) or (df and decision and critical_supplied):
        return ScopedTask(
            None,
            "No verified case combines those chi-square givens and decisions.",
        )
    if deriving or (df and decision):
        if critical_supplied:
            return ScopedTask(
                None,
                "The cross-based cases use a critical-value table.",
            )
        if report_statistic:
            return ScopedTask(
                None,
                "The cross-based cases ask for expected counts, degrees of freedom "
                "and a decision. A numerical statistic needs a different case.",
            )
        return ScopedTask(CHI_MODEL)
    if df:
        return ScopedTask(CHI_DF)
    if not (decision or computing) and requested(
        r"\bexpected (?:offspring )?counts\b", prompt
    ):
        return ScopedTask(CHI_EXPECTED)
    if given_statistic:
        if computing or report_statistic:
            return ScopedTask(
                None,
                "Should learners calculate the statistic or interpret it?",
            )
        return ScopedTask(CHI_DECISION)
    if report_statistic or computing:
        return ScopedTask(CHI_SUPPLIED_COUNTS)
    if expected_supplied or critical_supplied:
        return ScopedTask(CHI_LEGACY_DECISION)
    return ScopedTask(CHI_MODEL if difficulty == "hard" else CHI_DECISION)


def task_scope(prompt: str, difficulty: Difficulty) -> ScopedTask | None:
    """Resolve the supported learner action where topic overlap is misleading."""
    tasks: list[TaskCapability] = []
    if requested(r"\bmito(?:sis|tic)\b", prompt):
        if requested(
            r"\b(?:growth|repair|wound healing|asexual reproduction|chromosome "
            r"complement|chromosome number|roles?|purpose|significance|functions?)\b",
            prompt,
        ):
            tasks.append(MITOSIS_ROLES)
        if requested(r"\b(?:order\w*|sequence\w*|arrang\w*|stag\w*|phas\w*)\b", prompt):
            tasks.append(MITOSIS_STAGES)
        elif requested(r"\banaphase\b", prompt):
            tasks.append(ANAPHASE_ONSET)

    timing = requested(
        r"\b(?:warm\w*|earli\w*|mismatch\w*|asynchron\w*|advance\w*|phenolog\w*)\b",
        prompt,
    )
    if timing:
        if requested(r"\bbirds?\b", prompt) and requested(
            r"\b(?:insects?|prey)\b", prompt
        ):
            tasks.append(BIRD_FOOD_MISMATCH)
        if requested(r"\b(?:pollinat\w*|fruit set)\b", prompt):
            tasks.append(POLLINATION_MISMATCH)

    chloroplast = requested(
        r"\b(?:thylakoids?|chloroplasts?|photosynth\w*|photophosphorylation)\b", prompt
    )
    mitochondria = requested(
        r"\b(?:mitochondri\w*|oxidative phosphorylation|aerobic respiration)\b", prompt
    )
    gradient = requested(r"\b(?:chemiosmo\w*|proton\w*|h\+|atp synthase)\b", prompt)
    if chloroplast and mitochondria and gradient:
        if requested(
            r"\b(?:inhibit\w*|uncoupl\w*|block\w*|dissipat\w*|revers\w*|"
            r"simultan\w*|experiment\w*)\b",
            prompt,
        ):
            return ScopedTask(
                None,
                "The available comparison asks learners to identify compartments. "
                "A question about an experimental change needs its own verified case.",
            )
        tasks.append(CHEMIOSMOSIS_COMPARE)
    elif (
        not chloroplast
        and requested(r"\boxygen\b", prompt)
        and requested(
            r"\b(?:electron transport|terminal acceptor|final electron acceptor)\b",
            prompt,
        )
    ):
        tasks.append(RESPIRATORY_OXYGEN)

    if requested(r"(?:\bchi[ -]?squar\w*\b|χ²|\bchi\^2\b)", prompt):
        chi = _chi_square_task(prompt, difficulty)
        if chi.capability is None:
            return chi
        tasks.append(chi.capability)
    if len(tasks) > 1:
        return ScopedTask(
            None,
            "The request specifies several learner tasks. The verified cases "
            "cover these tasks in separate questions.",
        )
    if tasks:
        return ScopedTask(tasks[0])
    return None
