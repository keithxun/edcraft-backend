"""Small constants and type aliases for the biology domain."""

from __future__ import annotations

from typing import Literal

# Explicit re-exports: these names stay importable from this module even though
# the definitions live in the shared vocabulary module.
from edcraft_validator.domain_types import (
    DEFAULT_DISTRACTORS as DEFAULT_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    DIFFICULTIES as DIFFICULTIES,
)
from edcraft_validator.domain_types import (
    MAX_CHOICES as MAX_CHOICES,
)
from edcraft_validator.domain_types import (
    MAX_DISTRACTOR_CANDIDATES as MAX_DISTRACTOR_CANDIDATES,
)
from edcraft_validator.domain_types import (
    MAX_DISTRACTORS as MAX_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    MIN_CHOICES as MIN_CHOICES,
)
from edcraft_validator.domain_types import (
    MIN_DISTRACTORS as MIN_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    Difficulty as Difficulty,
)

BIOLOGY_DIFFICULTIES: tuple[Difficulty, ...] = DIFFICULTIES

# Authoring caps. The schema enforces these per parameter kind; the engine
# itself only ever sees canonical tokens and exact counts.
MIN_PARAMETERS = 1
MAX_PARAMETERS = 4
MAX_GENOTYPE_VALUES = 3
MAX_PHENOTYPE_VALUES = 2
MAX_COUNT_VALUES = 12
MIN_COUNT_VALUE = 1
MAX_COUNT_VALUE = 10000

PHENOTYPES: tuple[str, ...] = ("dominant", "recessive")

# Text placeholders owned by the template, not by a declared parameter.
RESERVED_PLACEHOLDERS: frozenset[str] = frozenset(
    {
        "organism",
        "trait",
        "dominant_phenotype",
        "recessive_phenotype",
        "given_phenotype",
    }
)

BIOLOGY_CROSS_TOOL = "biology_verify_cross"
BIOLOGY_OPTIONS_TOOL = "biology_validate_options"
BIOLOGY_FIDELITY_TOOL = "biology_verify_text_fidelity"

BIOLOGY_TOOL_VERSION = "1.0.0"
BIOLOGY_SCHEMA_VERSION: Literal["bio-mono/0.1"] = "bio-mono/0.1"
BIOLOGY_VALIDATOR_VERSION: Literal["mcp-biology-template-v1"] = (
    "mcp-biology-template-v1"
)
BIOLOGY_FORMAT_VERSION: Literal["1.0.0"] = "1.0.0"
BIOLOGY_CHECKING_MODE: Literal["property_based"] = "property_based"
