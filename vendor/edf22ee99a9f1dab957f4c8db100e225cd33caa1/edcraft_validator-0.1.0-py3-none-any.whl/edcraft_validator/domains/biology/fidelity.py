"""Biology plugin for the domain-neutral NL-fidelity gate.

The plugin owns the blind parse-back prompt, deterministic anchor rules and a
conservative genotype equivalence check. A parse that cannot be compared is
``inconclusive``; it is never silently approved.
"""

from __future__ import annotations

import hashlib
import json
import re
import string
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from edcraft_validator.application.fidelity.contracts import (
    CanonicalArtifact,
    EvidenceStrength,
    FidelityVerdict,
)
from edcraft_validator.domains.biology.biology_schemas import (
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.biology_types import RESERVED_PLACEHOLDERS
from edcraft_validator.domains.biology.checking import real_organism_terms
from edcraft_validator.domains.biology.cross import (
    BiologyCheckError,
    parse_genotype,
)
from edcraft_validator.domains.biology.question_generator import render_text
from edcraft_validator.llm.llm_contracts import StructuredGenerationRequest

PROMPT_VERSION = "biology-fidelity/4"
SCHEMA_NAME = "biology_reconstruction"

_SYSTEM_PROMPT = """\
You are a blind parser for a biology problem. Restate exactly what the supplied
text says. You have not seen the source template, its answer, its distractors or
its topic; do not try to infer them.

Rules:
- Do not solve the problem and do not add an answer.
- Parse only what the text states. Do not invent genotypes, phenotypes,
  quantities or crosses.
- Report both parent genotypes as complete two-letter tokens. If the text does
  not name both parents explicitly, report what it does state and mark the
  reading ambiguous.
- `quantity` is probability, expected_count or ratio. For a probability or an
  expected count, set `target_kind` and `target_value`; for a ratio, leave the
  target null and set `ratio_kind`.
- Report `given_phenotype` only when the text conditions on a phenotype.
- Report `offspring_count` only when the text states a concrete number of
  offspring.
- Use the closed vocabulary in the response schema for dominance and
  inheritance. `unspecified` means the text does not say.
- `gene_count` is the number of distinct genes the question involves.
- `organism_kind` is real when the text names a real species, breed, crop,
  animal, plant or human group, hypothetical when it says the organism is
  invented, and unspecified otherwise.
- `segregation` is non_mendelian when the text gives transmission or gamete
  probabilities other than one half for each allele.
- List in `additional_rules` every stated rule beyond the parents, dominance and
  the question itself, for example offspring dying, failing to survive or being
  removed, biased transmission, mutation, selection, environment effects or
  extra genes. Use an empty list when there are none.
- Report phenotypes as the descriptive word or words only, without the trait,
  for example "violet" for "violet petal colour".
- `sampled_population` says whose genotype or phenotype the question asks
  about: offspring of the cross, the parents, someone else (other), or
  unspecified when the text does not say.
- If the text supports more than one reading, set ambiguous=true and give at
  least one concrete ambiguity. Do not guess a single reading.
"""

_PLACEHOLDER = re.compile(r"\{[^{}]*\}")
_ZYGOSITY_WORDS = re.compile(
    r"\b(?:heterozygous|homozygous|heterozygote|homozygote|true-breeding|"
    r"true breeding|pure-breeding|pure breeding|purebred|hybrid|carrier)\b",
    re.IGNORECASE,
)
_UNSUPPORTED_INHERITANCE = re.compile(
    r"\b(?:x-linked|sex-linked|y-linked|linked|incomplete|codominan|blending|"
    r"lethal|penetrance|epista|dihybrid|pedigree|generation|grandparent)",
    re.IGNORECASE,
)


class BiologyFidelitySubject(BaseModel):
    """One concrete variant of a monohybrid template."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: MonohybridTemplateSpec
    parameters: dict[str, str]


class MonohybridReconstruction(BaseModel):
    """The blind parser's reading of one rendered question."""

    model_config = ConfigDict(extra="forbid", strict=True)

    parent1_genotype: str
    parent2_genotype: str
    quantity: Literal["probability", "expected_count", "ratio"]
    target_kind: Literal["genotype", "phenotype"] | None = None
    target_value: str | None = None
    given_phenotype: str | None = None
    offspring_count: int | None = None
    ratio_kind: Literal["genotype", "phenotype"] | None = None
    dominant_phenotype: str
    recessive_phenotype: str
    dominance: Literal["complete", "incomplete", "codominant", "unspecified"]
    inheritance: Literal["autosomal", "sex_linked", "unspecified"]
    gene_count: int
    organism_kind: Literal["hypothetical", "real", "unspecified"]
    segregation: Literal["mendelian", "non_mendelian", "unspecified"]
    additional_rules: list[str]
    sampled_population: Literal["offspring", "parents", "other", "unspecified"]
    ambiguous: bool = False
    ambiguities: list[str] = Field(default_factory=list)


class BiologyFidelityPlugin:
    """Blind parse-back and exact genotype comparison for biology."""

    domain: str = "biology"
    artifact_model: type[BaseModel] = BiologyFidelitySubject
    evidence_strength: EvidenceStrength = "probabilistic"

    def requires_check(self, artifact: BaseModel) -> bool:
        _subject(artifact)
        return True

    def reconstruction_request(self, text: str) -> StructuredGenerationRequest[Any]:
        return StructuredGenerationRequest(
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": text},
            ],
            response_model=MonohybridReconstruction,
            schema_name=SCHEMA_NAME,
            prompt_version=PROMPT_VERSION,
        )

    def canonicalize(self, artifact: BaseModel) -> CanonicalArtifact:
        subject = _subject(artifact)
        payload = {
            "template": subject.template.model_dump(
                mode="json",
                exclude={
                    "answer_recipe": True,
                    "distractors": True,
                },
            ),
            "parameters": dict(sorted(subject.parameters.items())),
        }
        encoded = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return CanonicalArtifact(
            domain=self.domain,
            payload=payload,
            digest=hashlib.sha256(encoded.encode()).hexdigest(),
        )

    def check_anchors(self, artifact: BaseModel, text: str) -> FidelityVerdict:
        subject = _subject(artifact)
        template = subject.template.text.template
        reasons: list[str] = []
        names, parse_error = _placeholder_names(template)
        if parse_error is not None:
            return FidelityVerdict(
                status="failed",
                reasons=[parse_error],
                evidence={"template_length": len(template)},
            )

        parameters = {parameter.name for parameter in subject.template.parameters}
        allowed = parameters | RESERVED_PLACEHOLDERS
        missing = sorted(parameters - set(names))
        unknown = sorted(set(names) - allowed)
        if missing:
            reasons.append("missing parameter placeholders: " + ", ".join(missing))
        if unknown:
            reasons.append("unknown placeholders: " + ", ".join(unknown))

        has_given = subject.template.question.given is not None
        given_used = "given_phenotype" in names
        if has_given and not given_used:
            reasons.append(
                "the question declares a given phenotype but the text has no "
                "{given_phenotype} placeholder"
            )
        if given_used and not has_given:
            reasons.append(
                "the text uses {given_phenotype} but the question has no given "
                "phenotype"
            )

        reasons.extend(_rendered_text_reasons(subject, text))
        # Free-text fields reach the learner through reserved placeholders, so
        # they obey the same literal rules as the text around the placeholders.
        item = subject.template
        free_text = {
            "text": _residual_text(template),
            "organism": item.organism,
            "trait": item.trait,
            "gene.dominant_phenotype": item.gene.dominant_phenotype,
            "gene.recessive_phenotype": item.gene.recessive_phenotype,
        }
        for field, value in free_text.items():
            reasons.extend(_literal_reasons(field, value, item.gene.symbol))
        for term, field in real_organism_terms(subject.template):
            reasons.append(f"real-organism term {term!r} appears in {field}")

        evidence = {
            "template_length": len(template),
            "placeholder_count": len(names),
            "parameter_placeholders": sorted(parameters & set(names)),
            "given_placeholder_expected": has_given,
            "rendered_length": len(text),
        }
        if reasons:
            return FidelityVerdict(status="failed", reasons=reasons, evidence=evidence)
        return FidelityVerdict(status="passed", evidence=evidence)

    def equivalent(
        self, expected: BaseModel, reconstructed: BaseModel
    ) -> FidelityVerdict:
        subject = _subject(expected)
        parse = _reconstruction(reconstructed)
        item = subject.template

        if parse.ambiguous:
            return FidelityVerdict(
                status="inconclusive",
                reasons=list(parse.ambiguities) or ["the blind parse is ambiguous"],
                evidence={"ambiguous": True, "ambiguities": parse.ambiguities},
            )

        try:
            expected_parents = {
                parse_genotype(
                    subject.parameters[item.cross.parent1], item.gene.symbol
                ),
                parse_genotype(
                    subject.parameters[item.cross.parent2], item.gene.symbol
                ),
            }
            reconstructed_parents = {
                parse_genotype(parse.parent1_genotype, item.gene.symbol),
                parse_genotype(parse.parent2_genotype, item.gene.symbol),
            }
        except (BiologyCheckError, KeyError) as exc:
            return FidelityVerdict(
                status="inconclusive",
                reasons=[f"parent genotypes cannot be compared: {exc}"],
                evidence={
                    "expected_parameters": dict(subject.parameters),
                    "reconstructed_parents": [
                        parse.parent1_genotype,
                        parse.parent2_genotype,
                    ],
                },
            )

        expected_target_kind, expected_target_value = _target(item, subject.parameters)
        expected_given = _given_word(item)
        expected_count, expected_ratio_kind = _quantity_fields(item, subject.parameters)

        evidence = {
            "expected_parents": sorted(expected_parents),
            "reconstructed_parents": sorted(reconstructed_parents),
            "expected_quantity": item.question.quantity,
            "reconstructed_quantity": parse.quantity,
            "expected_target": {
                "kind": expected_target_kind,
                "value": expected_target_value,
            },
            "reconstructed_target": {
                "kind": parse.target_kind,
                "value": parse.target_value,
            },
            "expected_given_phenotype": expected_given,
            "reconstructed_given_phenotype": parse.given_phenotype,
            "expected_offspring_count": expected_count,
            "reconstructed_offspring_count": parse.offspring_count,
            "expected_ratio_kind": expected_ratio_kind,
            "reconstructed_ratio_kind": parse.ratio_kind,
            "expected_dominance": item.assumptions.dominance,
            "reconstructed_dominance": parse.dominance,
            "expected_inheritance": item.assumptions.inheritance,
            "reconstructed_inheritance": parse.inheritance,
            "expected_gene_count": 1,
            "reconstructed_gene_count": parse.gene_count,
            "reconstructed_organism_kind": parse.organism_kind,
            "reconstructed_segregation": parse.segregation,
            "reconstructed_additional_rules": parse.additional_rules,
            "reconstructed_sampled_population": parse.sampled_population,
        }

        reasons: list[str] = []
        if expected_parents != reconstructed_parents:
            reasons.append(
                "parents are "
                f"{sorted(reconstructed_parents)!r}, not {sorted(expected_parents)!r}"
            )
        if item.question.quantity != parse.quantity:
            reasons.append(
                f"quantity is {parse.quantity!r}, not {item.question.quantity!r}"
            )
        if expected_target_kind != parse.target_kind:
            reasons.append(
                f"target kind is {parse.target_kind!r}, not {expected_target_kind!r}"
            )
        elif not _same_target_value(
            expected_target_kind,
            expected_target_value,
            parse.target_value,
            _opposite_word(item, expected_target_value),
        ):
            reasons.append(
                f"target value is {parse.target_value!r}, not {expected_target_value!r}"
            )
        if not _same_phenotype(
            expected_given,
            parse.given_phenotype,
            _opposite_word(item, expected_given),
        ):
            reasons.append(
                f"given phenotype is {parse.given_phenotype!r}, not {expected_given!r}"
            )
        if expected_count != parse.offspring_count:
            reasons.append(
                f"offspring count is {parse.offspring_count!r}, not {expected_count!r}"
            )
        if expected_ratio_kind != parse.ratio_kind:
            reasons.append(
                f"ratio kind is {parse.ratio_kind!r}, not {expected_ratio_kind!r}"
            )
        if parse.dominance != "complete":
            reasons.append(f"dominance is {parse.dominance!r}, not 'complete'")
        if parse.inheritance not in {"autosomal", "unspecified"}:
            reasons.append(f"inheritance is {parse.inheritance!r}, not autosomal")
        if parse.gene_count != 1:
            reasons.append(f"gene count is {parse.gene_count}, not 1")
        if parse.organism_kind == "real":
            reasons.append("the text names a real organism")
        if parse.segregation == "non_mendelian":
            reasons.append("the text states non-Mendelian segregation")
        if parse.sampled_population != "offspring":
            reasons.append(
                f"the question samples {parse.sampled_population!r}, not the "
                "offspring of the cross"
            )
        if parse.additional_rules:
            reasons.append(
                "the text adds unsupported rules: " + "; ".join(parse.additional_rules)
            )
        if not _same_phenotype(
            item.gene.dominant_phenotype,
            parse.dominant_phenotype,
            item.gene.recessive_phenotype,
        ):
            reasons.append(
                f"dominant phenotype is {parse.dominant_phenotype!r}, not "
                f"{item.gene.dominant_phenotype!r}"
            )
        if not _same_phenotype(
            item.gene.recessive_phenotype,
            parse.recessive_phenotype,
            item.gene.dominant_phenotype,
        ):
            reasons.append(
                f"recessive phenotype is {parse.recessive_phenotype!r}, not "
                f"{item.gene.recessive_phenotype!r}"
            )

        if reasons:
            return FidelityVerdict(status="failed", reasons=reasons, evidence=evidence)
        return FidelityVerdict(
            status="passed",
            reasons=["parents, question and phenotypes agree with the blind parse"],
            evidence=evidence,
        )


PLUGIN = BiologyFidelityPlugin()


def representative_variants(item: MonohybridTemplateSpec) -> list[dict[str, str]]:
    """The staggered variants that blind parse-back reads.

    Variant ``k`` gives the parameter at position ``i`` its value at index
    ``(k + i) mod len(values)``. Every declared value is therefore read at least
    once, so text that only misbehaves for a middle value is caught, and
    parameters with equal value lists are read off the diagonal, so a parent
    placeholder used in the wrong role cannot hide behind equal parents. There
    are as many variants as the longest value list (at most twelve).
    """
    rounds = max(len(parameter.values) for parameter in item.parameters)
    variants: list[dict[str, str]] = []
    for k in range(rounds):
        variant = {
            parameter.name: parameter.values[(k + i) % len(parameter.values)]
            for i, parameter in enumerate(item.parameters)
        }
        if variant not in variants:
            variants.append(variant)
    return variants


def biology_fidelity_plugin() -> BiologyFidelityPlugin:
    """Return the stateless biology plugin used by application wiring."""
    return PLUGIN


def identity_reconstruction(
    subject: BiologyFidelitySubject,
) -> MonohybridReconstruction:
    """The reading a perfect blind parser would return for this variant.

    Offline evaluation compares it with the item to check the comparison
    itself without a model call. It is never used as evidence of fidelity.
    """
    item = subject.template
    values = subject.parameters
    target_kind, target_value = _target(item, values)
    count, ratio_kind = _quantity_fields(item, values)
    given = item.question.given
    return MonohybridReconstruction(
        parent1_genotype=values[item.cross.parent1],
        parent2_genotype=values[item.cross.parent2],
        quantity=item.question.quantity,
        target_kind=target_kind,  # type: ignore[arg-type]
        target_value=target_value,
        given_phenotype=(
            None if given is None else _phenotype_word(item, given.phenotype)
        ),
        offspring_count=count,
        ratio_kind=ratio_kind,  # type: ignore[arg-type]
        dominant_phenotype=item.gene.dominant_phenotype,
        recessive_phenotype=item.gene.recessive_phenotype,
        dominance="complete",
        inheritance="autosomal",
        gene_count=1,
        organism_kind="hypothetical",
        segregation="mendelian",
        additional_rules=[],
        sampled_population="offspring",
    )


def _subject(artifact: BaseModel) -> BiologyFidelitySubject:
    if not isinstance(artifact, BiologyFidelitySubject):
        raise TypeError("biology fidelity expects a BiologyFidelitySubject")
    return artifact


def _reconstruction(artifact: BaseModel) -> MonohybridReconstruction:
    if not isinstance(artifact, MonohybridReconstruction):
        raise TypeError("biology fidelity expects a MonohybridReconstruction")
    return artifact


def _placeholder_names(text: str) -> tuple[list[str], str | None]:
    try:
        parsed = list(string.Formatter().parse(text))
    except ValueError as exc:
        return [], f"text has invalid braces: {exc}"
    return [field for _, field, _, _ in parsed if field is not None], None


def _literal_reasons(field: str, value: str, symbol: str) -> list[str]:
    """Literal facts that must come from the item, never from free text."""
    reasons: list[str] = []
    if re.search(r"\d", value):
        reasons.append(f"{field} contains digits outside placeholders")
    genotype_pattern = re.compile(
        rf"\b[{re.escape(symbol)}{re.escape(symbol.lower())}]{{2}}\b"
    )
    if genotype_pattern.search(value):
        reasons.append(f"{field} contains a literal genotype over gene {symbol!r}")
    if _ZYGOSITY_WORDS.search(value):
        reasons.append(f"{field} contains a zygosity word outside placeholders")
    if _UNSUPPORTED_INHERITANCE.search(value):
        reasons.append(f"{field} contains unsupported inheritance or cross wording")
    return reasons


def _rendered_text_reasons(subject: BiologyFidelitySubject, text: str) -> list[str]:
    """The parsed text must be the deterministic rendering of a declared variant."""
    item = subject.template
    declared = {parameter.name: parameter.values for parameter in item.parameters}
    if set(subject.parameters) != set(declared) or any(
        subject.parameters[name] not in values for name, values in declared.items()
    ):
        return ["subject parameters are not a declared combination"]
    try:
        rendered = render_text(item, subject.parameters)
    except BiologyCheckError as exc:
        return [exc.message]
    if rendered != text:
        return ["the checked text is not the rendering of the subject variant"]
    return []


def _residual_text(text: str) -> str:
    protected = text.replace("{{", "\x00").replace("}}", "\x01")
    return _PLACEHOLDER.sub(" ", protected)


def _phenotype_word(item: MonohybridTemplateSpec, phenotype: str) -> str:
    return (
        item.gene.dominant_phenotype
        if phenotype == "dominant"
        else item.gene.recessive_phenotype
    )


def _target(
    item: MonohybridTemplateSpec, parameters: dict[str, str]
) -> tuple[str | None, str | None]:
    target = item.question.target
    if target is None:
        return None, None
    value = parameters[target.param]
    if target.kind == "genotype":
        return target.kind, value
    return target.kind, _phenotype_word(item, value)


def _given_word(item: MonohybridTemplateSpec) -> str | None:
    given = item.question.given
    if given is None:
        return None
    return _normalise_word(_phenotype_word(item, given.phenotype))


def _quantity_fields(
    item: MonohybridTemplateSpec, parameters: dict[str, str]
) -> tuple[int | None, str | None]:
    count_name = item.question.offspring_count
    count = int(parameters[count_name]) if count_name is not None else None
    return count, item.question.ratio_kind


def _same_target_value(
    kind: str | None,
    expected: str | None,
    parsed: str | None,
    other: str | None,
) -> bool:
    """Genotype tokens are case-sensitive. Phenotypes compare as words."""
    if kind == "genotype":
        return expected == (parsed.strip() if parsed is not None else None)
    return _same_phenotype(expected, parsed, other)


def _opposite_word(item: MonohybridTemplateSpec, word: str | None) -> str | None:
    """The other phenotype word of the gene, used to reject mixed readings."""
    dominant = item.gene.dominant_phenotype
    recessive = item.gene.recessive_phenotype
    if _normalise_word(word) == _normalise_word(dominant):
        return recessive
    if _normalise_word(word) == _normalise_word(recessive):
        return dominant
    return None


def _same_phenotype(
    expected: str | None, parsed: str | None, other: str | None = None
) -> bool:
    """A parsed phenotype matches its word, alone or followed by other words.

        The text renders ``{dominant_phenotype} {trait}``, so a faithful reading of
        "violet petal colour" or "violet petals" is the phenotype "violet". Extra
        words must not contain the whole other phenotype, so "violet or cream" fails
    while "dark green colour" still matches "dark" when the other is "light green".
    """
    word, reading = _normalise_word(expected), _normalise_word(parsed)
    if word is None or reading is None:
        return word == reading
    if reading == word:
        return True
    if not reading.startswith(word + " "):
        return False
    rest = f" {reading[len(word) + 1 :]} "
    other_phrase = _normalise_word(other)
    return not other_phrase or f" {other_phrase} " not in rest


def _normalise_word(value: str | None) -> str | None:
    return None if value is None else " ".join(value.lower().split())
