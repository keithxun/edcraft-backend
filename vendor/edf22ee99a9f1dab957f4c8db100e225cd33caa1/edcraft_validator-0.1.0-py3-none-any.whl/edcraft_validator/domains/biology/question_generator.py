"""Deterministically expand approved biology templates into seeded questions.

Generation evaluates the approved exact recipes and renders them without model,
MCP or external calls. Unusable combinations such as a non-integer expected count
or repeated choices are skipped.
"""

from __future__ import annotations

import re
import string
from itertools import product
from typing import Literal

from edcraft_validator.domains.biology.biology_schemas import (
    BiologyCrossParents,
    BiologyFitQuestionInstance,
    BiologyGametes,
    BiologyQuestionInstance,
    H2BiologyQuestionInstance,
    H2TemplateSpec,
    MonohybridTemplateSpec,
    ValidatedBiologyTemplate,
)
from edcraft_validator.domains.biology.cross import (
    BiologyCheckError,
    check_variant,
)
from edcraft_validator.domains.biology.fit_schema import GoodnessOfFitTemplate
from edcraft_validator.domains.biology.goodness_of_fit import generate_fit_question
from edcraft_validator.domains.biology.h2_authoring import generate_h2_question
from edcraft_validator.domains.biology.options import check_options
from edcraft_validator.domains.domain_support import seeded_index


class UnusableVariant(ValueError):
    """One parameter combination cannot yield a sound question."""


ValueKind = Literal["genotype", "count", "word"]

# Letters whose spoken names start with a vowel sound: "an F", "an R".
_VOWEL_SOUND_LETTERS = frozenset("AEFHILMNORSX")
_TRAILING_ARTICLE = re.compile(r"(?:^|(?<=\s))(an?)\s+$", re.IGNORECASE)
_SENTENCE_START = re.compile(r"(?:^|[.!?]\s+|\n\s*)[\"'(]?$")
# A full stop after these does not end a sentence.
_ABBREVIATION_END = re.compile(r"\b(?:e\.g|i\.e|etc|vs|cf|Mr|Mrs|Ms|Dr)\.\s+$")


def render_text(template: MonohybridTemplateSpec, values: dict[str, str]) -> str:
    """Substitute one declared combination into the learner-facing text.

    Placeholders are plain names only. A conversion, format spec, index or
    attribute could reshape a rendered fact (``{parent1!s:.1}`` shows only one
    allele), so the text is assembled here instead of through ``str.format``.
    """
    mapping = _placeholder_values(template, values)
    try:
        parsed = list(string.Formatter().parse(template.text.template))
    except ValueError as exc:
        raise BiologyCheckError(
            "MALFORMED_TEXT", f"text has invalid braces: {exc}"
        ) from None

    kinds = _placeholder_kinds(template)
    text = ""
    for literal, name, format_spec, conversion in parsed:
        text += literal
        if name is None:
            continue
        if format_spec or conversion is not None:
            raise BiologyCheckError(
                "UNSUPPORTED_PLACEHOLDER",
                f"placeholder {name!r} may not use a conversion or format spec",
            )
        if name not in mapping:
            raise BiologyCheckError(
                "UNKNOWN_PLACEHOLDER",
                f"text placeholder {name!r} cannot be rendered",
            )
        text = _append_value(text, mapping[name], kinds.get(name, "word"))
    return text


def needs_an(value: str, kind: ValueKind) -> bool:
    """Whether the rendered value is spoken with a leading vowel sound."""
    if not value:
        return False
    if kind == "genotype":
        return value[0].upper() in _VOWEL_SOUND_LETTERS
    if kind == "count":
        return value.startswith("8") or value in {"11", "18"}
    return value[0].lower() in "aeiou"


def with_article(article: str, value: str, kind: ValueKind) -> str:
    """The article that agrees with the value, keeping its capitalisation."""
    wanted = "an" if needs_an(value, kind) else "a"
    if article.isupper() and len(article) > 1:
        wanted = wanted.upper()
    elif article[:1].isupper():
        wanted = wanted.capitalize()
    return f"{wanted} {value}"


def _append_value(text: str, value: str, kind: ValueKind) -> str:
    """Fix a preceding a/an and capitalise a word that starts a sentence.

    Genotypes and counts are never recased, because case carries meaning.
    """
    match = _TRAILING_ARTICLE.search(text)
    if match is not None:
        return text[: match.start()] + with_article(match.group(1), value, kind)
    if (
        kind == "word"
        and _SENTENCE_START.search(text)
        and not _ABBREVIATION_END.search(text)
    ):
        value = value[:1].upper() + value[1:]
    return text + value


def _placeholder_kinds(template: MonohybridTemplateSpec) -> dict[str, ValueKind]:
    kinds: dict[str, ValueKind] = {}
    for parameter in template.parameters:
        if parameter.kind == "genotype":
            kinds[parameter.name] = "genotype"
        elif parameter.kind == "count":
            kinds[parameter.name] = "count"
    return kinds


def generate_biology_question(
    validated: ValidatedBiologyTemplate, seed: int
) -> BiologyQuestionInstance | H2BiologyQuestionInstance | BiologyFitQuestionInstance:
    """Expand one approved template without AI calls, MCP calls or network I/O."""
    template = validated.template
    item = template.item
    if isinstance(item, H2TemplateSpec):
        return generate_h2_question(validated, item, seed)
    if isinstance(item, GoodnessOfFitTemplate):
        return generate_fit_question(validated, item, seed)
    combinations = _declared_combinations(item)
    if not combinations:
        raise ValueError("validated template has an empty parameter domain")

    start = seeded_index(
        template.template_id,
        seed,
        "parameter-combination",
        len(combinations),
    )

    for offset in range(len(combinations)):
        values = combinations[(start + offset) % len(combinations)]
        try:
            return _build_instance(validated, item, values, seed)
        except (BiologyCheckError, UnusableVariant):
            continue

    raise ValueError("Could not produce a usable question from this template")


def _declared_combinations(
    item: MonohybridTemplateSpec,
) -> list[dict[str, str]]:
    names = [parameter.name for parameter in item.parameters]
    return [
        dict(zip(names, combination, strict=True))
        for combination in product(*(parameter.values for parameter in item.parameters))
    ]


def _build_instance(
    validated: ValidatedBiologyTemplate,
    item: MonohybridTemplateSpec,
    values: dict[str, str],
    seed: int,
) -> BiologyQuestionInstance:
    question = render_text(item, values)
    # A sampled check may not have seen this combination, so every option rule
    # is validated again here; a failing combination is skipped.
    check_options(item, values)
    variant = check_variant(item, values)
    if not variant.distractor_values:
        raise UnusableVariant("the template declares no distractors")

    answer = variant.key
    distractors = list(variant.distractor_values)
    if answer in distractors or len(distractors) != len(set(distractors)):
        raise UnusableVariant("rendered choices are not distinct")

    correct_index = seeded_index(
        validated.template.template_id,
        seed,
        "correct-index",
        len(distractors) + 1,
    )
    choices = list(distractors)
    choices.insert(correct_index, answer)

    return BiologyQuestionInstance(
        template_id=validated.template.template_id,
        artifact_id=validated.artifact_id,
        seed=seed,
        parameters=dict(values),
        question=question,
        choices=choices,
        correct_index=correct_index,
        answer=answer,
        topic=item.topic,
        cross=BiologyCrossParents(
            parent1=variant.parents["parent1"],
            parent2=variant.parents["parent2"],
        ),
        gametes=BiologyGametes(
            parent1=list(variant.gametes["parent1"]),
            parent2=list(variant.gametes["parent2"]),
        ),
        punnett=variant.punnett,
        genotype_distribution=variant.genotype_distribution,
        phenotype_distribution=variant.phenotype_distribution,
    )


def _placeholder_values(
    template: MonohybridTemplateSpec, values: dict[str, str]
) -> dict[str, str]:
    mapping = {
        "organism": template.organism,
        "trait": template.trait,
        "dominant_phenotype": template.gene.dominant_phenotype,
        "recessive_phenotype": template.gene.recessive_phenotype,
    }
    given = template.question.given
    if given is not None:
        mapping["given_phenotype"] = _phenotype_word(template, given.phenotype)
    for parameter in template.parameters:
        try:
            value = values[parameter.name]
        except KeyError:
            raise BiologyCheckError(
                "UNKNOWN_PLACEHOLDER",
                f"no value supplied for parameter {parameter.name!r}",
            ) from None
        if parameter.kind == "phenotype":
            mapping[parameter.name] = _phenotype_word(template, value)
        elif parameter.kind == "count":
            mapping[parameter.name] = str(int(value))
        else:
            mapping[parameter.name] = value
    return mapping


def _phenotype_word(template: MonohybridTemplateSpec, phenotype: str) -> str:
    return (
        template.gene.dominant_phenotype
        if phenotype == "dominant"
        else template.gene.recessive_phenotype
    )
