"""Property-based checking for monohybrid biology templates.

The cross aspect re-derives the key and compares authored examples. The options
aspect additionally computes and validates every distractor. Both use the shared
bounded property runner, so small declared domains are enumerated whole.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal

from edcraft_validator.domains.biology.biology_schemas import (
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.biology_types import PHENOTYPES
from edcraft_validator.domains.biology.cross import (
    BiologyCheckError,
    assemble_variant,
    check_assumptions,
    compute_key,
    format_value,
    parse_answer,
    parse_genotype,
)
from edcraft_validator.domains.biology.options import (
    check_applicability,
    check_options,
    distractor_values,
)
from edcraft_validator.validation.check_contracts import ToolFinding
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

Aspect = Literal["cross", "options"]

MAX_RECORDED_VARIANTS = 32

PropertyCheck = Callable[[dict[str, str], PropertyCheckRun], dict[str, Any]]

REAL_ORGANISM_TERMS: tuple[str, ...] = (
    "pea",
    "pisum",
    "mendel",
    "drosophila",
    "fruit fly",
    "human",
    "people",
    "person",
    "child",
    "children",
    "mouse",
    "mice",
    "cattle",
    "cow",
    "dog",
    "cat",
    "maize",
    "corn",
    "arabidopsis",
    "cystic fibrosis",
    "sickle",
    "huntington",
    "albinism",
    "haemophilia",
    "hemophilia",
    "phenylketonuria",
    "tay-sachs",
    "blood group",
    "blood type",
)

_REAL_ORGANISM_PATTERN = re.compile(
    r"\b(?:" + "|".join(re.escape(term) for term in REAL_ORGANISM_TERMS) + r")\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class CheckReport:
    """One aspect's verdict plus its findings and coverage details."""

    status: Literal["passed", "failed", "error"]
    findings: list[ToolFinding]
    details: dict[str, Any]


def real_organism_terms(item: MonohybridTemplateSpec) -> list[tuple[str, str]]:
    """Return every real-organism term found, with the field it came from."""
    fields = {
        "organism": item.organism,
        "trait": item.trait,
        "gene.dominant_phenotype": item.gene.dominant_phenotype,
        "gene.recessive_phenotype": item.gene.recessive_phenotype,
        "text.template": item.text.template,
    }
    matches: list[tuple[str, str]] = []
    for field, text in fields.items():
        for match in _REAL_ORGANISM_PATTERN.finditer(text):
            matches.append((match.group(0).lower(), field))
    return matches


def _template_findings(
    item: MonohybridTemplateSpec, aspect: Aspect
) -> list[ToolFinding]:
    findings = [
        ToolFinding(code=finding.code, message=finding.message)
        for finding in check_assumptions(item.assumptions)
    ]
    findings.extend(_malformed_token_findings(item))
    findings.extend(_real_organism_findings(item))
    if aspect == "options":
        findings.extend(
            ToolFinding(code=finding.code, message=finding.message)
            for finding in check_applicability(item)
        )
    return findings


def _malformed_token_findings(item: MonohybridTemplateSpec) -> list[ToolFinding]:
    findings: list[ToolFinding] = []
    for parameter in item.parameters:
        for value in parameter.values:
            code = _malformed_value_code(item, parameter.kind, value)
            if code is not None:
                findings.append(
                    ToolFinding(
                        code=code,
                        message=f"parameter {parameter.name!r} has malformed "
                        f"{parameter.kind} value {value!r}",
                        field=f"parameters.{parameter.name}",
                    )
                )
    return findings


def _malformed_value_code(
    item: MonohybridTemplateSpec, kind: str, value: str
) -> str | None:
    try:
        if kind == "genotype":
            parse_genotype(value, item.gene.symbol)
        elif kind == "phenotype":
            if value not in PHENOTYPES:
                return "MALFORMED_PHENOTYPE"
        elif not value.isdigit() or not 1 <= int(value) <= 10000:
            return "MALFORMED_COUNT"
    except BiologyCheckError as exc:
        return exc.code
    return None


def _real_organism_findings(item: MonohybridTemplateSpec) -> list[ToolFinding]:
    return [
        ToolFinding(
            code="REAL_ORGANISM_REFERENCE",
            message=f"real-organism term {term!r} appears in {field}",
            field=field,
        )
        for term, field in real_organism_terms(item)
    ]


def _variant_key(values: dict[str, str]) -> tuple[tuple[str, str], ...]:
    return tuple(sorted(values.items()))


def _claimed_answers(
    item: MonohybridTemplateSpec,
) -> tuple[dict[tuple[tuple[str, str], ...], str], list[ToolFinding]]:
    declared = {parameter.name: set(parameter.values) for parameter in item.parameters}
    answers: dict[tuple[tuple[str, str], ...], str] = {}
    findings: list[ToolFinding] = []
    for index, example in enumerate(item.answer_recipe.claimed_examples):
        missing = sorted(set(declared) - set(example.parameters))
        unknown = sorted(set(example.parameters) - set(declared))
        undeclared = sorted(
            f"{name}={value}"
            for name, value in example.parameters.items()
            if name in declared and value not in declared[name]
        )
        if missing or unknown or undeclared:
            detail = ", ".join([*missing, *unknown, *undeclared])
            findings.append(
                ToolFinding(
                    code="CLAIMED_EXAMPLE_NOT_DECLARED",
                    message=f"claimed example {index} is not a declared "
                    f"combination ({detail})",
                    field="answer_recipe.claimed_examples",
                )
            )
            continue
        answers[_variant_key(example.parameters)] = example.answer
    return answers, findings


def _boundary_examples(
    item: MonohybridTemplateSpec, claimed: dict[tuple[tuple[str, str], ...], str]
) -> list[dict[str, str]]:
    examples = [
        dict(example.parameters) for example in item.answer_recipe.claimed_examples
    ]
    examples.append(
        {parameter.name: parameter.values[0] for parameter in item.parameters}
    )
    examples.append(
        {parameter.name: parameter.values[-1] for parameter in item.parameters}
    )
    return examples


def _record(
    values: dict[str, str], variant: Any, option_values: list[str]
) -> dict[str, Any]:
    return {
        "parameters": dict(values),
        "parents": dict(variant.parents),
        "punnett": variant.punnett,
        "genotype_distribution": variant.genotype_distribution,
        "phenotype_distribution": variant.phenotype_distribution,
        "key": variant.key,
        "option_values": option_values,
    }


def _best_effort_option_values(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> list[str]:
    try:
        return [format_value(value, item) for value in distractor_values(item, values)]
    except BiologyCheckError:
        return []


def _assemble_or_fail(
    item: MonohybridTemplateSpec, values: dict[str, str], field: str
) -> Any:
    try:
        return assemble_variant(item, values)
    except BiologyCheckError as exc:
        raise ValidationFailure(
            exc.message,
            code=exc.code,
            field=field,
            context={"variant": {"parameters": dict(values)}},
        ) from None


def _cross_property(
    item: MonohybridTemplateSpec,
    claimed: dict[tuple[tuple[str, str], ...], str],
    variants: list[dict[str, Any]],
) -> PropertyCheck:
    def check(values: dict[str, str], run: PropertyCheckRun) -> dict[str, Any]:
        run.reserve_execution()
        variant = _assemble_or_fail(item, values, "cross")
        record = _record(values, variant, _best_effort_option_values(item, values))
        answer = claimed.get(_variant_key(values))
        if answer is not None:
            try:
                expected = parse_answer(answer, item)
            except BiologyCheckError as exc:
                raise ValidationFailure(
                    exc.message,
                    code=exc.code,
                    field="answer_recipe.claimed_examples",
                    context={"variant": record},
                ) from None
            if expected != compute_key(item, values):
                raise ValidationFailure(
                    f"the claimed answer {answer!r} does not match the "
                    f"computed key {variant.key!r}",
                    code="CLAIMED_ANSWER_MISMATCH",
                    field="answer_recipe.claimed_examples",
                    context={"variant": record},
                )
        variants.append(record)
        return record

    return check


def _options_property(
    item: MonohybridTemplateSpec,
    variants: list[dict[str, Any]],
) -> PropertyCheck:
    def check(values: dict[str, str], run: PropertyCheckRun) -> dict[str, Any]:
        run.reserve_execution()
        variant = _assemble_or_fail(item, values, "distractors")
        record = _record(values, variant, [])
        try:
            computed = check_options(item, values)
        except BiologyCheckError as exc:
            raise ValidationFailure(
                exc.message,
                code=exc.code,
                field="distractors",
                context={"variant": record},
            ) from None
        record["option_values"] = [format_value(value, item) for value in computed]
        variants.append(record)
        return record

    return check


def check_template(
    template: MonohybridTemplateSpec,
    settings: PropertyCheckSettings | None = None,
    *,
    aspect: Aspect = "cross",
) -> CheckReport:
    """Check one aspect of a template over its declared parameter domain."""
    findings = _template_findings(template, aspect)
    if findings:
        return CheckReport(
            status="failed",
            findings=findings,
            details={"variants": [], "variants_truncated": False},
        )

    claimed, claim_findings = _claimed_answers(template)
    if claim_findings:
        return CheckReport(
            status="failed",
            findings=claim_findings,
            details={"variants": [], "variants_truncated": False},
        )

    run = PropertyCheckRun(settings or PropertyCheckSettings())
    parameters = {
        parameter.name: list(parameter.values) for parameter in template.parameters
    }
    boundary = _boundary_examples(template, claimed)
    variants: list[dict[str, Any]] = []
    inner_check = (
        _cross_property(template, claimed, variants)
        if aspect == "cross"
        else _options_property(template, variants)
    )
    first_failure: list[ValidationFailure] = []

    def property_check(values: dict[str, str], budget: PropertyCheckRun) -> Any:
        try:
            return inner_check(values, budget)
        except ValidationFailure as exc:
            # Shrinking spends execution calls, so keep the first real failure
            # in case the budget runs out before the property run finishes.
            if not first_failure:
                first_failure.append(exc)
            raise

    try:
        run.check(
            parameters,
            boundary,
            property_check,
            cover_small_domain=True,
        )
    except ValidationFailure as raised:
        exc = raised
        if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" and first_failure:
            exc = first_failure[0]
            exc.context.update(run.details())
        details = dict(exc.context)
        details["variants"] = variants[:MAX_RECORDED_VARIANTS]
        details["variants_truncated"] = len(variants) > MAX_RECORDED_VARIANTS
        failed_variant = exc.context.get("variant")
        if failed_variant is not None:
            details["failed_variant"] = failed_variant
        status: Literal["failed", "error"] = (
            "error" if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" else "failed"
        )
        return CheckReport(
            status=status,
            findings=[ToolFinding(code=exc.code, message=str(exc), field=exc.field)],
            details=details,
        )

    details = run.details()
    details["variants"] = variants[:MAX_RECORDED_VARIANTS]
    details["variants_truncated"] = len(variants) > MAX_RECORDED_VARIANTS
    return CheckReport(status="passed", findings=[], details=details)
