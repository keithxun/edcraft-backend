"""Biology-domain implementation of the generic domain contract.

The domain builds a candidate from a model proposal, binds its MCP checks,
finalises the checked template, and expands it into a seeded question.
"""

from typing import Any

from fastmcp import FastMCP
from pydantic import BaseModel

from edcraft_validator.application.difficulty_rubrics import (
    register_difficulty_rubric,
)
from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.biology.authored_cross import (
    checked_cross,
    explicit_limitation,
    fit_requested,
    require_biology_source,
    require_cross_output,
    require_cross_scope,
)
from edcraft_validator.domains.biology.biology_schemas import (
    AuthoredCross,
    BiologyAuthorProposal,
    BiologyQuestionBase,
    BiologyQuestionPayload,
    BiologyTemplateCandidate,
    BiologyTemplateContent,
    BiologyTemplateRequest,
    BiologyTemplateSpec,
    BiologyUnsupportedSpec,
    BiologyValidationSummary,
    H2TemplateSpec,
    ValidatedBiologyTemplate,
)
from edcraft_validator.domains.biology.biology_types import (
    BIOLOGY_CROSS_TOOL,
    BIOLOGY_FIDELITY_TOOL,
    BIOLOGY_OPTIONS_TOOL,
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
)
from edcraft_validator.domains.biology.candidate_builder import (
    build_biology_candidate,
    template_sha256,
)
from edcraft_validator.domains.biology.cross import BiologyCheckError
from edcraft_validator.domains.biology.difficulty import (
    BIOLOGY_DIFFICULTY_RUBRIC_ID,
    H2_BIOLOGY_DIFFICULTY_RUBRIC_ID,
    blinded_biology_template_payload,
    h2_biology_difficulty_rubric,
    load_biology_difficulty_rubric,
)
from edcraft_validator.domains.biology.fit_schema import GoodnessOfFitTemplate
from edcraft_validator.domains.biology.h2_authoring import h2_choices
from edcraft_validator.domains.biology.h2_cases import (
    CHEMIOSMOSIS_CONTRASTS,
    SUPERSEDED_H2_CASES,
    resolve_h2_cases,
)
from edcraft_validator.domains.biology.h2_task_scope import hard_task_note, requested
from edcraft_validator.domains.biology.prompt_builder import (
    build_biology_generation_request,
)
from edcraft_validator.domains.biology.question_generator import (
    generate_biology_question,
)
from edcraft_validator.domains.biology.relevance import template_relevance_text
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    build_review_view,
    require_checked,
    require_type,
    save_checked_evidence,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.mcp.biology_tools import register_biology_tools
from edcraft_validator.mcp.tool_dependencies import ToolDependencies
from edcraft_validator.validation.check_contracts import ToolEvidence
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.property_summary import property_details


class BiologyDomain:
    """Prompting, validation, and expansion for biology templates."""

    name = "biology"
    request_model = BiologyTemplateRequest
    candidate_model = BiologyTemplateCandidate
    validated_model = ValidatedBiologyTemplate
    question_model = BiologyQuestionPayload
    template_language = None
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )

    def register_tools(self, server: FastMCP, dependencies: ToolDependencies) -> None:
        """Register the biology domain's authoritative and advisory tools."""
        register_difficulty_rubric(load_biology_difficulty_rubric())
        register_difficulty_rubric(h2_biology_difficulty_rubric())
        register_biology_tools(
            server,
            property_settings=dependencies.property_settings,
            fidelity_provider_factory=dependencies.fidelity_provider_factory,
            fidelity_timeout_seconds=dependencies.fidelity_timeout_seconds,
        )

    def review_view(
        self, artifact: ValidatedTemplateArtifact
    ) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=self.template_language)
        if view is None or not isinstance(artifact, ValidatedBiologyTemplate):
            return view
        item = artifact.template.item
        if not isinstance(item, H2TemplateSpec):
            return view
        try:
            cases = resolve_h2_cases(item)
            view.case_previews = [
                ReviewCasePreview(
                    case_id=case.id,
                    outcome=case.outcome,
                    question=case.question,
                    answer=case.answer,
                    figure=case.figure.model_dump(mode="json") if case.figure else None,
                    choices=[case.answer, *h2_choices(case, item)],
                    superseded_by=SUPERSEDED_H2_CASES.get(case.id),
                )
                for case in cases
            ]
            if note := hard_task_note(tuple(item.cases), artifact.template.difficulty):
                view.warnings.append(note)
            count = len(item.distractors)
            if count < 4 and any(case.id in CHEMIOSMOSIS_CONTRASTS for case in cases):
                view.warnings.append(
                    f"The choices isolate {count} of four compartment assignments "
                    "per question. Four distractors can isolate each assignment."
                )
        except BiologyCheckError:
            # Invalid or stale artifacts cannot supply authoritative review copies.
            pass
        return view

    def generation_request(
        self, request: BaseModel
    ) -> StructuredGenerationRequest[PlannedGenerationResponse[BiologyAuthorProposal]]:
        typed_request = require_type(request, BiologyTemplateRequest)
        if limitation := explicit_limitation(typed_request.prompt):
            raise UnsupportedAuthoringRequest(limitation)
        return build_biology_generation_request(typed_request)

    def build_candidate(
        self, request: BaseModel, proposal: BaseModel
    ) -> BiologyTemplateCandidate:
        typed_request = require_type(request, BiologyTemplateRequest)
        if isinstance(proposal, BiologyAuthorProposal):
            authored = proposal.item
            if isinstance(authored, BiologyUnsupportedSpec):
                raise UnsupportedAuthoringRequest(authored.reason)
        else:
            authored = require_type(proposal, BiologyTemplateContent).item
            if isinstance(authored, H2TemplateSpec):
                raise UnsupportedAuthoringRequest(
                    "New biology questions require an independent calculation."
                )
            if not isinstance(authored, GoodnessOfFitTemplate):
                authored = AuthoredCross.model_validate(
                    authored.model_dump(exclude={"text"})
                )
        require_biology_source(
            typed_request, fit=isinstance(authored, GoodnessOfFitTemplate)
        )
        if isinstance(authored, GoodnessOfFitTemplate):
            _require_fit_output(typed_request, authored)
            return build_biology_candidate(
                typed_request, BiologyTemplateContent(item=authored)
            )
        if fit_requested(typed_request.prompt):
            raise UnsupportedAuthoringRequest(
                "Use the checked chi-square count-table operation for this task."
            )
        require_cross_scope(
            typed_request.prompt, has_materials=typed_request.materials is not None
        )
        require_cross_output(typed_request.prompt, authored)
        content = BiologyTemplateContent(item=checked_cross(authored))
        return build_biology_candidate(typed_request, content)

    def tool_bindings(
        self, request: BaseModel, candidate: BaseModel, tool_name: str
    ) -> dict[str, Any]:
        """Application-owned values never come from model tool arguments."""
        typed_candidate = require_type(candidate, BiologyTemplateCandidate)
        template = typed_candidate.item
        if tool_name == TEMPLATE_RELEVANCE_CHECK:
            return {
                "author_request": require_type(request, BiologyTemplateRequest).prompt,
                "question_text": template_relevance_text(typed_candidate),
                "subject_sha256": template_sha256(typed_candidate),
            }
        if tool_name == TEMPLATE_DIFFICULTY_CHECK:
            return {
                "rubric_id": (
                    H2_BIOLOGY_DIFFICULTY_RUBRIC_ID
                    if isinstance(template, (H2TemplateSpec, GoodnessOfFitTemplate))
                    else BIOLOGY_DIFFICULTY_RUBRIC_ID
                ),
                "question_payload": blinded_biology_template_payload(typed_candidate),
                "distractor_count": len(template.distractors),
                "requested_difficulty": typed_candidate.difficulty,
                "subject_sha256": template_sha256(typed_candidate),
            }
        if tool_name in {
            BIOLOGY_CROSS_TOOL,
            BIOLOGY_OPTIONS_TOOL,
            BIOLOGY_FIDELITY_TOOL,
        }:
            return {"template": template.model_dump(mode="json")}
        return {"candidate": typed_candidate.model_dump(mode="json")}

    def distractor_count(self, candidate: BaseModel) -> int:
        template = require_type(candidate, BiologyTemplateCandidate).item
        return len(template.distractors)

    def required_checks(self, candidate: BaseModel) -> frozenset[str]:
        """All biology checks always run: the text is always prose."""
        require_type(candidate, BiologyTemplateCandidate)
        return frozenset(
            {BIOLOGY_CROSS_TOOL, BIOLOGY_OPTIONS_TOOL, BIOLOGY_FIDELITY_TOOL}
        )

    def finalize_checked_template(
        self,
        candidate: BaseModel,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> ValidatedBiologyTemplate:
        """Package the checks' evidence without running them again."""
        template = require_type(candidate, BiologyTemplateCandidate)
        template_spec = template.item

        require_checked(
            evidence,
            required=self.required_checks(template),
            advisory_checks=advisory_checks,
        )
        _require_distractor_count(template_spec)

        cross_evidence = _cross_evidence(evidence)
        checked = _checked_property_details(cross_evidence)
        saved_evidence = [
            save_checked_evidence(
                item, template_sha256(template), advisory_checks=advisory_checks
            )
            for item in evidence
        ]

        summary = BiologyValidationSummary(
            **checked,
            evidence=saved_evidence,
        )

        return ValidatedBiologyTemplate(template=template, validation=summary)

    def checked_tool_bindings(
        self,
        request: BaseModel,
        candidate: BaseModel,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, Any]:
        """Checking never rewrites a biology template, so the candidate is bound."""
        return self.tool_bindings(request, candidate, tool_name)

    def generate_question(
        self, validated: BaseModel, *, seed: int
    ) -> BiologyQuestionBase:
        return generate_biology_question(
            require_type(validated, ValidatedBiologyTemplate), seed
        )


def _require_distractor_count(template: BiologyTemplateSpec) -> None:
    """Keep the option count within the range the artifact format allows."""
    count = len(template.distractors)
    if count < MIN_DISTRACTORS:
        raise ValueError("Biology templates require at least one distractor")
    if count > MAX_DISTRACTORS:
        raise ValueError(
            f"Biology templates allow at most {MAX_DISTRACTORS} distractors"
        )


def _require_fit_output(
    request: BiologyTemplateRequest, item: GoodnessOfFitTemplate
) -> None:
    prompt = request.prompt
    if limitation := explicit_limitation(prompt):
        raise UnsupportedAuthoringRequest(limitation)
    if not fit_requested(prompt) and request.materials is None:
        raise UnsupportedAuthoringRequest(
            "Use a checked operation that matches the requested Biology task."
        )
    if (
        requested(
            r"\b(?:critical value|whether to reject|test decision|"
            r"decision|conclusion)\b",
            prompt,
        )
        and item.critical_value is None
    ):
        raise UnsupportedAuthoringRequest(
            "Supply a critical value for the requested chi-square decision."
        )
    if (
        requested(
            r"\bstatistic alone\b|\bonly (?:the )?(?:numeric(?:al)? )?"
            r"(?:chi.square )?statistic\b",
            prompt,
        )
        and item.critical_value is not None
    ):
        raise UnsupportedAuthoringRequest("Ask for the statistic alone as requested.")
    if item.expected_display == "ratio" and requested(
        r"\bobserved and expected (?:phenotype )?counts\b"
        r"|\b(?:given|supplied|provided) expected (?:phenotype )?counts\b",
        prompt,
    ):
        raise UnsupportedAuthoringRequest("Display the requested expected counts.")
    if item.expected_display == "counts" and requested(
        r"\bexpected (?:phenotype )?ratio\b", prompt
    ):
        raise UnsupportedAuthoringRequest("Display the requested expected ratio.")


def _cross_evidence(evidence: list[ToolEvidence]) -> ToolEvidence:
    return next(item for item in evidence if item.tool == BIOLOGY_CROSS_TOOL)


def _checked_property_details(cross_evidence: ToolEvidence) -> dict[str, Any]:
    """Refuse a pass that sampled no parameter combinations."""
    checked = property_details(cross_evidence.details)
    if checked["examples_checked"] < 1:
        raise ValueError("Biology validation checked no parameter combinations")
    return checked
