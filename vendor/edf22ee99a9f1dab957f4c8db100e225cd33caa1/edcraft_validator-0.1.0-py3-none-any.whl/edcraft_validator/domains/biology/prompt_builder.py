"""Build biology-domain prompts and the structured LLM request."""

from __future__ import annotations

from edcraft_validator.domains.biology.biology_schemas import (
    BiologyAuthorProposal,
    BiologyTemplateRequest,
)
from edcraft_validator.domains.biology.biology_types import (
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

BIOLOGY_TEMPLATE_PROMPT_VERSION = "biology-authored-v2"

BIOLOGY_SCOPE_PROMPT = """\
Return one JSON object with exactly two top-level fields, `proposal` and
`checks`. Put the item object at `proposal.item`. Its `schema_version` and
other fields belong inside `item`. Put the nonempty array of check objects at
`checks`. First decide whether the learner action, format and content fit a
verified Biology question.
A multiple-choice question can assess interpretation of provided text, data
and figures. It cannot assess an original essay, independently produced drawing
or direct performance in a laboratory. Supporting material for a teacher does
not change what the learner must do.

Choose the verified monohybrid cross or chi-square plant-count operation below.
If neither operation can assess the requested objective, return an item with
schema_version "bio-unsupported/1"
and a brief reason. Keep one offered check in the response envelope. It will
not execute for an unsupported item. Never replace an unsupported objective
or image kind with a nearby topic or different task to make it fit.
"""

BIOLOGY_TEMPLATE_SYSTEM_PROMPT = """\
For a custom reusable one-gene calculation supported by the monohybrid model,
author the parameters, cross, target and distractor recipes. The application
derives identity, difficulty and question type.

ITEM FAMILY (`item`)
- `item.schema_version` is exactly "bio-mono/0.1".
- `item.topic` is a stable dotted identifier such as
  "genetics.monohybrid.probability".
- `item.organism` names a hypothetical organism, like "glimmerwort".
  `item.trait` names a visible trait, like "petal colour". These labels use
  letters, spaces and hyphens. The app provides the sentence around each label.
- `item.gene` declares one letter `symbol` (the dominant allele is upper case,
  the recessive allele lower case) and two distinct phenotype words. Phenotype
  words are lowercase letters, spaces or hyphens, for example "purple" and
  "white".
- `item.assumptions` must state inheritance "autosomal", dominance "complete",
  segregation "mendelian" and allele_count 2. Other values parse so that the
  checker can reject them with a named code.
- `item.parameters` declares one to four finite axes. Each parameter has a
  `name`, a `kind` (genotype, phenotype or count) and a list of `values`.
  Names are lowercase identifiers and must not reuse a reserved placeholder.
  Genotype parameters allow at most three values, each a canonical two-letter
  token over the gene symbol: `PP`, `Pp` or `pp` (dominant homozygote,
  heterozygote, recessive homozygote). Phenotype parameters allow at most two
  values, exactly "dominant" and "recessive". Count parameters allow at most
  twelve integer strings from 1 to 10000. Declare values in a useful order: the
  first value and the last value are always checked as boundaries.
- `item.cross.parent1` and `item.cross.parent2` name genotype parameters. Use
  the same parameter name twice for a self-cross.
- `item.question.quantity` is probability, expected_count or ratio.
  Probability questions require `target` and no count or ratio kind.
  Expected-count questions require `target` and `offspring_count`, which names a
  count parameter. Ratio questions require `ratio_kind` (genotype or phenotype)
  and no target, given or count.
  `target.kind` is genotype or phenotype and `target.param` names a parameter of
  that kind. `given` is an optional phenotype ("dominant" or "recessive") that
  conditions the question, for example "of the purple offspring".
  Every declared parameter must be referenced at least once.
- `item.answer_recipe.rule` is exactly "exact". Supply one to three
  `claimed_examples`, each with a complete declared parameter mapping and the
  exact answer the template should compute. The checker recomputes every
  example from the cross, so a wrong claim fails the template.
- `item.distractors` lists candidate wrong choices in order of pedagogical
  plausibility. Supply exactly the candidate recipe count in the request. The
  application selects one fixed set of the requested usable size. Give each
  candidate a `rule` from the vocabulary, a short `misconception` tag and an
  optional `reason`. Only `fixed_value` may set `value`. Use a fixed value when
  it represents a specific, recognisable error.

DISTRACTOR RULES (closed vocabulary)
- `unconditioned`: P(target) ignoring the given phenotype. Applies when `given`
  is set.
- `reverse_condition`: P(given phenotype | target). Applies when `given` is set.
- `forget_heterozygote`: remaps phenotypes so only the dominant homozygote is
  dominant and a heterozygote shows the recessive phenotype. Applies when the
  target is a phenotype or `given` is set.
- `phenotype_for_genotype`: P(the phenotype of the target genotype). Applies
  when the target kind is genotype.
- `uniform_genotype_classes`: treats every distinct genotype class in the
  Punnett square as equally likely. Applies to probability or expected_count.
- `complement`: one minus the key for a probability, or N minus the key for an
  expected count. Applies to probability or expected_count.
- `swap_dominance`: remaps phenotypes so the recessive allele is treated as
  dominant. Applies when the target is a phenotype or `given` is set.
- `genotype_ratio_for_phenotype`: reports the genotype ratio. Applies to a
  phenotype ratio question.
- `phenotype_ratio_for_genotype`: reports the phenotype ratio. Applies to a
  genotype ratio question.
- `fixed_value`: parses `value` exactly like an answer. Applies to any question.
  For expected-count questions the value must be a whole-number count; for
  probability questions it must be in [0, 1].
Count rules use the probability rule and then multiply by N. Use only rules
applicable to the question. The same selected recipes must yield distinct wrong
values for every checked input. Anticipate collisions between errors on unusual
inputs by offering genuinely different misconceptions.

DISPLAY
The application renders the question from the cross and target. Omit free-text
stems. Choose the gene symbol, hypothetical organism, trait and phenotype labels.
Keep the requested output and conditioning. For a recessive phenotype count,
set quantity="expected_count", target.kind="phenotype" and the target
parameter's values to ["recessive"]. Use the optional given only if the question
is conditional or the teacher asks for reasoning with a condition.

ANSWER FORMS
- Probability: an exact fraction such as "2/3" or a whole number "0" or "1".
  Never use percentages, decimals or mixed numbers.
- Expected count: a whole-number count such as "60". A combination whose exact
  expected count is not an integer is unusable, so declare count values that keep
  every variant whole.
- Ratio: a fully labelled ratio such as "1 PP : 2 Pp : 1 pp" or
  "3 purple : 1 white". Every class label appears at most once; an unlabelled
  "3:1" is rejected.

UNSUPPORTED FEATURES FOR THE MONOHYBRID SCHEMA
- Do not use incomplete dominance, codominance, multiple alleles, sex linkage,
  mitochondrial inheritance, non-Mendelian segregation, two or more genes,
  linkage, epistasis, lethal genotypes, penetrance, pedigrees, multi-generation
  crosses, or inference of parents from offspring. Each has a named failure code.
- The model writes declarative data only. Never include executable code.

CHECK PLAN
- Select a nonempty fixed subset of the available MCP tools using their supplied
  descriptions. Use each tool name at most once and do not invent names. Supply
  each selected check's model-owned arguments using its planning schema; use {}
  for checks without model-owned arguments.
- The application always runs biology_verify_cross, biology_validate_options and
  biology_verify_text_fidelity, whether or not you select them.
- Select assess_template_difficulty and assess_template_relevance. They are
  advisory evidence for educator review and never block a technically checked
  template. The difficulty rubric is provisional and uncalibrated.

"""

FIT_PROMPT = """\
CHI-SQUARE GOODNESS OF FIT
For a chi-square question from hypothetical plant counts, use item.schema_version
"bio-fit/0.1". Give a dotted topic. Supply two to six phenotype categories, each
with a short label, an observed list of integer counts, and a positive integer
expected_weight. At least one category needs multiple observed counts. The
weights form the expected ratio in category order. For each variant the
application computes expected counts from the ratio and the observed sample size.
Keep every expected count at least 5 for every combination. Set expected_display
to "ratio" to show the expected ratio or "counts" to show the expected counts.
For a statistic-only question, set critical_value to null. For a decision,
give the critical value as a decimal string, such as "3.84". The student compares
the unrounded statistic with the supplied critical value and rejects only when
the statistic exceeds it. The displayed statistic has two decimal places.

Give one to three claimed_examples. Each provides observed (one integer per
category), statistic (a decimal string), and decision ("reject" or
"fail_to_reject" when a critical value is supplied, otherwise null). The engine
derives the exact result independently. Supply the requested number of candidate
distractor recipes, each with a rule and misconception. The available rules are
observed_denominator, unweighted_squared_error, omit_category, divide_by_total,
largest_contribution, reverse_decision and fixed_value. Only omit_category sets
category (a one-based row number). Reverse_decision requires a critical value.
Only fixed_value sets statistic and, for a decision question, decision. Offer
distinct errors across the full count grid. Do not use an observed-denominator
recipe when an observed count can be zero.

The same biology_verify_cross, biology_validate_options and
biology_verify_text_fidelity checks apply. The application supplies the rendered
table, selection context and task wording. The author supplies no free-text stem.
"""


RESPONSE_GUIDANCE = """\
Use native JSON values. Parameter values are strings such as "30" or "Pp".
Answer values and fixed distractors are exact fractions, whole-number counts or
fully labelled ratios. Only learner-facing text uses `{...}` placeholders.
"""


def build_biology_generation_request(
    request: BiologyTemplateRequest,
) -> StructuredGenerationRequest[PlannedGenerationResponse[BiologyAuthorProposal]]:
    """Ask for an authored cross or a specific unsupported explanation."""
    candidate_count = request.num_distractors + SURPLUS_RECIPES
    user_prompt = f"""\
Author request (preserve its meaning):
{request.prompt}

Requested difficulty: {request.difficulty}
Required usable distractors: {request.num_distractors}
Candidate distractor recipes to supply: {candidate_count}
Supported usable distractor range: {MIN_DISTRACTORS} to {MAX_DISTRACTORS}
"""

    return StructuredGenerationRequest(
        revise_from_authored_pool=True,
        messages=[
            {
                "role": "system",
                "content": "\n".join(
                    (BIOLOGY_SCOPE_PROMPT, BIOLOGY_TEMPLATE_SYSTEM_PROMPT, FIT_PROMPT)
                ),
            },
            {"role": "user", "content": f"{user_prompt}\n{RESPONSE_GUIDANCE}"},
        ],
        response_model=PlannedGenerationResponse[BiologyAuthorProposal],
        prompt_version=f"{BIOLOGY_TEMPLATE_PROMPT_VERSION}+response-v1",
        schema_name="template_proposal_and_check_plan",
        check_argument_models=(),
    )
