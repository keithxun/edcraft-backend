"""Exact Mendelian monohybrid engine.

Probabilities and counts use :class:`fractions.Fraction` (counts are integer
subclasses), ratios are reduced tuples of ``(label, count)``. Nothing here uses
floating point, randomness, or I/O.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from fractions import Fraction
from itertools import product
from typing import Literal

from edcraft_validator.domains.biology.biology_schemas import (
    AssumptionSpec,
    GeneSpec,
    MonohybridTemplateSpec,
)

Ratio = tuple[tuple[str, int], ...]
Value = Fraction | Ratio

PhenotypeModel = Literal["complete", "forget_heterozygote", "swap_dominance"]

_PROBABILITY_PATTERN = re.compile(r"\s*(\d+)(?:\s*/\s*(\d+))?\s*")
_COUNT_PATTERN = re.compile(r"\s*(\d+)\s*")
_RATIO_PART_PATTERN = re.compile(r"\s*(\d+)\s+([A-Za-z][A-Za-z -]*)\s*")


class BiologyCheckError(ValueError):
    """A named, explainable failure in one variant of a biology template."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class Finding:
    """One template-level or assumption-level observation."""

    code: str
    message: str


@dataclass(frozen=True)
class VariantResult:
    """Reviewable evidence for one concrete parameter combination."""

    parents: dict[str, str]
    gametes: dict[str, dict[str, str]]
    punnett: list[list[str]]
    genotype_distribution: dict[str, str]
    phenotype_distribution: dict[str, str]
    key: str
    distractor_values: list[str]


def check_assumptions(assumptions: AssumptionSpec) -> list[Finding]:
    """Report every assumption this slice cannot model exactly."""
    findings: list[Finding] = []
    if assumptions.inheritance != "autosomal":
        findings.append(
            Finding(
                "UNSUPPORTED_INHERITANCE",
                f"inheritance {assumptions.inheritance!r} is not supported",
            )
        )
    if assumptions.dominance != "complete":
        findings.append(
            Finding(
                "UNSUPPORTED_DOMINANCE",
                f"dominance {assumptions.dominance!r} is not supported",
            )
        )
    if assumptions.segregation != "mendelian":
        findings.append(
            Finding(
                "UNSUPPORTED_SEGREGATION",
                f"segregation {assumptions.segregation!r} is not supported",
            )
        )
    if assumptions.allele_count != 2:
        findings.append(
            Finding(
                "UNSUPPORTED_ALLELE_COUNT",
                f"allele_count {assumptions.allele_count} is not supported",
            )
        )
    return findings


def _classes(symbol: str) -> tuple[str, str, str]:
    upper = symbol
    lower = symbol.lower()
    return (upper + upper, upper + lower, lower + lower)


def parse_genotype(token: str, symbol: str) -> str:
    """Return the canonical token, or fail with ``MALFORMED_GENOTYPE``."""
    classes = _classes(symbol)
    if token not in classes:
        raise BiologyCheckError(
            "MALFORMED_GENOTYPE",
            f"{token!r} is not a canonical genotype for gene {symbol}",
        )
    return token


def gametes(genotype: str) -> dict[str, Fraction]:
    """Allele frequencies contributed by one canonical genotype."""
    if len(genotype) != 2:
        raise BiologyCheckError(
            "MALFORMED_GENOTYPE", f"{genotype!r} is not a genotype token"
        )
    frequencies: dict[str, Fraction] = {}
    for allele in genotype:
        frequencies[allele] = frequencies.get(allele, Fraction(0)) + Fraction(1, 2)
    return frequencies


def _symbol_from_parents(parent1: str, parent2: str) -> str:
    if not parent1 or not parent2:
        raise BiologyCheckError("MALFORMED_GENOTYPE", "a parent genotype is empty")
    symbol = parent1[0].upper()
    parse_genotype(parent1, symbol)
    parse_genotype(parent2, symbol)
    return symbol


def _canonical_pair(first: str, second: str) -> str:
    return "".join(sorted((first, second)))


def punnett(parent1: str, parent2: str) -> list[list[str]]:
    """The 2x2 Punnett square as canonical cells, row by row."""
    symbol = _symbol_from_parents(parent1, parent2)
    parse_genotype(parent1, symbol)
    parse_genotype(parent2, symbol)
    cells = [_canonical_pair(left, right) for left, right in product(parent1, parent2)]
    return [cells[0:2], cells[2:4]]


def genotype_distribution(parent1: str, parent2: str) -> dict[str, Fraction]:
    """Offspring genotype probabilities in fixed class order."""
    symbol = _symbol_from_parents(parent1, parent2)
    distribution = dict.fromkeys(_classes(symbol), Fraction(0))
    for row in punnett(parent1, parent2):
        for cell in row:
            distribution[cell] += Fraction(1, 4)
    return distribution


def phenotype_of(genotype: str) -> Literal["dominant", "recessive"]:
    """Complete-dominance phenotype: any upper-case allele is dominant."""
    if len(genotype) != 2:
        raise BiologyCheckError(
            "MALFORMED_GENOTYPE", f"{genotype!r} is not a genotype token"
        )
    return "dominant" if any(allele.isupper() for allele in genotype) else "recessive"


def phenotype_distribution(
    parent1: str, parent2: str, gene: GeneSpec
) -> dict[str, Fraction]:
    """Offspring phenotype probabilities labelled with the gene's words."""
    genotypes = genotype_distribution(parent1, parent2)
    return {
        gene.dominant_phenotype: sum(
            (
                value
                for token, value in genotypes.items()
                if phenotype_of(token) == "dominant"
            ),
            Fraction(0),
        ),
        gene.recessive_phenotype: sum(
            (
                value
                for token, value in genotypes.items()
                if phenotype_of(token) == "recessive"
            ),
            Fraction(0),
        ),
    }


def _phenotype(
    genotype: str, symbol: str, model: PhenotypeModel
) -> Literal["dominant", "recessive"]:
    dominant_homozygote = symbol + symbol
    if model == "complete":
        return phenotype_of(genotype)
    if model == "forget_heterozygote":
        return "dominant" if genotype == dominant_homozygote else "recessive"
    return "recessive" if genotype == dominant_homozygote else "dominant"


def _phenotype_event(
    distribution: dict[str, Fraction],
    symbol: str,
    phenotype: str,
    model: PhenotypeModel,
) -> set[str]:
    if phenotype not in ("dominant", "recessive"):
        raise BiologyCheckError(
            "MALFORMED_PHENOTYPE",
            f"{phenotype!r} is not 'dominant' or 'recessive'",
        )
    return {
        genotype
        for genotype in distribution
        if _phenotype(genotype, symbol, model) == phenotype
    }


def parent_genotypes(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> tuple[str, str]:
    return (
        parse_genotype(values[item.cross.parent1], item.gene.symbol),
        parse_genotype(values[item.cross.parent2], item.gene.symbol),
    )


def target_event(
    item: MonohybridTemplateSpec,
    values: dict[str, str],
    distribution: dict[str, Fraction],
    model: PhenotypeModel,
) -> set[str]:
    target = item.question.target
    if target is None:
        raise BiologyCheckError("MISSING_TARGET", "the question declares no target")
    if target.kind == "genotype":
        return {parse_genotype(values[target.param], item.gene.symbol)}
    return _phenotype_event(distribution, item.gene.symbol, values[target.param], model)


def given_event(
    item: MonohybridTemplateSpec,
    distribution: dict[str, Fraction],
    model: PhenotypeModel,
) -> set[str] | None:
    given = item.question.given
    if given is None:
        return None
    return _phenotype_event(distribution, item.gene.symbol, given.phenotype, model)


def conditional_probability(
    distribution: dict[str, Fraction],
    target: set[str],
    given: set[str] | None,
    *,
    zero_condition_code: str,
) -> Fraction:
    """P(target), or P(target | given) when a condition is set."""
    if given is None:
        return sum((distribution[g] for g in target), Fraction(0))
    given_probability = sum((distribution[g] for g in given), Fraction(0))
    if given_probability == 0:
        raise BiologyCheckError(
            zero_condition_code,
            "the given phenotype is impossible for this cross",
        )
    joint = sum((distribution[g] for g in target & given), Fraction(0))
    return joint / given_probability


def offspring_count(item: MonohybridTemplateSpec, values: dict[str, str]) -> int:
    name = item.question.offspring_count
    if name is None:
        raise BiologyCheckError("MISSING_OFFSPRING_COUNT", "no count parameter")
    try:
        count = int(values[name])
    except (KeyError, TypeError, ValueError):
        raise BiologyCheckError(
            "MALFORMED_COUNT", f"offspring count {values.get(name)!r} is not an integer"
        ) from None
    if count < 0:
        raise BiologyCheckError("MALFORMED_COUNT", "offspring count cannot be negative")
    return count


def _expected_count(
    item: MonohybridTemplateSpec, values: dict[str, str], probability: Fraction
) -> Fraction:
    count = probability * offspring_count(item, values)
    if count.denominator != 1:
        raise BiologyCheckError(
            "NON_INTEGER_EXPECTED_COUNT",
            f"the expected count {count} is not a whole number",
        )
    return count


def integer_counts(distribution: dict[str, Fraction]) -> dict[str, int]:
    denominator = math.lcm(*(value.denominator for value in distribution.values()))
    return {label: int(value * denominator) for label, value in distribution.items()}


def reduce_ratio(counts: list[tuple[str, int]]) -> Ratio:
    non_zero = [(label, count) for label, count in counts if count > 0]
    if len(non_zero) < 2:
        raise BiologyCheckError(
            "DEGENERATE_RATIO",
            "a ratio needs at least two non-zero classes",
        )
    divisor = math.gcd(*(count for _, count in non_zero))
    return tuple((label, count // divisor) for label, count in non_zero)


def _ratio_value(item: MonohybridTemplateSpec, values: dict[str, str]) -> Ratio:
    parent1, parent2 = parent_genotypes(item, values)
    genotypes = genotype_distribution(parent1, parent2)
    if item.question.ratio_kind == "genotype":
        return reduce_ratio(list(integer_counts(genotypes).items()))
    phenotypes = phenotype_distribution(parent1, parent2, item.gene)
    return reduce_ratio(list(integer_counts(phenotypes).items()))


def compute_key(item: MonohybridTemplateSpec, values: dict[str, str]) -> Value:
    """The exact correct answer for one declared parameter combination."""
    findings = check_assumptions(item.assumptions)
    if findings:
        raise BiologyCheckError(findings[0].code, findings[0].message)

    if item.question.quantity == "ratio":
        return _ratio_value(item, values)

    parent1, parent2 = parent_genotypes(item, values)
    distribution = genotype_distribution(parent1, parent2)
    target = target_event(item, values, distribution, "complete")
    given = given_event(item, distribution, "complete")
    probability = conditional_probability(
        distribution,
        target,
        given,
        zero_condition_code="CONDITION_IMPOSSIBLE",
    )
    if item.question.quantity == "probability":
        return probability
    return _expected_count(item, values, probability)


def parse_answer(text: str, item: MonohybridTemplateSpec) -> Value:
    """Parse an authored answer into the same exact value the engine returns."""
    quantity = item.question.quantity
    if quantity == "probability":
        return _parse_probability(text)
    if quantity == "expected_count":
        return _parse_count(text)
    return _parse_ratio(text, item)


def _parse_probability(text: str) -> Fraction:
    match = _PROBABILITY_PATTERN.fullmatch(text)
    if match is None:
        raise BiologyCheckError(
            "MALFORMED_ANSWER", f"{text!r} is not an integer or a simple fraction"
        )
    denominator = int(match.group(2) or 1)
    if denominator == 0:
        raise BiologyCheckError("MALFORMED_ANSWER", "the denominator cannot be zero")
    value = Fraction(int(match.group(1)), denominator)
    if not Fraction(0) <= value <= Fraction(1):
        raise BiologyCheckError(
            "MALFORMED_ANSWER", f"{text!r} is not a probability in [0, 1]"
        )
    return value


def _parse_count(text: str) -> Fraction:
    match = _COUNT_PATTERN.fullmatch(text)
    if match is None:
        raise BiologyCheckError(
            "MALFORMED_ANSWER", f"{text!r} is not a non-negative integer"
        )
    return Fraction(int(match.group(1)))


def _parse_ratio(text: str, item: MonohybridTemplateSpec) -> Ratio:
    parts = text.split(":")
    if len(parts) < 2:
        raise BiologyCheckError(
            "MALFORMED_ANSWER", "a ratio needs labels: '1 PP : 2 Pp : 1 pp'"
        )
    labels = _ratio_labels(item)
    counts: dict[str, int] = {}
    for part in parts:
        match = _RATIO_PART_PATTERN.fullmatch(part)
        if match is None:
            raise BiologyCheckError(
                "MALFORMED_ANSWER", f"{part.strip()!r} is not 'count label'"
            )
        label = match.group(2).strip()
        if label not in labels:
            raise BiologyCheckError(
                "MALFORMED_ANSWER", f"{label!r} is not a label for this ratio"
            )
        if label in counts:
            raise BiologyCheckError(
                "MALFORMED_ANSWER", f"label {label!r} appears more than once"
            )
        counts[label] = int(match.group(1))
    if not any(counts.values()):
        raise BiologyCheckError("MALFORMED_ANSWER", "a ratio cannot be all zero")
    ordered = [(label, counts.get(label, 0)) for label in labels]
    return reduce_ratio(ordered)


def _ratio_labels(item: MonohybridTemplateSpec) -> tuple[str, ...]:
    if item.question.ratio_kind == "genotype":
        return _classes(item.gene.symbol)
    return (item.gene.dominant_phenotype, item.gene.recessive_phenotype)


def format_value(value: Value, item: MonohybridTemplateSpec) -> str:
    """Render a key or distractor exactly as a learner would see it."""
    if isinstance(value, Fraction):
        if item.question.quantity == "expected_count":
            return str(int(value))
        return str(value)
    return " : ".join(f"{count} {label}" for label, count in value)


def _cross_variant(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> VariantResult:
    parent1, parent2 = parent_genotypes(item, values)
    genotypes = genotype_distribution(parent1, parent2)
    phenotypes = phenotype_distribution(parent1, parent2, item.gene)
    return VariantResult(
        parents={"parent1": parent1, "parent2": parent2},
        gametes={
            "parent1": {
                allele: str(value) for allele, value in gametes(parent1).items()
            },
            "parent2": {
                allele: str(value) for allele, value in gametes(parent2).items()
            },
        },
        punnett=punnett(parent1, parent2),
        genotype_distribution={token: str(value) for token, value in genotypes.items()},
        phenotype_distribution={word: str(value) for word, value in phenotypes.items()},
        key=format_value(compute_key(item, values), item),
        distractor_values=[],
    )


def assemble_variant(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> VariantResult:
    """The cross-aspect evidence for one combination, without options."""
    return _cross_variant(item, values)


def check_variant(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> VariantResult:
    """The full variant engine, including every distractor value."""
    from edcraft_validator.domains.biology.options import distractor_values

    variant = _cross_variant(item, values)
    values_list = distractor_values(item, values)
    return VariantResult(
        parents=variant.parents,
        gametes=variant.gametes,
        punnett=variant.punnett,
        genotype_distribution=variant.genotype_distribution,
        phenotype_distribution=variant.phenotype_distribution,
        key=variant.key,
        distractor_values=[format_value(value, item) for value in values_list],
    )
