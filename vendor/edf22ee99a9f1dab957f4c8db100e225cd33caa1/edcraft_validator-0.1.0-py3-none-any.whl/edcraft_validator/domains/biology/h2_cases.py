"""Verified classroom cases for the Singapore H2 Biology 9477 syllabus."""

from __future__ import annotations

import base64
import hashlib
import json
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, replace
from fractions import Fraction
from functools import cache
from importlib.resources import files
from itertools import product
from math import isqrt
from typing import Literal

from edcraft_validator.domains.biology.biology_schemas import (
    H2BiologyFigure,
    H2TemplateSpec,
)
from edcraft_validator.domains.biology.cross import BiologyCheckError

SYLLABUS_URL = (
    "https://isomer-user-content.by.gov.sg/334/"
    "3fed64fd-6bf8-4a8b-b81b-931f2f8ccf74/9477_y26_sy.pdf"
)
SUPERSEDED_H2_CASES = {
    "skill.cell.osmosis": "skill.cell.osmosis_gradient",
    "skill.practical.axes": "skill.practical.axes_convention",
    "skill.energy.chemiosmosis_compare": (
        "skill.energy.chemiosmosis_compartment_contrasts"
    ),
    "skill.energy.chemiosmosis_compartments": (
        "skill.energy.chemiosmosis_compartment_contrasts"
    ),
    "skill.energy.chemiosmosis_acidity": "skill.energy.chemiosmosis_acidity_contrasts",
}


FigureKind = Literal[
    "schematic",
    "light photomicrograph",
    "transmission electron micrograph",
    "scanning electron micrograph",
]


@dataclass(frozen=True)
class H2Case:
    id: str
    topic: str
    outcome: str
    question: str
    answer: str
    distractors: tuple[str, ...]
    explanation: str
    figure: H2BiologyFigure | None = None
    figure_kind: FigureKind | None = None

    def choice(self, slot: int) -> str:
        return (self.answer, *self.distractors)[slot]

    def learner_context(self) -> str:
        if self.figure is None:
            return self.question
        return f"{self.question}\nImage ({self.figure_kind}): {self.figure.alt}"


def independent_cross_probability(
    parent1: str,
    parent2: str,
    matches: Callable[[str], bool],
) -> Fraction:
    """Count all equally probable gamete draws for two unlinked autosomal loci."""

    def gametes(parent: str) -> list[tuple[str, str]]:
        return list(product(parent[:2], parent[2:]))

    cells = Counter(
        "".join(sorted((first_a, second_a)) + sorted((first_b, second_b)))
        for (first_a, first_b), (second_a, second_b) in product(
            gametes(parent1), gametes(parent2)
        )
    )
    return Fraction(
        sum(count for genotype, count in cells.items() if matches(genotype)),
        cells.total(),
    )


def _dihybrid_cases() -> tuple[H2Case, ...]:
    context = (
        "In a hypothetical plant, R gives red petals over white and T gives tall "
        "stems over short. The two autosomal loci assort independently, show "
        "complete dominance and have no interaction. "
    )
    return (
        H2Case(
            "dihybrid.self",
            "inheritance.dihybrid",
            "2(x)",
            context + "What fraction of the RrTt × RrTt offspring is red and tall?",
            str(
                independent_cross_probability(
                    "RrTt", "RrTt", lambda g: "R" in g and "T" in g
                )
            ),
            ("3/4", "1/4", "3/16", "7/16", "1/16", "1/2"),
            "Each dominant phenotype has probability 3/4. Independence gives 9/16.",
        ),
        H2Case(
            "dihybrid.test",
            "inheritance.dihybrid",
            "2(x), 2(y)",
            context + "What fraction of the RrTt × rrtt offspring is white and tall?",
            str(
                independent_cross_probability(
                    "RrTt", "rrtt", lambda g: g[:2] == "rr" and "T" in g
                )
            ),
            ("1/2", "3/4", "3/16", "1/16", "0", "1"),
            "White and tall each have probability 1/2. Independence gives 1/4.",
        ),
        H2Case(
            "dihybrid.genotype",
            "inheritance.dihybrid",
            "2(x)",
            context + "What fraction of the RrTT × rrTt offspring has genotype RrTt?",
            str(independent_cross_probability("RrTT", "rrTt", lambda g: g == "RrTt")),
            ("1/2", "1/8", "3/4", "3/16", "0", "1"),
            "The Rr and Tt genotypes each have probability 1/2 independently.",
        ),
    )


def _population_cases() -> tuple[H2Case, ...]:
    cases = []
    for case_id, recessive, distractors in (
        (
            "evolution.hwe_low",
            Fraction(9, 100),
            ("9%", "21%", "30%", "49%", "70%", "91%"),
        ),
        (
            "evolution.hwe_high",
            Fraction(36, 100),
            ("16%", "24%", "36%", "40%", "60%", "64%"),
        ),
    ):
        q = Fraction(isqrt(recessive.numerator), isqrt(recessive.denominator))
        p = 1 - q
        cases.append(
            H2Case(
                case_id,
                "evolution.hardy_weinberg",
                "4(m), 4(n)",
                "A large randomly mating population of a hypothetical plant is at "
                f"Hardy–Weinberg equilibrium for a locus with two alleles. "
                f"{int(recessive * 100)}% show the completely recessive phenotype. "
                "What percentage of the full population is heterozygous?",
                f"{int(200 * p * q)}%",
                distractors,
                f"The recessive frequency is q², giving q = {q} and p = {p}. "
                f"The heterozygote frequency is 2pq = {2 * p * q}.",
            )
        )
    return tuple(cases)


def _pearson_terms(
    observed: tuple[int, ...], expected: tuple[int, ...]
) -> tuple[Fraction, ...]:
    return tuple(
        Fraction((o - e) ** 2, e) for o, e in zip(observed, expected, strict=True)
    )


def _chi_square_case(
    case: H2Case, observed: tuple[int, ...], expected: tuple[int, ...]
) -> H2Case:
    statistic = sum(_pearson_terms(observed, expected))
    reject = statistic > Fraction(599, 100)
    decision = "reject" if reject else "fail to reject"
    answer = f"χ² = {float(statistic):.2f}, so {decision} the model."
    return replace(case, answer=answer)


def _chi_square_statistic_case(
    suffix: str, observed: tuple[int, ...], expected: tuple[int, ...]
) -> H2Case:
    critical = Fraction("5.99")
    terms = _pearson_terms(observed, expected)
    statistic = sum(terms, Fraction(0))

    def option(value: Fraction, *, reverse: bool = False) -> str:
        reject = (value > critical) != reverse
        decision = "reject" if reject else "fail to reject"
        return f"χ² = {float(value):.2f}, so {decision} the model."

    expected_text = ", ".join(map(str, expected))
    observed_text = ", ".join(map(str, observed))
    contributions = " + ".join(map(str, terms))
    key = option(statistic)
    deviations = tuple(o - e for o, e in zip(observed, expected, strict=True))
    return H2Case(
        f"genetics.chi_statistic_{suffix}",
        "inheritance.chi_square",
        "2(dd)",
        "A breeder samples independent offspring of a fictional plant cross. "
        "In red, pink and white order, the inheritance model predicts expected "
        f"counts of {expected_text}. The observed counts are {observed_text}. "
        "The 5% critical chi-squared value is 5.99. Calculate and report the "
        "chi-squared statistic to two decimal places and decide whether to reject "
        "the model at 5%. Use the unrounded statistic for the decision.",
        key,
        (
            option(sum(_pearson_terms(expected, observed), Fraction(0))),
            option(statistic, reverse=True),
            option(statistic - terms[1]),
            option(Fraction(sum(deviations) ** 2, sum(expected))),
            option(max(terms)),
            option(Fraction(sum(map(abs, deviations)))),
        ),
        f"The three (O − E)²/E contributions sum to {contributions} = {statistic}. "
        f"This is {'above' if statistic > critical else 'below'} 5.99. {key}",
    )


@dataclass(frozen=True)
class GroupedChiSquareCase:
    suffix: str
    phenotype_rule: str
    # Display labels for A_B_, A_bb, aaB_ and aabb in that order.
    phenotype_by_class: tuple[str, str, str, str]
    observed: tuple[int, int, int]
    wrong_expected: tuple[int, int, int]
    wrong_df: int

    def variants(self) -> tuple[H2Case, H2Case]:
        phenotype_by_class = dict(
            zip(product((True, False), repeat=2), self.phenotype_by_class, strict=True)
        )
        labels = tuple(dict.fromkeys(self.phenotype_by_class))
        total = sum(self.observed)

        def expected_count(label: str) -> Fraction:
            return total * independent_cross_probability(
                "AaBb",
                "AaBb",
                lambda g: phenotype_by_class["A" in g, "B" in g] == label,
            )

        expected = tuple(map(expected_count, labels))
        df = len(labels) - 1
        critical_values = (Fraction("3.84"), Fraction("5.99"), Fraction("7.81"))
        critical = critical_values[df - 1]
        statistic = sum(
            Fraction(o - e) ** 2 / e
            for o, e in zip(self.observed, expected, strict=True)
        )
        reject = "Reject the model."
        retain = "Fail to reject the model."
        decision, opposite = (
            (reject, retain) if statistic > critical else (retain, reject)
        )

        def option(
            counts: tuple[int, ...] | tuple[Fraction, ...],
            degrees: int,
            conclusion: str,
        ) -> str:
            count_text = ", ".join(map(str, counts))
            return f"Expected counts {count_text}. df = {degrees}. {conclusion}"

        context = (
            "In a fictional plant, independently assorting loci A/a and B/b show "
            "complete dominance. The proposed model applies to an AaBb × AaBb cross. "
            + self.phenotype_rule
        )
        observed = ", ".join(
            f"{o} {label}" for label, o in zip(labels, self.observed, strict=True)
        )
        statistic_text = f"χ² = {float(statistic):.2f}"
        critical_text = f"{float(critical):.2f}"
        hard = H2Case(
            f"genetics.chi_model_{self.suffix}",
            "inheritance.chi_square",
            "2(x), 2(dd)",
            context + f" The independently sampled offspring were {observed}. "
            "No proportions were fitted from these data. For df = 1, 2 and 3, "
            "the respective 5% critical values are 3.84, 5.99 and 7.81. "
            "Which expected counts (in the stated phenotype order), degrees of "
            "freedom and chi-squared test decision are correct?",
            option(expected, df, decision),
            (
                option(self.wrong_expected, df, decision),
                option(expected, self.wrong_df, decision),
                option(expected, df, opposite),
                option(self.wrong_expected, self.wrong_df, opposite),
                option(self.wrong_expected, df, opposite),
                option(expected, self.wrong_df, opposite),
            ),
            "The four two-locus dominance classes occur in a 9 : 3 : 3 : 1 ratio. "
            "In that class order, the model gives "
            + ", ".join(self.phenotype_by_class)
            + ". Grouping matching phenotypes and multiplying by the sample size gives "
            + ", ".join(map(str, expected))
            + ". "
            f"The three observed phenotype classes give df = {df} because no "
            f"parameters were fitted. The sum of (O − E)²/E gives {statistic_text}, "
            f"{'above' if decision == reject else 'below'} {critical_text}. {decision}",
        )
        significant = "The discrepancies are statistically significant at 5%."
        insufficient = "The evidence is insufficient to reject it at 5%."
        evidence, opposite_evidence = (
            (significant, insufficient)
            if decision == reject
            else (insufficient, significant)
        )
        wrong_interpretation = (
            "The test identifies the true alternative inheritance model."
            if decision == reject
            else "The test proves the model is true."
        )
        easy = H2Case(
            f"genetics.chi_interpret_{self.suffix}",
            "inheritance.chi_square",
            "2(dd)",
            "A student uses a chi-squared goodness-of-fit test for the offspring "
            f"phenotypes in a fictional plant cross and obtains {statistic_text}. "
            f"The 5% critical value is {critical_text}. "
            "Which conclusion and interpretation follow?",
            f"{decision} {evidence}",
            (
                f"{opposite} {opposite_evidence}",
                f"{decision} {wrong_interpretation}",
                f"{decision} The probability that the model is false is 5%.",
                f"{opposite} {wrong_interpretation}",
                f"{decision} Every observed count must equal its expected count.",
                f"{opposite} The probability that the model is true is 5%.",
            ),
            f"{statistic_text} is {'above' if decision == reject else 'below'} "
            f"the 5% critical value {critical_text}. {decision} {evidence} "
            "The calculation does not establish whether the proposed model is true "
            "or identify an alternative model.",
        )
        return hard, easy


def _numeric_cases() -> tuple[H2Case, ...]:
    petals = GroupedChiSquareCase(
        "petal",
        "A dominant A allele is required to produce pigment. In pigmented plants "
        "a dominant B allele makes petals violet and bb plants have red petals. "
        "Plants without pigment have white petals.",
        ("violet", "red", "white", "white"),
        (75, 33, 52),
        (90, 40, 30),
        3,
    )
    leaves = GroupedChiSquareCase(
        "leaf",
        "Plants with a dominant allele at both loci have striped leaves. Plants "
        "with a dominant allele at exactly one locus have dark leaves. Plants "
        "homozygous recessive at both loci have pale leaves.",
        ("striped", "dark", "dark", "pale"),
        (80, 64, 16),
        (90, 30, 40),
        1,
    )
    return (
        *_dihybrid_cases(),
        *_population_cases(),
        *petals.variants(),
        *leaves.variants(),
        _chi_square_statistic_case("below", (33, 74, 53), (40, 80, 40)),
        _chi_square_statistic_case("above", (29, 38, 33), (25, 50, 25)),
    )


_CHEMIOSMOSIS_LABELS = (
    "Thylakoid H⁺ accumulation",
    "Thylakoid ATP destination",
    "Mitochondrial H⁺ accumulation",
    "Mitochondrial ATP destination",
)
_CHEMIOSMOSIS_ORDERS = {
    # Each initial pair covers both organelles and both processes. Rotate
    # the omitted contrast between variants when three slots are requested.
    "skill.energy.chemiosmosis_compartment_contrasts": (0, 3, 2, 1),
    "skill.energy.chemiosmosis_acidity_contrasts": (2, 1, 0, 3),
}
CHEMIOSMOSIS_CONTRASTS = {
    case_id: tuple(_CHEMIOSMOSIS_LABELS[index] for index in order)
    for case_id, order in _CHEMIOSMOSIS_ORDERS.items()
}


def _chemiosmosis_cases() -> tuple[H2Case, ...]:
    questions = {
        "skill.energy.chemiosmosis_compartment_contrasts": (
            "Compare the thylakoid membrane of an illuminated chloroplast and "
            "the inner membrane of a respiring mitochondrion. "
            "For each organelle, identify the compartment where protons accumulate "
            "and the compartment that first receives ATP made by ATP synthase."
        ),
        "skill.energy.chemiosmosis_acidity_contrasts": (
            "An illuminated chloroplast and a respiring mitochondrion both "
            "maintain proton gradients across the thylakoid and inner "
            "mitochondrial membranes, respectively. "
            "For each membrane, identify the more acidic compartment, where "
            "protons accumulate, and the compartment that receives newly made ATP."
        ),
    }
    correct = ("lumen", "stroma", "intermembrane space", "matrix")
    alternatives = (
        "chloroplast intermembrane space",
        "lumen",
        "cytosol",
        "intermembrane space",
    )

    def option(sides: tuple[str, ...]) -> str:
        assignments = [
            f"{label} = {side}"
            for label, side in zip(_CHEMIOSMOSIS_LABELS, sides, strict=True)
        ]
        return ". ".join(assignments) + "."

    def single_contrast(index: int) -> str:
        return option((*correct[:index], alternatives[index], *correct[index + 1 :]))

    return tuple(
        H2Case(
            case_id,
            "energy.respiration",
            "3(l)",
            questions[case_id],
            option(correct),
            (
                *(single_contrast(index) for index in order),
                option(("stroma", "lumen", *correct[2:])),
                option((*correct[:2], "matrix", "intermembrane space")),
            ),
            "Protons accumulate in the thylakoid lumen and the mitochondrial "
            "intermembrane space. They flow down their electrochemical gradients "
            "through ATP synthase towards the stroma and matrix, respectively. "
            "ATP synthase releases ATP on those receiving sides.",
        )
        for case_id, order in _CHEMIOSMOSIS_ORDERS.items()
    )


def _packaged_figures() -> dict[str, tuple[H2BiologyFigure, FigureKind]]:
    resource = files("edcraft_validator.domains.biology").joinpath("h2_figures")
    figures = {}
    for case_id, item in json.loads(
        resource.joinpath("cases.json").read_text()
    ).items():
        data = resource.joinpath(item["file"]).read_bytes()
        if not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError(f"Invalid PNG for H2 case {case_id!r}")
        encoded = base64.b64encode(data).decode("ascii")
        figures[case_id] = (
            H2BiologyFigure(
                data_url=f"data:image/png;base64,{encoded}",
                alt=item["alt"],
                credit=item["credit"],
            ),
            item["kind"],
        )
    return figures


@cache
def h2_catalogue(*, include_archived: bool = False) -> dict[str, H2Case]:
    """Load current cases and, for checked artifact replay, archived copies."""
    resource = files("edcraft_validator.domains.biology")
    figures = _packaged_figures()
    rows = [*_numeric_cases(), *_chemiosmosis_cases()]
    archived = set()
    archive_filename = "h2_archived_cases.json"
    for filename in ("h2_cases.json", "h2_skill_cases.json", archive_filename):
        for row in json.loads(resource.joinpath(filename).read_text(encoding="utf-8")):
            case_id, topic, outcome, question, answer, distractors, explanation = row
            if filename == archive_filename:
                archived.add(case_id)
            figure = figures.pop(case_id, (None, None))
            case = H2Case(
                case_id,
                topic,
                outcome,
                question,
                answer,
                tuple(distractors),
                explanation,
                *figure,
            )
            if case_id == "genetics.chi_square":
                case = _chi_square_case(case, (20, 45, 35), (25, 50, 25))
            if case_id == "genetics.chi_square_reject":
                case = _chi_square_case(case, (15, 50, 35), (25, 50, 25))
            rows.append(case)
    if figures:
        raise ValueError("H2 catalogue contains figures without matching case IDs")

    cases = {row.id: row for row in rows}
    if len(cases) != len(rows):
        raise ValueError("H2 catalogue contains duplicate case IDs")
    for case in cases.values():
        options = (case.answer, *case.distractors)
        if (
            len(options) != 7
            or any(not option.strip() for option in options)
            or len({option.strip() for option in options}) != 7
        ):
            raise ValueError(f"H2 catalogue case {case.id!r} has invalid options")
    if include_archived:
        return cases
    return {case_id: case for case_id, case in cases.items() if case_id not in archived}


def cases_sha256(cases: tuple[H2Case, ...]) -> str:
    records = []
    for case in cases:
        record = dict(vars(case))
        figure = record.pop("figure")
        # This kind classifies offers. The existing artifact digest binds the
        # unchanged learner-visible image object itself.
        record.pop("figure_kind")
        if figure is not None:
            record["figure"] = figure.model_dump(mode="json")
        records.append(record)
    canonical = json.dumps(records, sort_keys=True).encode()
    return hashlib.sha256(canonical).hexdigest()


def resolve_h2_cases(
    item: H2TemplateSpec, *, require_digest: bool = True
) -> tuple[H2Case, ...]:
    catalogue = h2_catalogue(include_archived=require_digest)
    unknown = [case_id for case_id in item.cases if case_id not in catalogue]
    if unknown:
        raise BiologyCheckError(
            "UNSUPPORTED_BIOLOGY_CASE", f"Unknown H2 cases: {', '.join(unknown)}"
        )
    cases = tuple(catalogue[case_id] for case_id in item.cases)
    if len({case.topic for case in cases}) != 1:
        raise BiologyCheckError(
            "MIXED_BIOLOGY_TOPICS", "Choose cases within a single H2 topic"
        )
    if require_digest and item.catalogue_sha256 != cases_sha256(cases):
        raise BiologyCheckError(
            "BIOLOGY_CATALOGUE_MISMATCH",
            "The H2 catalogue no longer matches the version used for checking",
        )
    return cases
