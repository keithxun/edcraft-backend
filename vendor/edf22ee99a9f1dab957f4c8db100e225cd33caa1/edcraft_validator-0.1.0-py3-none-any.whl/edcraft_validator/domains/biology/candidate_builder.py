"""Build a biology candidate with one fixed subset of proposed distractors."""

from __future__ import annotations

from edcraft_validator.domains.biology.biology_schemas import (
    BiologyTemplateCandidate,
    BiologyTemplateContent,
    BiologyTemplateRequest,
    DistractorSpec,
    H2TemplateSpec,
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.cross import (
    BiologyCheckError,
    compute_key,
    format_value,
    parse_answer,
)
from edcraft_validator.domains.biology.fit_schema import GoodnessOfFitTemplate
from edcraft_validator.domains.biology.goodness_of_fit import choose_fit_distractors
from edcraft_validator.domains.biology.h2_authoring import select_h2_distractors
from edcraft_validator.domains.biology.options import (
    check_applicability,
    distractor_value,
    validate_option_value,
)
from edcraft_validator.domains.domain_support import (
    build_template_id,
    content_sha256,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import PropertyCheckSettings


def build_biology_candidate(
    request: BiologyTemplateRequest, proposal: BiologyTemplateContent
) -> BiologyTemplateCandidate:
    """Freeze the selected recipes before the authoritative checks run."""
    item = proposal.item
    pool_size = request.num_distractors + SURPLUS_RECIPES
    if len(item.distractors) != pool_size:
        raise DistractorPoolError(
            f"Provide exactly {pool_size} candidate distractor recipes, "
            f"but the proposal contains {len(item.distractors)}."
        )
    if isinstance(item, H2TemplateSpec):
        item = select_h2_distractors(item, request.num_distractors)
    elif isinstance(item, GoodnessOfFitTemplate):
        item = item.model_copy(
            update={
                "distractors": choose_fit_distractors(item, request.num_distractors)
            }
        )
    else:
        _check_pool_structure(item)
        selected = _select_options(item, request.num_distractors)
        item = item.model_copy(update={"distractors": selected})
    selected_proposal = proposal.model_copy(update={"item": item})

    return BiologyTemplateCandidate(
        template_id=build_template_id("biology", request, selected_proposal),
        difficulty=request.difficulty,
        item=item,
        question_type="mcq",
    )


def _check_pool_structure(item: MonohybridTemplateSpec) -> None:
    findings = check_applicability(item)
    if findings:
        first = findings[0]
        raise DistractorPoolError(f"{first.code}: {first.message}")
    for index, recipe in enumerate(item.distractors, start=1):
        if recipe.value is not None:
            try:
                parse_answer(recipe.value, item)
            except ValueError as exc:
                raise DistractorPoolError(
                    f"MALFORMED_ANSWER in candidate recipe {index}: {exc}"
                ) from None


def _select_options(
    item: MonohybridTemplateSpec, required: int
) -> list[DistractorSpec]:
    axes = {parameter.name: parameter.values for parameter in item.parameters}
    settings = PropertyCheckSettings()
    claimed = [
        example.parameters
        for example in item.answer_recipe.claimed_examples
        if example.parameters.keys() == axes.keys()
        and all(value in axes[name] for name, value in example.parameters.items())
    ]
    draws = sample_assignments(axes, budget=settings.max_examples, seed=settings.seed)
    unique = {
        tuple(values[name] for name in axes): values for values in [*claimed, *draws]
    }
    assignments = list(unique.values())[: settings.max_examples]
    rows = []
    for values in assignments:
        try:
            key = compute_key(item, values)
        except BiologyCheckError as exc:
            raise DistractorPoolError(
                f"{exc.code} at {values!r}: {exc.message}"
            ) from None
        options = [
            _evaluate_option(item, values, recipe) for recipe in item.distractors
        ]
        rows.append((OptionValue(key, format_value(key, item)), options))
    indexes = select_fixed_subset(rows, required, assignments=assignments)
    return [item.distractors[index] for index in indexes]


def _evaluate_option(
    item: MonohybridTemplateSpec, values: dict[str, str], recipe: DistractorSpec
) -> OptionValue | UnusableOption:
    try:
        value = distractor_value(item, values, recipe)
        validate_option_value(value, item.question.quantity)
    except BiologyCheckError as exc:
        return UnusableOption(f"{exc.code}: {exc.message}")
    return OptionValue(value, format_value(value, item))


def template_sha256(candidate: BiologyTemplateCandidate) -> str:
    """Identify the exact reusable content independently of any assessment."""
    return content_sha256(candidate)
