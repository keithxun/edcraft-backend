"""Distractor rules for monohybrid biology questions.

Each rule recomputes the key under a changed model of the problem. Applicability
is structural: it depends on the template shape, not on one combination's values.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Literal

from edcraft_validator.domains.biology.biology_schemas import (
    DistractorSpec,
    MonohybridTemplateSpec,
)
from edcraft_validator.domains.biology.cross import (
    BiologyCheckError,
    Finding,
    PhenotypeModel,
    Value,
    compute_key,
    conditional_probability,
    format_value,
    genotype_distribution,
    given_event,
    integer_counts,
    offspring_count,
    parent_genotypes,
    parse_answer,
    parse_genotype,
    phenotype_distribution,
    phenotype_of,
    reduce_ratio,
    target_event,
)

Quantity = Literal["probability", "expected_count", "ratio"]


def is_applicable(rule: str, item: MonohybridTemplateSpec) -> bool:
    """Whether a rule can produce a meaningful distractor for this template."""
    question = item.question
    given_set = question.given is not None
    target_kind = question.target.kind if question.target is not None else None

    if rule in ("unconditioned", "reverse_condition"):
        return given_set
    if rule in ("forget_heterozygote", "swap_dominance"):
        return target_kind == "phenotype" or given_set
    if rule == "phenotype_for_genotype":
        return target_kind == "genotype"
    if rule in ("uniform_genotype_classes", "complement"):
        return question.quantity in ("probability", "expected_count")
    if rule == "genotype_ratio_for_phenotype":
        return question.quantity == "ratio" and question.ratio_kind == "phenotype"
    if rule == "phenotype_ratio_for_genotype":
        return question.quantity == "ratio" and question.ratio_kind == "genotype"
    return rule == "fixed_value"


def check_applicability(item: MonohybridTemplateSpec) -> list[Finding]:
    """Report missing options and every structurally inapplicable rule."""
    findings: list[Finding] = []
    if not item.distractors:
        findings.append(Finding("NO_OPTIONS", "the template declares no distractors"))
        return findings
    for index, distractor in enumerate(item.distractors):
        if not is_applicable(distractor.rule, item):
            findings.append(
                Finding(
                    "INAPPLICABLE_DISTRACTOR_RULE",
                    f"distractor {index} rule {distractor.rule!r} does not apply "
                    f"to a {item.question.quantity} question",
                )
            )
    return findings


def _uniform_distribution(
    distribution: dict[str, Fraction],
) -> dict[str, Fraction]:
    present = [genotype for genotype, value in distribution.items() if value > 0]
    share = Fraction(1, len(present))
    return {
        genotype: share if genotype in present else Fraction(0)
        for genotype in distribution
    }


def _distribution(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> dict[str, Fraction]:
    return genotype_distribution(*parent_genotypes(item, values))


def _as_quantity(
    item: MonohybridTemplateSpec, values: dict[str, str], probability: Fraction
) -> Fraction:
    """A probability rule's value, scaled to N offspring for count questions."""
    if item.question.quantity == "probability":
        return probability
    count = probability * offspring_count(item, values)
    if count.denominator != 1:
        raise BiologyCheckError(
            "DISTRACTOR_NOT_INTEGER",
            f"the distractor count {count} is not a whole number",
        )
    return count


def _probability_under(
    item: MonohybridTemplateSpec,
    values: dict[str, str],
    distribution: dict[str, Fraction],
    model: PhenotypeModel = "complete",
    *,
    conditioned: bool = True,
) -> Fraction:
    """P(target [| given]) for a changed distribution or phenotype model."""
    given = given_event(item, distribution, model) if conditioned else None
    return conditional_probability(
        distribution,
        target_event(item, values, distribution, model),
        given,
        zero_condition_code="DISTRACTOR_UNDEFINED",
    )


def _reverse_condition(item: MonohybridTemplateSpec, values: dict[str, str]) -> Value:
    distribution = _distribution(item, values)
    target = target_event(item, values, distribution, "complete")
    given = given_event(item, distribution, "complete")
    assert given is not None
    target_probability = sum((distribution[g] for g in target), Fraction(0))
    if target_probability == 0:
        raise BiologyCheckError(
            "DISTRACTOR_UNDEFINED",
            "the target event has probability zero, so the reverse "
            "condition is undefined",
        )
    joint = sum((distribution[g] for g in target & given), Fraction(0))
    return _as_quantity(item, values, joint / target_probability)


def _phenotype_for_genotype(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> Value:
    target = item.question.target
    assert target is not None
    phenotype = phenotype_of(parse_genotype(values[target.param], item.gene.symbol))
    distribution = _distribution(item, values)
    event = {
        genotype for genotype in distribution if phenotype_of(genotype) == phenotype
    }
    probability = conditional_probability(
        distribution,
        event,
        given_event(item, distribution, "complete"),
        zero_condition_code="DISTRACTOR_UNDEFINED",
    )
    return _as_quantity(item, values, probability)


def _complement(item: MonohybridTemplateSpec, values: dict[str, str]) -> Value:
    key = compute_key(item, values)
    if not isinstance(key, Fraction):
        raise BiologyCheckError(
            "INAPPLICABLE_DISTRACTOR_RULE", "complement needs a numeric key"
        )
    if item.question.quantity == "probability":
        return Fraction(1) - key
    return Fraction(offspring_count(item, values)) - key


def _ratio_for_other_kind(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> Value:
    parent1, parent2 = parent_genotypes(item, values)
    if item.question.ratio_kind == "phenotype":
        distribution = genotype_distribution(parent1, parent2)
    else:
        distribution = phenotype_distribution(parent1, parent2, item.gene)
    return reduce_ratio(list(integer_counts(distribution).items()))


def distractor_value(
    item: MonohybridTemplateSpec,
    values: dict[str, str],
    distractor: DistractorSpec,
) -> Value:
    """Compute one rule's value for one combination."""
    if not is_applicable(distractor.rule, item):
        raise BiologyCheckError(
            "INAPPLICABLE_DISTRACTOR_RULE",
            f"rule {distractor.rule!r} does not apply to a "
            f"{item.question.quantity} question",
        )

    rule = distractor.rule
    if rule == "unconditioned":
        probability = _probability_under(
            item, values, _distribution(item, values), conditioned=False
        )
        return _as_quantity(item, values, probability)
    if rule == "reverse_condition":
        return _reverse_condition(item, values)
    if rule in ("forget_heterozygote", "swap_dominance"):
        probability = _probability_under(
            item, values, _distribution(item, values), rule
        )
        return _as_quantity(item, values, probability)
    if rule == "phenotype_for_genotype":
        return _phenotype_for_genotype(item, values)
    if rule == "uniform_genotype_classes":
        uniform = _uniform_distribution(_distribution(item, values))
        return _as_quantity(item, values, _probability_under(item, values, uniform))
    if rule == "complement":
        return _complement(item, values)
    if rule in ("genotype_ratio_for_phenotype", "phenotype_ratio_for_genotype"):
        return _ratio_for_other_kind(item, values)
    return parse_answer(distractor.value or "", item)


def validate_option_value(value: Value, quantity: Quantity) -> None:
    """Reject a probability outside [0, 1] or a count that is not a count."""
    if quantity == "probability":
        if isinstance(value, bool) or not isinstance(value, (int, Fraction)):
            raise BiologyCheckError(
                "DISTRACTOR_OUT_OF_RANGE",
                f"probability distractor {value!r} is not in [0, 1]",
            )
        if not Fraction(0) <= Fraction(value) <= Fraction(1):
            raise BiologyCheckError(
                "DISTRACTOR_OUT_OF_RANGE",
                f"probability distractor {value!r} is not in [0, 1]",
            )
    elif quantity == "expected_count":
        if isinstance(value, bool) or not isinstance(value, (int, Fraction)):
            raise BiologyCheckError(
                "DISTRACTOR_NOT_INTEGER",
                f"count distractor {value!r} is not an integer",
            )
        count = Fraction(value)
        if count.denominator != 1:
            raise BiologyCheckError(
                "DISTRACTOR_NOT_INTEGER",
                f"count distractor {value!r} is not an integer",
            )
        if count < 0:
            raise BiologyCheckError(
                "DISTRACTOR_OUT_OF_RANGE",
                f"count distractor {value} is negative",
            )


def distractor_values(
    item: MonohybridTemplateSpec, values: dict[str, str]
) -> list[Value]:
    """Every distractor's exact value, without distinctness validation."""
    return [
        distractor_value(item, values, distractor) for distractor in item.distractors
    ]


def check_options(item: MonohybridTemplateSpec, values: dict[str, str]) -> list[Value]:
    """Validate every distractor for one combination and return their values."""
    findings = check_applicability(item)
    if findings:
        raise BiologyCheckError(findings[0].code, findings[0].message)

    key = compute_key(item, values)
    computed: list[Value] = []
    for index, distractor in enumerate(item.distractors):
        value = distractor_value(item, values, distractor)
        validate_option_value(value, item.question.quantity)
        if value == key:
            raise BiologyCheckError(
                "DISTRACTOR_EQUALS_KEY",
                f"distractor {index} rule {distractor.rule!r} reproduces the key "
                f"({format_value(value, item)})",
            )
        computed.append(value)

    for left in range(len(computed)):
        for right in range(left + 1, len(computed)):
            if computed[left] == computed[right]:
                raise BiologyCheckError(
                    "DISTRACTORS_NOT_DISTINCT",
                    f"distractors {left} and {right} both equal "
                    f"{format_value(computed[left], item)}",
                )
    return computed
