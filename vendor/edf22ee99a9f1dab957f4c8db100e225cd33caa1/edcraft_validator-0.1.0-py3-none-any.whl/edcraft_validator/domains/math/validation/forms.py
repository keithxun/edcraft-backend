"""Goal-form registry for authored answer recipes.

Form is deliberately separate from correctness: the deterministic engine decides
whether an answer is mathematically right, while this registry decides whether
it has the shape the goal's notation demands -- a fully expanded polynomial, a
product of irreducible factors, a solution set, a finite scalar determinant,
and so on.

Every malformed answer becomes a :class:`FormResult`; a genuine bug still
raises so tests can see it. SymPy inspection of the compiled answer happens
only here; the registry selects a rule from the goal kind but never decides
truth, so notation and correctness stay independent verdicts.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from fractions import Fraction
from typing import Literal

import sympy
from sympy.parsing.sympy_parser import (
    convert_xor,
    parse_expr,
    standard_transformations,
)

from edcraft_validator.domains.math.ir.compile import build_symbols
from edcraft_validator.domains.math.ir.instantiate import (
    render_expr,
    render_goal_display,
)
from edcraft_validator.domains.math.ir.schema import (
    AnswerKind,
    AnswerRecipe,
    GoalKind,
    MathItemSpec,
)
from edcraft_validator.domains.math.validation.answers import compile_answer_recipe

FormStatus = Literal["pass", "fail", "unsupported"]

_EXPRESSION_ANSWER_KINDS = frozenset({"numeric", "expression"})
_SET_TUPLE_ANSWER_KINDS = frozenset({"set", "tuple"})


_PARSE_RULES = (*standard_transformations, convert_xor)


@dataclass(frozen=True)
class FormResult:
    status: FormStatus
    reason: str = ""


FormRule = Callable[
    [MathItemSpec, AnswerRecipe, Mapping[str, Fraction] | None],
    FormResult,
]


def check_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None = None,
) -> FormResult:
    """Check the answer's form for the item's goal; malformed answers fail."""
    if answer.kind in {"interval", "boolean"}:
        return FormResult("unsupported", f"no form rule for {answer.kind} answers")
    rule = _FORM_RULES.get(item.goal.kind)
    if rule is None:
        return FormResult("unsupported", f"no form rule for {item.goal.kind!r} goals")
    return rule(item, answer, params)


# ---------------------------------------------------------------------------
# Shared helpers


def _compile_answer(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> tuple[object, None] | tuple[None, FormResult]:
    """Compile the recipe; any refusal becomes a ``fail`` result, never a raise."""
    try:
        return compile_answer_recipe(answer, item.symbols, params), None
    except (TypeError, ValueError) as exc:
        # An uncompilable answer has the wrong form; unexpected exceptions are
        # bugs and must surface in tests instead of becoming a form verdict.
        return None, FormResult("fail", f"answer does not compile: {exc}")


def _single_expression(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
    goal: str,
    *,
    non_expression: FormStatus,
) -> tuple[sympy.Expr, None] | tuple[None, FormResult]:
    """Require one compiled expression answer; non-expression kinds are refused."""
    if answer.kind not in _EXPRESSION_ANSWER_KINDS:
        return None, FormResult(
            non_expression, f"{goal} form applies to expression answers only"
        )

    compiled, failure = _compile_answer(item, answer, params)
    if failure is not None:
        return None, failure
    if not isinstance(compiled, sympy.Expr):
        return None, FormResult("fail", f"{goal} answers must be a single expression")
    return compiled, None


def _declared_poly(
    expr: sympy.Expr,
    item: MathItemSpec,
) -> tuple[sympy.Poly, None] | tuple[None, FormResult]:
    """Return the polynomial over the item's declared symbols, or a failure."""
    declared = list(build_symbols(item.symbols).values())
    undeclared = sorted(str(symbol) for symbol in expr.free_symbols - set(declared))
    if undeclared:
        return None, FormResult(
            "fail", "answer uses undeclared symbols: " + ", ".join(undeclared)
        )

    try:
        return sympy.Poly(expr, *declared), None
    except (sympy.PolynomialError, TypeError, ValueError) as exc:
        return None, FormResult(
            "fail", f"answer is not a polynomial in the declared symbols: {exc}"
        )


def _has_unexpanded_sum_power(expr: sympy.Expr) -> bool:
    """Whether some integer power of a sum still waits to be multiplied out."""
    for power in expr.atoms(sympy.Pow):
        exponent = power.exp
        if power.base.is_Add and exponent.is_Integer and exponent >= 2:
            return True
    return False


def _has_primitive_content(poly: sympy.Poly) -> bool:
    """Whether the polynomial has no common integer factor after clearing denominators.

    SymPy stores a rational coefficient inside one additive factor, so
    ``(x + 1/2)*(x + 2)`` and ``2*(x - 2)*(x + 2)`` both keep their numeric
    content within a linear factor.  Clearing denominators distinguishes a
    genuine common factor such as ``2*x + 2`` from a rational scale such as
    ``x + 1/2``.
    """
    _denominator, integer_poly = poly.clear_denoms(convert=True)
    return abs(integer_poly.content()) == 1


# ---------------------------------------------------------------------------
# Per-goal form rules


def _expanded_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    compiled, failure = _single_expression(
        item, answer, params, "expand", non_expression="fail"
    )
    if failure is not None:
        return failure
    _poly, failure = _declared_poly(compiled, item)
    if failure is not None:
        return failure

    if sympy.expand(compiled) != compiled:
        return FormResult("fail", "answer is not fully expanded")
    if _has_unexpanded_sum_power(compiled):
        return FormResult("fail", "answer contains an unexpanded power of a sum")
    return FormResult("pass")


def _factored_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    compiled, failure = _single_expression(
        item, answer, params, "factor", non_expression="fail"
    )
    if failure is not None:
        return failure
    poly, failure = _declared_poly(compiled, item)
    if failure is not None:
        return failure

    # A sum is already factored only when it is irreducible and no common
    # numeric factor remains.  A linear sum with a rational coefficient, such
    # as x + 1/2, is accepted because its cleared integer form is primitive.
    if isinstance(compiled, sympy.Add) and sympy.factor(compiled) != compiled:
        if poly.total_degree() != 1 or not _has_primitive_content(poly):
            return FormResult("fail", "answer is not factored")

    # SymPy distributes a leading number into one factor, so 2*(x + 1)*(x + 3)
    # arrives as (2*x + 2)*(x + 3). One factor may therefore carry numeric
    # content. Content in two or more factors, such as (2*x + 4)*(2*x - 6),
    # means a common factor was left inside the product.
    factors_with_content = 0
    seen_bases: set[sympy.Expr] = set()
    for factor in sympy.Mul.make_args(compiled):
        base, exponent = factor.as_base_exp()
        if base.is_number:
            continue
        if exponent.is_Integer is not True or exponent < 1:
            return FormResult("fail", f"factor {factor} is not a polynomial")
        try:
            base_poly = sympy.Poly(base, *poly.gens)
        except (sympy.PolynomialError, TypeError, ValueError) as exc:
            return FormResult("fail", f"factor {base} is not a polynomial: {exc}")
        if base_poly.total_degree() >= 2 and base_poly.is_irreducible is not True:
            return FormResult("fail", f"factor {base} is reducible")
        if not _has_primitive_content(base_poly):
            factors_with_content += int(exponent)
        # (x + 1)*(2*x + 2) is 2*(x + 1)**2: the same factor written twice.
        primitive = base_poly.primitive()[1].monic().as_expr()
        if primitive in seen_bases:
            return FormResult("fail", f"factor {base} repeats another factor")
        seen_bases.add(primitive)
    if factors_with_content > 1:
        return FormResult(
            "fail", "answer leaves a common numeric factor inside the product"
        )
    return FormResult("pass")


def _operator_free_form(
    unevaluated: type[sympy.Basic],
    description: str,
) -> FormRule:
    """Build a calculus form rule: a plain expression without the operator."""

    def rule(
        item: MathItemSpec,
        answer: AnswerRecipe,
        params: Mapping[str, Fraction] | None,
    ) -> FormResult:
        compiled, failure = _single_expression(
            item,
            answer,
            params,
            item.goal.kind,
            non_expression="unsupported",
        )
        if failure is not None:
            return failure
        if compiled.has(unevaluated):
            return FormResult("fail", f"answer contains an unevaluated {description}")
        return FormResult("pass")

    return rule


def _solution_set_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    _compiled, failure = _compile_answer(item, answer, params)
    if failure is not None:
        return failure

    targets = item.goal.symbols or (
        [item.goal.symbol] if item.goal.symbol is not None else []
    )
    expected: AnswerKind = "set" if len(targets) == 1 else "tuple"
    if answer.kind not in _SET_TUPLE_ANSWER_KINDS:
        return FormResult(
            "fail", f"a {len(targets)}-unknown solve requires an answer {expected}"
        )
    if answer.kind != expected:
        return FormResult(
            "fail",
            f"a {len(targets)}-unknown solve requires a {expected} answer, "
            f"not a {answer.kind}",
        )

    return FormResult("pass")


def _determinant_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    compiled, failure = _single_expression(
        item, answer, params, "determinant", non_expression="fail"
    )
    if failure is not None:
        return failure

    if not compiled.is_number:
        return FormResult("fail", "determinant answers must be a numeric scalar")
    if compiled.is_finite is not True:
        return FormResult("fail", "determinant answers must be finite")
    return FormResult("pass")


def _expression_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    _compiled, failure = _single_expression(
        item, answer, params, item.goal.kind, non_expression="fail"
    )
    if failure is not None:
        return failure
    return FormResult("pass")


def _same_display(shown: str, key: sympy.Expr) -> bool:
    """Whether the key is the shown expression, ignoring term order and spacing.

    The shown text is parsed without evaluation, so reordering and sign
    spelling (``y + x``, ``-1*x + 1``) still match, while collecting like terms
    (``x + x`` against ``2*x``) does not.
    """
    if shown.replace(" ", "") == render_expr(key).replace(" ", ""):
        return True
    try:
        parsed = parse_expr(shown, evaluate=False, transformations=_PARSE_RULES)
    except (SyntaxError, TypeError, ValueError, sympy.SympifyError):
        return False
    return str(parsed) == str(key)


def _simplified_form(
    item: MathItemSpec,
    answer: AnswerRecipe,
    params: Mapping[str, Fraction] | None,
) -> FormResult:
    """A simplify key must not repeat the expression the question shows."""
    compiled, failure = _single_expression(
        item, answer, params, item.goal.kind, non_expression="fail"
    )
    if failure is not None:
        return failure
    shown = render_goal_display(item, params)
    if _same_display(shown, compiled):
        return FormResult(
            "fail", "answer repeats the expression the question asks to simplify"
        )
    return FormResult("pass")


_FORM_RULES: dict[GoalKind, FormRule] = {
    "evaluate": _expression_form,
    "simplify": _simplified_form,
    "expand": _expanded_form,
    "factor": _factored_form,
    "derivative": _operator_free_form(sympy.Derivative, "derivative"),
    "integral": _operator_free_form(sympy.Integral, "integral"),
    "solve": _solution_set_form,
    "determinant": _determinant_form,
    # "limit" and "eigenvalues" have no entry: the registry reports them as
    # unsupported rather than inventing a form rule.
}
