"""Bind new H2 learner prompts to their independently checked math operations."""

from __future__ import annotations

import re

from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.domains.h2.task_requirements import clause_mentions
from edcraft_validator.domains.math.ir.compile import MathCompileError, parse_exact
from edcraft_validator.domains.math.ir.schema import (
    MathItemSpec,
    MathTemplateSpec,
    TextSpec,
    item_parameters,
    item_symbols,
)
from edcraft_validator.domains.operation_intent import require_operation_intent
from edcraft_validator.text_templates import template_fields

H2_MATH_GUIDANCE = """\
Author a Mathematics question for the teacher's stated task,
including their requested given quantities, method, and answer form. Choose
an operation and author its operands, parameter domain, correct answer recipe,
and misconception distractors. The application renders the stem and binds
its mathematical data to the checked operation. Use symbolic text, with the
operation's placeholders, as documentation of your intent.

For the unbiased variance estimate from summary totals, use goal.kind
sample_variance. Set symbols and givens to []. Set goal.sample_summary to
{size, total, squared_total} (each is an exact expression or parameter).
For coded totals, add origin for x - origin, scale for x / scale, or both
for y = (x - origin) / scale. The application displays the totals and coding
and derives the variance of the original observations. The response is the
variance estimate alone. The reserved {sample_summary} field shows the data.
Raw observations, recording corrections, pooled batches, jointly estimating
the mean and variance, and custom prose in the learner stem are unsupported.

For integration by parts, use an integral goal with integration_method="parts"
and author the actual product with variable-dependent factors, for example a
polynomial and an exponential.
Ask for one antiderivative. The checker checks each proposed function by
differentiating it. A constant offset alone never makes a distractor wrong.

If a required task, method, given or output lacks a checked representation,
return item=null and an actionable limitation describing the missing capability.
Otherwise return the item and limitation=null. Do not offer a different task.
"""

_PARTS = r"\b(?:integration|integrate|integrating) by parts\b|\bparts-antiderivative\b"
_VARIANCE = (
    r"\b(?:sample variance|variance estimate|estimate\b.{0,50}\bvariance|"
    r"unbiased\b.{0,50}\bvariance|variance-)"
)
_PROOF_SUBMISSION = re.compile(
    r"\b(?:grade|mark|score|assess)\s+(?:an?\s+|the\s+)?"
    r"(?:student(?:['’]s)\s+)?(?:original\s+)?(?:handwritten|written|submitted)\s+proof\b",
    re.IGNORECASE,
)
_EXACT_LITERAL = re.compile(r"[+-]?(?:\d+(?:/\d+|\.\d*)?|\.\d+)", re.ASCII)
_NO_VARIANCE_SUPPORT = (
    (r"\braw (?:observations|data|values)\b|\bvariance-raw\b", "raw observations"),
    (
        r"\brecording (?:error|correction)\b|\bmisrecord\w*\b|\bvariance-corrected\b",
        "corrections to recorded observations",
    ),
    (
        r"\b(?:two|pooled|combined) (?:groups|batches|samples)\b|\bvariance-combined\b",
        "pooled sample totals",
    ),
    (r"\bmean and variance\b|\bvariance and mean\b", "joint mean and variance"),
)
_EXPRESSION_STEMS = {
    "evaluate": "Evaluate {expr}.",
    "simplify": "Simplify {expr}.",
    "expand": "Expand {expr}.",
    "factor": "Factor {expr}.",
    "determinant": "Find the determinant of {matrix}.",
}
_OPERATION_NAMES = {
    "derivative": "differentiation",
    "integral": "integration",
    "sample_variance": "sample variance",
    "determinant": "a determinant",
}
_REQUEST_CUES = {
    "differentiation": (
        r"\b(?:differentiat(?:e|ing)|(?:find|calculate|compute|determine) "
        r"(?:the |an? )?(?:first |second )?derivative|(?:on|test) differentiation)\b"
    ),
    "integration": (
        r"\b(?:integrat(?:e|ing)|(?:find|calculate|compute|determine) "
        r"(?:the |an? )?(?:indefinite integral|antiderivative)"
        r"|(?:on|test) integration)\b"
    ),
    "sample variance": _VARIANCE,
    "a determinant": (
        r"\b(?:find|calculate|compute|determine) (?:the |a )?determinant\b"
    ),
}
_SOURCE_CUES = {
    "expand": r"\b(?:expanding|expansion|expand)\b",
    "factor": r"\bfactori[sz](?:e|ing|ation)\b|\bfactoring\b",
    "simplify": r"\b(?:simplification|simplify|simplifying)\b",
    "solve": r"\b(?:solve|solving|roots of|simultaneous equations)\b",
    "evaluate": (
        r"\bevaluat(?:e|ion|ing)\b|"
        r"\bsubstitut(?:e|ing) (?:the |a |given )?(?:values?|numbers?)\b"
    ),
    "limit": r"\blimits?\b(?!\s+of\s+integration)|\btends to\b",
    "eigenvalues": r"\beigenvalues?\b",
    "differentiation": r"\b(?:differentiat\w*|derivatives?|power rule|chain rule)\b",
    "integration": (
        r"\b(?:integrals?|integration|integrate|integrating|antiderivatives?)\b"
    ),
    "sample variance": _VARIANCE,
    "a determinant": r"\bdeterminants?\b",
}


def bind_h2_math_item(
    request: TemplateRequest, template: MathTemplateSpec
) -> MathTemplateSpec:
    """Render the model-authored mathematical task from the checked IR alone."""
    prompt = request.prompt
    item = template.body
    if item.text.mode != "symbolic":
        raise UnsupportedAuthoringRequest(
            "Use typed symbolic data and a symbolic stem "
            "whose givens and requested operation can be rendered from the item."
        )
    parts = clause_mentions(_PARTS, prompt)
    stem = _operation_stem(prompt, item, parts=parts)
    require_operation_intent(
        request,
        _OPERATION_NAMES.get(item.goal.kind, item.goal.kind),
        request_cues=_REQUEST_CUES,
        source_cues=_SOURCE_CUES,
    )
    goal = item.goal.model_copy(
        update={"integration_method": "parts" if parts else None}
    )
    bound = item.model_copy(update={"text": TextSpec(template=stem), "goal": goal})
    fields = template_fields(stem)
    stimulus = bound.model_copy(
        update={
            "goal": goal.model_copy(
                update={
                    "expr": goal.expr if "expr" in fields else None,
                    "matrix": goal.matrix if "matrix" in fields else None,
                }
            ),
            "givens": [
                given
                for given in bound.givens
                if given.kind == "relation" and "equations" in fields
            ],
            "answer_recipe": None,
            "distractors": [],
        }
    )
    visible = item_parameters(stimulus)
    bound_parameters = item_parameters(bound)
    if any(axis.name not in bound_parameters for axis in template.parameters):
        raise UnsupportedAuthoringRequest(
            "Each parameter must occur in the typed math problem or its options. "
            "A parameter used only in the draft wording will not reach the learner."
        )
    varied = _varying_parameters(template)
    if not (visible & varied):
        raise UnsupportedAuthoringRequest(
            "A reusable Mathematics question needs a visible input that varies "
            "across at least two values."
        )
    return MathTemplateSpec.model_validate({**template.model_dump(), "body": bound})


def requires_marking_a_proof(prompt: str) -> bool:
    return bool(_PROOF_SUBMISSION.search(prompt))


def _varying_parameters(template: MathTemplateSpec) -> set[str]:
    varied = set()
    for axis in template.parameters:
        values = [value.strip() for value in axis.values]
        # Bound numeric work here, before these values reach Fraction.
        if any(
            len(value) > 64 or not _EXACT_LITERAL.fullmatch(value) for value in values
        ):
            raise UnsupportedAuthoringRequest(
                f"Use short exact decimals or fractions for parameter {axis.name}."
            )
        try:
            if len({parse_exact(value) for value in values}) > 1:
                varied.add(axis.name)
        except MathCompileError as exc:
            raise UnsupportedAuthoringRequest(f"Use exact parameters: {exc}") from exc
    return varied


def _operation_stem(prompt: str, item: MathItemSpec, *, parts: bool) -> str:
    goal = item.goal
    if goal.kind == "sample_variance" or clause_mentions(_VARIANCE, prompt):
        return _variance_stem(prompt, item)

    relations = [given for given in item.givens if given.kind == "relation"]
    if any(given.kind == "dataset" for given in item.givens) or (
        relations and goal.kind != "solve"
    ):
        raise UnsupportedAuthoringRequest(
            "Use relation givens with a solve goal. This math operation cannot "
            "apply extra relations or datasets from the question."
        )
    if goal.kind != "limit" and goal.point is not None:
        raise UnsupportedAuthoringRequest(
            "This math operation cannot check an additional evaluation point. "
            "The learner's visible task must match the checked operation."
        )

    if parts and (
        goal.kind != "integral" or goal.expr is None or goal.expr.op != "mul"
    ):
        raise UnsupportedAuthoringRequest(
            "To assess integration by parts, use an integral goal with a product "
            "of two variable-dependent factors, such as a polynomial and an "
            "exponential."
        )

    if goal.kind in _EXPRESSION_STEMS:
        stem = _EXPRESSION_STEMS[goal.kind]
    elif goal.kind == "solve" and relations:
        unknowns = ", ".join(goal.symbols or [str(goal.symbol)])
        stem = f"Solve for {unknowns} in the {goal.domain} domain: {{equations}}."
    elif goal.kind == "derivative" and goal.symbol:
        order = "derivative" if goal.order == 1 else f"derivative of order {goal.order}"
        stem = f"Find the {order} of {{expr}} with respect to {goal.symbol}."
    elif goal.kind == "integral" and goal.symbol:
        lead = "Using integration by parts, which" if parts else "Which"
        stem = (
            f"{lead} expression is an antiderivative of {{expr}} "
            f"with respect to {goal.symbol}?"
        )
    else:
        raise UnsupportedAuthoringRequest(
            f"The math checker cannot render and verify the requested {goal.kind} "
            "operation. Use a supported typed operation that preserves the task."
        )
    return stem + _symbol_assumptions(item)


def _variance_stem(prompt: str, item: MathItemSpec) -> str:
    for cue, description in _NO_VARIANCE_SUPPORT:
        if clause_mentions(cue, prompt):
            raise UnsupportedAuthoringRequest(
                f"The H2 variance operation cannot check {description}. "
                "It supports one sample summarized by a count and two totals."
            )
    summary = item.goal.sample_summary
    if summary is None:
        raise UnsupportedAuthoringRequest(
            "Use the checked sample_variance operation with its visible sample summary "
            "to ask for an unbiased estimate of variance."
        )
    if summary.origin is None and clause_mentions(
        r"\bshift(?:ed|ing)?\b|\b(?:assumed mean|shifted origin|variance-shifted)\b",
        prompt,
    ):
        raise UnsupportedAuthoringRequest(
            "Include the requested origin in the sample summary for shifted totals."
        )
    if summary.scale is None and clause_mentions(
        r"\b(?:scale|scaled|scaling|affine|coded|coding|variance-coded)\b", prompt
    ):
        raise UnsupportedAuthoringRequest(
            "Include the requested scale in the sample summary for coded totals."
        )
    return (
        "A random sample of x gives the following summary. {sample_summary}. "
        "Find the unbiased estimate of the population variance of x."
    )


def _symbol_assumptions(item: MathItemSpec) -> str:
    stimulus = item.model_copy(update={"answer_recipe": None, "distractors": []})
    used = item_symbols(stimulus) | set(item.goal.symbols)
    if item.goal.symbol is not None:
        used.add(item.goal.symbol)
    assumptions: list[str] = []
    for symbol in item.symbols:
        if symbol.name not in used:
            continue
        domain = "integer" if symbol.integer else symbol.domain
        adjectives = (
            "positive " if symbol.positive else "nonzero " if symbol.nonzero else ""
        )
        assumptions.append(f"{symbol.name} is {adjectives}{domain}")
    assumptions.extend(
        f"{given.symbol} is {given.domain}"
        for given in item.givens
        if given.kind == "domain" and given.symbol in used
    )
    return (
        " Assume " + " and ".join(dict.fromkeys(assumptions)) + "."
        if assumptions
        else ""
    )
