"""Select a fixed subset of options and build a checked-math candidate."""

from __future__ import annotations

from edcraft_validator.domains.domain_support import (
    build_template_id,
    content_sha256,
)
from edcraft_validator.domains.math.math_schemas import (
    MathTemplateCandidate,
    MathTemplateContent,
    MathTemplateRequest,
)
from edcraft_validator.domains.math.validation.isolation import (
    ValidationTimeout,
    ValidationWorkerError,
    run_isolated,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
)


def build_math_candidate(
    request: MathTemplateRequest, proposal: MathTemplateContent
) -> MathTemplateCandidate:
    """Evaluate proposed reserves within the bounded math worker."""
    item = proposal.item
    if item is None:
        raise ValueError("A reusable math template requires an item.")
    options = item.body.distractors
    expected = request.num_distractors + SURPLUS_RECIPES
    if len(options) != expected:
        raise DistractorPoolError(
            f"Provide exactly {expected} candidate distractor recipes. "
            f"The proposal contains {len(options)}."
        )
    try:
        response = run_isolated(
            {
                "operation": "select_distractors",
                "template": item.model_dump(mode="json"),
                "required": request.num_distractors,
            }
        )
    except (ValidationTimeout, ValidationWorkerError) as exc:
        raise DistractorPoolError(
            f"The option-pool check could not complete: {exc}"
        ) from exc
    if "error" in response:
        raise DistractorPoolError(response["error"]["message"])
    selected = [options[index] for index in response["selected"]]
    item = item.model_copy(
        update={"body": item.body.model_copy(update={"distractors": selected})}
    )
    return candidate_with_selected_options(request, MathTemplateContent(item=item))


def candidate_with_selected_options(
    request: MathTemplateRequest, proposal: MathTemplateContent
) -> MathTemplateCandidate:
    """Package the fixed recipes for authoring or a prechecked research fixture."""
    item = proposal.item
    if item is None or len(item.body.distractors) != request.num_distractors:
        raise ValueError("Expected an item with the selected distractor count.")
    return MathTemplateCandidate(
        template_id=build_template_id("math", request, proposal),
        difficulty=request.difficulty,
        item=item,
        question_type="mcq",
    )


def template_sha256(candidate: MathTemplateCandidate) -> str:
    """Identify the exact reusable content independently of any assessment."""
    return content_sha256(candidate)
