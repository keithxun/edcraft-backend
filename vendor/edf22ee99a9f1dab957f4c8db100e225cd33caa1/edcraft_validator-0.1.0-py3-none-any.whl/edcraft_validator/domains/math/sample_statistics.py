"""Exact statistics computed from the same sample summary the learner sees."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from fractions import Fraction

from edcraft_validator.domains.math.ir.compile import MathCompileError, compile_expr
from edcraft_validator.domains.math.ir.schema import Expr, SampleSummary


@dataclass(frozen=True)
class SampleTotals:
    size: int
    total: Fraction
    squared_total: Fraction
    origin: Fraction | None
    scale: Fraction | None

    def unbiased_variance(self) -> Fraction:
        return (
            (self.squared_total - self.total**2 / self.size)
            / (self.size - 1)
            * (self.scale if self.scale is not None else 1) ** 2
        )

    def display(self) -> str:
        if self.origin is None and self.scale is None:
            return f"n = {self.size}, Σx = {self.total}, Σx² = {self.squared_total}"
        origin = self.origin if self.origin is not None else 0
        scale = self.scale if self.scale is not None else 1
        shift = f"x - {origin}" if origin >= 0 else f"x + {-origin}"
        coding = f"({shift})/({scale})" if scale != 1 else shift
        return (
            f"y = {coding}. n = {self.size}, "
            f"Σy = {self.total}, Σy² = {self.squared_total}"
        )


def sample_totals(
    summary: SampleSummary, params: Mapping[str, Fraction] | None = None
) -> SampleTotals:
    def number(expr: Expr) -> Fraction:
        value = compile_expr(expr, {}, params)
        if not value.is_Rational:
            raise MathCompileError("sample totals require exact rational numbers")
        return Fraction(int(value.p), int(value.q))

    size = number(summary.size)
    total = number(summary.total)
    squared = number(summary.squared_total)
    origin = number(summary.origin) if summary.origin is not None else None
    scale = number(summary.scale) if summary.scale is not None else None
    if size.denominator != 1 or size < 2:
        raise MathCompileError("the sample size must be an integer of at least two")
    if scale == 0:
        raise MathCompileError("the coding scale must be non-zero")
    if squared < total**2 / size:
        raise MathCompileError("sample total and squared total are inconsistent")
    return SampleTotals(int(size), total, squared, origin, scale)
