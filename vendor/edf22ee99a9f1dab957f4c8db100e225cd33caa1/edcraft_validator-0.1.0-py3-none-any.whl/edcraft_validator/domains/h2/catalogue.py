"""Look up immutable, subject-scoped 2026 syllabus families by their official number."""

import ast
import hashlib
import inspect
import json
import sys
from collections.abc import Callable
from dataclasses import asdict
from functools import cache
from textwrap import dedent

from edcraft_validator.domains.h2 import code_families, data_structures, math_families
from edcraft_validator.domains.h2.families import Family, question
from edcraft_validator.domains.h2.reviewed_cases import ReviewedVariants, load_reviewed


def _catalogue(subject: str, base: tuple[Family, ...]) -> dict[str, Family]:
    topics = {f.number: f.topic for f in base}
    catalogue = {f.number: f for f in base}
    for family in load_reviewed(subject, topics):
        catalogue[family.number] = family
    if subject == "code":
        # Prefer parameterised list and tree problems to their finite study cases.
        catalogue.update((f.number, f) for f in data_structures.FAMILIES)
    return catalogue


CATALOGUES = {
    "code": _catalogue("code", code_families.FAMILIES),
    "math": _catalogue("math", math_families.FAMILIES),
}


def variant_count(family: Family) -> int:
    """Number of selectable input indices in this family's released format."""
    if isinstance(family.render, ReviewedVariants):
        return len(family.render.items)
    return 1024


def eligible_cases(family: Family, allowed: list[int] | None) -> range | list[int]:
    """Resolve positions within the immutable family revision named by the artifact."""
    size = variant_count(family)
    if allowed is None:
        return range(size)
    if not isinstance(family.render, ReviewedVariants):
        raise ValueError("Numbered case selections apply only to curated families")
    if (
        len(allowed) < 2
        or allowed != sorted(set(allowed))
        or allowed[0] < 0
        or allowed[-1] >= size
    ):
        raise ValueError(
            "Select at least two distinct listed case numbers in ascending order"
        )
    return allowed


def family_for(subject: str, number: str) -> Family:
    try:
        return CATALOGUES[subject][number]
    except KeyError as exc:
        raise ValueError(f"Unknown H2 family {subject}/{number}") from exc


def _ast_dumps(source: str) -> tuple[str, str]:
    tree = ast.parse(source)
    if sys.version_info >= (3, 13):
        return ast.dump(tree), ast.dump(tree, show_empty=True)

    # Python 3.12 included empty list fields. Its dump skips absent fields,
    # so dropping only empty lists reproduces the newer format on parsed trees.
    expanded = ast.dump(tree)
    for node in ast.walk(tree):
        for field, value in ast.iter_fields(node):
            if isinstance(value, list) and not value:
                delattr(node, field)
    return ast.dump(tree), expanded


def family_digest(subject: str, number: str) -> str:
    """Identify a trusted builder in the same format on each supported Python."""
    return family_digests(subject, number)[0]


@cache
def family_digests(subject: str, number: str) -> tuple[str, str]:
    """Return compact and legacy expanded digests of the current family source."""
    family = family_for(subject, number)
    if isinstance(family.render, ReviewedVariants):
        reviewed = json.dumps(asdict(family.render), sort_keys=True, ensure_ascii=False)
        sources = [
            (reviewed, reviewed),
            _ast_dumps(dedent(inspect.getsource(ReviewedVariants.__call__))),
        ]
    else:
        builders: tuple[Callable[..., object], ...] = (
            question,
            family.render,
            *family.dependencies,
        )
        sources = [_ast_dumps(inspect.getsource(fn)) for fn in builders]
    if family.answer_type != "value":
        sources.append((family.answer_type, family.answer_type))
    compact, expanded = zip(*sources, strict=True)
    identity = (subject, number, family.topic, family.scope)
    return (
        hashlib.sha256("\n".join((*identity, *compact)).encode()).hexdigest(),
        hashlib.sha256("\n".join((*identity, *expanded)).encode()).hexdigest(),
    )
