"""Parameterised linked-list and tree questions for H2 Computing 9569."""

from edcraft_validator.domains.h2.families import Family, Item, question


def linked_insert(case: int) -> Item:
    head = 1 + case % 19
    successor = head + 2 + case // 19 % 9
    spare = successor + 1 + case // 171 % 5
    # Inserting between two nodes must retain the previous successor.
    return question(
        f"A singly linked list has head at index {head}; next[{head}] = {successor}. "
        f"Node {spare} has just been taken from the free list. It must become the "
        f"immediate successor of node {head}. Which assignments work in the given "
        "order without losing the rest of the list?",
        f"next[{spare}] = next[{head}]; next[{head}] = {spare}",
        (
            f"next[{head}] = {spare}; next[{spare}] = next[{head}]",
            f"next[{spare}] = {head}; next[{head}] = {spare}",
            f"next[{head}] = {successor}; next[{successor}] = {spare}",
            f"next[{spare}] = {spare}; next[{head}] = {spare}",
            f"next[{successor}] = {head}; next[{spare}] = {successor}",
        ),
    )


def insert_at_head(case: int) -> Item:
    old = 1 + case % 29
    new = old + 1 + case // 29 % 11
    return question(
        f"The head of a singly linked list is node {old}. Node {new} has been "
        "allocated and must become the first node. Which ordered assignments "
        "preserve the remaining chain?",
        f"next[{new}] = head; head = {new}",
        (
            f"head = {new}; next[{new}] = head",
            f"next[{old}] = {new}; head = {old}",
            f"head = {new}; next[{new}] = null",
            f"next[{new}] = null; head = {old}",
            f"next[{old}] = {old}; head = {new}",
            f"head = null; next[{new}] = {old}",
        ),
    )


def linked_delete(case: int) -> Item:
    head = 1 + case % 11
    deleted = head + 2 + case // 11 % 6
    tail = deleted + 2 + case // 66 % 8
    free = tail + 1 + case // 528 % 2
    return question(
        f"Active nodes of a singly linked list are {head} → {deleted} → {tail}. "
        f"The old free-list head is {free}. Delete {deleted} and put it first on "
        f"the free list. What are (next[{head}], next[{deleted}], free_head) now?",
        (tail, free, deleted),
        (
            (tail, deleted, free),
            (deleted, free, tail),
            (tail, head, deleted),
            (free, tail, deleted),
            (deleted, tail, free),
            (tail, free, head),
        ),
    )


def tree_traversal(case: int, order: str) -> Item:
    first = 2 + case % 27
    gap = 1 + case // 27 % 8
    a, b, c, d, e = [first + gap * i for i in range(5)]
    # The left child's right child and right child's left child make the
    # three traversal orders distinguishable even when the values increase.
    root, left, right = c, a, e
    stem = (
        f"A binary search tree has root {root}, left child {left} and right child "
        f"{right}. Node {left} has only a right child {b}. Node {right} has only "
        f"a left child {d}; {b} and {d} are leaves. Which sequence is its "
        f"{order} traversal, visiting left children before right children?"
    )
    traversals = {
        "preorder": (c, a, b, e, d),
        "inorder": (a, b, c, d, e),
        "postorder": (b, a, d, e, c),
    }
    key = traversals[order]
    # A type comment preserves the fingerprint of the saved family.
    errors = [seq for name, seq in traversals.items() if name != order]  # type: list[tuple[int, ...]]
    errors.extend(
        [(c, a, e, b, d), tuple(reversed(key)), (c, e, d, a, b), (a, c, b, e, d)]
    )
    return question(stem, key, errors)


def preorder(case: int) -> Item:
    return tree_traversal(case, "preorder")


def inorder(case: int) -> Item:
    return tree_traversal(case, "inorder")


def postorder(case: int) -> Item:
    return tree_traversal(case, "postorder")


FAMILIES = (
    Family(
        "1.3.linked-head",
        "Data structures",
        "Insert before the head of a singly linked chain",
        insert_at_head,
    ),
    Family(
        "1.3.linked-insert",
        "Data structures",
        "Insert a node in a singly linked list",
        linked_insert,
    ),
    Family(
        "1.3.linked-delete",
        "Data structures",
        "Delete a node and restore the free-list head",
        linked_delete,
    ),
    Family(
        "1.3.preorder",
        "Data structures",
        "Preorder traversal of a binary tree",
        preorder,
        (tree_traversal,),
    ),
    Family(
        "1.3.inorder",
        "Data structures",
        "Inorder traversal of a binary search tree",
        inorder,
        (tree_traversal,),
    ),
    Family(
        "1.3.postorder",
        "Data structures",
        "Postorder traversal of a binary tree",
        postorder,
        (tree_traversal,),
    ),
)
