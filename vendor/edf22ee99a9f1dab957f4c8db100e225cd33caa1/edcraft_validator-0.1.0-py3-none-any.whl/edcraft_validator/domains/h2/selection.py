"""Narrow an authoring request to a small set of named, trusted syllabus families."""

import math
import re
from collections import Counter
from functools import lru_cache
from typing import Literal

from pydantic import Field, create_model

from edcraft_validator.domains.h2.catalogue import CATALOGUES
from edcraft_validator.domains.h2.schemas import Proposal
from edcraft_validator.domains.h2.task_requirements import (
    AuthoredProposal,
    accepts_queue_output,
)

_REFERENCE = re.compile(
    r"^\s*(?:Singapore\s+)?H2\s+(?:(skill|topic)\s+)?"
    r"(\d+\.\d+(?:\.[a-z][a-z0-9-]*)?)\b",
    re.IGNORECASE,
)
_STOP = set(
    "a an the and or for of to from with on h2 singapore a level question "
    "questions reusable create generate students multiple choice computing "
    "mathematics hard medium easy topic skill select choose find using given".split()
)


def _terms(text: str) -> set[str]:
    return {
        s.removesuffix("s")
        for s in re.findall(r"[a-z]+", text.lower())
        if s not in _STOP and len(s) > 1
    }


def offered_families(subject: str, prompt: str) -> tuple[str, ...]:
    families = CATALOGUES[subject]
    if subject == "code":
        families = {
            key: family
            for key, family in families.items()
            if accepts_queue_output(key, prompt)
        }
    ref = _REFERENCE.match(prompt)
    if ref:
        number = ref[2].lower()
        if (ref[1] or "").lower() == "skill" or number.count(".") > 1:
            return (number,) if number in families else ()
        candidates = [
            key for key in families if key == number or key.startswith(number + ".")
        ]
    else:
        candidates = list(families)
    if ref and not _terms(prompt[ref.end() :]) and number in families:
        return (number,)
    if ref and len(candidates) <= 8:
        return tuple(candidates)
    terms = _terms(prompt)
    vocabulary = {
        key: _terms(f"{families[key].topic} {families[key].scope} {key}")
        for key in candidates
    }
    counts = Counter(word for words in vocabulary.values() for word in words)

    def score(key: str) -> float:
        return sum(
            math.log1p(len(candidates) / counts[word])
            for word in vocabulary[key] & terms
        )

    winners = sorted(candidates, key=lambda key: (-score(key), key))
    return tuple(key for key in winners if score(key) > 0)[:8]


@lru_cache(maxsize=128)
def proposal_type(offered: tuple[str, ...]) -> type[Proposal]:
    # A closed provider schema prevents labels, tool names and other free text
    # from being mistaken for a stable family ID during a correction.
    ids = (*offered, "unsupported")
    return create_model(
        "H2FamilyProposal",
        __base__=AuthoredProposal,
        # Pydantic requires the request's runtime enum in its generated schema.
        family=(
            Literal[ids],  # type: ignore[valid-type]
            Field(description="A listed family ID or unsupported."),
        ),
    )
