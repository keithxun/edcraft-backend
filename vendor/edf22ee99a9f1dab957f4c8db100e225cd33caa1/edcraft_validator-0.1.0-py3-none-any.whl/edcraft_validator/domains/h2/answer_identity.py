"""Compare H2 answer labels using a closed grammar for exact real values."""

import re
from dataclasses import dataclass
from fractions import Fraction
from math import isqrt

from edcraft_validator.domains.h2.families import AnswerType

_DECIMAL = r"(?:[0-9]{1,16}(?:\.[0-9]{1,12})?|\.[0-9]{1,12})"
_RATIO = r"[0-9]{1,16}/[1-9][0-9]{0,15}"
_SIGNED_DECIMAL = rf"[+-]?{_DECIMAL}"
_SCALAR = re.compile(rf"[+-]?(?:{_DECIMAL}|{_RATIO})")
_PERCENT = re.compile(rf"(?P<amount>{_SIGNED_DECIMAL})\s*%")
_SCIENTIFIC = re.compile(
    rf"(?P<mantissa>{_SIGNED_DECIMAL})"
    r"(?:[eE](?P<e>[+-]?[0-9]{1,3})"
    r"|\s*[×*]\s*10(?:\^(?P<power>[+-]?[0-9]{1,3})"
    r"|(?P<superscript>[⁺⁻]?[⁰¹²³⁴⁵⁶⁷⁸⁹]{1,3})))"
)
_SUPERSCRIPT_DIGITS = str.maketrans("⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹", "+-0123456789")
_MAX_POWER_OF_TEN = 100
_RADICAL = re.compile(
    rf"(?P<sign>[+-]?)\s*(?:(?P<coefficient>{_DECIMAL}|\([+-]?{_RATIO}\))"
    r"\s*(?:[×*]\s*)?)?"
    r"(?:√\s*(?P<bare>[0-9]{1,16})|(?:√|sqrt)\((?P<wrapped>[0-9]{1,16})\))"
    r"(?:\s*/\s*(?P<denominator>[1-9][0-9]{0,15}))?"
)


@dataclass(frozen=True)
class _IrrationalSquareRoot:
    negative: bool
    square: Fraction


def identity(
    label: str, answer_type: AnswerType
) -> Fraction | _IrrationalSquareRoot | str:
    """Return an exact value identity or preserve the label's text identity."""
    if answer_type == "exact_text":
        return label

    value = label.strip().replace("−", "-")
    if _SCALAR.fullmatch(value):
        return Fraction(value)

    percent = _PERCENT.fullmatch(value)
    if percent:
        return Fraction(percent["amount"]) / 100

    scientific = _SCIENTIFIC.fullmatch(value)
    if scientific:
        exponent_text = scientific["e"] or scientific["power"]
        if exponent_text is None:
            exponent_text = scientific["superscript"].translate(_SUPERSCRIPT_DIGITS)
        exponent = int(exponent_text)
        if abs(exponent) <= _MAX_POWER_OF_TEN:
            return Fraction(scientific["mantissa"]) * Fraction(10) ** exponent

    radical = _RADICAL.fullmatch(value)
    if radical:
        return _radical_identity(radical)
    return value


def _radical_identity(match: re.Match[str]) -> Fraction | _IrrationalSquareRoot:
    coefficient = Fraction((match["coefficient"] or "1").strip("()"))
    if match["sign"] == "-":
        coefficient = -coefficient
    coefficient /= int(match["denominator"] or "1")
    radicand = int(match["bare"] or match["wrapped"])
    root = isqrt(radicand)
    if root * root == radicand or coefficient == 0:
        return coefficient * root

    # Sign and exact square distinguish real values without factoring integers.
    return _IrrationalSquareRoot(coefficient < 0, coefficient**2 * radicand)
