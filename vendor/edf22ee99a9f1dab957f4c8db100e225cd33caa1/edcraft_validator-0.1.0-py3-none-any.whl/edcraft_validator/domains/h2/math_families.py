"""Original H2 Mathematics 9758 families. Each builder states the problem it grades."""

from fractions import Fraction
from math import comb
from statistics import NormalDist

from edcraft_validator.domains.h2 import variance_families
from edcraft_validator.domains.h2.families import Family, Item, question


def cartesian_conjugate(i: int) -> Item:
    real = (2 + i % 19) * (-1 if i % 2 else 1)
    imag = (23 + (i // 19) % 21) * (-1 if i % 3 else 1)

    def number(a: int, b: int) -> str:
        return f"{a}{b:+d}i"

    return question(
        f"Let z = {number(real, imag)}. Which value is its complex conjugate?",
        number(real, -imag),
        (
            number(-real, imag),
            number(-real, -imag),
            number(real, imag),
            number(imag, real),
            number(-imag, real),
            number(imag, -real),
        ),
    )


def parts_antiderivative(i: int) -> Item:
    slope = 2 + i % 16
    intercept = 1 + (i // 16) % 64
    # Taking u = ax+b and dv = e^x dx subtracts a times the same exponential.
    constant = intercept - slope

    def product(a: int, b: int) -> str:
        sign = "+" if b >= 0 else "−"
        return f"({a}x {sign} {abs(b)})e^x"

    return question(
        "Using integration by parts, which expression is an antiderivative of "
        + product(slope, intercept)
        + "?",
        product(slope, constant),
        (
            product(slope, intercept),
            product(slope, intercept + slope),
            product(slope, intercept - 2 * slope),
            product(-slope, constant),
            product(-slope, intercept),
            product(-slope, intercept + slope),
        ),
    )


def inverse_composite(i: int) -> Item:
    a, b, x = 2 + i % 7, 3 + i // 7 % 9, 7 + i // 63 % 12
    target = a * (x + b) + 1
    return question(
        f"Let f(x) = {a}x + 1 and g(x) = x + {b} on the real numbers. "
        f"Find (f ∘ g)⁻¹({target}).",
        x,
        (x + b, x + 2 * b, target - b, a * x + b, target, -x),
    )


def graph_transform(i: int) -> Item:
    x, y, a, b = 2 + i % 7, 3 + i // 7 % 6, 2 + i // 42 % 4, 1 + i // 168 % 5
    return question(
        f"The point ({x}, {y}) lies on y = f(x). Which point corresponds to it "
        f"on y = {a}f(x − {b})?",
        (x + b, a * y),
        (
            (x - b, a * y),
            (x + b, y + a),
            (x - b, y - a),
            (a * x, y + b),
            (x, a * y),
            (x + b, y),
        ),
    )


def inequality(i: int) -> Item:
    a, b = 2 + i % 11, 3 + i // 11 % 9
    return question(
        f"For real x, solve (x + {a})/(x − {b}) ≤ 0. Give the solution interval.",
        f"[−{a}, {b})",
        (
            f"(−{a}, {b}]",
            f"[−{a}, {b}]",
            f"(−{a}, {b})",
            f"(−∞, −{a}] ∪ ({b}, ∞)",
            f"(−∞, −{a}) ∪ [{b}, ∞)",
            f"[{b}, ∞)",
        ),
    )


def geometric_sum(i: int) -> Item:
    a, r, n = 2 + i % 9, 2 + i // 9 % 3, 4 + i // 27 % 5
    total = a * (r**n - 1) // (r - 1)
    return question(
        f"A geometric progression starts at {a} and has common ratio {r}. "
        f"Find the sum of its first {n} terms.",
        total,
        (a * r ** (n - 1), total - a, total + a * r**n, a * n * r, a * r**n, total * r),
    )


def vector_position(i: int) -> Item:
    x, y, z = 2 + i % 8, 3 + i // 8 % 9, 4 + i // 72 % 11
    a, b = (x, y, z), (x + 3, y - 6, z + 9)
    return question(
        f"Point P divides AB internally in the ratio AP:PB = 1:2. "
        f"Given A = {a} and B = {b}, find P.",
        (x + 1, y - 2, z + 3),
        ((x + 2, y - 4, z + 6), (1, -2, 3), (x - 1, y + 2, z - 3), b, a, (3, -6, 9)),
    )


def scalar_product(i: int) -> Item:
    a, b = 2 + i % 9, 3 + i // 9 % 11
    # The dot product of the two directions is a*x - 2*b + 1.
    key = Fraction(2 * b - 1, a)
    return question(
        f"The directions ({a}, −2, 1) and (t, {b}, 1) are perpendicular. Find t.",
        key,
        (
            -key,
            Fraction(2 * b + 1, a),
            a * (2 * b - 1),
            Fraction(b - 1, a),
            2 * b - 1,
            0,
        ),
    )


def line_plane(i: int) -> Item:
    t, a, b = 4 + i % 13, 2 + i // 13 % 7, 3 + i // 91 % 5
    c = a + b + 3 * t
    return question(
        f"A line has position vector ({a}, {b}, 0) + t(1, 1, 1). "
        f"It intersects the plane x + y + z = {c}. Find t.",
        t,
        (3 * t, t + 1, t - 1, c, c - a, c - b),
    )


def complex_product(i: int) -> Item:
    a, b, c, d = 2 + i % 7, 3 + i // 7 % 5, 2 + i // 35 % 5, 1 + i // 175 % 6
    real, imag = a * c - b * d, a * d + b * c
    return question(
        f"For z = ({a} + {b}i)({c} + {d}i), find the imaginary part of z.",
        imag,
        (real, a * c + b * d, a * d - b * c, -imag, a * b + c * d, b * d),
    )


def related_rates(i: int) -> Item:
    r, v = 11 + 2 * (i % 11), 2 + i // 11 % 7
    return question(
        f"The radius of a sphere is increasing at {v} cm/s. At radius {r} cm, "
        "the volume is increasing at kπ cm³/s. Find k.",
        4 * r * r * v,
        (
            4 * r * r,
            4 * r * v,
            4 * r**3 * v,
            Fraction(4 * r**3, 3),
            r * r * v,
            8 * r * v,
        ),
    )


def maclaurin(i: int) -> Item:
    a, b = 2 + i % 8, 1 + i // 8 % 7
    key = Fraction(a * a, 2) + a * b
    return question(
        f"Find the coefficient of x² in the Maclaurin expansion of "
        f"(1 + {b}x)exp({a}x).",
        key,
        (
            Fraction(a * a, 2),
            a * b,
            a * a + a * b,
            key + b * b,
            Fraction(a, 2) + b,
            -key,
        ),
    )


def substitution(i: int) -> Item:
    a, n = 2 + i % 7, 2 + i // 7 % 5
    key = Fraction(1, 2 * a * (n + 1))
    return question(
        f"An antiderivative of x({a}x² + 1)^{n} is k({a}x² + 1)^{n + 1} + C. Find k.",
        key,
        (
            Fraction(1, n + 1),
            Fraction(1, 2 * a),
            2 * a * (n + 1),
            Fraction(2 * a, n + 1),
            -key,
            1,
        ),
    )


def definite_integral(i: int) -> Item:
    b, k = 2 + i % 7, 1 + i // 7 % 6
    area = Fraction(k * b**3, 6)
    return question(
        f"The parabola y = {k}x({b} − x) meets the x-axis at x = 0 "
        f"and x = {b}. Find the area enclosed between the curve and the x-axis.",
        area,
        (area * 2, area * 3, area / 2, -area, k * b * b, Fraction(k * b * b, 4)),
    )


def differential_equation(i: int) -> Item:
    a, y0, x = 2 + i % 6, 3 + i // 6 % 8, 2 + i // 48 % 5
    key = y0 + a * x * x
    return question(
        f"A curve satisfies dy/dx = {2 * a}x and y(0) = {y0}. Find y({x}).",
        key,
        (
            a * x * x,
            2 * a * x + y0,
            2 * a * x * x + y0,
            key - y0 * 2,
            y0 + a * x,
            y0 * x + a,
        ),
    )


def conditional_probability(i: int) -> Item:
    a, b, c = 11 + i % 13, 2 + i // 13 % 5, 30 + i // 65 % 7
    key = Fraction(a, a + b)
    return question(
        f"Of the students who took Physics, {a} also took Art and {b} did not. "
        f"A further {c} students took only Art. A student is selected uniformly "
        "from those who took Physics. What is the probability they also took Art?",
        key,
        (
            Fraction(a, a + b + c),
            Fraction(a, a + c),
            Fraction(b, a + b),
            Fraction(a + b, a + b + c),
            Fraction(b, b + c),
            Fraction(c, a + b + c),
        ),
    )


def binomial(i: int) -> Item:
    n, k = 5 + i % 9, 2 + i // 9 % 2
    key = Fraction(comb(n, k), 2**n)
    return question(
        f"A fair coin is tossed independently {n} times. Find the exact "
        f"probability of getting exactly {k} heads.",
        key,
        (
            Fraction(1, 2**n),
            Fraction(k, n),
            1 - key,
            Fraction(comb(n, k - 1), 2**n),
            Fraction(1, 2**k),
            Fraction(comb(n, k), 2 ** (n - 1)),
        ),
    )


def normal_sum(i: int) -> Item:
    mu, s, n = 20 + i % 17, 2 + i // 17 % 7, 4
    z = 1 + i // 119 % 3
    cutoff = n * mu + 2 * s * z

    def prob(z: float) -> str:
        return f"{NormalDist().cdf(z):.3f}"

    return question(
        f"Four independent masses each follow N({mu}, {s * s}), with mean and "
        f"variance shown. Find P(their total is below {cutoff}) to 3 decimal places.",
        prob(z),
        tuple(prob(other) for other in (-z, z / 2, 2 * z, -z / 2, 0, -2 * z)),
    )


def standard_error(i: int) -> Item:
    sigma, root = 6 + i % 13, 3 + i // 13 % 8
    return question(
        f"A random sample of {root**2} independent observations comes from "
        f"a population of standard deviation {sigma}. What is the standard deviation "
        "of the sample mean?",
        Fraction(sigma, root),
        (
            Fraction(sigma, root**2),
            sigma * root,
            Fraction(sigma**2, root**2),
            sigma,
            sigma**2,
            root**2,
        ),
    )


def one_sided_test(i: int) -> Item:
    mu, s, r = 20 + i % 13, 4 + i // 13 % 5, 4 + i // 65 % 5
    z = Fraction(2 + i // 91 % 3, 2)
    obs = Fraction(mu) + z * Fraction(s, r)

    def p(z: float) -> str:
        return f"{NormalDist().cdf(z):.4f}"

    return question(
        f"A normal population has known standard deviation {s}. For H₀: μ = {mu} "
        f"against H₁: μ > {mu}, a random sample of {r * r} gives mean {obs}. "
        "Find the one-sided p-value to four decimal places.",
        # NormalDist accepts these Fraction arguments through its float
        # arithmetic. Changing the released renderer's AST breaks saved replay.
        p(-z),  # type: ignore[arg-type]
        (
            p(z),  # type: ignore[arg-type]
            f"{2 * NormalDist().cdf(-z):.4f}",  # type: ignore[arg-type]
            p(-z / 2),  # type: ignore[arg-type]
            p(z / 2),  # type: ignore[arg-type]
            p(0),
            p(-2 * z),  # type: ignore[arg-type]
        ),
    )


def regression(i: int) -> Item:
    mean_x, mean_y = 4 + i % 7, 15 + i // 7 % 9
    slope, delta = 2 + i // 63 % 5, 1 + i // 315 % 3
    sxx = 12 + 2 * (i % 9)
    return question(
        f"A data set has mean x = {mean_x}, mean y = {mean_y}, "
        f"Sxx = Σ(x − mean x)² = {sxx} and Sxy = Σ(x − mean x)(y − mean y) "
        f"= {slope * sxx}. The value x = {mean_x + delta} is within the observed "
        "range. Using the regression line of y on x, estimate y at that value.",
        mean_y + slope * delta,
        (
            mean_y - slope * delta,
            mean_y + Fraction(delta, slope),
            slope * (mean_x + delta),
            mean_y + slope * (mean_x + delta),
            mean_y,
            mean_x + slope * delta,
        ),
    )


FAMILIES = (
    Family(
        "5.3.parts-antiderivative",
        "Integration",
        "Use integration by parts to select an antiderivative of a product of "
        "an affine function and an exponential.",
        parts_antiderivative,
        answer_type="exact_text",
    ),
    Family(
        "4.1.cartesian-conjugate",
        "Complex numbers",
        "Find the complex conjugate of a number given in Cartesian form.",
        cartesian_conjugate,
        answer_type="exact_text",
    ),
    Family(
        "1.1",
        "Functions",
        "Inverse of a composition of affine functions",
        inverse_composite,
    ),
    Family(
        "1.2",
        "Graphs and transformations",
        "Coordinates after two transformations",
        graph_transform,
    ),
    Family(
        "1.3",
        "Equations and inequalities",
        "Rational inequality with sign and endpoint checks",
        inequality,
    ),
    Family(
        "2.1",
        "Sequences and series",
        "Sum of a finite geometric progression",
        geometric_sum,
    ),
    Family(
        "3.1",
        "Basic vector properties",
        "Internal division of a segment in 3D",
        vector_position,
    ),
    Family(
        "3.2",
        "Scalar and vector products",
        "Perpendicular directions from a scalar product",
        scalar_product,
    ),
    Family(
        "3.3",
        "Three-dimensional geometry",
        "Line–plane intersection parameter",
        line_plane,
    ),
    Family(
        "4.1",
        "Complex numbers",
        "Imaginary part of a Cartesian product",
        complex_product,
    ),
    Family("5.1", "Differentiation", "Related rates for a sphere", related_rates),
    Family("5.2", "Maclaurin series", "Coefficient in a product of series", maclaurin),
    Family(
        "5.3", "Integration techniques", "Antiderivative by substitution", substitution
    ),
    Family(
        "5.4",
        "Definite integrals",
        "Area between a parabola and the x-axis",
        definite_integral,
    ),
    Family(
        "5.5",
        "Differential equations",
        "Initial-value problem for a first-order ODE",
        differential_equation,
    ),
    Family(
        "6.1",
        "Probability",
        "Conditional probability from overlapping counts",
        conditional_probability,
    ),
    Family(
        "6.2", "Discrete random variables", "Exact binomial point probability", binomial
    ),
    Family(
        "6.3",
        "Normal distribution",
        "Probability for a sum of independent normals",
        normal_sum,
    ),
    Family(
        "6.4",
        "Sampling",
        "Standard error of an independent sample mean",
        standard_error,
    ),
    Family(
        "6.5",
        "Hypothesis testing",
        "One-tailed z-test with known variance",
        one_sided_test,
    ),
    Family(
        "6.6",
        "Correlation and linear regression",
        "Regression and interpolation from summary statistics",
        regression,
    ),
) + variance_families.FAMILIES
