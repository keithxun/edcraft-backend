"""Wire types for constrained H2 authoring and deterministic reuse."""

from typing import Final, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domain_types import Difficulty
from edcraft_validator.validation.property_summary import PropertyCheckSummary

Subject = Literal["math", "code"]
FORMAT: Final = "h2-2026.2"


class ClosedModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class TaskRequirement(ClosedModel):
    value: str = Field(min_length=1, max_length=64)
    wording: str = Field(min_length=1, max_length=16000)


class Proposal(ClosedModel):
    family: str = Field(min_length=1, max_length=80)
    example_answer: str = Field(min_length=1, max_length=400)
    allowed_cases: list[int] | None = Field(
        default=None,
        description="Sorted zero-based curated case numbers fulfilling the request. "
        "Use null for the whole family or a parameterised family.",
    )


class Candidate(Proposal):
    quoted_requirements: list[TaskRequirement] | None = Field(
        default=None, exclude_if=lambda v: v is None, max_length=16
    )
    subject: Subject
    template_id: str
    difficulty: Difficulty
    required: int = Field(ge=1, le=10)


class H2ValidationSummary(PropertyCheckSummary):
    validator_version: Literal["mcp-h2-2026-v1"] = "mcp-h2-2026-v1"


class CheckedTemplate(ValidatedTemplateArtifact):
    model_config = ConfigDict(extra="forbid", strict=True)
    format_version: Literal["h2-2026.2"] = FORMAT
    template: Candidate
    family_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    selected_slots: list[int] = Field(min_length=1, max_length=10)
    validation: H2ValidationSummary

    @model_validator(mode="after")
    def check_selection(self) -> Self:
        if (
            len(self.selected_slots) != self.template.required
            or len(set(self.selected_slots)) != self.template.required
            or any(slot < 0 or slot >= 13 for slot in self.selected_slots)
        ):
            raise ValueError("Saved H2 option selection does not match the request")
        if self.authoring and self.authoring.domain != self.template.subject:
            raise ValueError(
                "Saved H2 template subject conflicts with its authoring record"
            )
        return self


class Question(ClosedModel):
    template_id: str
    artifact_id: str | None
    topic: str
    family: str
    seed: int
    parameters: dict[str, int]
    question: str
    choices: list[str]
    answer: str
    correct_index: int
    requires_manual_review: Literal[True] = True
