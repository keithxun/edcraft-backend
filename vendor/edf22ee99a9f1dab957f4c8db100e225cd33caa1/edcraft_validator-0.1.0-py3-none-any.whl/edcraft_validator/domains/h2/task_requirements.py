"""Check quoted author interpretations against capabilities of trusted task variants."""

import re

from pydantic import Field

from edcraft_validator.domains.h2.schemas import (
    ClosedModel,
    Proposal,
)
from edcraft_validator.domains.h2.schemas import (
    TaskRequirement as TaskRequirement,
)
from edcraft_validator.validation.distractor_pool import DistractorPoolError


class RequirementSelection(ClosedModel):
    value: str = Field(min_length=1, max_length=64)
    clause: int = Field(ge=0, description="Zero-based teacher clause number.")


class AuthoredProposal(Proposal):
    task_requirements: list[RequirementSelection] = Field(
        default_factory=list, max_length=16
    )


def teacher_clauses(prompt: str) -> list[str]:
    return [
        chunk.strip()
        for chunk in re.split(r"(?<=[.!?;])\s+|\n+", prompt)
        if chunk.strip()
    ]


def resolve_requirements(
    prompt: str, selections: list[RequirementSelection]
) -> list[TaskRequirement]:
    clauses = teacher_clauses(prompt)
    if any(s.clause >= len(clauses) for s in selections):
        raise DistractorPoolError("Use the numbered clauses in the teacher request.")
    return [
        TaskRequirement(value=s.value, wording=clauses[s.clause]) for s in selections
    ]


# Each entry describes a complete family, or an individual legacy case below.
# A capability absent from the entry cannot be asserted by the author.
FAMILY_TASKS = {
    "5.3.parts-antiderivative": {"parts_antiderivative"},
    "4.1.cartesian-conjugate": {"cartesian_conjugate"},
    "1.3.preorder": {"preorder_traversal"},
    "6.4.variance-totals": {"summary_totals", "unbiased_variance"},
    "6.4.variance-raw-observations": {"raw_observations", "unbiased_variance"},
    "6.4.variance-shifted-totals": {
        "summary_totals",
        "shifted_origin",
        "unbiased_variance",
    },
    "6.4.variance-coded-totals": {
        "summary_totals",
        "affine_scale",
        "unbiased_variance",
    },
    "6.4.variance-corrected-totals": {
        "summary_totals",
        "affine_scale",
        "recording_error",
        "unbiased_variance",
    },
    "6.4.variance-combined-shifted-totals": {
        "summary_totals",
        "shifted_origin",
        "two_groups",
        "unbiased_variance",
    },
    "2.4.boundary-predicate": {"boolean_predicate"},
    "1.2.merge-output": {"concrete_runs", "complete_merged_run"},
    "1.2.stable-merge-output": {
        "concrete_runs",
        "complete_merged_run",
        "stable_ties",
        "record_identities",
    },
    "1.2.merge-tie-rule": {"tie_rule", "stable_ties"},
    "1.2.merge-step": {"concrete_runs", "next_heads"},
    "1.2.merge-trace": {
        "concrete_runs",
        "next_heads",
        "next_writes",
        "stable_ties",
        "record_identities",
    },
    "1.3.circular-queue-conditional": {"wraparound", "queue_state", "later_operation"},
    "1.3.circular-queue-trace": {"wraparound", "queue_state", "later_operation"},
}
CASE_TASKS = {
    "4.1.conjugation": ({"cartesian_conjugate"}, {"conjugate_root"}),
    "6.4.unbiased-estimates": (
        {"summary_totals", "mean_and_variance"},
        {"summary_totals", "shifted_origin", "mean_and_variance"},
        {"raw_observations", "mean_and_variance"},
    ),
    "1.2.merge-sort": ({"concrete_runs", "next_heads"}, {"stable_ties", "tie_rule"}),
    "2.4.range-check": ({"invalid_values"}, {"boolean_predicate"}),
}
# A citation must mention the concept it is being offered as evidence for.
# These checks reject unrelated clauses; interpretation of full prose remains
# part of authoring and teacher review. They do not validate answer keys.
TERM_CUES = {
    "parts_antiderivative": r"integration by parts|integrat(?:e|ing) by parts",
    "cartesian_conjugate": r"conjugat|cartesian",
    "conjugate_root": r"root|polynomial",
    "preorder_traversal": r"pre[- ]?order|root[- ,]+left|depth.first",
    "summary_totals": r"sum|total|aggregate|[Σ∑]",
    "unbiased_variance": r"varianc|unbiased|bias",
    "raw_observations": r"raw|observations|scores|individual (?:values|readings)",
    "shifted_origin": r"origin|shift|deviation|assumed mean|cod(?:e|ing)",
    "affine_scale": r"scale|scaling|affine|cod(?:e|ing)",
    "recording_error": (
        r"error|wrong|misrecord|miscop|incorrect (?:entry|value)|"
        r"correct(?:ing|ed)? (?:a |the )?(?:record|measurement|entry)"
    ),
    "two_groups": r"group|batch|pool|combine|class(?:es)?",
    "mean_and_variance": r"mean|variance",
    "boolean_predicate": r"boolean|predicate|condition|range check",
    "invalid_values": r"invalid|reject|out.of.range",
    "concrete_runs": r"runs|lists|arrays|sequences",
    "complete_merged_run": r"complete|output|result|sequence|ordered|produces",
    "stable_ties": r"stab[il]|equal|ties|duplicate",
    "record_identities": r"record|identit|tag|origin",
    "tie_rule": r"tie|equal|advanc|stability",
    "next_heads": r"head|next|comparison|compare",
    "next_writes": r"writes?|emit|next",
    "wraparound": r"wrap|circular",
    "queue_state": r"queue|state|pointer|contents",
    "later_operation": r"subsequent|later|next|then|after|dequeue|removed",
}


# Extra conditions change the teacher's task and need affirmative evidence.
EXTRA_CONDITIONS = {"recording_error", "two_groups"}


QUEUE_OUTPUTS = {
    "1.3": "front",
    "1.3.circular-queue": "mixed",
    "1.3.circular-queue-trace": "mixed",
    "1.3.circular-queue-conditional": "state",
}
_NEXT_QUEUE_ITEM = (
    r"(?:which|what) (?:item|value) (?:(?:will|would|should) be |is |gets )?"
    r"(?:removed|dequeued) next"
)
_QUEUE_STATE = r"(?:the )?(?:final |resulting )?queue state"
_QUEUE_OUTPUT_LIMITS = {
    "front": r"front(?: index| pointer)?",
    "state": r"queue state",
    "single": (
        r"next (?:item|value)(?: to be (?:removed|dequeued))?"
        r"|next (?:removed|dequeued) (?:item|value)"
        r"|(?:logical |FIFO |queue )?contents(?: in FIFO order)?"
        r"|FIFO order|(?:stored |backing )?array|size|count|nextWrite|write index"
    ),
}


def accepts_queue_output(family: str, prompt: str) -> bool:
    output = QUEUE_OUTPUTS.get(family)
    if output is None:
        return True
    if re.search(
        r"\b(?:without (?:(?:asking|reporting|giving|showing) )?|"
        r"(?:do not|don't) (?:ask|report|give|show) )(?:for )?(?:the )?"
        r"(?:queue )?(?:front(?: index| pointer)?|indices|pointers)\b",
        prompt,
        re.I,
    ):
        return False
    for clause in teacher_clauses(prompt):
        if clause_mentions(rf"\b{_NEXT_QUEUE_ITEM}\b", clause):
            # A state-only item fulfils the state alternative in either order.
            return output == "state" and bool(
                re.search(
                    rf"\bqueue state or {_NEXT_QUEUE_ITEM}\b"
                    rf"|\b{_NEXT_QUEUE_ITEM} or (?:for )?{_QUEUE_STATE}\b",
                    clause,
                    re.I,
                )
            )
    for needed, wording in _QUEUE_OUTPUT_LIMITS.items():
        target = rf"(?:the )?(?:final |resulting )?(?:{wording})"
        if re.search(
            rf"\b(?:only|just) (?:(?:ask|require)(?: students? to)? )?"
            rf"(?:(?:report|give|show|identify|determine) )?(?:for )?{target}\b"
            rf"|\b{target} (?:only|alone|and nothing else)\b",
            prompt,
            re.I,
        ):
            return output == needed
    return True


def supported_requirements(offered: tuple[str, ...] | list[str]) -> list[str]:
    return sorted(
        set().union(
            *(
                tasks
                for family in offered
                for tasks in (
                    FAMILY_TASKS.get(family, set()),
                    *CASE_TASKS.get(family, ()),
                )
            )
        )
    )


def clause_mentions(cue: str, wording: str) -> bool:
    # Punctuation bounds this local negation check so independent alternatives
    # can still provide evidence. A bias-free estimator is a positive requirement.
    text = re.sub(r"\b(?:without|no)\s+bias\b", "unbiased", wording, flags=re.I)
    negated = re.compile(
        r"\b(?:not(?!\s+(?:only|just)\b)|no|never|without|avoid|exclude|"
        r"except|unless|cannot|can['’]t|instead of|rather than|don['’]t)"
        r"\b[^,;:.!?]*$",
        re.I,
    )
    return any(
        not negated.search(text[: m.start()]) for m in re.finditer(cue, text, re.I)
    )


def compatible_cases(
    family: str,
    cases: list[int] | None,
    prompt: str,
    requirements: list[TaskRequirement],
) -> bool:
    terms = {r.value for r in requirements}

    def normalize(s: str) -> str:
        return " ".join(s.casefold().split())

    if any(normalize(r.wording) not in normalize(prompt) for r in requirements):
        raise DistractorPoolError(
            "Requirement wording must quote the original teacher request."
        )
    for req in requirements:
        cue = TERM_CUES.get(req.value)
        if cue is None or not clause_mentions(cue, req.wording):
            raise DistractorPoolError(
                f"The cited wording does not describe {req.value!r}. "
                "Cite its teacher clause or revise the interpretation."
            )
    if family in CASE_TASKS:
        variants = CASE_TASKS[family]
        selected = range(len(variants)) if cases is None else cases
        return bool(selected) and all(
            0 <= i < len(variants) and terms <= variants[i] for i in selected
        )
    offered = FAMILY_TASKS.get(family, set())
    explicit = re.match(
        rf"^\s*(?:Singapore\s+)?H2\s+(?:skill\s+)?{re.escape(family)}(?:\b|$)",
        prompt,
        re.IGNORECASE,
    )
    return terms <= offered and (
        (offered & EXTRA_CONDITIONS) <= terms or bool(explicit)
    )
