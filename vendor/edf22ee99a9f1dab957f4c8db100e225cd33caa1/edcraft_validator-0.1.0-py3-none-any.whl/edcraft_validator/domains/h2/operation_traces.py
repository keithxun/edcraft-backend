"""Computing families that distinguish an algorithm's rule from a concrete trace."""

from itertools import pairwise, permutations
from typing import NamedTuple

from edcraft_validator.domains.h2.families import Family, Item, question

Record = tuple[int, str]


class MergeWrite(NamedTuple):
    left_head: str
    right_head: str
    record: Record


def _merge_inputs(case: int) -> tuple[list[Record], list[Record]]:
    layouts = (
        ((1, 3, 5, 7, 10, 13), (2, 3, 4, 7, 9, 12)),
        ((2, 4, 5, 8, 9, 12), (1, 4, 6, 8, 10, 13)),
        ((1, 2, 4, 6, 9, 11), (2, 3, 4, 7, 10, 12)),
        ((1, 4, 6, 8, 9, 13), (2, 3, 4, 5, 8, 11)),
    )
    left, right = layouts[case % len(layouts)]
    scale, offset = 1 + case // 4 % 4, 3 + case // 16
    # Rotate the record tags independently of the key layout.
    rotation = case // 8 % 26
    tags = [chr(ord("A") + (rotation + 7 * i) % 26) for i in range(12)]
    return (
        [(offset + scale * key, tag) for key, tag in zip(left, tags[:6], strict=True)],
        [(offset + scale * key, tag) for key, tag in zip(right, tags[6:], strict=True)],
    )


def _merge(
    left: list[Record], right: list[Record], *, right_ties: bool = False
) -> list[MergeWrite]:
    """Record the run heads before each write, including writes after exhaustion."""
    i = j = 0
    writes = []
    while i < len(left) or j < len(right):
        a = left[i] if i < len(left) else None
        b = right[j] if j < len(right) else None
        take_left = a is not None and (
            b is None or a[0] < b[0] or (a[0] == b[0] and not right_ties)
        )
        if take_left:
            record = left[i]
            i += 1
        else:
            record = right[j]
            j += 1
        writes.append(MergeWrite(a[1] if a else "–", b[1] if b else "–", record))
    return writes


def _tags(writes: list[MergeWrite]) -> list[str]:
    return [write.record[1] for write in writes]


def _tagged_stem(left: list[Record], right: list[Record]) -> str:
    return (
        "In merge sort, the left run precedes the right run in the original input.\n"
        f"Left run (key, tag): {left}\nRight run (key, tag): {right}\n"
        "Merge the runs stably in ascending order by key. Compare the first unused "
        "record from each run until a run is exhausted, then append the other "
        "run's remaining records in order."
    )


def _trace_label(heads: tuple[str, str], tags: list[str]) -> str:
    return f"Heads {', '.join(heads)}; next {', '.join(tags[:3])}"


def merge_trace(case: int) -> Item:
    left, right = _merge_inputs(case)
    writes = _merge(left, right)
    tied_key = max(set(dict(left)) & set(dict(right)))
    tie = next(i for i, write in enumerate(writes) if write.record[0] == tied_key)
    checkpoint = tie - case // 4 % 2
    heads = writes[checkpoint][:2]
    next_tags = _tags(writes[checkpoint:])
    left_tie, right_tie = writes[tie][:2]
    reversed_ties = _merge(left, right, right_ties=True)
    return question(
        _tagged_stem(left, right)
        + f" Immediately after writing {checkpoint} records, which tags are at the "
        "heads of the two runs (left, then right), and which three tags are "
        "written next, in order?",
        _trace_label(heads, next_tags),
        (
            _trace_label(
                reversed_ties[checkpoint][:2], _tags(reversed_ties[checkpoint:])
            ),
            _trace_label(heads, [tag for tag in next_tags if tag != left_tie]),
            _trace_label(heads, [tag for tag in next_tags if tag != right_tie]),
            _trace_label(writes[checkpoint - 1][:2], _tags(writes[checkpoint - 1 :])),
            _trace_label(writes[checkpoint + 1][:2], next_tags[1:]),
            _trace_label(heads[::-1], next_tags),
        ),
    )


def stable_merge_output(case: int) -> Item:
    left, right = _merge_inputs(case)
    writes = _merge(left, right)
    tags = _tags(writes)
    scores = [write.record[0] for write in writes]
    ties = [i for i, (a, b) in enumerate(pairwise(scores)) if a == b]
    first_tie, second_tie = ties
    prefix = tags[: second_tie - 1]
    wrong = (
        _tags(_merge(left, right, right_ties=True)),
        prefix + [tag for _, tag in left + right if tag not in prefix],
        tags[:-2] + tags[-2:][::-1],
        tags[:first_tie]
        + tags[first_tie : first_tie + 2][::-1]
        + tags[first_tie + 2 :],
        tags[:second_tie]
        + tags[second_tie : second_tie + 2][::-1]
        + tags[second_tie + 2 :],
        tags[1::-1] + tags[2:],
        tags[:second_tie] + tags[second_tie + 1 :],
        tags[: second_tie + 2] + tags[second_tie + 1 :],
        tags[:-1],
        [tag for _, tag in left + right],
        [tag for _, tag in right + left],
        tags[::-1],
        tags[: first_tie + 1] + tags[first_tie + 2 :],
    )
    return question(
        _tagged_stem(left, right)
        + " What is the complete order of tags in the output after this merge?",
        ", ".join(tags),
        (", ".join(option) for option in wrong),
    )


def merge_output(case: int) -> Item:
    tagged_left, tagged_right = _merge_inputs(case)
    # Offset the right keys to produce distinct values without changing the layout.
    left = [(2 * key, tag) for key, tag in tagged_left]
    right = [(2 * key + 1, tag) for key, tag in tagged_right]
    keys = [write.record[0] for write in _merge(left, right)]
    l_values = [key for key, _ in left]
    r_values = [key for key, _ in right]
    if l_values[0] > r_values[0]:
        wrong_first = [l_values[0], *(w.record[0] for w in _merge(left[1:], right))]
    else:
        wrong_first = [r_values[0], *(w.record[0] for w in _merge(left, right[1:]))]
    return question(
        "In merge sort, these two runs are already in ascending order.\n"
        f"Left run: {l_values}\nRight run: {r_values}\n"
        "What is the complete output after merging them in ascending order?",
        keys,
        (
            wrong_first,
            keys[:-1],
            keys[:4] + [key for key in l_values + r_values if key not in keys[:4]],
            keys[:3] + keys[4:],
            keys[:4] + keys[3:],
            keys[:4] + keys[4:6][::-1] + keys[6:],
            l_values + r_values,
            r_values + l_values,
            keys[::-1],
            keys[:-2] + keys[-2:][::-1],
            keys[:-2],
            keys[1:],
            keys[:1] + keys,
        ),
    )


def merge_step(case: int) -> Item:
    base, stride = 1 + case % 32, 1 + case // 32
    small, large = base, base + stride
    if case % 2 == 0:
        left, right = [small, small + 2 * stride], [large, large + 3 * stride]
        after_small, after_large = (left[1], right[0]), (left[0], right[1])
    else:
        left, right = [large, large + 3 * stride], [small, small + 2 * stride]
        after_small, after_large = (left[0], right[1]), (left[1], right[0])
    return question(
        "Merge sort is about to merge two ascending runs. "
        f"The unused portions are {left} (left) and {right} (right). "
        "Which value is written at the next comparison and which values are compared "
        "immediately afterwards (left head, then right head)?",
        (small, *after_small),
        (
            (large, *after_large),
            (small, left[1], right[1]),
            (small, left[0], right[0]),
            (large, left[0], right[0]),
            (small, *after_large),
            (large, left[1], right[1]),
        ),
    )


def merge_tie_rule(case: int) -> Item:
    key = 1 + case
    return question(
        f"During a merge, the first unused records L and R both have key {key}. "
        "L comes from the left run and preceded R in the original input. "
        "What should a stable merge write at this comparison, and which run "
        "should it advance?",
        "Write L and advance the left run only",
        (
            "Write R and advance the right run only",
            "Write L and advance both runs",
            "Write R and advance both runs",
            "Write L and advance the right run only",
            "Write R and advance the left run only",
            "Write L and keep both run positions unchanged",
        ),
    )


class QueueResult(NamedTuple):
    rejected: list[int]
    removed: list[int]
    front: int
    write: int
    fifo: list[int]


def _circular_queue(
    capacity: int,
    front: int,
    initial: list[int],
    operations: list[int | None],
    *,
    overwrite: bool = False,
) -> QueueResult:
    """Run a circular buffer. An integer enqueues it and None requests a dequeue."""
    slots = [0] * capacity
    count = len(initial)
    write = (front + count) % capacity
    for i, initial_value in enumerate(initial):
        slots[(front + i) % capacity] = initial_value
    rejected: list[int] = []
    removed: list[int] = []
    for value in operations:
        if value is None:
            if count:
                removed.append(slots[front])
                front = (front + 1) % capacity
                count -= 1
            continue
        if count == capacity:
            if not overwrite:
                rejected.append(value)
                continue
            front = (front + 1) % capacity
            count -= 1
        slots[write] = value
        write = (write + 1) % capacity
        count += 1
    fifo = [slots[(front + i) % capacity] for i in range(count)]
    return QueueResult(rejected, removed, front, write, fifo)


def _queue_label(result: QueueResult) -> str:
    return (
        f"Rejected {result.rejected}; removed {result.removed}; "
        f"(front, nextWrite) = {(result.front, result.write)}; FIFO {result.fifo}"
    )


def circular_queue_trace(case: int) -> Item:
    capacity, extra_cycle = 5 + case % 4, case // 4 % 2
    front, count = capacity - 1, capacity - 2
    initial = [10 + case * 16 + i * (1 + extra_cycle) for i in range(count)]
    a, b, c, d, e, f = range(initial[-1] + 1, initial[-1] + 7)
    operations = [a, b, c, None, d, None, e]
    last_arrival = e
    if extra_cycle:
        operations.extend([None, f])
        last_arrival = f
    start_write = (front + count) % capacity
    result = _circular_queue(capacity, front, initial, operations)
    listed = ", ".join(
        "Dequeue()" if v is None else f"Enqueue({v})" for v in operations
    )
    physical_start = capacity - result.front
    wrong = (
        _circular_queue(capacity, front, initial, operations, overwrite=True),
        _circular_queue(capacity, front, initial, operations[:-1]),
        result._replace(write=(result.write - 1) % capacity),
        result._replace(
            fifo=result.fifo[physical_start:] + result.fifo[:physical_start]
        ),
        result._replace(removed=result.removed[::-1]),
        _circular_queue(capacity, front, initial, operations[:-2] + operations[-1:]),
        _circular_queue(capacity, front, initial, operations[1:]),
        _circular_queue(capacity, front, initial, operations[:4] + operations[5:]),
        _circular_queue(capacity, 0, initial, operations),
        result._replace(front=(result.front - 1) % capacity),
        result._replace(fifo=result.fifo[::-1]),
        result._replace(rejected=result.rejected + [last_arrival]),
        result._replace(removed=result.removed[:-1]),
    )
    return question(
        f"A circular queue has capacity {capacity}; front {front}; "
        f"nextWrite {start_write}.\n"
        f"Initial contents in FIFO order: {initial}\n"
        "Indices run from zero to capacity minus one. front is the next removal "
        "index, nextWrite is the index used by the next successful enqueue, and "
        "each index wraps to zero after advancing past the last slot. A separate "
        "count distinguishes full from empty. An enqueue on a full queue or a "
        "dequeue on an empty queue is rejected and leaves the queue unchanged.\n"
        f"Apply these operations from left to right: {listed}.\n"
        "Which enqueue values are rejected, which values do the dequeues return "
        "in order, and what are the final indices and queue contents in FIFO order?",
        _queue_label(result),
        (_queue_label(option) for option in wrong),
    )


class QueueBuffer(NamedTuple):
    array: tuple[int, ...]
    front: int
    size: int

    def peek(self) -> int:
        assert self.size > 0
        return self.array[self.front]

    def dequeue(self) -> "QueueBuffer":
        assert self.size > 0
        return self._replace(
            front=(self.front + 1) % len(self.array), size=self.size - 1
        )

    def enqueue(self, value: int) -> "QueueBuffer":
        assert self.size < len(self.array)
        array = list(self.array)
        array[(self.front + self.size) % len(array)] = value
        return self._replace(array=tuple(array), size=self.size + 1)


def conditional_queue_trace(case: int) -> Item:
    capacity = 5 + case % 4
    front = capacity - 4
    pivot = 28 + case // 16
    first = pivot + 13 if case & 4 else pivot - 14
    before_wrap = (pivot - 5, pivot + 6)
    if case & 8:
        before_wrap = before_wrap[::-1]
    array = [pivot + 20 + i for i in range(capacity)]
    array[front] = first
    a, b = pivot + 10, pivot - 9

    start = QueueBuffer(tuple(array), front, 1)
    ready = start.dequeue().enqueue(before_wrap[0]).enqueue(before_wrap[1])
    take_extra = ready.peek() < start.peek()
    before_writes = ready.dequeue() if take_extra else ready
    other_path = ready if take_extra else ready.dequeue()
    order = (a, b) if before_writes.peek() < pivot else (b, a)
    correct = before_writes.enqueue(order[0]).enqueue(order[1]).dequeue()

    def label(state: QueueBuffer) -> str:
        return (
            f"front = {state.front}, size = {state.size}, array = {list(state.array)}"
        )

    def relabel_writes(state: QueueBuffer, values: tuple[int, ...]) -> str:
        penultimate, last, zero = values
        array = (zero, *state.array[1:-2], penultimate, last)
        return label(state._replace(array=array))

    # Dequeue leaves storage alone. Both paths therefore write the same
    # positions, and the answer can test the metadata and array separately.
    other = other_path.enqueue(order[0]).enqueue(order[1]).dequeue()
    written = (before_wrap[1], *order)
    reversed_order = (before_wrap[1], *order[::-1])
    alternatives = [
        relabel_writes(correct, reversed_order),
        label(other),
        relabel_writes(other, reversed_order),
    ]
    for values in permutations(written):
        if values[0] != before_wrap[1]:
            alternatives.extend(
                (relabel_writes(other, values), relabel_writes(correct, values))
            )
    return question(
        f"A circular queue starts with this array in index order: {array}\n"
        f"The initial front index is {front} and size is {start.size}.\n"
        "Indices start at 0 and size counts occupied slots. "
        "Peek() reads the front item without removing it. "
        "Dequeue() returns that item, advances front with wraparound, and reduces "
        "size without clearing the array cell. Enqueue() writes to index "
        "(front + size) MOD the array length, then increases size.\n"
        "x = Dequeue()\n"
        f"Enqueue({before_wrap[0]}), Enqueue({before_wrap[1]})\n"
        "IF Peek() < x THEN Dequeue()\n"
        f"IF Peek() < {pivot} THEN Enqueue({a}), Enqueue({b})\n"
        f"ELSE Enqueue({b}), Enqueue({a})\n"
        "Dequeue()\n"
        "What is the resulting queue state "
        "(front, size and stored array in index order)?",
        label(correct),
        alternatives,
    )


FAMILIES = (
    Family(
        "1.2.merge-trace",
        "Fundamental algorithms",
        "Trace an intermediate stable merge of concrete tagged runs and the "
        "next three writes after a checkpoint",
        merge_trace,
        (MergeWrite, _merge_inputs, _merge, _tags, _tagged_stem, _trace_label),
    ),
    Family(
        "1.2.stable-merge-output",
        "Fundamental algorithms",
        "Determine the complete order of tagged records after a stable merge "
        "of two sorted runs with multiple cross-run ties",
        stable_merge_output,
        (MergeWrite, _merge_inputs, _merge, _tags, _tagged_stem),
    ),
    Family(
        "1.2.merge-output",
        "Fundamental algorithms",
        "Determine the complete numerical output from merging two sorted runs",
        merge_output,
        (MergeWrite, _merge_inputs, _merge),
    ),
    Family(
        "1.2.merge-step",
        "Fundamental algorithms",
        "Trace one routine merge-sort comparison and the resulting concrete run heads",
        merge_step,
    ),
    Family(
        "1.2.merge-tie-rule",
        "Fundamental algorithms",
        "Identify which run a stable merge takes and advances on one equal-key tie",
        merge_tie_rule,
    ),
    Family(
        "1.3.circular-queue-conditional",
        "Data structures",
        "Trace a circular queue that wraps around, then removes an item. "
        "Determine the resulting queue state after data-dependent operations "
        "(front, size and the stored array)",
        conditional_queue_trace,
        (QueueBuffer,),
    ),
    Family(
        "1.3.circular-queue-trace",
        "Data structures",
        "Trace circular queue contents, full-state rejection and subsequent FIFO "
        "operations after the read or write index wraps around",
        circular_queue_trace,
        (QueueResult, _circular_queue, _queue_label),
    ),
)


REQUIRED_CONTRASTS = {
    "1.2.merge-trace": (
        (0, "Takes the right run first on an equal key"),
        (1, "Advances the left run past an equal key without writing its record"),
    ),
    "1.2.stable-merge-output": (
        (0, "Takes the right run first on an equal key"),
        (1, "Stops comparing too soon and appends both unfinished runs in turn"),
    ),
    "1.2.merge-output": (
        (0, "Writes the larger of the first compared keys before the smaller one"),
        (1, "Omits the last write when appending the remaining run"),
    ),
    "1.3.circular-queue-conditional": (
        (0, "Reverses the order of the two enqueues with the right front and size"),
        (1, "Takes the wrong optional dequeue branch with the right stored array"),
        (2, "Takes the wrong dequeue branch and uses its enqueue order"),
    ),
    "1.3.circular-queue-trace": (
        (0, "Overwrites the oldest record when a full queue must reject an enqueue"),
        (1, "Skips the final enqueue following wraparound"),
    ),
}
