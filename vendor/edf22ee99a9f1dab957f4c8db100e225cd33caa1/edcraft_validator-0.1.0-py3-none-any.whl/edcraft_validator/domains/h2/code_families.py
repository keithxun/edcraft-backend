"""Original H2 Computing 9569 classroom scenarios and programs."""

from edcraft_validator.domains.h2.families import Family, Item, question
from edcraft_validator.domains.h2.operation_traces import FAMILIES as TRACE_FAMILIES


def boundary_predicate(i: int) -> Item:
    low = i % 31 - 15
    high = low + 4 + (i // 31) % 13
    left_closed = bool(i % 2)
    left = ">=" if left_closed else ">"
    right = "<" if left_closed else "<="
    flip_left = ">" if left_closed else ">="
    flip_right = "<=" if left_closed else "<"
    return question(
        f"A real reading x must be {'at least' if left_closed else 'greater than'} "
        f"{low} and {'less than' if left_closed else 'at most'} {high}. "
        "Which Boolean predicate accepts exactly the valid readings?",
        f"x {left} {low} and x {right} {high}",
        (
            f"x {flip_left} {low} and x {right} {high}",
            f"x {left} {low} and x {flip_right} {high}",
            f"x {flip_left} {low} and x {flip_right} {high}",
            f"x {left} {low} or x {right} {high}",
            f"x < {low}",
            f"x > {high}",
        ),
    )


def decision_table(i: int) -> Item:
    # Each row is a reviewed Boolean rule and the count of true truth-table rows.
    policies = (
        ("A and (B or C)", 3, (1, 2, 4, 5, 6, 7)),
        ("A or (B and C)", 5, (1, 2, 3, 4, 6, 7)),
        ("A and B and not C", 1, (2, 3, 4, 5, 6, 7)),
        ("exactly two of A, B and C are true", 3, (1, 2, 4, 5, 6, 7)),
    )
    policy, count, alternatives = policies[i % len(policies)]
    action = ("grant a discount", "request an inspection", "reserve a slot")[
        i // len(policies) % 3
    ]
    return question(
        "A decision table has three independent Boolean conditions A, B and C. "
        f"The action is to {action} precisely when {policy}. How many "
        "uncompressed rules perform the action?",
        count,
        alternatives,
    )


def binary_search(i: int) -> Item:
    k = 3 + i % 9
    return question(
        "Binary search probes the middle element of a sorted array of "
        f"{2**k - 1} distinct "
        "keys, then continues in one half. Count one probe for each element inspected. "
        "What is the maximum number of probes for a successful search?",
        k,
        (k + 1, k - 1, 2**k - 1, 2 ** (k - 1), 2 * k, 1),
    )


def circular_queue(i: int) -> Item:
    size, front = 7 + i % 9, 3 + i // 9 % 4
    remove = size - front + 1 + i // 36 % 2
    return question(
        f"A circular queue has {size} slots numbered 0 to {size - 1}. Its front "
        f"index is {front}. After {remove} successful removals, advancing front "
        "after each removal, what is the new front index?",
        (front + remove) % size,
        (
            front + remove,
            (front + remove - 1) % size,
            (front + remove + 1) % size,
            (front - remove) % size,
            size - 1,
            front,
        ),
    )


def naming(i: int) -> Item:
    pairs = (
        (
            "total of all accepted prices",
            "running_total",
            "largest_price",
            "input_text",
            "has_discount",
        ),
        (
            "number of rejected records",
            "rejected_count",
            "last_record",
            "is_valid",
            "record_length",
        ),
        (
            "index of the next free slot",
            "next_free_index",
            "item_count",
            "first_value",
            "has_space",
        ),
        (
            "whether a match has been found",
            "match_found",
            "search_key",
            "match_index",
            "total_matches",
        ),
    )
    meaning, key, *others = pairs[i % len(pairs)]
    return question(
        f"A programmer is renaming a variable that stores the {meaning}. "
        "Which Python identifier most clearly describes its recorded meaning?",
        key,
        others,
    )


def slicing(i: int) -> Item:
    first, step = 3 + i % 12, 2 + i // 12 % 5
    values = [first + j * step for j in range(7)]
    return question(
        f"For nums = {values}, what does Python return for sum(nums[1:6:2])?",
        sum(values[1:6:2]),
        (
            sum(values[1:6]),
            sum(values[0:6:2]),
            sum(values[1:5:2]),
            sum(values[1:7]),
            sum(values),
            sum(values[2:6:2]),
        ),
    )


def insertion_pass(i: int) -> Item:
    base, step = 1 + i % 20, 1 + i // 20 % 5
    a, b, c, d = [base + j * step for j in range(4)]
    return question(
        f"In ascending insertion sort, the sorted prefix is [{b}, {d}]. "
        f"The remaining elements are [{a}, {c}]. Which array results immediately "
        "after inserting only the next element?",
        [a, b, d, c],
        (
            [a, b, c, d],
            [b, d, a, c],
            [b, a, d, c],
            [b, c, d, a],
            [d, b, a, c],
            [a, d, b, c],
        ),
    )


def boundaries(i: int) -> Item:
    lo, hi = 10 + i % 21, 55 + i // 21 % 17
    return question(
        f"An integer is valid from {lo} to {hi} inclusive. Which four tests check "
        "the two valid endpoints and the nearest invalid integer at each end?",
        (lo - 1, lo, hi, hi + 1),
        (
            (lo, lo + 1, hi - 1, hi),
            (lo - 2, lo, hi, hi + 2),
            (lo - 1, lo + 1, hi - 1, hi + 1),
            (lo - 1, lo, hi - 1, hi),
            (lo, lo + 1, hi, hi + 1),
            (lo - 2, lo - 1, hi + 1, hi + 2),
        ),
    )


def dynamic_dispatch(i: int) -> Item:
    fee, extra = 12 + i % 17, 3 + i // 17 % 8
    stem = (
        f"Consider the following Python code.\n\nclass Ticket:\n"
        f"    def price(self):\n        return {fee}\n\nclass Express(Ticket):\n"
        f"    def price(self):\n        return super().price() + {extra}\n\n"
        "tickets = [Ticket(), Express(), Express()]\n"
        "What is sum(t.price() for t in tickets)?"
    )
    return question(
        stem,
        3 * fee + 2 * extra,
        (
            3 * fee,
            3 * (fee + extra),
            fee + 2 * extra,
            2 * fee + extra,
            3 * fee + extra,
            2 * (fee + extra),
        ),
    )


def base_conversion(i: int) -> Item:
    value = 5 + i % 239
    digits = f"{value:08b}"
    return question(
        f"A positive integer is stored in binary as {digits}. "
        "What is its value in denary?",
        value,
        (
            int(digits[::-1], 2),
            2 * value,
            value // 2,
            int(digits),
            255 - value,
            value + 256,
        ),
    )


def encoding(i: int) -> Item:
    single, double, triple = 3 + i % 11, 2 + i // 11 % 7, 1 + i // 77 % 4
    return question(
        f"A UTF-8 text contains {single} one-byte characters, {double} two-byte "
        f"characters and {triple} three-byte characters. Excluding any header, "
        "how many bytes does the encoded text occupy?",
        single + 2 * double + 3 * triple,
        (
            single + double + triple,
            4 * (single + double + triple),
            single + double + 3 * triple,
            8 * (single + 2 * double + 3 * triple),
            single + 2 * double + triple,
            2 * (single + double + triple),
        ),
    )


def join_count(i: int) -> Item:
    a, b = 2 + i % 9, 3 + i // 9 % 7
    return question(
        f"Table Customer has three rows with distinct IDs. Orders contains {a} "
        f"rows for the first customer, {b} for the second, and none for the third. "
        "Every order references exactly one customer. How many rows does a "
        "LEFT JOIN from Customer to Orders on customer ID return?",
        a + b + 1,
        (a + b, 3, a * b, 3 * (a + b), a + b + 3, 1),
    )


def ethical_design(i: int) -> Item:
    cases = (
        (
            "A library wants only an aggregate count of daily visits. Which "
            "design meets that purpose "
            "while minimising personal data collection?",
            "Increment an anonymous daily counter",
            (
                "Store names and birth dates with each visit",
                "Store a persistent visitor identifier alongside each visit",
                "Keep a dated list of named visitors and calculate its length",
            ),
        ),
        (
            "An automated scholarship shortlist has a substantially higher "
            "error rate for one student "
            "group. Which response directly investigates the reported "
            "disparity before deployment?",
            "Compare errors across groups using appropriately governed evaluation data",
            (
                "Increase the global accuracy threshold without examining "
                "subgroup errors",
                "Balance the overall training set by award outcome alone",
                "Assume the overall accuracy applies equally to every group",
            ),
        ),
        (
            "A team must tell users why it requests location data before they "
            "choose whether to share it. "
            "Which design best supports that requirement?",
            "Explain the purpose at the point of choice",
            (
                "Record the purpose in an internal audit log only",
                "Start tracking before displaying the request",
                "Explain the purpose only in a confirmation sent after collection",
            ),
        ),
    )
    stem, key, wrong = cases[i % len(cases)]
    return question(stem, key, wrong)


def transmission(i: int) -> Item:
    packets, payload, header = 4 + i % 13, 100 + i // 13 % 15, 20 + i // 195 % 6
    return question(
        f"A message fills {packets} packets. Each carries {payload} payload bytes "
        f"and a {header}-byte header. With no retransmissions or other overheads, "
        "how many bytes cross the link?",
        packets * (payload + header),
        (
            packets * payload,
            packets * payload + header,
            packets * header,
            payload + header,
            packets * (payload - header),
            8 * packets * (payload + header),
        ),
    )


def web_roles(i: int) -> Item:
    cases = (
        (
            "A user changes a price in a submitted web form. Where should the "
            "application obtain "
            "the authoritative price before saving the order?",
            "From its server-side product records",
            (
                "From the displayed label",
                "From a hidden field in the submitted form",
                "From the price stored in the client’s session storage",
            ),
        ),
        (
            "A public registration form must display its fields in a single "
            "column on a narrow screen. "
            "Which component directly controls this visual layout?",
            "The client-side CSS",
            (
                "The database schema for each field",
                "The URL routing configuration",
                "The response status code",
            ),
        ),
        (
            "A server processes a submitted HTML form and must store a booking "
            "across separate visits. "
            "Which action directly provides persistent storage?",
            "Commit the booking to a database",
            (
                "Set a local variable in the request handler",
                "Store the booking only in the current response body",
                "Keep the submitted fields only in this request object",
            ),
        ),
    )
    return question(*cases[i % len(cases)])


def security(i: int) -> Item:
    cases = (
        (
            "The receiver knows the sender’s authentic public key and wants to "
            "check the origin and "
            "integrity of a received document. Which operation meets both "
            "requirements?",
            "Verify the document’s digital signature with the sender’s public key",
            (
                "Recompute a checksum received in the same unauthenticated message",
                "Encrypt the received file with the receiver’s own public key",
                "Compare its file size with the size in the message",
            ),
        ),
        (
            "A network team wants a device that monitors traffic and raises an "
            "alert when a configured "
            "suspicious pattern is detected, without intervening in the "
            "traffic. Which is most appropriate?",
            "A passive intrusion detection system",
            (
                "A firewall configured only to drop matching packets",
                "A router configured only to forward by destination",
                "A load balancer configured only to distribute connections",
            ),
        ),
        (
            "A laptop may be lost while powered down. Which control protects "
            "the confidentiality "
            "of its stored files if the recovery key is kept separately?",
            "Full-disk encryption",
            (
                "A host firewall that denies unsolicited network connections",
                "Multi-factor authentication for the owner’s webmail",
                "A backup stored unencrypted on a second partition",
            ),
        ),
    )
    return question(*cases[i % len(cases)])


FAMILIES = (
    Family(
        "2.4.boundary-predicate",
        "Input validation",
        "Choose a Boolean predicate with one included and one excluded endpoint.",
        boundary_predicate,
        answer_type="exact_text",
    ),
    Family(
        "1.1",
        "Algorithmic representation",
        "Decision-table rule counting",
        decision_table,
    ),
    Family(
        "1.2",
        "Fundamental algorithms",
        "Worst-case binary-search probes on a perfect tree",
        binary_search,
    ),
    Family("1.3", "Data structures", "Circular queue wraparound", circular_queue),
    Family(
        "2.1",
        "Coding standards",
        "Selecting meaningful identifiers for specified state",
        naming,
    ),
    Family(
        "2.2",
        "Programming elements and constructs",
        "Trace a strided Python slice",
        slicing,
    ),
    Family(
        "2.3",
        "Implementing algorithms and data structures",
        "Trace an insertion-sort pass",
        insertion_pass,
    ),
    Family(
        "2.4",
        "Data validation and program testing",
        "Boundary tests for an inclusive interval",
        boundaries,
    ),
    Family(
        "2.5",
        "Object-oriented programming",
        "Tracing inherited and overridden methods",
        dynamic_dispatch,
    ),
    Family(
        "3.1",
        "Data representation",
        "Convert a positive binary integer to denary",
        base_conversion,
    ),
    Family(
        "3.2",
        "Character encoding",
        "Calculate storage in mixed-width UTF-8 text",
        encoding,
    ),
    Family(
        "3.3",
        "Databases and data management",
        "Row multiplicity in a one-to-many outer join",
        join_count,
    ),
    Family(
        "3.4",
        "Social, ethical, legal and economic issues",
        "Data minimisation, fairness and transparency",
        ethical_design,
    ),
    Family(
        "4.1", "Computer networks", "Packet headers and payload overheads", transmission
    ),
    Family(
        "4.2",
        "Web applications",
        "Browser, application server and persistence responsibilities",
        web_roles,
    ),
    Family(
        "4.3",
        "Network security",
        "Defensive control selection under stated requirements",
        security,
    ),
) + TRACE_FAMILIES
