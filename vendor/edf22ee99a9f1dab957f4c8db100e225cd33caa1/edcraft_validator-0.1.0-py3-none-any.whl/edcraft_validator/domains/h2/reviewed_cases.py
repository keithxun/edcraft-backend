"""Load reviewed classroom cases as versioned data."""

import json
from dataclasses import dataclass
from importlib import resources
from typing import Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from edcraft_validator.domains.h2.families import AnswerType, Family, Item


class ReviewedCase(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)
    focus: str = Field(min_length=1, max_length=300)
    stem: str = Field(min_length=1, max_length=2800)
    key: str = Field(min_length=1, max_length=1000)
    wrong: list[str] = Field(min_length=3, max_length=10)

    @model_validator(mode="after")
    def distinct_choices(self) -> Self:
        choices = [self.key, *self.wrong]
        canonical = {value.strip().casefold() for value in choices}
        if "" in canonical or len(canonical) != len(choices):
            raise ValueError("Reviewed cases need nonempty distinct display choices")
        return self


class ReviewedFamily(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)
    id: str = Field(pattern=r"^[0-9]+\.[0-9]+\.[a-z][a-z0-9-]*$")
    scope: str = Field(min_length=1, max_length=500)
    answer_type: AnswerType = "value"
    cases: list[ReviewedCase] = Field(min_length=2)

    @model_validator(mode="after")
    def distinct_stems(self) -> Self:
        if len({case.stem.strip() for case in self.cases}) != len(self.cases):
            raise ValueError("Reviewed cases must have distinct question stems")
        return self


@dataclass(frozen=True)
class ReviewedVariants:
    """Each variant has its own approved wording and independent keyed audit record."""

    items: tuple[Item, ...]

    def __call__(self, case: int) -> Item:
        return self.items[case % len(self.items)]


def load_reviewed(subject: str, topics: dict[str, str]) -> tuple[Family, ...]:
    directory = resources.files(__package__).joinpath("data", subject)
    if not directory.is_dir():
        return ()
    result: dict[str, Family] = {}
    for path in sorted(directory.iterdir(), key=lambda p: p.name):
        if not path.name.endswith(".json"):
            continue
        for raw in json.loads(path.read_text(encoding="utf-8")):
            row = ReviewedFamily.model_validate(raw)
            if row.id in result:
                raise ValueError(f"Duplicate H2 family identifier {subject}/{row.id}")
            unit = row.id.rsplit(".", 1)[0]
            items = tuple(
                Item(case.stem, case.key, tuple(case.wrong)) for case in row.cases
            )
            result[row.id] = Family(
                row.id,
                topics[unit],
                row.scope,
                ReviewedVariants(items),
                answer_type=row.answer_type,
            )
    return tuple(result.values())
