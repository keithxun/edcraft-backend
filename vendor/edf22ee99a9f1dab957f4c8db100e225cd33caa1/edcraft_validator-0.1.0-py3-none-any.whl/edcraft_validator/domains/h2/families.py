"""Authoritative family values shared by the two H2 subject catalogues."""

from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Literal

AnswerType = Literal["value", "exact_text"]


@dataclass(frozen=True)
class Item:
    stem: str
    answer: str
    distractors: tuple[str, ...]


def question(stem: str, key: object, wrong: Iterable[object]) -> Item:
    """Preserve recipe positions across variants so one fixed subset can be checked."""
    answer = str(key)
    options = tuple(str(x) for x in wrong)
    return Item(stem, answer, options)


@dataclass(frozen=True)
class Family:
    number: str
    topic: str
    scope: str
    render: Callable[[int], Item]
    dependencies: tuple[Callable[..., object], ...] = ()
    answer_type: AnswerType = "value"
