"""H2 Mathematics variance questions with exact arithmetic and fixed recipes."""

from fractions import Fraction
from statistics import variance

from edcraft_validator.domains.h2.families import Family, Item, question


def _sample(index: int) -> tuple[int, int, tuple[int, ...]]:
    size, centre, spread = 8 + index % 4, 3 + index // 4 % 4, 2 + index // 16 % 4
    scale, origin = 2 + index // 64 % 4, 30 + 5 * (index // 256 % 4)
    offsets = (-2 * spread, -spread, -1, 0, 1, spread, 2 * spread, 3 * spread, 1, 2, -1)
    return origin, scale, tuple(centre + offset for offset in offsets[:size])


def _summary(values: tuple[int, ...]) -> tuple[int, int, int]:
    return len(values), sum(values), sum(value**2 for value in values)


def _centred_sum(size: int, total: int, squares: int) -> Fraction:
    return squares - Fraction(total**2, size)


def _variance(values: tuple[int, ...]) -> Fraction:
    # Compute the key from the underlying observations so the summary formulas
    # can check the displayed problem independently.
    return variance(map(Fraction, values))


def _stem(givens: str) -> str:
    return f"{givens} Find the exact unbiased estimate of the population variance of x."


def _direct_options(size: int, total: int, squares: int) -> tuple[Fraction, ...]:
    centred = _centred_sum(size, total, squares)
    return (
        centred / size,
        Fraction(squares, size - 1),
        centred,
        Fraction(squares, size),
        centred / (size - 2),
        centred / (size - 1) ** 2,
    )


def raw_observations(index: int) -> Item:
    origin, scale, codes = _sample(index)
    values = tuple(origin + scale * code for code in codes)
    return question(
        _stem(
            "The observations in a random sample of x are "
            f"{', '.join(map(str, values))}."
        ),
        _variance(values),
        _direct_options(*_summary(values)),
    )


def unshifted_totals(index: int) -> Item:
    origin, scale, codes = _sample(index)
    values = tuple(origin + scale * code for code in codes)
    size, total, squares = _summary(values)
    return question(
        _stem(
            f"For a random sample of {size} observations, "
            f"Σx = {total} and Σx² = {squares}."
        ),
        _variance(values),
        _direct_options(size, total, squares),
    )


def shifted_totals(index: int) -> Item:
    origin, scale, codes = _sample(index)
    shifted = tuple(scale * code for code in codes)
    size, total, squares = _summary(shifted)
    key = _variance(tuple(origin + value for value in shifted))
    return question(
        _stem(
            f"For a random sample of {size} observations, "
            f"Σ(x − {origin}) = {total} and Σ(x − {origin})² = {squares}."
        ),
        key,
        (key + origin, *_direct_options(size, total, squares)[:5]),
    )


def coded_totals(index: int) -> Item:
    origin, scale, codes = _sample(index)
    size, total, squares = _summary(codes)
    key = _variance(tuple(origin + scale * code for code in codes))
    return question(
        _stem(
            f"For a random sample of {size} observations, "
            f"let y = (x − {origin})/{scale}. "
            f"The coded totals are Σy = {total} and Σy² = {squares}."
        ),
        key,
        (
            key / scale,
            key * (size - 1) / size,
            Fraction(squares * scale**2, size - 1),
            key / scale**2,
            key + origin,
            key / scale**4,
        ),
    )


def corrected_totals(index: int) -> Item:
    origin, scale, codes = _sample(index)
    size, total, squares = _summary(codes)
    old = codes[7]
    new = old - 2
    corrected = codes[:7] + (new,) + codes[8:]
    _, new_total, new_squares = _summary(corrected)
    key = _variance(tuple(origin + scale * code for code in corrected))
    return question(
        _stem(
            f"For a random sample of {size} observations, "
            f"let y = (x − {origin})/{scale}. "
            f"The recorded coded totals are Σy = {total} and Σy² = {squares}. "
            f"One observation recorded as x = {origin + scale * old} should be "
            f"x = {origin + scale * new}."
        ),
        key,
        (
            _centred_sum(size, new_total, squares) * scale**2 / (size - 1),
            _centred_sum(size, total, new_squares) * scale**2 / (size - 1),
            key / scale,
            key * (size - 1) / size,
            _variance(tuple(origin + scale * code for code in codes)),
            key / scale**2,
        ),
    )


def combined_shifted_totals(index: int) -> Item:
    size_a = 5 + index % 4
    size_b = size_a + 2 + index // 4 % 2
    origin_a = 24 + 4 * (index // 8 % 4)
    shift = 6 + 2 * (index // 32 % 4)
    origin_b = origin_a + shift
    centre_a, centre_b = 1 + index // 128 % 2, 4 + index // 256 % 4
    offsets_a = (-2, -1, 0, 1, 3, -1, 4, 0)
    offsets_b = (-3, -1, 0, 2, 3, 4, -2, 1, 5, 0, 1)
    a = tuple(centre_a + offset for offset in offsets_a[:size_a])
    b = tuple(centre_b + offset for offset in offsets_b[:size_b])
    _, total_a, squares_a = _summary(a)
    _, total_b, squares_b = _summary(b)
    key = _variance(
        tuple(origin_a + value for value in a) + tuple(origin_b + value for value in b)
    )
    # Express the pooled sample in coordinates measured from batch A's origin.
    pooled = a + tuple(value + shift for value in b)
    size, _, squares = _summary(pooled)
    within = _centred_sum(size_a, total_a, squares_a) + _centred_sum(
        size_b, total_b, squares_b
    )
    mean_a = Fraction(total_a, size_a)
    return question(
        _stem(
            "The observations of x in a random sample are split into two batches. "
            f"Batch A's {size_a} observations with reference value {origin_a} give "
            f"Σ(x − {origin_a}) = {total_a} and Σ(x − {origin_a})² = {squares_a}. "
            f"Batch B's {size_b} observations with reference value {origin_b} give "
            f"Σ(x − {origin_b}) = {total_b} and Σ(x − {origin_b})² = {squares_b}. "
            "Use the observations from both batches together."
        ),
        key,
        (
            _centred_sum(size, total_a + total_b, squares_a + squares_b) / (size - 1),
            within / (size - 1),
            key * (size - 1) / size,
            Fraction(squares, size - 1),
            sum((value - mean_a) ** 2 for value in pooled) / (size - 1),
            within / (size - 2),
        ),
    )


_DIRECT = (_sample, _summary, _centred_sum, _variance, _stem, _direct_options)
FAMILIES = (
    Family(
        "6.4.variance-raw-observations",
        "Sampling",
        "Find the unbiased population variance estimate from listed raw observations",
        raw_observations,
        _DIRECT,
    ),
    Family(
        "6.4.variance-totals",
        "Sampling",
        "Find the unbiased population variance estimate from unshifted summary totals",
        unshifted_totals,
        _DIRECT,
    ),
    Family(
        "6.4.variance-shifted-totals",
        "Sampling",
        "Find the unbiased population variance estimate from shifted summary totals",
        shifted_totals,
        _DIRECT,
    ),
    Family(
        "6.4.variance-coded-totals",
        "Sampling",
        "Find the unbiased population variance estimate from shifted and scaled totals",
        coded_totals,
        (_sample, _summary, _variance, _stem),
    ),
    Family(
        "6.4.variance-corrected-totals",
        "Sampling",
        "Correct shifted and scaled totals before estimating population variance",
        corrected_totals,
        (_sample, _summary, _centred_sum, _variance, _stem),
    ),
    Family(
        "6.4.variance-combined-shifted-totals",
        "Sampling",
        "Estimate variance for the combined sample using differently shifted totals",
        combined_shifted_totals,
        (_summary, _centred_sum, _variance, _stem),
    ),
)

_DIRECT_CONTRASTS = (
    (0, "Divide by n instead of n − 1."),
    (1, "Use the second moment without subtracting the squared mean term."),
)

REQUIRED_CONTRASTS = {
    "6.4.variance-raw-observations": _DIRECT_CONTRASTS,
    "6.4.variance-totals": _DIRECT_CONTRASTS,
    "6.4.variance-shifted-totals": (
        (0, "Add the coding origin to the variance."),
        (1, "Divide by n instead of n − 1."),
        (2, "Use the second moment without subtracting the squared mean term."),
    ),
    "6.4.variance-coded-totals": (
        (0, "Multiply the coded variance by the scale instead of its square."),
        (1, "Divide by n instead of n − 1."),
        (2, "Use the second moment without subtracting the squared mean term."),
    ),
    "6.4.variance-corrected-totals": (
        (0, "Correct the sum of the observations and leave the sum of squares stale."),
        (1, "Correct the sum of squares and leave the sum of the observations stale."),
        (
            2,
            "Multiply the corrected coded variance by the scale instead of its square.",
        ),
    ),
    "6.4.variance-combined-shifted-totals": (
        (0, "Combine both batches' totals directly despite the different origins."),
        (1, "Add within-batch squared deviations and omit between-batch variation."),
        (2, "Divide by the total number of observations instead of one fewer."),
    ),
}
