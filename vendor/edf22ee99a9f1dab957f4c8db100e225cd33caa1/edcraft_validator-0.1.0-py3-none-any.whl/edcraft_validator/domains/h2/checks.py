"""Check H2 worked answers and select fixed options across sampled inputs."""

import re
from time import monotonic

from fastmcp import FastMCP

from edcraft_validator.domains.domain_support import content_sha256
from edcraft_validator.domains.h2.answer_identity import identity as identity
from edcraft_validator.domains.h2.catalogue import eligible_cases, family_for
from edcraft_validator.domains.h2.families import AnswerType, Item
from edcraft_validator.domains.h2.operation_traces import (
    REQUIRED_CONTRASTS as TRACE_CONTRASTS,
)
from edcraft_validator.domains.h2.schemas import Candidate
from edcraft_validator.domains.h2.variance_families import (
    REQUIRED_CONTRASTS as VARIANCE_CONTRASTS,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.distractor_pool import (
    DistractorPoolError,
    OptionValue,
    sample_assignments,
    select_fixed_subset,
)

BUDGET = 32
TIME_LIMIT = 5.0
CHECK_NAME = "h2_verify_syllabus_family"


def option_row(
    item: Item, count: int, answer_type: AnswerType
) -> tuple[OptionValue, list[OptionValue | None]]:
    options: list[OptionValue | None] = [
        OptionValue(identity(text, answer_type), text)
        for text in item.distractors[:count]
    ]
    # Short conceptual pools have fewer vetted alternatives than numeric ones.
    # Empty reserve positions can never enter the saved subset.
    return OptionValue(identity(item.answer, answer_type), item.answer), options + [
        None
    ] * (count - len(options))


def matches_example(
    actual: str,
    example: Item,
    answer_type: AnswerType,
    *,
    integer_traversal: bool = False,
) -> bool:
    if identity(actual, answer_type) == identity(example.answer, answer_type):
        return True
    # An author can copy an integer traversal with or without its list wrapper.
    # The student still sees the exact approved choice. Preserve order and signs.
    if not integer_traversal:
        return False
    expected = example.answer.strip()
    if not (
        (expected.startswith("(") and expected.endswith(")"))
        or (expected.startswith("[") and expected.endswith("]"))
    ):
        return False
    sequence = r"[+-]?\d+(?:\s*,\s*[+-]?\d+)+"
    given = actual.strip()
    if (given.startswith("(") and given.endswith(")")) or (
        given.startswith("[") and given.endswith("]")
    ):
        given = given[1:-1].strip()
    target = expected[1:-1].strip()
    if not re.fullmatch(sequence, target) or not re.fullmatch(sequence, given):
        return False
    return tuple(map(int, given.split(","))) == tuple(map(int, target.split(",")))


def verify(candidate: Candidate) -> ToolEvidence:
    start = monotonic()
    try:
        family = family_for(candidate.subject, candidate.family)
        cases = eligible_cases(family, candidate.allowed_cases)
        example = family.render(cases[0])
        if not matches_example(
            candidate.example_answer,
            example,
            family.answer_type,
            integer_traversal=candidate.subject == "code"
            and family.number in {"1.3.preorder", "1.3.inorder", "1.3.postorder"},
        ):
            raise ValueError(
                f"The example answer does not match family {family.number}. "
                f"Re-evaluate the displayed example: {example.stem}"
            )
        size = len(cases)
        budget = min(size, BUDGET)
        rows = sample_assignments({"case": cases}, budget=budget, seed=9758)
        material = []
        for row in rows:
            if monotonic() - start > TIME_LIMIT:
                raise ValueError("H2 sampling exceeded its checking time budget")
            material.append(
                option_row(
                    family.render(row["case"]),
                    candidate.required + 3,
                    family.answer_type,
                )
            )
        contrasts = (TRACE_CONTRASTS | VARIANCE_CONTRASTS).get(family.number, ())
        chosen = select_fixed_subset(
            material,
            candidate.required,
            assignments=rows,
            required_slots=[i for i, _ in contrasts],
        )
        details = dict(
            subject_sha256=content_sha256(candidate),
            selected_slots=list(chosen),
            required_contrasts=[
                {"slot": i, "misconception": text} for i, text in contrasts
            ],
            examples_checked=len(rows),
            execution_calls=len(rows),
            max_examples=budget,
            max_execution_calls=budget,
            timeout_seconds=TIME_LIMIT,
            seed=9758,
            whole_domain=len(rows) == size,
            declared_domain_size=size,
            checking_mode="property_based",
        )
        return ToolEvidence(
            tool=CHECK_NAME, version="1.0.0", status="passed", details=details
        )
    except (ValueError, DistractorPoolError) as exc:
        return ToolEvidence(
            tool=CHECK_NAME,
            version="1.0.0",
            status="failed",
            findings=[ToolFinding(code="H2_FAMILY_REJECTED", message=str(exc))],
        )


def register_h2_check(server: FastMCP) -> None:
    server.tool(
        name=CHECK_NAME,
        version="1.0.0",
        tags={"domain:h2-syllabus"},
        description="Check the syllabus family, worked answer, "
        "and distinct fixed distractor slots on sampled inputs.",
    )(verify)
