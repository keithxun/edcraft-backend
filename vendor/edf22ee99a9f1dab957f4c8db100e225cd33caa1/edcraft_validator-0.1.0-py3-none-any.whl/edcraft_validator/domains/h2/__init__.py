"""Versioned, syllabus-aligned families with application-owned wording and answers."""
