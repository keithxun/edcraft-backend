"""Learner-facing text projection for shared template relevance.

The measurement, threshold and verdict live in the shared classifier. This
module only renders what a learner would actually see, so the same relevance
policy can judge a physics template without knowing anything about forces.
"""

from __future__ import annotations

from edcraft_validator.domains.physics import text as physics_text
from edcraft_validator.domains.physics.h2_catalog import FAMILIES
from edcraft_validator.domains.physics.h2_statement_data import H2StatementSpec
from edcraft_validator.domains.physics.h2_statements import (
    pinned_statement_family,
    statement_stem,
)
from edcraft_validator.domains.physics.h2_task_data import H2TaskSpec
from edcraft_validator.domains.physics.h2_tasks import pinned_task_family
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsTemplateCandidate,
)
from edcraft_validator.domains.physics.quantities import QUANTITY_UNITS


def template_relevance_text(candidate: PhysicsTemplateCandidate) -> str:
    """Render the reusable task without answers, hints or distractor recipes."""
    template = candidate.item
    if isinstance(template, H2TaskSpec):
        cases = pinned_task_family(template).cases
        return "\n\n".join(
            case.question
            + (
                f"\nDisplayed stimulus: {case.stimulus.model_dump_json()}"
                if case.stimulus
                else ""
            )
            for case in cases
        )
    if isinstance(template, H2StatementSpec):
        statement_family = pinned_statement_family(template)
        examples = [
            statement_stem(case, (0, 1, 2, 3), ask_false=False)
            + (
                f"\nDisplayed stimulus: {case.stimulus.model_dump_json()}"
                if case.stimulus
                else ""
            )
            for case in statement_family.cases
        ]
        return statement_family.skill + "\n\n" + "\n\n".join(examples)
    if isinstance(template, H2TemplateSpec):
        family = FAMILIES[template.family_id]
        return f"{family.stem}\nParameter values: {template.parameters!r}\n"
    parameters = "; ".join(
        f"{parameter.name} ({parameter.quantity}, {QUANTITY_UNITS[parameter.quantity]})"
        f" in [{', '.join(parameter.values)}]"
        for parameter in template.parameters
    )
    assumptions = " ".join(physics_text.assumptions(template))

    return (
        "Physics multiple-choice question template\n\n"
        f"Topic: {template.topic}\n"
        f"Stem: {template.body.text}\n"
        f"Assumptions: {assumptions}\n"
        f"Question: {physics_text.question_sentence(template)}\n"
        f"Parameter values: {parameters}\n"
        "Each generated question substitutes one allowed value for every "
        "parameter.\n"
    )
