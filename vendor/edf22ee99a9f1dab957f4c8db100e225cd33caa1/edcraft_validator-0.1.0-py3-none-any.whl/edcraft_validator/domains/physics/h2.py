"""Exact validation and deterministic generation for the H2 Physics catalogue."""

from __future__ import annotations

from fractions import Fraction
from math import prod
from string import Formatter

from edcraft_validator.domains.domain_support import seeded_index
from edcraft_validator.domains.physics import correctness
from edcraft_validator.domains.physics.correctness import (
    DISTRACTOR_DUPLICATE,
    DISTRACTOR_EQUALS_KEY,
    DISTRACTOR_NOT_EXACT,
    DISTRACTOR_NOT_PHYSICAL,
    PHYSICS_ANSWER_MISMATCH,
    PHYSICS_ANSWER_NOT_EXACT,
    PhysicsCheckError,
)
from edcraft_validator.domains.physics.h2_catalog import FAMILIES
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsQuestionInstance,
)
from edcraft_validator.domains.physics.physics_types import (
    PHYSICS_FIDELITY_TOOL,
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TEXT_TOOL,
    PHYSICS_TOOL_VERSION,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.distractor_pool import OptionValue, UnusableOption
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

_STEM_FORMATTER = Formatter()


def render_h2_stem(spec: H2TemplateSpec, combination: dict[str, str]) -> str:
    return FAMILIES[spec.family_id].stem.format_map(combination)


def render_h2_value(spec: H2TemplateSpec, value: Fraction) -> str:
    family = FAMILIES[spec.family_id]
    number = correctness._format_number(value, family.decimals)
    return (
        f"{number.rstrip('0').rstrip('.') if '.' in number else number} {family.unit}"
    )


def check_key(spec: H2TemplateSpec, combination: dict[str, str]) -> Fraction:
    family = FAMILIES[spec.family_id]
    values = {name: Fraction(value) for name, value in combination.items()}
    canonical = family.solve(*(values[axis.name] for axis in family.axes))
    authored = correctness.evaluate_display_values(spec.body.answer_recipe, values)
    if authored != canonical:
        raise PhysicsCheckError(
            PHYSICS_ANSWER_MISMATCH,
            f"{combination!r}: the recipe gives {authored}, expected {canonical} "
            f"using {family.rule}",
        )
    if not correctness.is_exact(canonical, family.decimals):
        raise PhysicsCheckError(
            PHYSICS_ANSWER_NOT_EXACT,
            f"{combination!r}: {canonical} is inexact at the display precision",
        )
    return canonical


def option_row(
    spec: H2TemplateSpec, combination: dict[str, str]
) -> tuple[OptionValue, list[OptionValue | UnusableOption]]:
    canonical = check_key(spec, combination)
    family = FAMILIES[spec.family_id]
    values = {name: Fraction(value) for name, value in combination.items()}
    options: list[OptionValue | UnusableOption] = []
    for entry in spec.body.distractors:
        try:
            value = correctness.evaluate_display_values(entry.recipe, values)
        except PhysicsCheckError as exc:
            options.append(UnusableOption(f"{exc.code}: {exc.message}"))
            continue
        if not correctness.is_exact(value, family.decimals):
            options.append(UnusableOption(f"{DISTRACTOR_NOT_EXACT}: {value}"))
        elif value < 0 and not family.signed:
            options.append(UnusableOption(f"{DISTRACTOR_NOT_PHYSICAL}: {value}"))
        else:
            options.append(OptionValue(value, render_h2_value(spec, value)))
    return OptionValue(canonical, render_h2_value(spec, canonical)), options


def checked_options(spec: H2TemplateSpec, combination: dict[str, str]) -> list[str]:
    key, options = option_row(spec, combination)
    seen_values, seen_labels = {key.semantic}, {key.display}
    labels = [key.display]
    for index, option in enumerate(options, 1):
        if isinstance(option, UnusableOption):
            code, _, reason = option.reason.partition(": ")
            raise PhysicsCheckError(code, f"{combination!r}, option {index}: {reason}")
        if option.semantic == key.semantic or option.display == key.display:
            raise PhysicsCheckError(
                DISTRACTOR_EQUALS_KEY, f"{combination!r}, option {index} equals the key"
            )
        if option.semantic in seen_values or option.display in seen_labels:
            raise PhysicsCheckError(
                DISTRACTOR_DUPLICATE, f"{combination!r}, option {index} repeats another"
            )
        seen_values.add(option.semantic)
        seen_labels.add(option.display)
        labels.append(option.display)
    return labels


def verify_numeric(
    spec: H2TemplateSpec, *, options: bool, timeout_seconds: float
) -> ToolEvidence:
    tool = PHYSICS_OPTIONS_TOOL if options else PHYSICS_ITEM_TOOL
    run = PropertyCheckRun(PropertyCheckSettings(timeout_seconds=timeout_seconds))
    axes = {
        name: sorted(values, key=Fraction) for name, values in spec.parameters.items()
    }
    low = {name: values[0] for name, values in axes.items()}
    high = {name: values[-1] for name, values in axes.items()}
    boundary = [low, high, *(low | {name: value} for name, value in high.items())]

    def check(combination: dict[str, str], budget: PropertyCheckRun) -> None:
        budget.reserve_execution()
        try:
            if options:
                checked_options(spec, combination)
            else:
                check_key(spec, combination)
        except PhysicsCheckError as error:
            raise ValidationFailure(error.message, code=error.code) from error

    findings = []
    try:
        run.check(axes, boundary, check, cover_small_domain=True)
    except ValidationFailure as error:
        findings.append(ToolFinding(code=error.code, message=str(error)))
    budget_exhausted = any(
        finding.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" for finding in findings
    )
    return ToolEvidence(
        tool=tool,
        version=PHYSICS_TOOL_VERSION,
        status="error" if budget_exhausted else "failed" if findings else "passed",
        findings=findings,
        details={
            **run.details(),
            "family_id": spec.family_id,
            "rule": FAMILIES[spec.family_id].rule,
        },
    )


def verify_realisation(spec: H2TemplateSpec, *, fidelity: bool) -> ToolEvidence:
    """Verify the stem structurally because authors cannot supply its wording."""
    sample = {name: values[0] for name, values in spec.parameters.items()}
    family = FAMILIES[spec.family_id]
    fields = [field for _, field, _, _ in _STEM_FORMATTER.parse(family.stem) if field]
    matches = (
        sorted(fields) == sorted(spec.parameters)
        and family.stem.endswith("?")
        and spec.family_sha256 == family.fingerprint
    )
    return ToolEvidence(
        tool=PHYSICS_FIDELITY_TOOL if fidelity else PHYSICS_TEXT_TOOL,
        version=PHYSICS_TOOL_VERSION,
        status="passed" if matches else "failed",
        findings=[]
        if matches
        else [
            ToolFinding(
                code="H2_STEM_MISMATCH", message="Family stem does not match its axes"
            )
        ],
        details={
            "checking_mode": "constrained_realisation",
            "family_id": spec.family_id,
            "example_question": render_h2_stem(spec, sample) if matches else None,
            "routes_to_review": not matches,
        },
    )


def generate_h2_question(
    spec: H2TemplateSpec, *, template_id: str, artifact_id: str | None, seed: int
) -> PhysicsQuestionInstance:
    family = FAMILIES[spec.family_id]
    axes = {
        axis.name: sorted(spec.parameters[axis.name], key=Fraction)
        for axis in family.axes
    }
    size = prod(map(len, axes.values()))
    start = seeded_index(template_id, seed, "parameter-combination", size)
    for offset in range(min(size, 256)):
        index = (start + offset) % size
        combination = {}
        for name, values in axes.items():
            index, position = divmod(index, len(values))
            combination[name] = values[position]
        try:
            answer, *choices = checked_options(spec, combination)
        except PhysicsCheckError:
            continue
        correct_index = seeded_index(
            template_id, seed, "correct-index", len(choices) + 1
        )
        choices.insert(correct_index, answer)
        return PhysicsQuestionInstance(
            template_id=template_id,
            artifact_id=artifact_id,
            seed=seed,
            parameters=combination,
            question=render_h2_stem(spec, combination),
            choices=choices,
            correct_index=correct_index,
            answer=answer,
            topic=f"h2.syllabus_9478.topic_{family.topic}.{spec.family_id}",
            target="h2_quantity",
            unit=family.unit,
            assumptions=[],
        )
    raise ValueError(
        "Could not produce a usable question from this H2 Physics template"
    )
