"""Check and expand task-specific H2 Physics templates."""

from __future__ import annotations

import re
from fractions import Fraction
from itertools import pairwise

from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    build_template_id,
    seeded_index,
)
from edcraft_validator.domains.physics.h2_statement_data import TraceGraph
from edcraft_validator.domains.physics.h2_task_data import (
    FAMILIES,
    SI_PREFIX_POWERS,
    H2TaskSpec,
    TaskCase,
    TaskFamily,
    TaskId,
)
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsQuestionInstance,
    PhysicsTemplateCandidate,
    PhysicsTemplateRequest,
)
from edcraft_validator.domains.physics.physics_types import (
    PHYSICS_FIDELITY_TOOL,
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TOOL_VERSION,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure


def build_task_candidate(
    request: PhysicsTemplateRequest, task_id: TaskId
) -> PhysicsTemplateCandidate:
    if task_id == "turntable_angle_and_arc" and request.num_distractors < 2:
        raise UnsupportedAuthoringRequest(
            "The turntable task needs at least two distractors to test both quantities."
        )
    family = FAMILIES[task_id]
    spec = H2TaskSpec.model_validate(
        {
            "schema_version": "physics-h2-task/1.0",
            "family_id": task_id,
            "family_sha256": family.fingerprint,
            "body": {"distractors": list(range(request.num_distractors))},
        }
    )
    return PhysicsTemplateCandidate(
        template_id=build_template_id("physics", request, spec),
        item=spec,
        difficulty=request.difficulty,
    )


def pinned_task_family(spec: H2TaskSpec) -> TaskFamily:
    family = FAMILIES[spec.family_id]
    if spec.family_sha256 != family.fingerprint:
        raise ValueError("The checked Physics task no longer matches its fingerprint")
    return family


def _choices(spec: H2TaskSpec, case: TaskCase) -> list[str]:
    try:
        wrong = [case.distractors[index].label for index in spec.body.distractors]
    except IndexError as error:
        raise ValueError("The Physics task lacks the requested choice count") from error
    choices = [case.answer, *wrong]
    if len(choices) != len(set(choices)):
        raise ValueError("The Physics task has duplicate displayed options")
    return choices


def _check_elastic_options(case: TaskCase, choices: list[str]) -> None:
    m_p, m_q, u_p, u_q = (
        Fraction(case.parameters[name]) for name in ("m_P", "m_Q", "u_P", "u_Q")
    )
    if not (m_p > 0 and m_q > 0 and m_p != m_q and u_p > 0 > u_q):
        raise ValueError("The two unequal-mass carts must approach each other")

    def satisfies_laws(choice: str) -> tuple[bool, bool]:
        p, q = (Fraction(component.split()[0]) for component in choice.split(", "))
        return (
            m_p * p + m_q * q == m_p * u_p + m_q * u_q,
            q - p == u_p - u_q,
        )

    key, *wrong = [satisfies_laws(choice) for choice in choices]
    if key != (True, True) or (True, True) in wrong:
        raise ValueError("Only the keyed pair may satisfy both elastic collision laws")
    if len(wrong) >= 2 and not {(True, False), (False, True)} <= set(wrong):
        raise ValueError("The choices must distinguish both collision laws")


_DISPLACEMENT_RANGE = re.compile(r"displacement from t = (-?\d+) to (-?\d+) s")
_ACCELERATION_RANGE = re.compile(r"acceleration between t = (-?\d+) s and (-?\d+) s")
_POSITION_RANGE = re.compile(r"(-?\d+) < x/m < (-?\d+)")


def _quantity_value(label: str, unit: str) -> Fraction:
    number, _, actual_unit = label.partition(" ")
    if actual_unit != unit:
        raise ValueError(f"Expected a Physics answer in {unit}")
    return Fraction(number)


def _motion_values(
    question: str, points: list[tuple[Fraction, Fraction]]
) -> list[tuple[Fraction, str]]:
    values = dict(points)
    expected = []
    if displacement := _DISPLACEMENT_RANGE.search(question):
        start, end = map(Fraction, displacement.groups())
        if start not in values or end not in values or start >= end:
            raise ValueError("Displacement range must use ordered plotted times")
        area = sum(
            (
                (t1 - t0) * (v0 + v1) / 2
                for (t0, v0), (t1, v1) in pairwise(points)
                if start <= t0 < t1 <= end
            ),
            Fraction(0),
        )
        expected.append((area, "m"))
    if acceleration := _ACCELERATION_RANGE.search(question):
        start, end = map(Fraction, acceleration.groups())
        if (start, end) not in pairwise(values):
            raise ValueError("Acceleration range must be one plotted segment")
        expected.append(((values[end] - values[start]) / (end - start), "m/s²"))
    if not expected:
        raise ValueError("No motion quantity could be read from the question")
    return expected


def _graph_contrasts(
    spec: H2TaskSpec, case: TaskCase, choices: list[str]
) -> list[tuple[bool, ...]]:
    if not isinstance(case.stimulus, TraceGraph) or len(case.stimulus.series) != 1:
        raise ValueError("The graph task requires one plotted trace")
    points = [
        (Fraction(str(x)), Fraction(str(y))) for x, y in case.stimulus.series[0].points
    ]
    motion_graph = spec.family_id.startswith("motion_graph_")
    axes = (
        ("Time t / s", "Velocity v / (m/s)")
        if motion_graph
        else ("Position x / m", "Electric potential / V")
    )
    if (case.stimulus.x, case.stimulus.y) != axes:
        raise ValueError("The plotted axes must match the graph task")
    if motion_graph:
        expected = _motion_values(case.question, points)
        expected_count = 2 if spec.family_id == "motion_graph_both" else 1
        if len(expected) != expected_count:
            raise ValueError("The motion graph asks for an unexpected number of values")
        motion_rows = [choice.split(", ") for choice in choices]
        if any(len(row) != expected_count for row in motion_rows):
            raise ValueError("Graph choices must give all requested motion quantities")
        return [
            tuple(
                _quantity_value(label, unit) == value
                for label, (value, unit) in zip(row, expected, strict=True)
            )
            for row in motion_rows
        ]

    values = dict(points)
    interval = _POSITION_RANGE.search(case.question)
    if interval is None:
        raise ValueError("No field interval could be read from the question")
    start, end = map(Fraction, interval.groups())
    if (start, end) not in pairwise(values):
        raise ValueError("Field range must be one plotted segment")
    field = (values[start] - values[end]) / (end - start)
    if spec.family_id == "potential_graph_gradient":
        return [(_quantity_value(choice, "V/m") == field,) for choice in choices]

    flat = [(x0, x1) for (x0, v0), (x1, v1) in pairwise(points) if v0 == v1]
    if len(flat) != 1:
        raise ValueError("The graph must have exactly one zero-field interval")
    rows: list[tuple[bool, ...]] = []
    for choice in choices:
        field_label, _, interval_label = choice.partition("; ")
        named_interval = _POSITION_RANGE.fullmatch(interval_label)
        if named_interval is None:
            raise ValueError("Every option must name a zero-field interval")
        region = tuple(map(Fraction, named_interval.groups()))
        rows.append((_quantity_value(field_label, "V/m") == field, region == flat[0]))
    return rows


def _check_graph_options(spec: H2TaskSpec, case: TaskCase, choices: list[str]) -> None:
    key, *wrong = _graph_contrasts(spec, case, choices)
    if not all(key) or any(all(option) for option in wrong):
        raise ValueError("Only the keyed answer may agree with the plotted data")
    if len(key) == 2 and len(wrong) >= 2:
        if not {(True, False), (False, True)} <= set(wrong):
            raise ValueError("The graph choices must test both requested quantities")


_PREFIX_READING = re.compile(
    r" is (\d+(?:\.\d+)?) (\S+)\. What is the equivalent value in ([A-Za-z]+)\?$"
)
_TURNTABLE_GIVENS = re.compile(
    r"^A turntable of radius (\d+(?:\.\d+)?) m rotates through "
    r"(\d+(?:\.\d+)?) revolution\. "
    r"What are its angular displacement in radians and the arc length travelled "
    r"by a point on its rim, respectively\?$"
)


def _check_prefix_options(case: TaskCase, choices: list[str]) -> None:
    reading = _PREFIX_READING.search(case.question)
    if reading is None:
        raise ValueError("Give a prefixed reading and ask for the equivalent SI value")
    number, prefixed_unit, unit = reading.groups()
    if unit not in {"A", "Hz", "N", "V", "m", "s"}:
        raise ValueError("Ask for one of the registered unprefixed SI units")
    prefix = prefixed_unit.removesuffix(unit)
    if prefix == prefixed_unit or prefix not in SI_PREFIX_POWERS:
        raise ValueError("The displayed reading must use a prefix on the answer unit")
    expected = Fraction(number) * Fraction(10) ** SI_PREFIX_POWERS[prefix]
    options = [_quantity_value(choice, unit) for choice in choices]
    if options[0] != expected or len(set(options)) != len(choices):
        raise ValueError("The keyed SI value must be exact and the options must differ")


def _pi_coefficient(label: str, unit: str) -> Fraction:
    match = re.fullmatch(rf"(\d+(?:\.\d+)?)π {unit}", label)
    if match is None:
        raise ValueError(f"Expected an exact multiple of π in {unit}")
    return Fraction(match[1])


def _check_turntable_options(case: TaskCase, choices: list[str]) -> None:
    givens = _TURNTABLE_GIVENS.fullmatch(case.question)
    if givens is None:
        raise ValueError("Give a turntable radius and fraction of a turn in the stem")
    radius, turns = map(Fraction, givens.groups())
    if radius <= 0 or not 0 < turns < 1:
        raise ValueError("Use a positive radius and a rotation of less than one turn")
    options = []
    for choice in choices:
        angle_label, _, arc_label = choice.partition(", ")
        options.append(
            (_pi_coefficient(angle_label, "rad"), _pi_coefficient(arc_label, "m"))
        )

    angle = 2 * turns
    arc = 2 * radius * turns
    if options[0] != (angle, arc) or len(set(options)) != len(choices):
        raise ValueError(
            "Only the keyed pair may give the correct angle and arc length"
        )
    if not (
        any(a == angle and s != arc for a, s in options[1:])
        and any(a != angle and s == arc for a, s in options[1:])
    ):
        raise ValueError("The choices must test both the angle and the rim arc length")


_NUMERIC_TASK_CHECKS = {
    "si_prefix_conversion": _check_prefix_options,
    "turntable_angle_and_arc": _check_turntable_options,
}


def verify_task(spec: H2TaskSpec, tool: str, *, timeout_seconds: float) -> ToolEvidence:
    run = PropertyCheckRun(PropertyCheckSettings(timeout_seconds=timeout_seconds))
    findings = []
    graph_task = spec.family_id.startswith(("motion_graph_", "potential_graph_"))
    numeric_check = _NUMERIC_TASK_CHECKS.get(spec.family_id)
    details: dict[str, object] = {}
    if tool == PHYSICS_FIDELITY_TOOL:
        details["fidelity_method"] = "pinned_native_renderer"
        if graph_task:
            details["verified_graph_values"] = False
        if numeric_check:
            details["verified_numeric_values"] = False
    try:
        family = pinned_task_family(spec)

        def check(row: dict[str, int], budget: PropertyCheckRun) -> None:
            budget.reserve_execution()
            case = family.cases[row["case"]]
            choices = _choices(spec, case)
            if spec.family_id == "elastic_cart_velocities" and tool in (
                PHYSICS_ITEM_TOOL,
                PHYSICS_OPTIONS_TOOL,
            ):
                _check_elastic_options(case, choices)
            if graph_task and tool in (
                PHYSICS_ITEM_TOOL,
                PHYSICS_OPTIONS_TOOL,
                PHYSICS_FIDELITY_TOOL,
            ):
                _check_graph_options(spec, case, choices)
            if numeric_check:
                numeric_check(case, choices)
            if not case.question.endswith("?") or not case.worked_solution:
                raise ValueError(
                    "The Physics task requires a question and worked solution"
                )

        run.check(
            {"case": range(len(family.cases))}, [], check, cover_small_domain=True
        )
        details.update(
            outcome=family.outcome,
            operations=list(family.operations),
            worked_solutions=[case.worked_solution for case in family.cases],
        )
        if graph_task and tool == PHYSICS_FIDELITY_TOOL:
            details["verified_graph_values"] = True
        if numeric_check and tool == PHYSICS_FIDELITY_TOOL:
            details["verified_numeric_values"] = True
        if tool == PHYSICS_OPTIONS_TOOL:
            details["contrast_choices"] = [
                [case.distractors[index].reason for index in spec.body.distractors]
                for case in family.cases
            ]
    except ValidationFailure as error:
        findings.append(ToolFinding(code=error.code, message=str(error)))
    except ValueError as error:
        findings.append(ToolFinding(code="H2_TASK_INVALID", message=str(error)))
    budget_exhausted = any(
        finding.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" for finding in findings
    )
    return ToolEvidence(
        tool=tool,
        version=PHYSICS_TOOL_VERSION,
        status="error" if budget_exhausted else "failed" if findings else "passed",
        findings=findings,
        details={**run.details(), "family_id": spec.family_id, **details},
    )


def task_case_previews(spec: H2TaskSpec) -> list[ReviewCasePreview]:
    family = pinned_task_family(spec)
    outcome = f"{family.outcome[:-1]}({family.outcome[-1]})"
    return [
        ReviewCasePreview(
            case_id=f"{spec.family_id}-{number}",
            outcome=outcome,
            question=case.question,
            answer=case.answer,
            choices=_choices(spec, case),
            stimulus=case.stimulus.model_dump(mode="json") if case.stimulus else None,
        )
        for number, case in enumerate(family.cases, start=1)
    ]


def generate_task_question(
    spec: H2TaskSpec, *, template_id: str, artifact_id: str | None, seed: int
) -> PhysicsQuestionInstance:
    family = pinned_task_family(spec)
    case = family.cases[seeded_index(template_id, seed, "task-case", len(family.cases))]
    answer, *choices = _choices(spec, case)
    correct_index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
    choices.insert(correct_index, answer)
    return PhysicsQuestionInstance(
        template_id=template_id,
        artifact_id=artifact_id,
        seed=seed,
        parameters=case.parameters,
        question=case.question,
        choices=choices,
        correct_index=correct_index,
        answer=answer,
        topic=f"h2.syllabus_9478.skill_{family.outcome}.{spec.family_id}",
        target="h2_task",
        unit="",
        assumptions=[],
        stimulus=case.stimulus,
    )
