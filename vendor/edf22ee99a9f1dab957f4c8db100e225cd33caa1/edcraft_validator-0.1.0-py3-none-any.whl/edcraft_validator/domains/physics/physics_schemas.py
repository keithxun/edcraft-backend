"""Canonical request, template, and question schemas for the physics pilot.

Every model rejects unknown fields. Validation messages are written for the
authoring model that reads them, so each one names the offending field, what is
wrong, and what this pilot accepts instead.
"""

from __future__ import annotations

import re
from typing import Annotated, Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domains.domain_support import TemplateRequest
from edcraft_validator.domains.physics.authored_laws import AuthoredUnit
from edcraft_validator.domains.physics.h2_catalog import FAMILIES, H2Unit
from edcraft_validator.domains.physics.h2_statement_data import (
    H2StatementSpec,
    Stimulus,
)
from edcraft_validator.domains.physics.h2_task_data import H2TaskSpec
from edcraft_validator.domains.physics.physics_types import (
    MAX_DECIMALS,
    MAX_DISTRACTORS,
    MAX_KNOWN_FORCES,
    MAX_PARAMETERS,
    MAX_RECIPE_DEPTH,
    MAX_RECIPE_NODES,
    MAX_VALUES_PER_PARAMETER,
    PHYSICS_CHECKING_MODE,
    PHYSICS_FORMAT_VERSION,
    PHYSICS_SCHEMA_VERSION,
    PHYSICS_VALIDATOR_VERSION,
    Difficulty,
)
from edcraft_validator.domains.physics.quantities import (
    QUANTITY_UNITS,
    parse_decimal,
    within_bounds,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES
from edcraft_validator.validation.property_summary import PropertyCheckSummary
from edcraft_validator.validation.validation_contracts import ValidationEvidence

Quantity = Literal["mass", "force", "acceleration"]
Unit = Literal["kg", "N", "m/s^2"]
Direction = Literal["positive", "negative"]
Target = Literal["acceleration", "net_force", "mass", "missing_force"]
AnswerForm = Literal["signed_component", "magnitude_and_direction", "magnitude"]
RecipeOp = Literal["add", "sub", "mul", "div", "neg"]
Misconception = Literal[
    "multiplied_instead_of_divided",
    "inverted_ratio",
    "added_opposing_forces",
    "ignored_opposing_force",
    "direction_sign_error",
    "reported_net_force",
    "other",
]

Label = Annotated[str, Field(pattern=r"^[a-z][a-z -]{0,23}$")]

_CONST_PATTERN = r"^-?(0|[1-9][0-9]{0,4})(\.[0-9]{1,3})?$"
_PARAMETER_PATTERN = r"^[A-Za-z][A-Za-z0-9_]{0,15}$"

# Keys that belong to other physics families. They are reported together so an
# author fixes the model in one revision instead of one field at a time.
_OUT_OF_SCOPE_KEYS = (
    "angle",
    "angles",
    "weight",
    "gravity",
    "g",
    "friction_coefficient",
    "mu",
    "incline",
)

# A force label is read back in "What is the magnitude of the <label> force?",
# so a label must name one force, never a combination, and never end in "force".
_RESERVED_LABEL_WORDS = frozenset(
    {"net", "resultant", "total", "overall", "combined", "sum", "force", "forces"}
)

_ARITY: dict[str, tuple[int, int]] = {
    "add": (2, 4),
    "mul": (2, 4),
    "sub": (2, 2),
    "div": (2, 2),
    "neg": (1, 1),
}

_ANSWER_FORMS: dict[str, frozenset[str]] = {
    "acceleration": frozenset({"signed_component", "magnitude_and_direction"}),
    "net_force": frozenset({"signed_component", "magnitude_and_direction"}),
    "mass": frozenset({"magnitude"}),
    "missing_force": frozenset({"magnitude"}),
}


# One request shape serves every domain; the name is kept for existing imports.
PhysicsTemplateRequest = TemplateRequest


class PhysicsParameter(BaseModel):
    """One authored parameter and the finite set of magnitudes it takes."""

    model_config = ConfigDict(extra="forbid", strict=True)

    name: str = Field(pattern=_PARAMETER_PATTERN)
    quantity: Quantity
    unit: Unit
    values: list[str] = Field(min_length=1, max_length=MAX_VALUES_PER_PARAMETER)

    @model_validator(mode="before")
    @classmethod
    def reject_unsupported_unit(cls, value: object) -> object:
        """Turn a wrong unit into one message that names the accepted units."""
        if not isinstance(value, dict):
            return value
        quantity = value.get("quantity")
        unit = value.get("unit")
        if not isinstance(quantity, str) or not isinstance(unit, str):
            return value
        expected = QUANTITY_UNITS.get(quantity)
        if expected is not None and unit != expected:
            raise ValueError(
                f"unsupported unit {unit!r} for {quantity}: this pilot accepts kg "
                "for mass, N for force and m/s^2 for acceleration and does not "
                "convert units"
            )
        return value

    @model_validator(mode="after")
    def validate_values(self) -> PhysicsParameter:
        parsed = []
        for raw in self.values:
            try:
                value = parse_decimal(raw)
            except ValueError as error:
                raise ValueError(f"parameter {self.name}: {error}") from error
            if not within_bounds(self.quantity, value):
                raise ValueError(
                    f"parameter {self.name}: value {raw} is outside the pilot range "
                    f"for {self.quantity} (mass 0 < v <= 1000, force 0 <= v <= 10000, "
                    "acceleration 0 <= v <= 1000)"
                )
            parsed.append(value)
        if len(set(parsed)) != len(parsed):
            raise ValueError(
                f"parameter {self.name}: values must be distinct by exact value, so "
                f"2 and 2.0 clash ({', '.join(self.values)})"
            )
        return self


class Axis(BaseModel):
    """The single horizontal axis every force in the pilot acts along."""

    model_config = ConfigDict(extra="forbid", strict=True)

    orientation: Literal["horizontal"]
    positive: Literal["right", "left"]


class DirectedParameter(BaseModel):
    """A parameter used as a directed quantity in the body."""

    model_config = ConfigDict(extra="forbid", strict=True)

    param: str
    direction: Direction


class ForceTerm(BaseModel):
    """One known force in the free-body description."""

    model_config = ConfigDict(extra="forbid", strict=True)

    param: str
    direction: Direction
    label: Label


class UnknownForce(BaseModel):
    """The force a missing-force question asks the learner to find."""

    model_config = ConfigDict(extra="forbid", strict=True)

    direction: Direction
    label: Label


class Display(BaseModel):
    """How many decimal places every option shows."""

    model_config = ConfigDict(extra="forbid", strict=True)

    decimals: int = Field(ge=0, le=MAX_DECIMALS)


class RecipeNode(BaseModel):
    """One node of a closed arithmetic recipe over parameters and constants."""

    model_config = ConfigDict(extra="forbid", strict=True)

    param: str | None = None
    const: str | None = None
    op: RecipeOp | None = None
    args: list[RecipeNode] | None = None

    @model_validator(mode="after")
    def validate_node(self) -> RecipeNode:
        kinds = [name for name in ("param", "const", "op") if getattr(self, name)]
        if len(kinds) != 1:
            raise ValueError(
                "every recipe node sets exactly one of param, const or op "
                f"(found: {', '.join(kinds) or 'none'})"
            )
        if self.op is None and self.args is not None:
            raise ValueError("only an op node carries args")
        if self.op is not None and self.args is None:
            raise ValueError(f"op {self.op!r} needs args")
        if self.const is not None and not _is_signed_decimal(self.const):
            raise ValueError(
                f"const {self.const!r} is not a signed decimal with at most 3 "
                "decimal places"
            )
        if self.op is not None and self.args is not None:
            low, high = _ARITY[self.op]
            if not low <= len(self.args) <= high:
                expected = str(low) if low == high else f"{low} to {high}"
                raise ValueError(
                    f"op {self.op!r} takes {expected} args, got {len(self.args)}"
                )
        return self


def _is_signed_decimal(text: str) -> bool:
    """Check a signed constant string without importing the evaluator."""
    return re.fullmatch(_CONST_PATTERN, text) is not None


class PhysicsDistractor(BaseModel):
    """A wrong option, its recipe and the error rule it is meant to capture."""

    model_config = ConfigDict(extra="forbid", strict=True)

    recipe: RecipeNode
    misconception: Misconception
    explanation: str = Field(min_length=1, max_length=200)

    @model_validator(mode="after")
    def require_single_line(self) -> PhysicsDistractor:
        if "\n" in self.explanation:
            raise ValueError("explanation must be a single line")
        return self


class PhysicsBody(BaseModel):
    """The question body: roles, stem, display and recipes for one target."""

    model_config = ConfigDict(extra="forbid", strict=True)

    target: Target
    mass: str | None = None
    net_force: DirectedParameter | None = None
    forces: list[ForceTerm] | None = Field(
        default=None, min_length=1, max_length=MAX_KNOWN_FORCES
    )
    acceleration: DirectedParameter | None = None
    unknown_force: UnknownForce | None = None
    text: str = Field(min_length=1, max_length=600)
    answer_form: AnswerForm
    display: Display
    answer_recipe: RecipeNode
    distractors: list[PhysicsDistractor] = Field(
        min_length=1, max_length=MAX_DISTRACTORS
    )

    @model_validator(mode="after")
    def validate_roles(self) -> PhysicsBody:
        target = self.target
        has_net = self.net_force is not None
        has_forces = self.forces is not None

        if target in {"acceleration", "mass"}:
            if has_net == has_forces:
                raise ValueError(
                    f"{target} templates need exactly one of net_force or forces; "
                    f"found {sum((has_net, has_forces))}"
                )
        elif target == "net_force" and (has_net or has_forces):
            raise ValueError(
                "net_force templates compute the net force, so net_force and forces "
                "are not allowed in the body"
            )
        elif target == "missing_force" and (has_net or not has_forces):
            raise ValueError(
                "missing_force templates require forces and do not allow net_force; "
                "the unknown force is isolated from the known ones"
            )

        if target in {"acceleration", "net_force", "missing_force"}:
            if self.mass is None:
                raise ValueError(f"{target} templates require mass")
        elif self.mass is not None:
            raise ValueError("mass templates find the mass, so mass is not a role")

        if target in {"net_force", "mass", "missing_force"}:
            if self.acceleration is None:
                raise ValueError(f"{target} templates require acceleration")
        elif self.acceleration is not None:
            raise ValueError(
                "acceleration templates find the acceleration, so acceleration is "
                "not a role"
            )

        if target == "missing_force":
            if self.unknown_force is None:
                raise ValueError("missing_force templates require unknown_force")
        elif self.unknown_force is not None:
            raise ValueError(
                f"{target} templates do not ask for an unknown force; remove "
                "unknown_force"
            )

        allowed = _ANSWER_FORMS[target]
        if self.answer_form not in allowed:
            raise ValueError(
                f"{target} answers must use {' or '.join(sorted(allowed))}; got "
                f"{self.answer_form!r}"
            )

        labels = [force.label for force in self.forces or []]
        if self.unknown_force is not None:
            labels.append(self.unknown_force.label)
        if len(labels) != len(set(labels)):
            raise ValueError(
                "force labels must be distinct so the stem can name each force"
            )
        for label in labels:
            reserved = sorted(
                _RESERVED_LABEL_WORDS & set(label.replace("-", " ").split())
            )
            if reserved:
                raise ValueError(
                    f"force label {label!r} uses {', '.join(reserved)}, which names a "
                    "combination of forces or repeats 'force'; label one individual "
                    "force with a short noun such as 'push' or 'drag'"
                )

        for name, node in _body_recipes(self):
            _check_recipe_size(name, node)
        return self


class PhysicsTemplateSpec(BaseModel):
    """A complete reusable physics template over a finite parameter family."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["physics-1d/0.1"] = PHYSICS_SCHEMA_VERSION
    topic: str = Field(pattern=r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$", max_length=80)
    axis: Axis
    parameters: list[PhysicsParameter] = Field(min_length=1, max_length=MAX_PARAMETERS)
    body: PhysicsBody

    @model_validator(mode="before")
    @classmethod
    def reject_out_of_scope_keys(cls, value: object) -> object:
        """Name the first out-of-scope key instead of a generic extra-field error."""
        if not isinstance(value, dict):
            return value
        body = value.get("body")
        for key in _OUT_OF_SCOPE_KEYS:
            if key in value or (isinstance(body, dict) and key in body):
                raise ValueError(
                    "this pilot models forces along one horizontal line only; "
                    f"{key} is not supported"
                )
        return value

    @model_validator(mode="after")
    def validate_parameters(self) -> PhysicsTemplateSpec:
        quantities = _declared_quantities(self.parameters)
        roles = _role_targets(self.body)
        counts = dict.fromkeys(quantities, 0)

        for role, param, expected in roles:
            if param not in quantities:
                raise ValueError(
                    f"{role} refers to undeclared parameter {param!r}; declare it "
                    "in parameters"
                )
            if quantities[param] != expected:
                raise ValueError(
                    f"{role} must refer to a {expected} parameter; {param!r} is "
                    f"{quantities[param]}"
                )
            counts[param] += 1

        unused = sorted(name for name, count in counts.items() if count == 0)
        repeated = sorted(name for name, count in counts.items() if count > 1)
        if repeated:
            raise ValueError(
                "every parameter must fill exactly one role; used more than once: "
                + ", ".join(repeated)
            )
        if unused:
            raise ValueError(
                "every parameter must fill exactly one role; unused: "
                + ", ".join(unused)
            )

        for name, node in _body_recipes(self.body):
            for param in _recipe_params(node):
                if param not in quantities:
                    raise ValueError(
                        f"{name} refers to undeclared parameter {param!r}; declare "
                        "it in parameters"
                    )
        return self


def _body_recipes(body: PhysicsBody) -> list[tuple[str, RecipeNode]]:
    recipes = [("answer_recipe", body.answer_recipe)]
    recipes.extend(
        (f"distractor {index}", distractor.recipe)
        for index, distractor in enumerate(body.distractors, start=1)
    )
    return recipes


def _check_recipe_size(name: str, node: RecipeNode) -> None:
    depth = _recipe_depth(node)
    if depth > MAX_RECIPE_DEPTH:
        raise ValueError(
            f"{name} is {depth} levels deep; this pilot accepts at most "
            f"{MAX_RECIPE_DEPTH}"
        )
    nodes = _recipe_nodes(node)
    if nodes > MAX_RECIPE_NODES:
        raise ValueError(
            f"{name} has {nodes} nodes; this pilot accepts at most {MAX_RECIPE_NODES}"
        )


def _recipe_depth(node: RecipeNode) -> int:
    if not node.args:
        return 1
    return 1 + max(_recipe_depth(child) for child in node.args)


def _recipe_nodes(node: RecipeNode) -> int:
    return 1 + sum(_recipe_nodes(child) for child in node.args or [])


def _recipe_params(node: RecipeNode) -> list[str]:
    names = [node.param] if node.param else []
    for child in node.args or []:
        names.extend(_recipe_params(child))
    return names


def _declared_quantities(parameters: list[PhysicsParameter]) -> dict[str, str]:
    quantities: dict[str, str] = {}
    for parameter in parameters:
        if parameter.name in quantities:
            raise ValueError(
                f"parameter name {parameter.name!r} is declared more than once"
            )
        quantities[parameter.name] = parameter.quantity
    return quantities


def _role_targets(body: PhysicsBody) -> list[tuple[str, str, str]]:
    roles: list[tuple[str, str, str]] = []
    if body.mass is not None:
        roles.append(("mass", body.mass, "mass"))
    if body.net_force is not None:
        roles.append(("net_force", body.net_force.param, "force"))
    for force in body.forces or []:
        roles.append(("forces", force.param, "force"))
    if body.acceleration is not None:
        roles.append(("acceleration", body.acceleration.param, "acceleration"))
    return roles


class PhysicsProposalBody(PhysicsBody):
    """Authoring may supply reserve recipes beyond the saved distractor limit."""

    distractors: list[PhysicsDistractor] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


class PhysicsProposalSpec(PhysicsTemplateSpec):
    body: PhysicsProposalBody


class H2Body(BaseModel):
    """Recipes over the displayed numeric values of a fixed syllabus family."""

    model_config = ConfigDict(extra="forbid", strict=True)

    target: Literal["h2_quantity"] = "h2_quantity"
    answer_recipe: RecipeNode
    distractors: list[PhysicsDistractor] = Field(
        min_length=1, max_length=MAX_DISTRACTORS
    )


class H2TemplateSpec(BaseModel):
    """A learner-facing statement and calculation defined by a versioned family."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["physics-h2/1.0"]
    family_id: str = Field(pattern=r"^[a-z][a-z0-9_]{0,39}$")
    family_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    parameters: dict[str, list[str]] = Field(default_factory=dict)
    body: H2Body

    @model_validator(mode="after")
    def validate_family(self) -> H2TemplateSpec:
        family = FAMILIES.get(self.family_id)
        if family is None:
            raise ValueError(f"Unsupported H2 Physics family {self.family_id!r}")
        family_hash = family.fingerprint
        if self.family_sha256 is not None and self.family_sha256 != family_hash:
            raise ValueError(
                "H2 Physics family content no longer matches this artifact"
            )
        self.family_sha256 = family_hash
        defaults = family.default_axes
        extra = self.parameters.keys() - defaults.keys()
        if extra:
            raise ValueError(f"Unknown parameter axes: {', '.join(sorted(extra))}")
        for name, values in self.parameters.items():
            if not values or len(values) > len(defaults[name]):
                raise ValueError(f"Parameter {name} needs a nonempty allowed subset")
            if len(set(values)) != len(values):
                raise ValueError(f"Parameter {name} has duplicate values")
            if not set(values) <= set(defaults[name]):
                raise ValueError(f"Parameter {name} is outside the allowed values")
        self.parameters = defaults | self.parameters

        nodes = [("answer_recipe", self.body.answer_recipe)]
        nodes.extend(
            (f"distractor {index}", entry.recipe)
            for index, entry in enumerate(self.body.distractors, 1)
        )
        for name, node in nodes:
            _check_recipe_size(name, node)
            unknown = set(_recipe_params(node)) - defaults.keys()
            if unknown:
                raise ValueError(
                    f"{name} uses unknown parameters: {', '.join(sorted(unknown))}"
                )
        return self


class H2ProposalBody(H2Body):
    distractors: list[PhysicsDistractor] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


class H2ProposalSpec(H2TemplateSpec):
    body: H2ProposalBody


PhysicsItem = PhysicsTemplateSpec | H2TemplateSpec | H2StatementSpec | H2TaskSpec


class UnsupportedPhysicsSpec(BaseModel):
    """An authoring response for a request outside the selected-response catalogue."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["physics-unsupported/1.0"]
    reason: Literal["graph_or_diagram", "practical_investigation", "outside_catalogue"]


class PhysicsTemplateContent(BaseModel):
    """Model-authored physics template proposal with a distractor pool."""

    model_config = ConfigDict(extra="forbid", strict=True)

    item: PhysicsProposalSpec | H2ProposalSpec | UnsupportedPhysicsSpec


class PhysicsTemplateCandidate(BaseModel):
    """Provider-neutral reusable template contract for physics items."""

    model_config = ConfigDict(extra="forbid", strict=True)

    item: PhysicsItem
    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]*$")
    difficulty: Difficulty
    question_type: Literal["mcq"] = "mcq"


class PhysicsValidationSummary(PropertyCheckSummary):
    """Sampled-domain evidence for one checked physics template."""

    validator_version: Literal["mcp-physics-template-v1"] = PHYSICS_VALIDATOR_VERSION
    checking_mode: Literal["property_based"] = PHYSICS_CHECKING_MODE
    evidence: list[ValidationEvidence] = Field(min_length=1)


class ValidatedPhysicsTemplate(ValidatedTemplateArtifact):
    """A physics template whose recipes passed the bounded property checks."""

    model_config = ConfigDict(extra="forbid", strict=True)

    format_version: Literal["1.0.0"] = PHYSICS_FORMAT_VERSION
    template: PhysicsTemplateCandidate
    validation: PhysicsValidationSummary


class PhysicsQuestionInstance(BaseModel):
    """A reproducible question expanded from a validated physics template."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template_id: str
    artifact_id: str | None = None
    seed: int
    parameters: dict[str, str]
    question: str = Field(min_length=1)
    choices: list[str] = Field(min_length=2)
    correct_index: int = Field(ge=0)
    answer: str = Field(min_length=1)
    topic: str
    target: (
        Target
        | Literal["h2_quantity", "h2_statement_set", "h2_task", "authored_quantity"]
    )
    unit: Unit | H2Unit | AuthoredUnit | Literal[""]
    assumptions: list[str]
    stimulus: Stimulus | None = None
    requires_manual_review: Literal[True] = True

    @model_serializer(mode="wrap")
    def omit_empty_stimulus(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        payload = handler(self)
        if self.stimulus is None:
            payload.pop("stimulus", None)
        return payload

    @model_validator(mode="after")
    def validate_choices(self) -> PhysicsQuestionInstance:
        if self.correct_index >= len(self.choices):
            raise ValueError("correct_index must identify one choice")
        if len(self.choices) != len(set(self.choices)):
            raise ValueError("choices must be distinct")
        if self.choices[self.correct_index] != self.answer:
            raise ValueError("answer must equal the choice at correct_index")
        return self
