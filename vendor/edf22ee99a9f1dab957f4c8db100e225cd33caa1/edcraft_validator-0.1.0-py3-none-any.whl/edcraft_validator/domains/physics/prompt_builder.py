"""Build physics-domain prompts and the structured LLM request."""

from __future__ import annotations

from typing import Any

from edcraft_validator.domains.physics.h2_authoring import (
    CompactH2Response,
    H2CompactUnsupported,
)
from edcraft_validator.domains.physics.h2_catalog import FAMILIES, Family
from edcraft_validator.domains.physics.h2_statement_data import (
    H2StatementProposal,
    catalogue,
    requested_skill,
    skill_hints,
)
from edcraft_validator.domains.physics.h2_task_data import (
    FAMILIES as TASK_FAMILIES,
)
from edcraft_validator.domains.physics.h2_task_data import H2TaskProposal, match_task
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsTemplateContent,
    PhysicsTemplateRequest,
)
from edcraft_validator.domains.physics.physics_types import (
    MAX_DISTRACTORS,
    MIN_DISTRACTORS,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

PHYSICS_TEMPLATE_PROMPT_VERSION = "physics-template-v4"
H2_COMPACT_PROMPT_VERSION = "physics-h2-compact-v3"


def _family_description(name: str, family: Family) -> str:
    axes = ", ".join(f"{axis.name}={'/'.join(axis.values)}" for axis in family.axes)
    sign = "Signed" if family.signed else "Nonnegative"
    return (
        f"- {name}, 9478 Topic {family.topic}: {family.title}. {axes}. "
        f"Key uses {family.rule}. {sign} answer in {family.unit}."
    )


_H2_FAMILIES = "\n".join(
    _family_description(name, family) for name, family in FAMILIES.items()
)
_STIMULUS_NAMES = {
    "graph": "plotted graph",
    "diagram": "schematic diagram",
    "table": "observation table",
}


def _statement_hint(key: str, skill: str) -> str:
    family = catalogue()[key]
    kinds = sorted({case.stimulus.kind for case in family.cases if case.stimulus})
    stimulus_text = (
        " Built-in displayed stimulus: "
        + ", ".join(_STIMULUS_NAMES[kind] for kind in kinds)
        if kinds
        else ""
    )
    return f"{key}: {skill}{stimulus_text}"


def build_compact_h2_generation_request(
    request: PhysicsTemplateRequest,
) -> StructuredGenerationRequest[Any]:
    task = match_task(request.prompt)
    if task is not None:
        description = TASK_FAMILIES[task].description
        return StructuredGenerationRequest(
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"The built-in H2 Physics task {task} matches this request. "
                        f"It requires students to {description.lower()}. "
                        "Return this task_id and select physics_verify_item with {}. "
                        "The server renders the question, answer and contrast choices."
                    ),
                },
                {"role": "user", "content": request.prompt},
            ],
            response_model=PlannedGenerationResponse[
                H2TaskProposal | H2StatementProposal | H2CompactUnsupported
            ],
            prompt_version="physics-h2-task-v1",
            schema_name="template_proposal_and_check_plan",
            check_argument_models=(),
            reasoning_effort="low",
        )
    pool_size = request.num_distractors + SURPLUS_RECIPES
    explicit = requested_skill(request.prompt)
    hints = skill_hints(request.prompt)
    numeric_instructions = (
        "Author a reusable Singapore 9478 H2 Physics MCQ. Pick the catalogue "
        "family that fulfils the requested skill. The server renders its fixed "
        "question and samples its stated parameter values. The proposal supplies "
        "family_id, answer and distractors. An answer or wrong-choice expression "
        "uses variables, decimal constants, + - * / and parentheses. No functions, "
        "powers or prose in expressions. For a square, write x*x. Each wrong "
        "choice has expression and a brief explanation of the learner's error. "
        "Use the listed numerical values in their displayed units. Every retained "
        "choice must be exact to 3 decimals, distinct from the key and each "
        "other choice over sampled inputs, and nonnegative for a nonnegative "
        "family. Write reserves with genuinely different failure modes. Choose "
        "physics_verify_item and physics_validate_options with {} in checks; the "
        "server adds the other required checks. Use the unsupported proposal "
        "shape for missing families, unsupplied evidence or practical performance.\n\n"
        + _H2_FAMILIES
    )
    statement_instructions = (
        "For a listed reviewed statement-set skill, use proposal.skill_id, key 0 "
        "and distinct integer distractors from 1 through 15. Each integer uses "
        "four binary positions to indicate which of the four statements change "
        "membership from the correct option. The server supplies the scenario, "
        "any built-in displayed stimulus listed below and the verified answer. "
        "A matching built-in stimulus fulfils a request to show a graph, diagram "
        "or table. Select the listed skill in that case. You do not generate a "
        "separate image. Prefer a mix of "
        "single-statement flips and useful combinations. Select "
        "physics_verify_item with {} in checks. Use the unsupported proposal "
        "shape when the listed skill cannot fulfil the requested task.\n"
        + "\n".join(_statement_hint(key, skill) for key, skill in hints)
    )
    if explicit:
        system = (
            "Author a reusable Singapore 9478 H2 Physics MCQ.\n"
            + statement_instructions
        )
    elif hints:
        system = numeric_instructions + "\n\n" + statement_instructions
    else:
        system = numeric_instructions
    response_model = (
        PlannedGenerationResponse[H2StatementProposal | H2CompactUnsupported]
        if explicit
        else PlannedGenerationResponse[CompactH2Response]
    )
    return StructuredGenerationRequest(
        messages=[
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": (
                    f"{request.prompt}\nRequested difficulty: {request.difficulty}. "
                    f"Author exactly {pool_size} wrong-choice candidates so the "
                    f"server can keep {request.num_distractors}."
                ),
            },
        ],
        response_model=response_model,
        prompt_version=H2_COMPACT_PROMPT_VERSION,
        schema_name="template_proposal_and_check_plan",
        check_argument_models=(),
        reasoning_effort="low",
        revise_from_authored_pool=True,
    )


_H2_SCOPE = (
    """\
REVISED SINGAPORE H2 PHYSICS (9478)
For a request matching a listed family, use item.schema_version physics-h2/1.0,
item.family_id from the list and item.body with answer_recipe and distractors.
Do not supply prose, units, axes or question wording for this shape. Default
numeric parameter values are chosen by the application. The recipe variables
are the stated numerical values, including signs and displayed-unit scales.
Use the same closed arithmetic nodes and exact candidate count described below.
For multiplication with more than four factors, nest multiplication nodes.
Candidate decimals must be exact to three places. Negative options are allowed
only for signed questions. Select the normal Physics tools. The text fidelity
tool checks the controlled wording structurally for this shape.
Aim for wrong recipes that stay distinct at the extremes of the listed ranges.
Division by an arbitrary input can make otherwise plausible options inexact.
For an explicit request outside these families and the legacy scope below,
do not substitute an unrelated valid question. Return item.schema_version
physics-unsupported/1.0 and item.reason from graph_or_diagram,
practical_investigation or outside_catalogue. Use a recognised Physics check
in the response plan even for a declared unsupported item.

Supported H2 families
"""
    + _H2_FAMILIES
    + "\n\n"
)

PHYSICS_WORKED_EXAMPLE = """\
{
  "item": {
    "schema_version": "physics-1d/0.1",
    "topic": "school.newton_second_law",
    "axis": {"orientation": "horizontal", "positive": "right"},
    "parameters": [
      {"name": "m", "quantity": "mass", "unit": "kg", "values": ["2", "4", "5", "8"]},
      {"name": "F1", "quantity": "force", "unit": "N", "values": ["20", "30", "40"]},
      {"name": "F2", "quantity": "force", "unit": "N", "values": ["5", "10", "15"]}
    ],
    "body": {
      "target": "acceleration",
      "mass": "m",
      "forces": [
        {"param": "F1", "direction": "positive", "label": "push"},
        {"param": "F2", "direction": "negative", "label": "friction"}
      ],
      "text": "A {m} box is pushed with {F1} while friction of {F2} acts on it.",
      "answer_form": "magnitude_and_direction",
      "display": {"decimals": 3},
      "answer_recipe": {
        "op": "div",
        "args": [
          {"op": "sub", "args": [{"param": "F1"}, {"param": "F2"}]},
          {"param": "m"}
        ]
      },
      "distractors": [
        {
          "recipe": {
            "op": "div",
            "args": [
              {"op": "add", "args": [{"param": "F1"}, {"param": "F2"}]},
              {"param": "m"}
            ]
          },
          "misconception": "added_opposing_forces",
          "explanation": "Adds the friction force instead of subtracting it."
        },
        {
          "recipe": {"op": "div", "args": [{"param": "F1"}, {"param": "m"}]},
          "misconception": "ignored_opposing_force",
          "explanation": "Ignores the friction force."
        },
        {
          "recipe": {"op": "mul", "args": [{"param": "m"}, {"param": "F1"}]},
          "misconception": "multiplied_instead_of_divided",
          "explanation": "Multiplies by the mass instead of dividing by it."
        },
        {
          "recipe": {
            "op": "neg",
            "args": [
              {
                "op": "div",
                "args": [
                  {"op": "sub", "args": [{"param": "F1"}, {"param": "F2"}]},
                  {"param": "m"}
                ]
              }
            ]
          },
          "misconception": "direction_sign_error",
          "explanation": "Points the acceleration the wrong way."
        },
        {
          "recipe": {
            "op": "mul",
            "args": [
              {"op": "add", "args": [{"param": "F1"}, {"param": "F2"}]},
              {"param": "m"}
            ]
          },
          "misconception": "multiplied_instead_of_divided",
          "explanation": "Adds the forces and multiplies by mass."
        },
        {
          "recipe": {
            "op": "neg",
            "args": [{"op": "div", "args": [{"param": "F1"}, {"param": "m"}]}]
          },
          "misconception": "direction_sign_error",
          "explanation": "Uses only the push and reverses its direction."
        }
      ]
    }
  }
}"""

PHYSICS_TEMPLATE_SYSTEM_PROMPT = (
    _H2_SCOPE
    + """\
Generate one reusable physics multiple-choice template and recommend its fixed
validation checks in the same structured response. Do not generate one concrete
question. The local application derives identity, difficulty and question type;
you author the reusable task and its wrong choices.

Return one item family in the `item` field as `{"item": {...}}`.

LEGACY PHYSICS SCOPE (physics-1d/0.1)
- One object of constant positive mass on one horizontal axis, with F_net = m a
  and SI units only: kg for mass, N for force, m/s^2 for acceleration. Do not
  use weight, gravity, vertical motion, friction coefficients, angles or unit
  conversion.
- `item.topic` is a stable dotted identifier such as `school.newton_second_law`.
- `item.axis` is always {"orientation": "horizontal", "positive": "right"} or
  the same with "left". Every direction below is "positive" or "negative"
  relative to that axis.

PARAMETERS
- `item.parameters` declares one to six parameters. Every value is a
  non-negative magnitude string with at most three decimal places and no sign,
  exponent or leading zeros, for example "2" or "1.5". A mass must satisfy
  0 < v <= 1000; a force 0 <= v <= 10000; an acceleration 0 <= v <= 1000.
- Give each parameter a broad value list of up to 16 values so the family yields
  distinct questions. Validation samples the family and always checks the lowest
  and highest value of every parameter, so a breaking extreme is a real defect.
- `unit` must match the quantity: kg, N or m/s^2.

ROLES
Every declared parameter fills exactly one role, and every role names a declared
parameter of the matching quantity. A parameter must not be unused or used
twice. The body sets these roles per target (R required, - forbidden):

| target | mass | net_force | forces | acceleration | unknown_force |
|---|---|---|---|---|---|
| acceleration | R | one of net_force/forces | one of | - | - |
| net_force | R | - | - | R | - |
| mass | - | one of net_force/forces | one of | R | - |
| missing_force | R | - | R | R | R |

`forces` has one to three `{"param", "direction", "label"}` entries. Force
labels, including `unknown_force.label`, are distinct lowercase words such as
"push", "friction" or "air resistance". A label names one force, so it never
uses net, resultant, total, overall, combined or sum, and never the word force
(the application adds it).

STEM TEXT
- `body.text` is learner-facing prose with exactly one `{name}` placeholder for
  every declared parameter. It allows no other braces, no digit outside a
  placeholder and no question mark, because the application appends the
  assumptions and the question sentence itself. A placeholder shows the value
  with its role: a force or acceleration reads "30 N to the right" or
  "3 m/s² to the left", and a mass reads "2 kg".
- The stem uses only letters, spaces and the punctuation , . ; : ' ( ), with a
  hyphen only between two letters.
- Write each known force's label within the four words just before its
  placeholder, for example "a push of {F1}" or "friction of {F2}" (a short
  inflection such as "pushed with {F1}" also counts).
- The stem describes the object and its forces only. It must not contain
  numbers written in words (two, half, twice, ...), the words left, right,
  leftward, rightward, east or west outside placeholders, a motion state the
  checks never see (at rest, stationary, constant velocity or speed,
  equilibrium, balanced, slows, decelerates, speeds up), or answer
  instructions (answer, report, give, find, calculate, determine, magnitude,
  decimal, round, positive, negative, sign).
- For `missing_force`, the stem names the unknown force by its exact label,
  without any value or side, and never puts that label just before a known
  force's value. The application states its side.
- The application appends "Take right as the positive direction." (or left)
  and "All forces act along one horizontal line.". With `forces` it adds "The
  forces described are the only horizontal forces acting on the object.". With
  `net_force` it adds "The net force given is the resultant of all horizontal
  forces on the object.". With `missing_force` it adds "The <label> force acts
  to the <side>." and "The forces described, including the <label> force, are
  the only horizontal forces acting on the object.".
- It then asks one fixed sentence, so never repeat it in the stem:
  "What is the magnitude and direction of the object's acceleration?",
  "What is the object's acceleration along the positive direction? A negative
  value means it points the other way.", the same two with "net force",
  "What is the mass of the object?", or "What is the magnitude of the {label}
  force?" for `missing_force`.

RECIPES
- Every recipe is a closed data tree. A node sets exactly one of {"param": "m"},
  {"const": "2"} or {"op": "...", "args": [...]}. Supported ops are add and mul
  (2 to 4 args), sub and div (2 args) and neg (1 arg). A tree is at most 5
  levels deep and 15 nodes; `const` is a signed decimal with at most 3 decimals.
- Parameters evaluate to their non-negative magnitudes, so the recipe applies
  directions itself with sub or neg.
- The answer recipe's value is the signed component along the positive axis for
  `acceleration` and `net_force` in both answer forms, and the positive
  magnitude for `mass` and `missing_force`. It must equal the canonical value
  exactly: acceleration F_net / m, net_force m a, mass F_net / a, and
  missing_force F_u = s_u (m a - sum s_i F_i), where s is +1 for positive and
  -1 for negative.
- `answer_form` is "signed_component" or "magnitude_and_direction" for
  acceleration and net_force, and "magnitude" for mass and missing_force.
- `display.decimals` is 0 to 3. Every correct answer AND every distractor must
  be exact at that many decimals for every parameter combination, so choose
  values whose divisions come out exact.
- Every combination must be physically consistent. For a mass target the
  acceleration is never zero and points the same way as the net force. For a
  missing force the result is always positive in its stated direction; a zero is
  a contradiction because the force would not exist.

DISTRACTORS
- Provide exactly the candidate count specified in the author request, three
  more than the number of usable distractors it asks for. The application
  chooses one fixed set of usable recipes that works across sampled inputs.
  Each candidate has a recipe, a misconception tag from this
  closed list: multiplied_instead_of_divided, inverted_ratio,
  added_opposing_forces, ignored_opposing_force, direction_sign_error,
  reported_net_force, other; and a one-line explanation of the error.
- Aim for each candidate to differ from the key and from every other option, by
  exact value and rendered text, for every combination. A retained candidate
  must also be exact at `display.decimals` and non-negative for a magnitude
  answer (strictly positive for a mass).
- A distractor recipe may carry a different unit or dimension, for example
  reporting an acceleration as a mass. That unit slip is a valid misconception:
  the dimension is reported but does not fail the option.
- For legacy recipes, addition or subtraction must combine terms with matching
  physical dimensions even when the final dimension differs from the key.

CHECK PLAN
- Select a nonempty fixed subset of the available MCP tools using their supplied
  descriptions. Use each tool name at most once and do not invent names. Supply
  each selected check's model-owned arguments using its planning schema; use {}
  for checks without model-owned arguments.
- The application always runs physics_verify_item, physics_validate_options,
  physics_verify_text and physics_verify_text_fidelity, whether or not you select
  them. The fourth check is a blind parse-back: a separate model reads the
  rendered question without the template and restates the setup. The stem must
  therefore describe exactly the structured setup and nothing else, because any
  extra claim or different reading quarantines the template.
- Select assess_template_difficulty and assess_template_relevance. They are
  advisory evidence for educator review and never block a technically checked
  template. The difficulty rubric is provisional and uncalibrated.

WORKED EXAMPLE
The JSON below supplies six candidates for a request for three usable
distractors. Adapt the item and the candidate count to the author request.
"""
    + PHYSICS_WORKED_EXAMPLE
)

RESPONSE_GUIDANCE = """\
Use native JSON values. Parameter values are strings such as "2" or "1.5";
recipes are objects such as {"op": "sub", "args": [{"param": "F1"},
{"param": "F2"}]}, and only learner-facing text uses `{...}` placeholders.
"""


def build_physics_generation_request(
    request: PhysicsTemplateRequest,
) -> StructuredGenerationRequest[PlannedGenerationResponse[PhysicsTemplateContent]]:
    """Return the provider-independent physics proposal contract."""
    user_prompt = f"""\
Author request (preserve its meaning):
{request.prompt}

Requested difficulty: {request.difficulty}
Required usable distractors: {request.num_distractors}
Candidate distractors to author: exactly {request.num_distractors + SURPLUS_RECIPES}
Supported distractor range: {MIN_DISTRACTORS} to {MAX_DISTRACTORS}
"""

    return StructuredGenerationRequest(
        revise_from_authored_pool=True,
        messages=[
            {"role": "system", "content": PHYSICS_TEMPLATE_SYSTEM_PROMPT},
            {"role": "user", "content": f"{user_prompt}\n{RESPONSE_GUIDANCE}"},
        ],
        response_model=PlannedGenerationResponse[PhysicsTemplateContent],
        prompt_version=f"{PHYSICS_TEMPLATE_PROMPT_VERSION}+response-v1",
        schema_name="template_proposal_and_check_plan",
        check_argument_models=(),
    )
