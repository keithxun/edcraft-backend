"""Property-checked template checks for the physics pilot.

A physics template describes a finite parameter family, so both the answer
recipe and every distractor can be checked exactly for each combination. The
shared property runner samples that family, always covers small domains
completely, and reports the first defect it finds. Nothing here floats: values
stay :class:`fractions.Fraction` until they are rendered as evidence text.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from fractions import Fraction
from typing import Any

from edcraft_validator.domains.physics import correctness
from edcraft_validator.domains.physics import text as physics_text
from edcraft_validator.domains.physics.correctness import PhysicsCheckError
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsTemplateSpec,
    RecipeNode,
)
from edcraft_validator.domains.physics.physics_types import (
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TEXT_TOOL,
    PHYSICS_TOOL_VERSION,
)
from edcraft_validator.domains.physics.quantities import (
    QUANTITY_DIMENSIONS,
    QUANTITY_UNITS,
    TARGET_QUANTITIES,
    parse_decimal,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

_MAX_FINDINGS = 20


@dataclass(frozen=True)
class _Failure:
    """The first failing combination, kept before the property engine shrinks."""

    variant: str
    code: str
    message: str
    canonical: str | None = None
    recipe_value: str | None = None
    options: tuple[dict[str, object], ...] = ()


def verify_item(
    template: PhysicsTemplateSpec, *, timeout_seconds: float = 30.0
) -> ToolEvidence:
    """Check the answer recipe equals the exact correct value at every sampled
    combination, with the right dimension and no contradiction."""
    return _run_property_check(template, kind="item", timeout_seconds=timeout_seconds)


def validate_options(
    template: PhysicsTemplateSpec, *, timeout_seconds: float = 30.0
) -> ToolEvidence:
    """Check every distractor is wrong, distinct, exact and physical at every
    sampled combination, so the key is the only acceptable option."""
    return _run_property_check(
        template, kind="options", timeout_seconds=timeout_seconds
    )


def verify_text(template: PhysicsTemplateSpec) -> ToolEvidence:
    """Check the stem shows each declared parameter once and carries no other
    number, foreign placeholder or question mark."""
    started = time.perf_counter()
    try:
        found = physics_text.placeholders(template.body.text)
        defects = physics_text.text_findings(template)
    except Exception as exc:  # noqa: BLE001 - the tool boundary reports failures
        return _error_evidence(
            PHYSICS_TEXT_TOOL,
            code="TOOL_FAILURE",
            message=f"physics text check failed with {type(exc).__name__}",
            details={"placeholders": []},
            started=started,
        )

    return ToolEvidence(
        tool=PHYSICS_TEXT_TOOL,
        version=PHYSICS_TOOL_VERSION,
        status="failed" if defects else "passed",
        findings=[ToolFinding(code=code, message=message) for code, message in defects],
        details={"placeholders": found},
        duration_ms=_elapsed_ms(started),
    )


def _run_property_check(
    template: PhysicsTemplateSpec,
    *,
    kind: str,
    timeout_seconds: float,
) -> ToolEvidence:
    started = time.perf_counter()
    run = PropertyCheckRun(PropertyCheckSettings(timeout_seconds=timeout_seconds))
    axes = _axes(template)
    boundary = _boundary_examples(axes)
    failures: list[_Failure] = []

    def check_case(
        combination: dict[str, str], budget: PropertyCheckRun
    ) -> list[dict[str, object]] | None:
        budget.reserve_execution()
        variant = _variant_text(template, combination)
        try:
            if kind == "item":
                correctness.check_key(template, combination)
                return None
            entries = correctness.check_options(template, combination)
        except PhysicsCheckError as error:
            failure = _key_failure(template, combination, variant, error)
            _remember(failures, failure)
            raise ValidationFailure(
                failure.message,
                code=failure.code,
                context=_failure_context(failure),
            ) from None

        failed = next(
            (entry for entry in entries if entry.get("status") == "failed"), None
        )
        if failed is None:
            return entries

        failure = _option_failure(template, combination, variant, failed, entries)
        _remember(failures, failure)
        raise ValidationFailure(
            failure.message,
            code=failure.code,
            context=_failure_context(failure),
        )

    try:
        results = run.check(axes, boundary, check_case, cover_small_domain=True)
    except ValidationFailure as exc:
        if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED":
            return _error_evidence(
                _tool_name(kind),
                code=exc.code,
                message=str(exc),
                details=_details(template, run, kind=kind, options=[]),
                started=started,
            )
        return _failed_evidence(template, run, kind, failures, exc, started)
    except Exception as exc:  # noqa: BLE001 - the tool boundary reports failures
        return _error_evidence(
            _tool_name(kind),
            code="TOOL_FAILURE",
            message=f"physics {kind} check failed with {type(exc).__name__}",
            details=_details(template, run, kind=kind, options=[]),
            started=started,
        )

    options: list[dict[str, object]] | None = None
    if kind == "options":
        options = _option_entries(results[0]) if results else []
    return ToolEvidence(
        tool=_tool_name(kind),
        version=PHYSICS_TOOL_VERSION,
        status="passed",
        details=_details(template, run, kind=kind, options=options),
        duration_ms=_elapsed_ms(started),
    )


def _failed_evidence(
    template: PhysicsTemplateSpec,
    run: PropertyCheckRun,
    kind: str,
    failures: list[_Failure],
    error: ValidationFailure,
    started: float,
) -> ToolEvidence:
    """Report the first defect, then the final shrunk one when it differs."""
    findings: list[ToolFinding] = []
    first = failures[0] if failures else None
    if first is not None:
        findings.append(ToolFinding(code=first.code, message=first.message))
    final_variant = error.context.get("variant")
    if first is None or first.code != error.code or first.variant != final_variant:
        findings.append(ToolFinding(code=error.code, message=str(error)))
    findings = findings[:_MAX_FINDINGS]

    options: list[dict[str, object]] | None = None
    if kind == "options":
        options = _option_entries(list(first.options)) if first is not None else []

    details = _details(template, run, kind=kind, options=options)
    if first is not None:
        details["first_failure"] = _failure_context(first)
    elif final_variant is not None:
        details["first_failure"] = {
            "variant": str(final_variant),
            "code": error.code,
        }

    return ToolEvidence(
        tool=_tool_name(kind),
        version=PHYSICS_TOOL_VERSION,
        status="failed",
        findings=findings,
        details=details,
        duration_ms=_elapsed_ms(started),
    )


def _error_evidence(
    tool: str,
    *,
    code: str,
    message: str,
    details: dict[str, Any],
    started: float,
) -> ToolEvidence:
    return ToolEvidence(
        tool=tool,
        version=PHYSICS_TOOL_VERSION,
        status="error",
        findings=[ToolFinding(code=code, message=message)],
        details=details,
        duration_ms=_elapsed_ms(started),
    )


def _details(
    template: PhysicsTemplateSpec,
    run: PropertyCheckRun,
    *,
    kind: str,
    options: list[dict[str, object]] | None,
) -> dict[str, Any]:
    quantity = TARGET_QUANTITIES[template.body.target]
    details: dict[str, Any] = {
        **run.details(),
        "target": template.body.target,
        "unit": QUANTITY_UNITS[quantity],
        "dimension": list(QUANTITY_DIMENSIONS[quantity]),
        "rule": correctness.rule_text(template.body.target),
        "answer_form": template.body.answer_form,
    }
    if kind == "options":
        details["options"] = options or []
    return details


def _axes(template: PhysicsTemplateSpec) -> dict[str, list[str]]:
    """Declared values per parameter, ordered by exact value."""
    return {
        parameter.name: sorted(parameter.values, key=parse_decimal)
        for parameter in template.parameters
    }


def _boundary_examples(axes: dict[str, list[str]]) -> list[dict[str, str]]:
    """All-minimum, all-maximum, then each axis extreme with others minimal."""
    minimum = {name: values[0] for name, values in axes.items()}
    maximum = {name: values[-1] for name, values in axes.items()}
    examples = [minimum, maximum]
    for name, values in axes.items():
        examples.append(minimum | {name: values[0]})
        examples.append(minimum | {name: values[-1]})

    unique: dict[tuple[tuple[str, str], ...], dict[str, str]] = {}
    for example in examples:
        unique[_combination_key(example)] = example
    return list(unique.values())


def _combination_key(combination: dict[str, str]) -> tuple[tuple[str, str], ...]:
    return tuple((name, value) for name, value in sorted(combination.items()))


def _variant_text(template: PhysicsTemplateSpec, combination: dict[str, str]) -> str:
    return ", ".join(
        f"{parameter.name}={combination[parameter.name]}"
        for parameter in template.parameters
    )


def _key_failure(
    template: PhysicsTemplateSpec,
    combination: dict[str, str],
    variant: str,
    error: PhysicsCheckError,
) -> _Failure:
    return _Failure(
        variant=variant,
        code=error.code,
        message=error.message,
        canonical=_canonical_text(template, combination),
        recipe_value=_recipe_text(template, combination, template.body.answer_recipe),
    )


def _option_failure(
    template: PhysicsTemplateSpec,
    combination: dict[str, str],
    variant: str,
    entry: dict[str, object],
    entries: list[dict[str, object]],
) -> _Failure:
    raw_index = entry["index"]
    assert isinstance(raw_index, int)
    index = raw_index
    return _Failure(
        variant=variant,
        code=str(entry["code"]),
        message=str(entry["reason"]),
        canonical=_canonical_text(template, combination),
        recipe_value=_recipe_text(
            template,
            combination,
            template.body.distractors[index - 1].recipe,
        ),
        options=tuple(entries),
    )


def _remember(failures: list[_Failure], failure: _Failure) -> None:
    """Keep only the first failure; shrinking replays the same combination."""
    if not failures:
        failures.append(failure)


def _failure_context(failure: _Failure) -> dict[str, Any]:
    context: dict[str, Any] = {
        "variant": failure.variant,
        "code": failure.code,
    }
    if failure.canonical is not None:
        context["canonical"] = failure.canonical
    if failure.recipe_value is not None:
        context["recipe_value"] = failure.recipe_value
    return context


def _canonical_text(
    template: PhysicsTemplateSpec, combination: dict[str, str]
) -> str | None:
    try:
        values = correctness.parameter_values(template, combination)
        return _fraction_text(correctness.canonical_answer(template, values))
    except Exception:  # noqa: BLE001 - evidence is best effort
        return None


def _recipe_text(
    template: PhysicsTemplateSpec,
    combination: dict[str, str],
    node: RecipeNode,
) -> str | None:
    try:
        values = correctness.parameter_values(template, combination)
        value, _ = correctness.evaluate_recipe(node, template, values)
        return _fraction_text(value)
    except Exception:  # noqa: BLE001 - evidence is best effort
        return None


def _fraction_text(value: Fraction) -> str:
    return str(value)


def _option_entries(
    entries: list[dict[str, object]],
) -> list[dict[str, object]]:
    normalized: list[dict[str, object]] = []
    for entry in entries:
        item: dict[str, object] = {
            "index": entry["index"],
            "misconception": entry["misconception"],
            "dimension_consistent": entry["dimension_consistent"],
            "status": entry["status"],
        }
        if entry.get("status") == "failed":
            item["reason"] = entry.get("reason")
        normalized.append(item)
    return normalized


def _tool_name(kind: str) -> str:
    return PHYSICS_ITEM_TOOL if kind == "item" else PHYSICS_OPTIONS_TOOL


def _elapsed_ms(started: float) -> float:
    return (time.perf_counter() - started) * 1000
