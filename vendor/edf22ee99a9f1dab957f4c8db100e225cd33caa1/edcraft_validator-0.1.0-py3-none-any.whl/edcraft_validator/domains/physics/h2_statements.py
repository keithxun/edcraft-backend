"""Select, verify and render reviewed Physics statement cases."""

from __future__ import annotations

from itertools import permutations
from time import monotonic

from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewChoiceExample,
    build_template_id,
    seeded_index,
)
from edcraft_validator.domains.physics.h2_statement_data import (
    ChoiceFamily,
    H2StatementProposal,
    H2StatementSpec,
    StatementCase,
    catalogue,
    historical_statement_families,
    requested_skill,
)
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsQuestionInstance,
    PhysicsTemplateCandidate,
    PhysicsTemplateRequest,
)
from edcraft_validator.domains.physics.physics_types import (
    PHYSICS_FIDELITY_TOOL,
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TEXT_TOOL,
    PHYSICS_TOOL_VERSION,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    sample_assignments,
    select_fixed_subset,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

_ORDERS = tuple(permutations(range(4)))
_LABELS = "ABCD"
STATEMENT_CHECK_BUDGET = 12
STATEMENT_CHECK_TIMEOUT_SECONDS = 1.0


def key_mask(truth: list[bool], order: tuple[int, ...], *, ask_false: bool) -> int:
    return sum(
        1 << slot for slot, original in enumerate(order) if truth[original] != ask_false
    )


def labelled_mask(mask: int) -> str:
    labels = [label for index, label in enumerate(_LABELS) if mask & (1 << index)]
    if len(labels) == 4:
        return "All four statements"
    if not labels:
        return "None of the statements"
    return (
        " and ".join(labels)
        if len(labels) < 3
        else f"{', '.join(labels[:-1])} and {labels[-1]}"
    ) + " only"


def pinned_statement_family(spec: H2StatementSpec) -> ChoiceFamily:
    family = catalogue().get(spec.skill_id)
    if family is not None and spec.family_sha256 == family.fingerprint:
        return family
    historical = historical_statement_families().get(
        (spec.skill_id, spec.family_sha256)
    )
    if historical is not None and historical.fingerprint == spec.family_sha256:
        return historical
    if family is None:
        raise ValueError(f"Unsupported 9478 skill {spec.skill_id}")
    raise ValueError("The checked statement case no longer matches its fingerprint")


def _options(
    case: StatementCase,
    masks: list[int],
    order: tuple[int, ...] = _ORDERS[0],
    *,
    ask_false: bool,
) -> tuple[OptionValue, list[OptionValue]]:
    correct = key_mask(
        [row.valid for row in case.statements], order, ask_false=ask_false
    )
    key = OptionValue(correct, labelled_mask(correct))
    return key, [
        OptionValue(correct ^ mask, labelled_mask(correct ^ mask)) for mask in masks
    ]


def build_statement_candidate(
    request: PhysicsTemplateRequest, proposal: H2StatementProposal
) -> PhysicsTemplateCandidate:
    expected = requested_skill(request.prompt)
    if expected is not None and proposal.skill_id != expected:
        raise DistractorPoolError(f"Use the requested 9478 skill {expected}")
    family = catalogue().get(proposal.skill_id)
    if family is None:
        raise DistractorPoolError(f"Unsupported 9478 skill {proposal.skill_id}")
    if proposal.key != 0:
        raise DistractorPoolError(
            "PHYSICS_ANSWER_MISMATCH: use the verified truth pattern"
        )
    required = request.num_distractors
    masks = proposal.distractors
    if len(masks) != required + SURPLUS_RECIPES:
        raise DistractorPoolError(
            f"Author exactly {required + SURPLUS_RECIPES} statement distractor masks"
        )
    # XOR with the correct mask is bijective, so collisions are identical for
    # every key. Each four-bit mask has its own rendered label.
    representative = _options(family.cases[0], masks, ask_false=False)
    selected = select_fixed_subset((representative,), required)
    spec = H2StatementSpec.model_validate(
        {
            "schema_version": "physics-h2-statements/1.0",
            "skill_id": proposal.skill_id,
            "family_sha256": family.fingerprint,
            "body": {
                "key": proposal.key,
                "distractors": [masks[index] for index in selected],
            },
        }
    )
    return PhysicsTemplateCandidate(
        template_id=build_template_id("physics", request, proposal),
        difficulty=request.difficulty,
        item=spec,
    )


def _checked_body(spec: H2StatementSpec) -> ChoiceFamily:
    family = pinned_statement_family(spec)
    _validate_answer_and_masks(spec)
    return family


def _validate_answer_and_masks(spec: H2StatementSpec) -> None:
    if spec.body.key != 0:
        raise ValueError("The answer must use the verified statement truth pattern")
    masks = spec.body.distractors
    if len(set(masks)) != len(masks) or 0 in masks:
        raise ValueError("Each distractor needs a distinct nonzero statement mask")


def verify_statement(
    spec: H2StatementSpec,
    tool: str,
    *,
    timeout_seconds: float = STATEMENT_CHECK_TIMEOUT_SECONDS,
) -> ToolEvidence:
    timeout_seconds = min(timeout_seconds, STATEMENT_CHECK_TIMEOUT_SECONDS)
    started = monotonic()
    deadline = started + timeout_seconds

    def require_time() -> None:
        if monotonic() >= deadline:
            raise TimeoutError("Statement checking exhausted its time budget")

    findings = []
    family = None
    checked = 0
    calls = 0
    timed_out = False
    try:
        family = pinned_statement_family(spec)
        if tool == PHYSICS_ITEM_TOOL and spec.body.key != 0:
            raise ValueError("The answer must use the verified statement truth pattern")
        if tool == PHYSICS_OPTIONS_TOOL:
            _validate_answer_and_masks(spec)
        require_time()
        assignments = sample_assignments(
            {
                "scenario": range(len(family.cases)),
                "order": range(len(_ORDERS)),
                "polarity": (False, True),
            },
            budget=STATEMENT_CHECK_BUDGET,
            seed=0,
        )
        require_time()
        if not assignments:
            raise ValueError("No statement assignments were checked")
        for row in assignments:
            require_time()
            calls += 1
            case = family.cases[row["scenario"]]
            order = _ORDERS[row["order"]]
            polarity = bool(row["polarity"])
            key, choices = _options(
                case, spec.body.distractors, order, ask_false=polarity
            )
            if (
                tool == PHYSICS_OPTIONS_TOOL
                and len({key.display, *(item.display for item in choices)})
                != len(choices) + 1
            ):
                raise ValueError("The displayed choice set contains a collision")
            if tool in (PHYSICS_TEXT_TOOL, PHYSICS_FIDELITY_TOOL):
                _check_rendered_stem(case, order, ask_false=polarity)
            require_time()
            checked += 1
    except TimeoutError as error:
        timed_out = True
        findings.append(
            ToolFinding(code="PROPERTY_CHECK_BUDGET_EXCEEDED", message=str(error))
        )
    except ValidationFailure as error:
        timed_out = error.code == "PROPERTY_CHECK_BUDGET_EXCEEDED"
        findings.append(ToolFinding(code=error.code, message=str(error)))
    except ValueError as error:
        findings.append(ToolFinding(code="H2_STATEMENT_INVALID", message=str(error)))
    size = len(family.cases) * len(_ORDERS) * 2 if family is not None else None
    return ToolEvidence(
        tool=tool,
        version=PHYSICS_TOOL_VERSION,
        status="error" if timed_out else "failed" if findings else "passed",
        findings=findings,
        details={
            "checking_mode": "property_based",
            "examples_checked": checked,
            "execution_calls": calls,
            "max_examples": STATEMENT_CHECK_BUDGET,
            "max_execution_calls": STATEMENT_CHECK_BUDGET,
            "timeout_seconds": timeout_seconds,
            "seed": 0,
            "whole_domain": not findings and checked == size,
            "declared_domain_size": size,
            "skill_id": spec.skill_id,
            "stimulus_kinds": sorted(
                {case.stimulus.kind for case in family.cases if case.stimulus}
                if family
                else set()
            ),
        },
        duration_ms=(monotonic() - started) * 1000,
    )


def _check_rendered_stem(
    case: StatementCase, order: tuple[int, ...], *, ask_false: bool
) -> None:
    stem = statement_stem(case, order, ask_false=ask_false)
    context, *statements, task = stem.split("\n\n")
    if (
        context != case.context
        or [line[3:] for line in statements] != [case.statements[i].text for i in order]
        or [line[:3] for line in statements] != [f"{letter}. " for letter in _LABELS]
        or task
        != (
            "Which listed statements are incorrect?"
            if ask_false
            else "Which listed statements are correct?"
        )
    ):
        raise ValueError("Rendered text differs from the reviewed case")


def statement_stem(
    case: StatementCase, order: tuple[int, ...], *, ask_false: bool
) -> str:
    terms = "incorrect" if ask_false else "correct"
    lines = [
        case.context,
        *(
            f"{label}. {case.statements[i].text}"
            for label, i in zip(_LABELS, order, strict=True)
        ),
    ]
    return "\n\n".join([*lines, f"Which listed statements are {terms}?"])


def statement_case_previews(spec: H2StatementSpec) -> list[ReviewCasePreview]:
    family = _checked_body(spec)
    outcome = f"{spec.skill_id[:-1]}({spec.skill_id[-1]})"
    previews = []
    for number, case in enumerate(family.cases, start=1):
        positive = _review_choice_example(
            case, spec.body.distractors, _ORDERS[0], ask_false=False
        )
        negative = _review_choice_example(
            case, spec.body.distractors, (1, 2, 3, 0), ask_false=True
        )
        previews.append(
            ReviewCasePreview(
                case_id=f"{spec.skill_id}-{number}",
                outcome=outcome,
                question=positive.question,
                answer=positive.answer,
                choices=positive.choices,
                stimulus=case.stimulus.model_dump(mode="json")
                if case.stimulus
                else None,
                incorrect_statements_example=negative,
            )
        )
    return previews


def _review_choice_example(
    case: StatementCase, masks: list[int], order: tuple[int, ...], *, ask_false: bool
) -> ReviewChoiceExample:
    key, distractors = _options(case, masks, order, ask_false=ask_false)
    return ReviewChoiceExample(
        question=statement_stem(case, order, ask_false=ask_false),
        answer=key.display,
        choices=[key.display, *(choice.display for choice in distractors)],
    )


def roll_question(
    spec: H2StatementSpec, *, template_id: str, artifact_id: str | None, seed: int
) -> PhysicsQuestionInstance:
    family = _checked_body(spec)
    case = family.cases[
        seeded_index(template_id, seed, "statement-case", len(family.cases))
    ]
    order = _ORDERS[seeded_index(template_id, seed, "statement-order", len(_ORDERS))]
    ask_false = bool(seeded_index(template_id, seed, "statement-polarity", 2))
    key, distractors = _options(case, spec.body.distractors, order, ask_false=ask_false)
    choices = [choice.display for choice in distractors]
    answer = key.display
    index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
    choices.insert(index, answer)
    return PhysicsQuestionInstance(
        template_id=template_id,
        artifact_id=artifact_id,
        seed=seed,
        parameters={},
        question=statement_stem(case, order, ask_false=ask_false),
        choices=choices,
        answer=answer,
        correct_index=index,
        target="h2_statement_set",
        unit="",
        topic=f"h2.syllabus_9478.skill_{spec.skill_id}",
        assumptions=[],
        stimulus=case.stimulus,
    )
