"""Task-specific, versioned H2 Physics cases and contrast choices."""

from __future__ import annotations

import hashlib
import re
from fractions import Fraction
from itertools import pairwise, product
from typing import Annotated, Literal

from pydantic import Field, model_validator

from edcraft_validator.domain_types import MAX_DISTRACTORS
from edcraft_validator.domains.physics.h2_statement_data import (
    Stimulus,
    StrictData,
    TraceGraph,
    TraceSeries,
    requested_skill,
)

TaskId = Literal[
    "elastic_cart_velocities",
    "elastic_cart_approach",
    "motion_graph_displacement",
    "motion_graph_acceleration",
    "motion_graph_both",
    "motion_graph_either",
    "potential_graph_signed_zero",
    "potential_graph_gradient",
    "si_prefix_conversion",
    "turntable_angle_and_arc",
]


class TaskChoice(StrictData):
    label: str
    reason: str


class TaskCase(StrictData):
    question: str
    answer: str
    distractors: list[TaskChoice]
    worked_solution: str
    parameters: dict[str, str] = Field(default_factory=dict)
    stimulus: Stimulus | None = None


class TaskFamily(StrictData):
    outcome: str
    description: str
    operations: tuple[str, ...]
    cases: tuple[TaskCase, ...]

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(self.model_dump_json().encode()).hexdigest()


class H2TaskProposal(StrictData):
    task_id: TaskId


class TaskBody(StrictData):
    distractors: list[Annotated[int, Field(ge=0, lt=MAX_DISTRACTORS)]] = Field(
        min_length=1, max_length=MAX_DISTRACTORS
    )

    @model_validator(mode="after")
    def require_contrast_order(self) -> TaskBody:
        if self.distractors != list(range(len(self.distractors))):
            raise ValueError("Retain the task's registered contrast choices in order")
        return self


class H2TaskSpec(StrictData):
    schema_version: Literal["physics-h2-task/1.0"]
    family_id: TaskId
    family_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    body: TaskBody


def _decimal(value: int | Fraction, *, signed: bool = False) -> str:
    number = Fraction(value)
    thousandths = number * 1000
    if thousandths.denominator != 1:
        raise ValueError(f"Cannot display {value} exactly to three decimals")
    sign = "-" if number < 0 else "+" if number > 0 and signed else ""
    whole, fractional = divmod(abs(thousandths.numerator), 1000)
    decimal = f".{fractional:03}".rstrip("0") if fractional else ""
    return f"{sign}{whole}{decimal}"


def _choices(answer: str, alternatives: list[tuple[str, str]]) -> list[TaskChoice]:
    seen = {answer}
    choices = []
    for label, reason in alternatives:
        if label not in seen:
            seen.add(label)
            choices.append(TaskChoice(label=label, reason=reason))
    return choices[:MAX_DISTRACTORS]


def _collision_cases(
    m_p: int, m_q: int, u_p: int, u_q: int
) -> tuple[TaskCase, TaskCase]:
    momentum = m_p * u_p + m_q * u_q
    total_mass = m_p + m_q
    approach = u_p - u_q
    centre = Fraction(momentum, total_mass)
    v_p = centre - Fraction(m_q * approach, total_mass)
    v_q = centre + Fraction(m_p * approach, total_mass)
    parameters = dict(
        zip(("m_P", "m_Q", "u_P", "u_Q"), map(str, (m_p, m_q, u_p, u_q)), strict=True)
    )
    context = (
        f"Cart P ({m_p} kg) is to the left of cart Q ({m_q} kg) on a frictionless "
        f"straight track. Right is positive. P moves at {_decimal(u_p, signed=True)} "
        f"m/s and Q moves at {_decimal(u_q, signed=True)} m/s. They collide "
        "head-on and perfectly elastically."
    )

    def pair(p: int | Fraction, q: int | Fraction) -> str:
        return f"{_decimal(p, signed=True)} m/s, {_decimal(q, signed=True)} m/s"

    answer = pair(v_p, v_q)
    coordinate_foils = [
        (pair(v_p, -v_q), "Finds P correctly but reverses Q's direction."),
        (pair(-v_p, v_q), "Finds Q correctly but reverses P's direction."),
    ]
    if m_p > m_q:
        coordinate_foils.reverse()
    hard = TaskCase(
        question=context + " What are the signed velocities of P and Q, in that "
        "order, immediately after the collision?",
        answer=answer,
        distractors=_choices(
            answer,
            [
                (
                    pair((centre + v_p) / 2, (centre + v_q) / 2),
                    "Conserves momentum but treats the collision as partly inelastic.",
                ),
                (
                    pair(v_p + 1, v_q + 1),
                    "Keeps the signed separation but shifts the centre-of-mass speed.",
                ),
                *coordinate_foils,
                (pair(u_p, u_q), "Keeps the approach branch after impact."),
                (pair(u_q, u_p), "Exchanges velocities as if the masses were equal."),
                (pair(centre, centre), "Treats the two carts as sticking together."),
                (pair(-v_p, -v_q), "Uses the opposite sign convention for both carts."),
                (
                    pair(v_p - 1, v_q - 1),
                    "Keeps the same separation after shifting both velocities left.",
                ),
                (
                    pair(2 * v_p - centre, 2 * v_q - centre),
                    "Conserves momentum while doubling the separation speed.",
                ),
            ],
        ),
        worked_solution=(
            f"Conservation of momentum gives {m_p}v_P + {m_q}v_Q = {momentum}. "
            f"The relative velocity reverses, so v_Q − v_P = u_P − u_Q = {approach}. "
            f"Substituting v_Q = v_P + {approach} into momentum gives "
            f"{total_mass}v_P = {momentum - m_q * approach}. "
            f"The velocities of P and Q are {answer}, respectively."
        ),
        parameters=parameters,
    )

    easy_answer = f"{_decimal(approach)} m/s"
    approach_foils: list[tuple[int | Fraction, str]] = [
        (
            u_p + u_q,
            "Adds signed velocities instead of taking the difference.",
        ),
        (u_p, "Uses only P's speed relative to the track."),
        (u_q, "Uses only Q's speed relative to the track."),
        (Fraction(approach, 2), "Averages the two speed magnitudes."),
        (2 * approach, "Counts the closing speed twice."),
        (centre, "Uses the centre-of-mass speed."),
        (approach + u_p, "Counts P's motion twice."),
        (approach - u_q, "Counts Q's motion twice."),
        (v_p, "Reports P's speed after the collision."),
        (v_q, "Reports Q's speed after the collision."),
        (Fraction(approach, 4), "Divides the closing speed by four."),
        (Fraction(3 * approach, 2), "Scales the closing speed by 1.5."),
        (
            Fraction(3 * approach, 4),
            "Uses only three quarters of the closing speed.",
        ),
        (3 * approach, "Counts the closing speed three times."),
    ]
    easy = TaskCase(
        question=context + " What is the relative speed of approach just before "
        "the collision?",
        answer=easy_answer,
        distractors=_choices(
            easy_answer,
            [
                (f"{_decimal(abs(Fraction(value)))} m/s", reason)
                for value, reason in approach_foils
            ],
        ),
        worked_solution=(
            f"The carts close at u_P − u_Q = {u_p} − ({u_q}) = {easy_answer}."
        ),
        parameters=parameters,
    )
    return hard, easy


def _graph(
    x: str, y: str, label: str, points: tuple[tuple[int, int], ...]
) -> TraceGraph:
    return TraceGraph(
        kind="graph",
        x=x,
        y=y,
        series=[
            TraceSeries(label=label, points=[(float(t), float(v)) for t, v in points])
        ],
    )


def _motion_cases(
    points: tuple[tuple[int, int], ...],
) -> tuple[TaskCase, TaskCase, TaskCase]:
    segments = tuple(pairwise(points))
    areas = [Fraction((end - start) * (a + b), 2) for (start, a), (end, b) in segments]
    path = sum(
        abs(area)
        if a * b >= 0
        else Fraction((end - start) * (a * a + b * b), 2 * abs(b - a))
        for ((start, a), (end, b)), area in zip(segments, areas, strict=True)
    )
    (ta, va), (tb, vb) = segments[-1]
    displacement = sum(areas, Fraction(0))
    acceleration = Fraction(vb - va, tb - ta)
    stimulus = _graph("Time t / s", "Velocity v / (m/s)", "Trolley", points)
    context = (
        "The velocity–time graph shows a trolley on a straight track. "
        "Velocity is positive to the right."
    )
    displacement_work = (
        "Displacement is the signed area between the trace and time axis. "
        f"The three trapezium areas are {', '.join(map(_decimal, areas))} m, "
        f"giving {_decimal(displacement, signed=True)} m."
    )
    acceleration_work = (
        f"Acceleration on the last straight segment is its slope, "
        f"({vb} − ({va})) / ({tb} − {ta}) = {_decimal(acceleration, signed=True)} m/s²."
    )
    displacement_question = f"the signed displacement from t = 0 to {tb} s"
    acceleration_question = f"the signed acceleration between t = {ta} s and {tb} s"

    def distance(value: int | Fraction) -> str:
        return f"{_decimal(value, signed=True)} m"

    def slope(value: int | Fraction) -> str:
        return f"{_decimal(value, signed=True)} m/s²"

    dx = distance(displacement)
    dv = slope(acceleration)
    dx_wrong = _choices(
        dx,
        [
            (distance(value), reason)
            for value, reason in (
                (path, "Uses total distance instead of signed displacement."),
                (-displacement, "Reverses the stated positive direction."),
                (areas[0] + areas[1], "Omits the final segment."),
                (areas[1] + areas[2], "Omits the first segment."),
                (areas[0] + areas[2], "Omits the middle segment."),
                (areas[0], "Uses only the first segment."),
                (areas[1], "Uses only the middle segment."),
                (areas[2], "Uses only the last segment."),
                (
                    vb - points[0][1],
                    "Reports the change in velocity as a displacement.",
                ),
                (
                    sum(abs(area) for area in areas),
                    "Adds the magnitude of each segment's net area.",
                ),
                (tb * points[0][1], "Assumes constant initial velocity throughout."),
                (tb * vb, "Assumes constant final velocity throughout."),
                (ta * va, "Assumes a constant velocity up to the last segment."),
                (
                    2 * displacement,
                    "Omits the factor of one half from the trapezium areas.",
                ),
                (displacement / 2, "Halves the trapezium areas a second time."),
                (displacement * 4, "Uses four times the graph's time scale."),
                (displacement / 4, "Uses one quarter of the graph's time scale."),
                (displacement * 3, "Uses three times the graph's time scale."),
                (-path, "Uses total distance and reverses the axis direction."),
            )
        ],
    )
    dv_wrong = _choices(
        dv,
        [
            (slope(value), reason)
            for value, reason in (
                (-acceleration, "Reverses the sign of the slope."),
                (vb, "Uses the final velocity as the acceleration."),
                (va, "Uses the initial velocity on the segment."),
                (vb - va, "Omits division by the elapsed time."),
                (
                    Fraction(va - points[0][1], ta),
                    "Uses the average slope of earlier segments.",
                ),
                (Fraction(1, acceleration), "Inverts rise over run."),
                (2 * acceleration, "Uses half the interval length."),
                (acceleration / 2, "Uses double the interval length."),
                (0, "Assumes the straight segment means zero acceleration."),
                (tb - ta, "Reports the interval length as the acceleration."),
                (3 * acceleration, "Uses one third of the interval length."),
                (3 * acceleration / 2, "Uses two thirds of the interval length."),
                (4 * acceleration, "Uses one quarter of the interval length."),
                (
                    -2 * acceleration,
                    "Reverses the sign and halves the interval length.",
                ),
                (
                    -3 * acceleration,
                    "Reverses the sign and uses one third of the interval.",
                ),
                (5 * acceleration, "Uses one fifth of the interval length."),
            )
            if (Fraction(value) * 1000).denominator == 1
        ],
    )
    paired_answer = f"{dx}, {dv}"
    paired_choices = _joint_choices(dx, dv, dx_wrong, dv_wrong, separator=", ")
    return (
        TaskCase(
            question=f"{context} What is {displacement_question}?",
            answer=dx,
            distractors=dx_wrong,
            worked_solution=displacement_work,
            stimulus=stimulus,
        ),
        TaskCase(
            question=f"{context} What is {acceleration_question}?",
            answer=dv,
            distractors=dv_wrong,
            worked_solution=acceleration_work,
            stimulus=stimulus,
        ),
        TaskCase(
            question=f"{context} What are {displacement_question} and "
            f"{acceleration_question}, in that order?",
            answer=paired_answer,
            distractors=paired_choices,
            worked_solution=f"{displacement_work} {acceleration_work}",
            stimulus=stimulus,
        ),
    )


def _joint_choices(
    first: str,
    second: str,
    first_wrong: list[TaskChoice],
    second_wrong: list[TaskChoice],
    *,
    separator: str,
) -> list[TaskChoice]:
    alternatives = [
        (f"{first_wrong[0].label}{separator}{second}", first_wrong[0].reason),
        (f"{first}{separator}{second_wrong[0].label}", second_wrong[0].reason),
        *[
            (f"{item.label}{separator}{second}", item.reason)
            for item in first_wrong[1:]
        ],
        *[
            (f"{first}{separator}{item.label}", item.reason)
            for item in second_wrong[1:]
        ],
        *[
            (f"{a.label}{separator}{b.label}", f"{a.reason} {b.reason}")
            for a, b in product(first_wrong, second_wrong)
        ],
    ]
    return _choices(f"{first}{separator}{second}", alternatives)


def _potential_cases(
    points: tuple[tuple[int, int], ...],
) -> tuple[TaskCase, TaskCase]:
    ((x0, v0), (x1, v1)), *other_segments = pairwise(points)
    first = (x0, x1)
    field = -Fraction(v1 - v0, x1 - x0)
    intervals = [(a, b) for (a, _), (b, _) in other_segments]
    zero = next((a, b) for (a, start), (b, end) in other_segments if start == end)
    nonzero = sorted(set([first, *intervals]) - {zero})

    def e(value: int | Fraction) -> str:
        return f"{_decimal(value, signed=True)} V/m"

    def region(interval: tuple[int, int]) -> str:
        a, b = interval
        return f"{a} < x/m < {b}"

    e_x = e(field)
    field_wrong = _choices(
        e_x,
        [
            (e(-field), "Uses the potential gradient without reversing its sign."),
            (
                e(field * (x1 - x0)),
                "Uses the signed potential change without dividing by distance.",
            ),
            (e(0), "Treats the first segment as flat."),
            (e(field / 2), "Uses double the correct interval length."),
            (e(v0), "Reports the potential at the first endpoint as a field."),
            (e(v1), "Reports the potential at the second endpoint as a field."),
        ],
    )
    zero_region = region(zero)
    region_wrong = [
        TaskChoice(label=region(span), reason="Chooses a segment with nonzero slope.")
        for span in nonzero
    ]
    stem = (
        "The graph shows the electric potential along the x-axis. The field "
        "has only an x component. What is the signed electric field component "
        f"Eₓ for {region(first)}"
    )
    solution = (
        f"Eₓ is minus the potential gradient, so −({v1} − ({v0})) / "
        f"({x1} − {x0}) = {e_x} on the first segment."
    )
    stimulus = _graph("Position x / m", "Electric potential / V", "Potential", points)
    joint = TaskCase(
        question=f"{stem}, and in which interval on the plot is Eₓ zero?",
        answer=f"{e_x}; {zero_region}",
        distractors=_joint_choices(
            e_x, zero_region, field_wrong, region_wrong, separator="; "
        ),
        worked_solution=(
            f"{solution} Potential is constant for {zero_region}, so Eₓ is zero there."
        ),
        stimulus=stimulus,
    )
    gradient = TaskCase(
        question=f"{stem}?",
        answer=e_x,
        distractors=_choices(
            e_x,
            [
                *((choice.label, choice.reason) for choice in field_wrong),
                (e(field * 2), "Uses half the separation of the two points."),
                (e(-field * 2), "Uses half the separation and reverses the sign."),
                (e(field * 3), "Uses one third of the actual interval length."),
                (
                    e(field / 4),
                    "Overestimates the horizontal scale by a factor of four.",
                ),
                (e(-field / 2), "Reverses the sign and doubles the interval length."),
                (e(-field / 4), "Reverses the sign and multiplies the length by four."),
                (e(v0 + v1), "Adds the potential values instead of finding a slope."),
                (e(v0 - v1), "Uses the potential difference as a field."),
            ],
        ),
        worked_solution=solution,
        stimulus=stimulus,
    )
    return joint, gradient


SI_PREFIX_POWERS = {
    "p": -12,
    "n": -9,
    "μ": -6,
    "m": -3,
    "c": -2,
    "d": -1,
    "k": 3,
    "M": 6,
    "G": 9,
    "T": 12,
}


def _si_prefix_case(quantity: str, value: str, prefix: str, unit: str) -> TaskCase:
    power = SI_PREFIX_POWERS[prefix]

    def label(exponent: int) -> str:
        scale = f"e{exponent}" if exponent else ""
        return f"{value}{scale} {unit}"

    answer = label(power)
    nearby = sorted(SI_PREFIX_POWERS.items(), key=lambda item: abs(power - item[1]))
    alternatives = [
        (label(0), "Drops the prefix without scaling the measured value."),
        (label(-power), "Reverses the sign of the prefix exponent."),
        *[
            (label(exponent), f"Uses the scale for the prefix {other}.")
            for other, exponent in nearby
            if other != prefix
        ],
    ]
    return TaskCase(
        question=(
            f"A measured {quantity} is {value} {prefix}{unit}. "
            f"What is the equivalent value in {unit}?"
        ),
        answer=answer,
        distractors=_choices(answer, alternatives),
        worked_solution=(
            f"The prefix {prefix} means × 10^{power}, so the reading is {answer}."
        ),
        parameters={"value": value, "prefixed_unit": prefix + unit, "unit": unit},
    )


def _turntable_case(radius: str, revolutions: str) -> TaskCase:
    angle = 2 * Fraction(revolutions)
    arc = Fraction(radius) * angle

    def radians(coefficient: Fraction | int) -> str:
        return f"{_decimal(coefficient)}π rad"

    def metres(coefficient: Fraction | int) -> str:
        return f"{_decimal(coefficient)}π m"

    angle_label, arc_label = radians(angle), metres(arc)
    return TaskCase(
        question=(
            f"A turntable of radius {radius} m rotates through {revolutions} "
            "revolution. "
            "What are its angular displacement in radians and the arc length travelled "
            "by a point on its rim, respectively?"
        ),
        answer=f"{angle_label}, {arc_label}",
        distractors=_joint_choices(
            angle_label,
            arc_label,
            [
                TaskChoice(
                    label=radians(angle / 2), reason="Uses π rad per revolution."
                ),
                TaskChoice(label=radians(2), reason="Uses the angle of a full turn."),
                TaskChoice(
                    label=radians(2 - angle), reason="Uses the remaining turn angle."
                ),
            ],
            [
                TaskChoice(
                    label=metres(2 * arc),
                    reason="Multiplies by diameter instead of radius.",
                ),
                TaskChoice(
                    label=metres(arc / 2),
                    reason="Halves the radius before multiplying.",
                ),
                TaskChoice(
                    label=metres(2 * Fraction(radius)),
                    reason="Uses the full rim circumference.",
                ),
            ],
            separator=", ",
        ),
        worked_solution=(
            f"One revolution is 2π rad, so θ = {revolutions} × 2π rad = {angle_label}. "
            f"The rim arc length is s = rθ = {radius} × {_decimal(angle)}π m "
            f"= {arc_label}."
        ),
        parameters={"radius_m": radius, "revolutions": revolutions},
    )


_MOTION_GRAPHS = tuple(
    _motion_cases(points)
    for points in (
        ((0, 2), (2, 4), (5, -2), (7, -6)),
        ((0, -5), (2, -2), (5, 4), (7, 6)),
        ((0, 2), (2, 6), (6, -2), (8, -6)),
        ((0, -4), (3, -1), (7, 3), (9, 9)),
        ((0, 2), (1, 6), (5, -2), (10, -7)),
    )
)
_POTENTIAL_GRAPHS = tuple(
    _potential_cases(points)
    for points in (
        ((0, 8), (2, 2), (3, 2), (5, 6)),
        ((0, -3), (2, 5), (4, 1), (5, 1)),
        ((0, 3), (3, -3), (5, -3), (6, -5)),
        ((0, 2), (2, 8), (3, 5), (6, 5)),
    )
)


_COLLISIONS = tuple(
    _collision_cases(*values)
    for values in (
        (2, 3, 8, -2),
        (5, 3, 5, -3),
        (4, 1, 7, -3),
        (1, 4, 3, -7),
        (3, 2, 6, -4),
        (7, 3, 11, -9),
    )
)

FAMILIES: dict[TaskId, TaskFamily] = {
    "elastic_cart_velocities": TaskFamily(
        outcome="6d",
        description="Solve for signed velocities in an unequal-mass elastic collision",
        operations=(
            "conserve signed momentum",
            "reverse signed relative velocity",
            "solve for the two outgoing velocities",
        ),
        cases=tuple(hard for hard, _ in _COLLISIONS),
    ),
    "elastic_cart_approach": TaskFamily(
        outcome="6d",
        description="Find the relative approach speed of two carts before collision",
        operations=("subtract the two signed incoming velocities",),
        cases=tuple(easy for _, easy in _COLLISIONS),
    ),
    "motion_graph_displacement": TaskFamily(
        outcome="3c",
        description="Find signed displacement from a velocity–time graph",
        operations=("find the signed area between the trace and time axis",),
        cases=tuple(case[0] for case in _MOTION_GRAPHS),
    ),
    "motion_graph_acceleration": TaskFamily(
        outcome="3c",
        description="Calculate acceleration from a displayed velocity–time graph",
        operations=("find the signed gradient of a specified segment",),
        cases=tuple(case[1] for case in _MOTION_GRAPHS),
    ),
    "motion_graph_both": TaskFamily(
        outcome="3c",
        description="Find displacement and acceleration from a velocity–time graph",
        operations=(
            "find the signed area between the trace and time axis",
            "find the signed gradient of a specified segment",
        ),
        cases=tuple(case[2] for case in _MOTION_GRAPHS),
    ),
    "motion_graph_either": TaskFamily(
        outcome="3c",
        description="Find displacement or acceleration from a velocity–time graph",
        operations=("find signed area or local signed gradient, as asked",),
        cases=tuple(case for graph in _MOTION_GRAPHS for case in graph[:2]),
    ),
    "potential_graph_signed_zero": TaskFamily(
        outcome="14f",
        description="Find the signed field and a zero interval from a potential graph",
        operations=(
            "apply the negative sign to the local potential gradient",
            "identify the interval of constant potential",
        ),
        cases=tuple(joint for joint, _ in _POTENTIAL_GRAPHS),
    ),
    "potential_graph_gradient": TaskFamily(
        outcome="14f",
        description="Find the signed electric field from a potential graph's slope",
        operations=("apply the negative sign to the local potential gradient",),
        cases=tuple(gradient for _, gradient in _POTENTIAL_GRAPHS),
    ),
    "si_prefix_conversion": TaskFamily(
        outcome="1b",
        description="Convert a measured quantity to its equivalent unprefixed SI value",
        operations=("apply the prefix's power of ten to the given measurement",),
        cases=tuple(
            _si_prefix_case(*values)
            for values in (
                ("voltage", "2.5", "p", "V"),
                ("time interval", "3.6", "n", "s"),
                ("current", "4.2", "μ", "A"),
                ("force", "6.8", "m", "N"),
                ("length", "7.2", "c", "m"),
                ("length", "2.4", "d", "m"),
                ("frequency", "5.3", "k", "Hz"),
                ("frequency", "6.4", "M", "Hz"),
                ("frequency", "8.7", "G", "Hz"),
                ("frequency", "9.1", "T", "Hz"),
            )
        ),
    ),
    "turntable_angle_and_arc": TaskFamily(
        outcome="7a",
        description="Calculate a turntable angle in radians and its rim arc length",
        operations=("multiply the fraction of a revolution by 2π", "apply s = rθ"),
        cases=tuple(
            _turntable_case(*values)
            for values in (
                ("0.40", "0.25"),
                ("0.60", "0.125"),
                ("0.80", "0.375"),
                ("0.25", "0.3"),
                ("0.45", "0.8"),
                ("0.35", "0.4"),
            )
        ),
    ),
}


_GRAPH_WORD = re.compile(r"\b(?:graph|graphed|plot|plotted|trace)\b")
_NUMBER = r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:e[+-]?\d+)?"
_GRAPH_DATA = re.compile(
    rf"[('\[\"“‘]\s*{_NUMBER}\s*,\s*{_NUMBER}\s*[)'\]\"”’]"
    rf"|\b(?:t|v|x|time|velocity|position|potential)\s*=\s*{_NUMBER}"
    rf"|\b(?:points|coordinates|vertices|times|velocities|positions|potentials)"
    rf"\s*(?:are|=|:)\s*[\[(]?\s*{_NUMBER}\s*[,;]"
    rf"|{_NUMBER}\s*(?:s|ms|seconds?|m|cm|metres?|meters?|v|volts?)\b"
    rf"|\|\s*{_NUMBER}\s*\|\s*{_NUMBER}\s*\|"
)
_EXCLUDED_MOTION_QUANTITY = re.compile(
    r"\b(?:not|rather than|instead of|exclude|omit|without)\s+"
    r"(?:ask(?:ing)?\s+(?:(?:students|learners)\s+)?(?:(?:to|for)\s+)?)?"
    r"(?:(?:find(?:ing)?|calculat(?:e|ing)|determin(?:e|ing)|assess(?:ing)?)\s+)?"
    r"(?:(?:the|its|signed|net|local)\s+)*(displacement|acceleration)\b"
)


def _normalise(prompt: str) -> str:
    return prompt.casefold().translate(str.maketrans("‐‑–—−", "-----"))


def requests_fixed_graph_data(prompt: str) -> bool:
    words = _normalise(prompt)
    return bool(_GRAPH_WORD.search(words) and _GRAPH_DATA.search(words))


def references_external_stimulus(prompt: str) -> bool:
    return bool(
        re.search(
            r"\b(?:attached|uploaded) (?:[\w-]+ ){0,7}"
            r"(?:graph|plot|diagram|image|data|dataset)\b"
            r"|\b(?:my|our) (?:(?:own|original|recorded|supplied|experimental|"
            r"[a-z]+-[a-z]+) ){0,2}(?:graph|plot|diagram|image|data|dataset)\b",
            _normalise(prompt),
        )
    )


def numerical_task_intent(prompt: str) -> TaskId | None:
    words = _normalise(prompt)
    conversion = re.search(r"\b(?:convert\w*|equivalent|express\w*|rewrit\w*)\b", words)
    target_si_unit = re.search(
        r"\b(?:to|in) (?:the )?(?:(?:standard|unprefixed) )?si (?:base )?units?\b",
        words,
    )
    prefixed_measurement = (
        re.search(r"\bsi\b", words)
        and re.search(r"\b(?:un)?prefix(?:ed|es)?\b", words)
        and re.search(r"\b(?:values?|measure(?:d|ment)|quantit(?:y|ies))\b", words)
    )
    if (target_si_unit and conversion) or (
        prefixed_measurement and (conversion or target_si_unit)
    ):
        return "si_prefix_conversion"
    if (
        re.search(r"\bturn[- ]?table\b", words)
        and re.search(r"\b(?:angle|angular displacement|rad(?:ians?)?)\b", words)
        and re.search(r"\barc[- ]length\b", words)
    ):
        return "turntable_angle_and_arc"
    return None


_NUMERICAL_TASK_COMMON = frozenset(
    "2026 9478 a an and are as ask asking at author based build by calculate "
    "calculating choice choose class classroom convert converting corresponding "
    "create determine draft easy equivalent exercise find for from give given gives "
    "giving h2 i in is it its learner learners make mcq multiple need of on "
    "physics practise practice "
    "present question quiz recognise recognize set short show singapore student "
    "students test that the them they this through to up use uses using want warm "
    "warmup what where which with write your".split()
)
_NUMERICAL_TASK_WORDS = {
    "si_prefix_conversion": frozenset(
        "conversion correct express measurement measured numerical numeric prefix "
        "prefixed prefixes quantity reading rewrite si standard unit units "
        "unprefixed value".split()
    ),
    "turntable_angle_and_arc": frozenset(
        "angle angular arc displacement fraction fractional laboratory length moves "
        "ordered pair part point rad radian radians radius respectively revolution "
        "revolutions rim rotate rotates rotating rotation table travel traveled "
        "travelled travels turn turntable turns".split()
    ),
}


def _matches_numerical_task_scope(
    words: str, task_id: TaskId, outcome: str | None
) -> bool:
    expected = FAMILIES[task_id].outcome
    if outcome is not None:
        if outcome != expected:
            return False
        number, letter = expected
        words = re.sub(
            rf"\b(?:outcome|skill|9478|h2 physics)\s*[:#]?\s*{number}"
            rf"(?:\(\s*{letter}\s*\)|{letter}\b)",
            "",
            words,
            count=1,
        )
    if task_id == "si_prefix_conversion":
        words = re.sub(
            r"\bone (?=(?:measured quantity|quantity|measurement)\b)", "", words
        )
        if re.search(r"\b(?:to|into) (?:the )?prefixed units?\b", words):
            return False
    if task_id == "turntable_angle_and_arc" and not re.search(
        r"\b(?:revolutions?|fractional turn|part of a turn)\b", words
    ):
        return False
    # Match only the free choice of inputs that these renderers support. An
    # extra quantity, fixed datum, format or context must not be discarded.
    if re.search(r"[^a-z0-9\s.,:;?!'-]", words):
        return False
    vocabulary = _NUMERICAL_TASK_COMMON | _NUMERICAL_TASK_WORDS[task_id]
    return set(re.findall(r"[a-z0-9]+", words)) <= vocabulary


def match_task(prompt: str) -> TaskId | None:
    """Match the requested student action before trusting a topic suggestion."""
    words = _normalise(prompt)
    outcome = requested_skill(words)
    if (
        references_external_stimulus(prompt)
        or requests_fixed_graph_data(prompt)
        or re.search(
            r"\b(?:students?|learners?) (?:to |must |should )(?:draw|plot|sketch)\b"
            r"|\b(?:measure|record|upload|submit|draw)\b.{0,55}"
            r"\b(?:actual|own|live|measurements|readings|sketch|drawing)\b",
            words,
        )
    ):
        return None

    if numerical := numerical_task_intent(prompt):
        return (
            numerical
            if _matches_numerical_task_scope(words, numerical, outcome)
            else None
        )

    if (
        outcome in (None, "6c", "6d")
        and re.search(r"\b(?:collision|collide|colliding)\b", words)
        and re.search(r"\belastic\b", words)
        and not re.search(
            r"\b(?:inelastic|stick together|stationary|at rest|overtakes?"
            r"|same direction)\b",
            words,
        )
        and re.search(
            r"\b(?:head[- ]on|opposite|one[- ]dimensional|1[- ]?d|same straight)\b",
            words,
        )
        and not re.search(r"\b\d+(?:\.\d+)?\s*(?:kg|m/s)\b", words)
        and re.search(
            r"\b(?:unequal|different|distinct|uneven)[- ]mass(?:es)?\b"
            r"|\b(?:unequal|different|distinct) (?:cart |trolley )?masses\b"
            r"|\b(?:unequal|different|distinct) (?:in )?(?:their )?mass\b",
            words,
        )
    ):
        pair = re.search(
            r"\b(?:velocities|velocity of (?:each|both)|speeds? and directions?)\b"
            r"|\b(?:each|both) (?:cart'?s|trolley'?s) (?:final |signed )?velocity\b"
            r"|\bsigned (?:final |outgoing )?speeds\b",
            words,
        )
        final = re.search(
            r"\b(?:after|outgoing|final|post[- ](?:collision|impact))\b", words
        )
        carts = re.search(r"\b(?:carts?|trolleys?)\b", words)
        abstract_collision = (
            re.search(r"\bmomentum\b", words)
            and re.search(r"\b(?:relative|approach|separation|closing)\b", words)
            and not re.search(r"\b(?:balls?|pucks?|blocks?|particles?|atoms?)\b", words)
        )
        if pair and final and (carts or abstract_collision):
            return "elastic_cart_velocities"
        if (
            carts
            and re.search(
                r"\b(?:relative|closing) speed(?:s)? (?:of |during the )?approach\b"
                r"|\bclosing speed\b",
                words,
            )
            and not re.search(r"\b(?:separation|outgoing|final|after)\b", words)
        ):
            return "elastic_cart_approach"
    if outcome in (None, "3c") and re.search(r"\bgraph\b", words):
        velocity_graph = re.search(
            r"\b(?:velocity[- /]+(?:against |versus |vs\.? )?time|v[- ]t)\b",
            words,
        )
        generic_motion = re.search(r"\bmotion graph\b", words)
        foreign_axes = re.search(
            r"\b(?:position|displacement|acceleration)[- /]+time\b", words
        )
        if (velocity_graph or generic_motion) and not foreign_axes:
            excluded = set(_EXCLUDED_MOTION_QUANTITY.findall(words))
            displacement = "displacement" not in excluded and re.search(
                r"\bdisplacement\b", words
            )
            acceleration = "acceleration" not in excluded and re.search(
                r"\bacceleration\b", words
            )
            if displacement and acceleration:
                if re.search(
                    r"\b(?:displacement or acceleration|acceleration or displacement)"
                    r"\b",
                    words,
                ):
                    return "motion_graph_either"
                return "motion_graph_both"
            if displacement:
                return "motion_graph_displacement"
            if acceleration:
                return "motion_graph_acceleration"

    if (
        outcome in (None, "14f")
        and _GRAPH_WORD.search(words)
        and re.search(
            r"\bpotential[- /]+(?:versus |against |vs\.? )?(?:position|distance)\b"
            r"|\bv[- ]x\b|\bpotential (?:graph|plot|trace)\b"
            r"|\bpotential (?:along|against|versus|changes? with|varies? with"
            r"|as a function of) (?:the )?(?:x[- ]axis|x|position|distance)\b",
            words,
        )
        and re.search(r"\bfield\b", words)
        and re.search(
            r"\b(?:gradient|slope|signed|direction|positive|negative)\b", words
        )
        and not re.search(
            r"\b(?:nonlinear|curved|magnitude only|gravitational|magnetic)\b", words
        )
    ):
        if re.search(
            r"\b(?:zero|vanishes|no electric field|where the field is absent)\b", words
        ):
            return "potential_graph_signed_zero"
        return "potential_graph_gradient"
    return None
