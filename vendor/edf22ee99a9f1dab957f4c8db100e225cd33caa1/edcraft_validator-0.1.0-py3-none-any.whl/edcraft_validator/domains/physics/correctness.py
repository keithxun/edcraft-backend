"""Exact checks for one-dimensional Newton's second law templates.

All arithmetic uses :class:`fractions.Fraction`. A recipe value is the signed
component along the positive axis, or a scalar magnitude when the answer form
asks for one. Rendering only changes how that value is displayed.
"""

from __future__ import annotations

from collections.abc import Callable
from fractions import Fraction

from edcraft_validator.domains.physics.physics_schemas import (
    AnswerForm,
    PhysicsBody,
    PhysicsTemplateSpec,
    RecipeNode,
    Target,
)
from edcraft_validator.domains.physics.quantities import (
    DISPLAY_UNITS,
    OPPOSITE_SIDE,
    QUANTITY_DIMENSIONS,
    QUANTITY_UNITS,
    TARGET_QUANTITIES,
    Dimension,
    dimension_name,
    parse_decimal,
)

PHYSICS_CONTRADICTORY_ASSUMPTIONS = "PHYSICS_CONTRADICTORY_ASSUMPTIONS"
PHYSICS_RECIPE_UNDEFINED = "PHYSICS_RECIPE_UNDEFINED"
PHYSICS_DIMENSION_MISMATCH = "PHYSICS_DIMENSION_MISMATCH"
PHYSICS_ANSWER_MISMATCH = "PHYSICS_ANSWER_MISMATCH"
PHYSICS_ANSWER_NOT_EXACT = "PHYSICS_ANSWER_NOT_EXACT"
DISTRACTOR_UNDEFINED = "DISTRACTOR_UNDEFINED"
DISTRACTOR_EQUALS_KEY = "DISTRACTOR_EQUALS_KEY"
DISTRACTOR_DUPLICATE = "DISTRACTOR_DUPLICATE"
DISTRACTOR_NOT_EXACT = "DISTRACTOR_NOT_EXACT"
DISTRACTOR_NOT_PHYSICAL = "DISTRACTOR_NOT_PHYSICAL"

_SIGNS: dict[str, int] = {"positive": 1, "negative": -1}
_RULES: dict[str, str] = {
    "acceleration": "a = F_net / m",
    "net_force": "F_net = m a",
    "mass": "m = F_net / a",
    "missing_force": "F_u = s_u (m a - sum s_i F_i)",
}


class PhysicsCheckError(Exception):
    """One exact-check defect, carrying a stable code for callers and tests."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def parameter_values(
    spec: PhysicsTemplateSpec, combination: dict[str, str]
) -> dict[str, Fraction]:
    """Parse one parameter combination into exact magnitudes."""
    declared = [parameter.name for parameter in spec.parameters]
    unknown = sorted(set(combination) - set(declared))
    missing = sorted(set(declared) - set(combination))
    if unknown:
        raise ValueError(
            "combination sets undeclared parameters: " + ", ".join(unknown)
        )
    if missing:
        raise ValueError("combination is missing parameters: " + ", ".join(missing))
    return {
        parameter.name: parse_decimal(combination[parameter.name])
        for parameter in spec.parameters
    }


def evaluate_recipe(
    node: RecipeNode,
    spec: PhysicsTemplateSpec,
    values: dict[str, Fraction],
) -> tuple[Fraction, Dimension]:
    """Evaluate one recipe node to a value and its dimension."""
    return _evaluate_recipe(
        node, values, lambda name: QUANTITY_DIMENSIONS[_parameter_quantity(spec, name)]
    )


def evaluate_display_values(node: RecipeNode, values: dict[str, Fraction]) -> Fraction:
    """Evaluate magnitudes expressed in a constrained H2 family's stated units."""
    value, _ = _evaluate_recipe(node, values, lambda _: (0, 0, 0))
    return value


def _evaluate_recipe(
    node: RecipeNode,
    values: dict[str, Fraction],
    parameter_dimension: Callable[[str], Dimension],
) -> tuple[Fraction, Dimension]:
    if node.param is not None:
        if node.param not in values:
            raise PhysicsCheckError(
                PHYSICS_RECIPE_UNDEFINED,
                f"recipe uses parameter {node.param!r}, which the combination "
                "does not set",
            )
        return values[node.param], parameter_dimension(node.param)
    if node.const is not None:
        return Fraction(node.const), (0, 0, 0)

    args = node.args or []
    if node.op is None or not args:
        raise PhysicsCheckError(
            PHYSICS_RECIPE_UNDEFINED, "recipe node has no value to evaluate"
        )
    evaluated = [_evaluate_recipe(arg, values, parameter_dimension) for arg in args]

    if node.op == "neg":
        value, dimension = evaluated[0]
        return -value, dimension
    if node.op in {"add", "sub"}:
        total, first = evaluated[0]
        for value, dimension in evaluated[1:]:
            if dimension != first:
                raise PhysicsCheckError(
                    PHYSICS_DIMENSION_MISMATCH,
                    f"cannot {node.op} {dimension_name(first)} and "
                    f"{dimension_name(dimension)}",
                )
            total = total + value if node.op == "add" else total - value
        return total, first
    if node.op == "mul":
        total, dimension = evaluated[0]
        for value, other in evaluated[1:]:
            total = total * value
            dimension = _combine(dimension, other, 1)
        return total, dimension
    if node.op == "div":
        numerator, top = evaluated[0]
        denominator, bottom = evaluated[1]
        if denominator == 0:
            raise PhysicsCheckError(PHYSICS_RECIPE_UNDEFINED, "recipe divides by zero")
        return numerator / denominator, _combine(top, bottom, -1)
    raise PhysicsCheckError(
        PHYSICS_RECIPE_UNDEFINED, f"recipe op {node.op!r} is not supported"
    )


def canonical_answer(
    spec: PhysicsTemplateSpec, values: dict[str, Fraction]
) -> Fraction:
    """Compute the correct value for one combination, exactly."""
    body = spec.body
    target = body.target

    if target == "acceleration":
        return net_force_value(body, values) / _mass(body, values)
    if target == "net_force":
        return _mass(body, values) * _acceleration(body, values)
    if target == "mass":
        acceleration = _acceleration(body, values)
        if acceleration == 0:
            raise PhysicsCheckError(
                PHYSICS_CONTRADICTORY_ASSUMPTIONS,
                "the acceleration is zero, so F_net / a cannot give a mass",
            )
        mass = net_force_value(body, values) / acceleration
        if mass <= 0:
            if net_force_value(body, values) == 0:
                reason = "the net force is zero, so F_net / a gives 0"
            else:
                reason = (
                    "the net force and the acceleration point in opposite "
                    f"directions, so F_net / a gives {_describe(mass)}"
                )
            raise PhysicsCheckError(PHYSICS_CONTRADICTORY_ASSUMPTIONS, reason)
        return mass
    return _missing_force(body, values)


def net_force_value(body: PhysicsBody, values: dict[str, Fraction]) -> Fraction:
    """Signed net force along the positive axis."""
    if body.net_force is not None:
        return _sign(body.net_force.direction) * values[body.net_force.param]
    total = Fraction(0)
    for force in body.forces or []:
        total += _sign(force.direction) * values[force.param]
    return total


def rule_text(target: Target) -> str:
    """The canonical rule text reported alongside evidence."""
    return _RULES[target]


def is_exact(value: Fraction, decimals: int) -> bool:
    """Report whether the value shows exactly in the given decimal places."""
    return (value * 10**decimals).denominator == 1


def is_physical_distractor(
    value: Fraction, *, form: AnswerForm, target: Target
) -> bool:
    """Only signed answer forms can display a negative distractor."""
    if form != "magnitude":
        return True
    return value > 0 if target == "mass" else value >= 0


def check_key(spec: PhysicsTemplateSpec, combination: dict[str, str]) -> Fraction:
    """Return the canonical value, or raise the first defect in spec order."""
    prefix = _prefix(spec, combination)
    values = parameter_values(spec, combination)
    canonical = _contextual(canonical_answer, spec, values, prefix)

    value, dimension = _contextual_recipe(spec.body.answer_recipe, spec, values, prefix)
    body = spec.body
    expected = QUANTITY_DIMENSIONS[TARGET_QUANTITIES[body.target]]
    if dimension != expected:
        raise PhysicsCheckError(
            PHYSICS_DIMENSION_MISMATCH,
            f"{prefix}: answer recipe gives {dimension_name(dimension)} but "
            f"{body.target} needs {dimension_name(expected)}",
        )
    if value != canonical:
        raise PhysicsCheckError(
            PHYSICS_ANSWER_MISMATCH,
            f"{prefix}: answer recipe gives {_describe(value)} but the correct "
            f"value is {_describe(canonical)} ({rule_text(body.target)})",
        )
    if not is_exact(canonical, body.display.decimals):
        raise PhysicsCheckError(
            PHYSICS_ANSWER_NOT_EXACT,
            f"{prefix}: {_describe(canonical)} cannot be shown with "
            f"{body.display.decimals} decimals",
        )
    return canonical


def check_options(
    spec: PhysicsTemplateSpec, combination: dict[str, str]
) -> list[dict[str, object]]:
    """Check every distractor, treating a contradiction as a hard failure."""
    prefix = _prefix(spec, combination)
    values = parameter_values(spec, combination)
    canonical = _contextual(canonical_answer, spec, values, prefix)

    body = spec.body
    target = body.target
    decimals = body.display.decimals
    form = body.answer_form
    unit = QUANTITY_UNITS[TARGET_QUANTITIES[target]]
    axis_positive = spec.axis.positive
    expected = QUANTITY_DIMENSIONS[TARGET_QUANTITIES[target]]

    key_text = None
    if is_exact(canonical, decimals):
        key_text = render_answer(
            canonical,
            unit=unit,
            decimals=decimals,
            form=form,
            axis_positive=axis_positive,
        )
    seen_values = [canonical]
    seen_texts = [key_text] if key_text is not None else []
    results: list[dict[str, object]] = []

    for index, distractor in enumerate(body.distractors, start=1):
        entry: dict[str, object] = {
            "index": index,
            "misconception": distractor.misconception,
            "dimension_consistent": False,
            "status": "passed",
            "code": None,
            "reason": None,
        }
        try:
            value, dimension = evaluate_recipe(distractor.recipe, spec, values)
        except PhysicsCheckError as error:
            code = (
                DISTRACTOR_UNDEFINED
                if error.code == PHYSICS_RECIPE_UNDEFINED
                else error.code
            )
            entry.update(
                status="failed",
                code=code,
                reason=(
                    f"{prefix}: distractor {index} cannot be evaluated "
                    f"({error.message})"
                ),
            )
            results.append(entry)
            continue

        entry["dimension_consistent"] = dimension == expected
        failure = _distractor_failure(
            value,
            canonical=canonical,
            seen_values=seen_values,
            seen_texts=seen_texts,
            decimals=decimals,
            form=form,
            target=target,
            unit=unit,
            axis_positive=axis_positive,
        )
        if failure is not None:
            code, reason = failure
            entry.update(
                status="failed",
                code=code,
                reason=f"{prefix}: distractor {index} {reason}",
            )
        else:
            seen_values.append(value)
            if is_exact(value, decimals):
                seen_texts.append(
                    render_answer(
                        value,
                        unit=unit,
                        decimals=decimals,
                        form=form,
                        axis_positive=axis_positive,
                    )
                )
        results.append(entry)
    return results


def render_answer(
    value: Fraction,
    *,
    unit: str,
    decimals: int,
    form: AnswerForm,
    axis_positive: str,
) -> str:
    """Render one answer value without ever rounding it silently."""
    number = _format_number(value, decimals)
    display = DISPLAY_UNITS[unit]
    if form == "magnitude_and_direction":
        if value == 0:
            return f"{number} {display}"
        direction = axis_positive if value > 0 else OPPOSITE_SIDE[axis_positive]
        magnitude = _format_number(abs(value), decimals)
        return f"{magnitude} {display} to the {direction}"
    if form == "magnitude":
        return f"{_format_number(abs(value), decimals)} {display}"
    return f"{number} {display}"


def _missing_force(body: PhysicsBody, values: dict[str, Fraction]) -> Fraction:
    unknown = body.unknown_force
    if unknown is None:
        raise ValueError("body has no unknown force")
    inside = _mass(body, values) * _acceleration(body, values) - net_force_value(
        body, values
    )
    result = _sign(unknown.direction) * inside
    if result <= 0:
        raise PhysicsCheckError(
            PHYSICS_CONTRADICTORY_ASSUMPTIONS,
            "the unknown force would be "
            f"{_describe(result)}, so it cannot act in the stated direction",
        )
    return result


def _distractor_failure(
    value: Fraction,
    *,
    canonical: Fraction,
    seen_values: list[Fraction],
    seen_texts: list[str],
    decimals: int,
    form: AnswerForm,
    target: Target,
    unit: str,
    axis_positive: str,
) -> tuple[str, str] | None:
    if value == canonical:
        return (
            DISTRACTOR_EQUALS_KEY,
            f"gives {_describe(value)}, which equals the correct answer",
        )
    if any(value == seen for seen in seen_values):
        return (DISTRACTOR_DUPLICATE, "repeats an earlier option")
    exact = is_exact(value, decimals)
    if exact:
        text = render_answer(
            value,
            unit=unit,
            decimals=decimals,
            form=form,
            axis_positive=axis_positive,
        )
        if text in seen_texts:
            return (DISTRACTOR_DUPLICATE, "repeats an earlier option")
    if not exact:
        return (
            DISTRACTOR_NOT_EXACT,
            f"gives {_describe(value)}, which cannot be shown with {decimals} decimals",
        )
    if not is_physical_distractor(value, form=form, target=target):
        return (
            DISTRACTOR_NOT_PHYSICAL,
            f"gives {_describe(value)}, which is not a physical value for this "
            "answer form",
        )
    return None


def _mass(body: PhysicsBody, values: dict[str, Fraction]) -> Fraction:
    if body.mass is None:
        raise ValueError("body has no mass role")
    return values[body.mass]


def _acceleration(body: PhysicsBody, values: dict[str, Fraction]) -> Fraction:
    if body.acceleration is None:
        raise ValueError("body has no acceleration role")
    return _sign(body.acceleration.direction) * values[body.acceleration.param]


def _sign(direction: str) -> int:
    return _SIGNS[direction]


def _parameter_quantity(spec: PhysicsTemplateSpec, name: str) -> str:
    for parameter in spec.parameters:
        if parameter.name == name:
            return parameter.quantity
    raise PhysicsCheckError(
        PHYSICS_RECIPE_UNDEFINED,
        f"recipe refers to undeclared parameter {name!r}",
    )


def _combine(left: Dimension, right: Dimension, factor: int) -> Dimension:
    return (
        left[0] + factor * right[0],
        left[1] + factor * right[1],
        left[2] + factor * right[2],
    )


def _prefix(spec: PhysicsTemplateSpec, combination: dict[str, str]) -> str:
    names = [parameter.name for parameter in spec.parameters]
    return ", ".join(f"{name}={combination[name]}" for name in names)


def _contextual(
    compute: Callable[[PhysicsTemplateSpec, dict[str, Fraction]], Fraction],
    spec: PhysicsTemplateSpec,
    values: dict[str, Fraction],
    prefix: str,
) -> Fraction:
    try:
        return compute(spec, values)
    except PhysicsCheckError as error:
        raise PhysicsCheckError(error.code, f"{prefix}: {error.message}") from None


def _contextual_recipe(
    node: RecipeNode,
    spec: PhysicsTemplateSpec,
    values: dict[str, Fraction],
    prefix: str,
) -> tuple[Fraction, Dimension]:
    try:
        return evaluate_recipe(node, spec, values)
    except PhysicsCheckError as error:
        raise PhysicsCheckError(error.code, f"{prefix}: {error.message}") from None


def _format_number(value: Fraction, decimals: int) -> str:
    scaled = value * 10**decimals
    if scaled.denominator != 1:
        raise ValueError(
            f"value {_describe(value)} is not exact at {decimals} decimals"
        )
    digits = str(abs(scaled.numerator))
    sign = "-" if scaled < 0 else ""
    if decimals == 0:
        return f"{sign}{digits}"
    digits = digits.rjust(decimals + 1, "0")
    return f"{sign}{digits[:-decimals]}.{digits[-decimals:]}"


def _describe(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"
