"""Compose model-authored numerical physics tasks from independently checked laws."""

from __future__ import annotations

import json
import time
from fractions import Fraction
from typing import Annotated, Any, Literal

from fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

from edcraft_validator.artifact_contracts import ValidatedTemplateArtifact
from edcraft_validator.domain_types import MAX_DISTRACTORS, Difficulty
from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    ReviewCasePreview,
    ReviewTemplateView,
    TemplateRequest,
    build_review_view,
    build_template_id,
    content_sha256,
    require_checked,
    require_type,
    save_checked_evidence,
    seeded_index,
)
from edcraft_validator.domains.h2.task_requirements import clause_mentions
from edcraft_validator.domains.operation_intent import require_operation_intent
from edcraft_validator.domains.physics.authored_laws import LAWS, AuthoredUnit
from edcraft_validator.domains.physics.correctness import (
    PhysicsCheckError,
    evaluate_display_values,
)
from edcraft_validator.domains.physics.difficulty import H2_PHYSICS_DIFFICULTY_RUBRIC_ID
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsQuestionInstance,
    RecipeNode,
)
from edcraft_validator.llm.llm_contracts import (
    PlannedGenerationResponse,
    StructuredGenerationRequest,
)
from edcraft_validator.mcp.tool_dependencies import ToolDependencies
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.check_names import (
    TEMPLATE_DIFFICULTY_CAPABILITY,
    TEMPLATE_DIFFICULTY_CHECK,
    TEMPLATE_RELEVANCE_CAPABILITY,
    TEMPLATE_RELEVANCE_CHECK,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)
from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)
from edcraft_validator.validation.property_summary import (
    PropertyCheckSummary,
    property_details,
)
from edcraft_validator.validation.validation_contracts import ValidationFailure

TOOL = "physics_verify_authored_task"
TOOL_SCOPE = "physics-authored"
VERSION: Literal["physics-authored/1.0"] = "physics-authored/1.0"
CHECK_VERSION = "1.1.0"
MAX_GENERATION_TRIES = 32
Name = Annotated[str, Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,15}$")]
Number = Annotated[str, Field(pattern=r"^-?(0|[1-9][0-9]{0,4})(\.[0-9]{1,3})?$")]

_ASK = (
    r"\b(?:find|calculate|compute|determine|work out|what is|ask for|questions? on)\s+"
    r"(?:the\s+)?(?:signed\s+)?"
)
_TARGETS = {
    "signed acceleration": r"acceleration",
    "signed net force": r"(?:net|resultant) force",
    "signed final velocity": r"final velocity",
    "signed displacement": r"displacement",
    "signed momentum": r"(?:linear )?momentum",
    "signed impulse": r"impulse",
    "translational kinetic energy": r"(?:translational )?kinetic energy",
    "average power": r"average power",
    "force magnitude": r"(?:spring|restoring) force",
    "current magnitude": r"(?:(?:electric|electrical) )?current",
    "electrical power": r"(?:electrical|resistive) power",
}
_COMPOUND_TARGET = (
    r"\s*(?:,|and\b|or\b|then\b)\s*(?:the )?"
    rf"(?:{'|'.join(_TARGETS.values())})\b"
)
_REQUEST_CUES = {
    name: rf"{_ASK}{cue}\b(?!{_COMPOUND_TARGET})" for name, cue in _TARGETS.items()
}
_SOURCE_CUES = {
    **{name: rf"\b{cue}\b" for name, cue in _TARGETS.items()},
    "signed acceleration": r"\bacceleration\b|\bF\s*=\s*ma\b",
    "signed net force": r"\b(?:net|resultant) force\b|\bF\s*=\s*ma\b",
    "force magnitude": r"\b(?:spring force|restoring force|hooke['’]s law)\b",
    "current magnitude": r"\bohm['’]s law\b|\b(?:electric|electrical) current\b",
    "signed final velocity": r"\bfinal velocity\b",
    "signed displacement": r"\bdisplacement\b",
    "translational kinetic energy": r"\bkinetic energy\b",
    "signed momentum": r"\b(?:linear )?momentum\b",
    "electrical power": (
        r"\b(?:electrical|resistive) power\b|\bP\s*=\s*(?:V\s*I|I\s*V|"
        r"I\s*(?:²|\^2|\*\*2|squared)|V\s*(?:²|\^2|\*\*2|squared))"
    ),
}
_POWER_LAWS = {"electrical_power", "resistive_power"}
_UNIT_CONVERSION = (
    r"\b(?:unit conversions?|convert(?:ing)? (?:between )?units|SI prefixes?|"
    r"km/h|m/min|cm/s|kmh|mph|centimet(?:re|er)s?|millimet(?:re|er)s?|"
    r"kilomet(?:re|er)s?|minutes?|hours?|centiseconds?|milliseconds?|"
    r"(?:milli|micro|nano)(?:amps?|amperes?|volts?|grams?)|"
    r"cm|mm|km|kgf|lbf|inches|feet|pounds)\b"
    r"|\b(?:\d+(?:\.\d+)?\s*|in\s+)"
    r"(?-i:mA|mV|kN|kJ|kW|kΩ|mg|g|min|hr|ms)\b(?![\^⁻−-])"
)

_AUTHORING_PROMPT = """\
Author a reusable physics MCQ from explicit data you supply and one or more
composable physical laws. The learner sees the physical assumptions and givens
for every step and sees when an input is the result of an earlier step. Ask for
the last step's result.

Provide a closed arithmetic tree over the original named parameters for the
proposed answer and each candidate distractor. Use a parameter node {"param": "F"},
a constant node {"const": "2"}, or an operation {"op": "div", "args": [...]}.
Operations are add and mul (two to four arguments), sub and div (two), and neg
(one). The proposed answer must be exact before rounding. Retained distractors
must differ at the requested number of decimal places. Use signed quantities
along one axis where required. Use several values when the teacher leaves inputs
variable. Numeric parameters use plain decimal strings.

Preserve the teacher's target, values, units and constraints. If the task needs
other laws, assumptions, graphs, prose, or a response format these operations
cannot express, return kind unsupported. Name the missing independent check
in one sentence under 300 characters.
"""


class _Record(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Given(_Record):
    name: Name
    unit: AuthoredUnit
    values: list[Number] = Field(min_length=1, max_length=24)


class Step(_Record):
    name: Name
    law: Literal[
        "newton_acceleration",
        "newton_force",
        "final_velocity",
        "displacement",
        "momentum",
        "impulse",
        "kinetic_energy",
        "average_power",
        "spring_force",
        "ohmic_current",
        "electrical_power",
        "resistive_power",
    ]
    inputs: list[Name] = Field(min_length=1, max_length=4)


class QuantitativeTask(_Record):
    kind: Literal["quantitative"]
    parameters: list[Given] = Field(min_length=1, max_length=8)
    steps: list[Step] = Field(min_length=1, max_length=5)
    decimals: int = Field(ge=0, le=6)
    proposed_answer: RecipeNode
    distractors: list[RecipeNode] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


class UnsupportedTask(_Record):
    kind: Literal["unsupported"]
    reason: str = Field(min_length=1, max_length=400)


class PhysicsTaskProposal(_Record):
    item: Annotated[QuantitativeTask | UnsupportedTask, Field(discriminator="kind")]


class PhysicsTaskCandidate(_Record):
    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]*$")
    difficulty: Difficulty
    question_type: Literal["mcq"] = "mcq"
    item: QuantitativeTask


class ValidatedPhysicsTask(ValidatedTemplateArtifact):
    model_config = ConfigDict(extra="forbid", strict=True)

    format_version: Literal["physics-authored/1.0"] = VERSION
    template: PhysicsTaskCandidate
    validation: PropertyCheckSummary


class PhysicsTaskDomain:
    name = "physics"
    tool_scope = TOOL_SCOPE
    capabilities = frozenset(
        {TEMPLATE_DIFFICULTY_CAPABILITY, TEMPLATE_RELEVANCE_CAPABILITY}
    )
    request_model = TemplateRequest
    candidate_model = PhysicsTaskCandidate
    validated_model = ValidatedPhysicsTask
    question_model = PhysicsQuestionInstance
    template_language = None
    requires_visible_variants = True

    def register_tools(self, server: FastMCP, dependencies: ToolDependencies) -> None:
        register_authored_physics_tool(server)

    def generation_request(self, request: BaseModel) -> StructuredGenerationRequest:
        request = require_type(request, TemplateRequest)
        ordered_inputs = "\n".join(
            f"{name}: "
            + ", ".join(f"{quantity.name} [{quantity.unit}]" for quantity in law.inputs)
            + f" → {law.output.name} [{law.output.unit}]. {law.condition}"
            for name, law in LAWS.items()
        )
        return StructuredGenerationRequest(
            messages=[
                {
                    "role": "system",
                    "content": (
                        _AUTHORING_PROMPT
                        + f"\nSelect {TOOL} with empty arguments."
                        + f"\nUse these laws and ordered inputs:\n{ordered_inputs}"
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Author request: {request.prompt}\n"
                        f"Requested difficulty: {request.difficulty}\n"
                        f"Author exactly {request.num_distractors + SURPLUS_RECIPES} "
                        "candidate distractor recipes. "
                        f"The app selects {request.num_distractors}."
                    ),
                },
            ],
            response_model=PlannedGenerationResponse[PhysicsTaskProposal],
            prompt_version="physics-authored-task-v1",
            schema_name="template_proposal_and_check_plan",
            revise_from_authored_pool=True,
        )

    def build_candidate(
        self, request: BaseModel, proposal: BaseModel
    ) -> PhysicsTaskCandidate:
        request = require_type(request, TemplateRequest)
        proposal = require_type(proposal, PhysicsTaskProposal)
        if isinstance(proposal.item, UnsupportedTask):
            raise UnsupportedAuthoringRequest(proposal.item.reason)
        if clause_mentions(_UNIT_CONVERSION, request.prompt):
            raise UnsupportedAuthoringRequest(
                "The requested unit conversion has no independent check. "
                "Use the supported units for the quantities being assessed."
            )
        item = proposal.item
        last_law = item.steps[-1].law
        require_operation_intent(
            request,
            "electrical power"
            if last_law in _POWER_LAWS
            else LAWS[last_law].output.name,
            request_cues=_REQUEST_CUES,
            source_cues=_SOURCE_CUES,
        )
        required = request.num_distractors
        if len(item.distractors) != required + SURPLUS_RECIPES:
            raise DistractorPoolError(
                f"Author exactly {required + SURPLUS_RECIPES} distractor recipes."
            )
        try:
            _check_structure(item)
            assignments = sample_assignments(_axes(item))
            chosen = select_fixed_subset(
                (_option_row(item, inputs) for inputs in assignments),
                required,
                assignments=assignments,
            )
        except ValidationFailure:
            # The required check reports invalid givens or the law's domain.
            chosen = tuple(range(required))
        return PhysicsTaskCandidate(
            template_id=build_template_id(self.name, request, proposal),
            difficulty=request.difficulty,
            item=item.model_copy(
                update={"distractors": [item.distractors[i] for i in chosen]}
            ),
        )

    def tool_bindings(
        self, request: BaseModel, candidate: BaseModel, tool_name: str
    ) -> dict[str, Any]:
        request = require_type(request, TemplateRequest)
        candidate = require_type(candidate, PhysicsTaskCandidate)
        if tool_name in {TEMPLATE_RELEVANCE_CHECK, TEMPLATE_DIFFICULTY_CHECK}:
            inputs, _, choices, _ = _seeded_variant(candidate, seed=31)
            question = _question(candidate.item, inputs)
            digest = content_sha256(candidate)
            if tool_name == TEMPLATE_DIFFICULTY_CHECK:
                return {
                    "rubric_id": H2_PHYSICS_DIFFICULTY_RUBRIC_ID,
                    "question_payload": json.dumps(
                        {"template": {"question": question, "choices": choices}}
                    ),
                    "distractor_count": len(choices) - 1,
                    "requested_difficulty": candidate.difficulty,
                    "subject_sha256": digest,
                }
            return {
                "author_request": request.prompt,
                "question_text": question,
                "subject_sha256": digest,
            }
        return {
            "candidate": candidate.model_dump(mode="json"),
            "num_distractors": request.num_distractors,
        }

    def distractor_count(self, candidate: BaseModel) -> int:
        return len(require_type(candidate, PhysicsTaskCandidate).item.distractors)

    def required_checks(self, candidate: BaseModel) -> frozenset[str]:
        return frozenset({TOOL})

    def finalize_checked_template(
        self,
        candidate: BaseModel,
        evidence: list[ToolEvidence],
        *,
        advisory_checks: frozenset[str],
    ) -> ValidatedPhysicsTask:
        candidate = require_type(candidate, PhysicsTaskCandidate)
        require_checked(
            evidence,
            required=self.required_checks(candidate),
            advisory_checks=advisory_checks,
        )
        authority = next(item for item in evidence if item.tool == TOOL)
        digest = content_sha256(candidate)
        if authority.details.get("subject_sha256") != digest:
            raise ValueError(
                "The verification evidence belongs to a different Physics draft"
            )
        saved = []
        for item in evidence:
            row = save_checked_evidence(item, digest, advisory_checks=advisory_checks)
            if item.tool == TOOL:
                row.details.update(
                    subject_sha256=digest,
                    operations=item.details["operations"],
                    method=item.details["method"],
                    boundary_cases=item.details["boundary_cases"],
                )
            saved.append(row)
        return ValidatedPhysicsTask(
            template=candidate,
            validation=PropertyCheckSummary(
                **property_details(authority.details), evidence=saved
            ),
        )

    def checked_tool_bindings(
        self,
        request: BaseModel,
        candidate: BaseModel,
        tool_name: str,
        evidence: list[ToolEvidence],
    ) -> dict[str, Any]:
        return self.tool_bindings(request, candidate, tool_name)

    def review_view(
        self, artifact: ValidatedTemplateArtifact
    ) -> ReviewTemplateView | None:
        view = build_review_view(artifact, language=self.template_language)
        if view is not None and isinstance(artifact, ValidatedPhysicsTask):
            preview = self.generate_question(artifact, seed=0)
            view.case_previews = [
                ReviewCasePreview(
                    case_id=artifact.template.item.steps[-1].law,
                    question=preview.question,
                    answer=preview.answer,
                    choices=preview.choices,
                    seed=0,
                )
            ]
        return view

    def generate_question(
        self, validated: BaseModel, *, seed: int
    ) -> PhysicsQuestionInstance:
        artifact = require_type(validated, ValidatedPhysicsTask)
        template_id = artifact.template.template_id
        item = artifact.template.item
        inputs, key, choices, correct_index = _seeded_variant(artifact.template, seed)
        return PhysicsQuestionInstance(
            template_id=template_id,
            artifact_id=artifact.artifact_id,
            seed=seed,
            parameters=inputs,
            question=_question(item, inputs),
            choices=choices,
            correct_index=correct_index,
            answer=key,
            topic="Quantitative physics",
            target="authored_quantity",
            unit=LAWS[item.steps[-1].law].output.unit,
            assumptions=[LAWS[step.law].condition for step in item.steps],
        )


def register_authored_physics_tool(server: FastMCP) -> None:
    @server.tool(
        name=TOOL,
        version=CHECK_VERSION,
        tags={f"domain:{TOOL_SCOPE}", "validation:correctness", "validation:options"},
        annotations={"readOnlyHint": True, "openWorldHint": False},
        description=(
            "Derive an authored physics answer from the displayed measurements and "
            "physical laws with exact arithmetic. Check units and assumptions, the "
            "independent key and every distractor, with explicit boundary cases."
        ),
    )
    async def verify_authored_task(
        candidate: PhysicsTaskCandidate, num_distractors: int
    ) -> ToolEvidence:
        return _verify_task(candidate, num_distractors)


def _seeded_variant(
    candidate: PhysicsTaskCandidate, seed: int
) -> tuple[dict[str, str], str, list[str], int]:
    item, template_id = candidate.item, candidate.template_id
    _check_structure(item)
    axes = _axes(item)
    for attempt in range(MAX_GENERATION_TRIES):
        inputs = {
            name: values[
                seeded_index(template_id, seed, f"{name}/{attempt}", len(values))
            ]
            for name, values in axes.items()
        }
        try:
            key, choices = _evaluate(item, inputs)
        except (PhysicsCheckError, ValidationFailure):
            continue
        index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
        choices.insert(index, key)
        return inputs, key, choices, index
    raise ValueError("No independently valid Physics question was found for this seed.")


def _axes(item: QuantitativeTask) -> dict[str, list[str]]:
    return {given.name: sorted(given.values, key=Fraction) for given in item.parameters}


def _question(item: QuantitativeTask, inputs: dict[str, str]) -> str:
    labels = {
        parameter.name: f"{inputs[parameter.name]} {parameter.unit}"
        for parameter in item.parameters
    }
    lines = []
    for number, step in enumerate(item.steps, start=1):
        law = LAWS[step.law]
        facts = "; ".join(
            f"{quantity.name} = {labels[name]}"
            for quantity, name in zip(law.inputs, step.inputs, strict=True)
        )
        text = f"{law.condition} Given {facts}. Find the {law.output.name}."
        lines.append(f"Step {number}. {text}" if len(item.steps) > 1 else text)
        labels[step.name] = f"the result of Step {number}"
    places = "place" if item.decimals == 1 else "places"
    lines.append(f"Give the final answer to {item.decimals} decimal {places}.")
    return "\n".join(lines)


def _verify_task(
    candidate: PhysicsTaskCandidate, requested_distractors: int
) -> ToolEvidence:
    started = time.perf_counter()
    item = candidate.item
    axes = _axes(item)
    minima = {name: values[0] for name, values in axes.items()}
    maxima = {name: values[-1] for name, values in axes.items()}
    boundaries = [
        minima,
        maxima,
        *(minima | {name: value} for name, value in maxima.items()),
        *(
            minima | {name: value}
            for name, values in axes.items()
            for value in values
            if Fraction(value) == 0
        ),
    ]
    boundary = list({tuple(row.items()): row for row in boundaries}.values())
    run = PropertyCheckRun(
        PropertyCheckSettings(
            timeout_seconds=5,
            max_examples=max(1, PropertyCheckSettings().max_examples - len(boundary)),
        )
    )

    def check(inputs: dict[str, str], budget: PropertyCheckRun) -> None:
        budget.reserve_execution()
        try:
            _evaluate(item, inputs)
            _question(item, inputs)
        except PhysicsCheckError as exc:
            raise ValidationFailure(
                str(exc), code=exc.code, context={"inputs": inputs}
            ) from exc
        except ValidationFailure as exc:
            exc.context["inputs"] = inputs
            raise

    status: Literal["passed", "failed", "error"] = "passed"
    findings = []
    failure_context: dict[str, Any] = {}
    try:
        if len(item.distractors) != requested_distractors:
            raise ValidationFailure(
                f"Author exactly {requested_distractors} distractors.",
                code="PHYSICS_AUTHORED_DISTRACTOR_COUNT",
            )
        _check_structure(item)
        _check_force_links(item)
        run.check(axes, boundary, check)
    except ValidationFailure as exc:
        status = "error" if exc.code == "PROPERTY_CHECK_BUDGET_EXCEEDED" else "failed"
        findings.append(ToolFinding(code=exc.code, message=str(exc)))
        failure_context = exc.context
    return ToolEvidence(
        tool=TOOL,
        version=CHECK_VERSION,
        status=status,
        details={
            **run.details(),
            "subject_sha256": content_sha256(candidate),
            "method": "Exact rational physical law, unit and option checks",
            "operations": [
                {"law": step.law, "equation": LAWS[step.law].equation}
                for step in item.steps
            ],
            "boundary_cases": boundary,
            "failure_context": failure_context,
        },
        findings=findings,
        duration_ms=(time.perf_counter() - started) * 1000,
    )


def _check_structure(item: QuantitativeTask) -> None:
    given_units = {given.name: given.unit for given in item.parameters}
    if len(given_units) != len(item.parameters) or any(
        len(set(map(Fraction, given.values))) != len(given.values)
        for given in item.parameters
    ):
        raise ValidationFailure(
            "Declare unique given names and distinct numeric values for each.",
            code="PHYSICS_AUTHORED_PARAMETER_DUPLICATE",
        )
    units = dict(given_units)
    for step in item.steps:
        law = LAWS[step.law]
        if step.name in units or len(step.inputs) != len(law.inputs):
            raise ValidationFailure(
                f"Give step {step.name!r} a unique name and {len(law.inputs)} inputs.",
                code="PHYSICS_AUTHORED_INVALID_STEP",
            )
        for name, quantity in zip(step.inputs, law.inputs, strict=True):
            if units.get(name) != quantity.unit:
                raise ValidationFailure(
                    f"Step {step.name!r} requires {quantity.name} in {quantity.unit}; "
                    f"input {name!r} has unit {units.get(name)!r} or is undeclared.",
                    code="PHYSICS_AUTHORED_UNIT_MISMATCH",
                )
        units[step.name] = law.output.unit
    needed = {item.steps[-1].name}
    for step in reversed(item.steps):
        if step.name not in needed:
            raise ValidationFailure(
                f"Step {step.name!r} must contribute to the final result.",
                code="PHYSICS_AUTHORED_UNUSED_STEP",
            )
        needed.update(step.inputs)
    unused = sorted(given_units.keys() - needed)
    if unused:
        raise ValidationFailure(
            f"Undisplayed inputs: {', '.join(unused)}.",
            code="PHYSICS_AUTHORED_UNUSED_INPUT",
        )
    _check_recipe(item.proposed_answer, set(given_units))


def _check_force_links(item: QuantitativeTask) -> None:
    spring_magnitudes = {step.name for step in item.steps if step.law == "spring_force"}
    for step in item.steps:
        if step.law in {"newton_acceleration", "impulse"} and (
            step.inputs[0] in spring_magnitudes
        ):
            raise ValidationFailure(
                f"Step {step.name!r} requires a signed resultant force. The spring "
                "calculation gives only a magnitude. Supply the signed resultant "
                "force as a separate given.",
                code="PHYSICS_AUTHORED_FORCE_ASSUMPTION",
            )


def _check_recipe(recipe: RecipeNode, names: set[str]) -> None:
    nodes = [(recipe, 1)]
    count = 0
    while nodes:
        node, depth = nodes.pop()
        count += 1
        if count > 63 or depth > 8:
            raise ValidationFailure(
                "An answer or distractor recipe exceeds 63 nodes or 8 levels.",
                code="PHYSICS_AUTHORED_RECIPE_LIMIT",
            )
        if node.param is not None and node.param not in names:
            raise ValidationFailure(
                f"Recipe input {node.param!r} is not a displayed numeric given.",
                code="PHYSICS_AUTHORED_RECIPE_INPUT",
            )
        nodes.extend((child, depth + 1) for child in node.args or [])


def _canonical(item: QuantitativeTask, given_values: dict[str, Fraction]) -> Fraction:
    values = dict(given_values)
    for step in item.steps:
        law = LAWS[step.law]
        arguments = [values[name] for name in step.inputs]
        for argument, quantity in zip(arguments, law.inputs, strict=True):
            outside = (quantity.positive and argument <= 0) or (
                quantity.nonnegative and argument < 0
            )
            if outside:
                sign = "positive" if quantity.positive else "nonnegative"
                raise ValidationFailure(
                    f"Step {step.name!r} needs {sign} {quantity.name}; "
                    f"got {argument} {quantity.unit}.",
                    code="PHYSICS_AUTHORED_OUTSIDE_LAW_DOMAIN",
                )
        values[step.name] = law.solve(*arguments)
    return values[item.steps[-1].name]


def _option(
    item: QuantitativeTask, recipe: RecipeNode, given_values: dict[str, Fraction]
) -> OptionValue | UnusableOption:
    output = LAWS[item.steps[-1].law].output
    try:
        _check_recipe(recipe, set(given_values))
        value = evaluate_display_values(recipe, given_values)
    except (PhysicsCheckError, ValidationFailure) as exc:
        return UnusableOption(str(exc))
    if output.nonnegative and value < 0:
        return UnusableOption("a magnitude distractor is negative")
    return OptionValue(value, _display(value, item.decimals, output.unit))


def _option_row(
    item: QuantitativeTask, raw: dict[str, str]
) -> tuple[OptionValue, list[OptionValue | UnusableOption]]:
    given_values = {name: Fraction(value) for name, value in raw.items()}
    key = _canonical(item, given_values)
    unit = LAWS[item.steps[-1].law].output.unit
    return OptionValue(key, _display(key, item.decimals, unit)), [
        _option(item, recipe, given_values) for recipe in item.distractors
    ]


def _evaluate(item: QuantitativeTask, raw: dict[str, str]) -> tuple[str, list[str]]:
    given_values = {name: Fraction(value) for name, value in raw.items()}
    key = _canonical(item, given_values)
    unit = LAWS[item.steps[-1].law].output.unit
    proposed = evaluate_display_values(item.proposed_answer, given_values)
    if proposed != key:
        raise ValidationFailure(
            f"The proposed answer {proposed} {unit} differs from the independently "
            f"derived {key} {unit}.",
            code="PHYSICS_AUTHORED_KEY_MISMATCH",
        )
    wrong = []
    wrong_display = []
    for recipe in item.distractors:
        option = _option(item, recipe, given_values)
        if isinstance(option, UnusableOption):
            raise ValidationFailure(
                option.reason, code="PHYSICS_AUTHORED_INVALID_DISTRACTOR"
            )
        wrong.append(option.semantic)
        wrong_display.append(option.display)
    key_display = _display(key, item.decimals, unit)
    if key in wrong or key_display in wrong_display:
        raise ValidationFailure(
            "A distractor matches the correct answer at the displayed precision.",
            code="PHYSICS_AUTHORED_DISTRACTOR_EQUIVALENT",
        )
    if len(set(wrong)) != len(wrong) or len(set(wrong_display)) != len(wrong_display):
        raise ValidationFailure(
            "Two distractors are equivalent at the displayed precision.",
            code="PHYSICS_AUTHORED_DISTRACTOR_DUPLICATE",
        )
    return key_display, wrong_display


def _display(value: Fraction, decimals: int, unit: AuthoredUnit) -> str:
    scale = 10**decimals
    rounded = int(abs(value) * scale + Fraction(1, 2))
    sign = "-" if value < 0 and rounded else ""
    whole, fractional = divmod(rounded, scale)
    number = f"{whole}.{fractional:0{decimals}d}" if decimals else str(whole)
    return f"{sign}{number} {unit}"
