"""Small constants for the physics domain."""

from __future__ import annotations

from typing import Literal

# Explicit re-exports: the shared authoring vocabulary lives in one module.
from edcraft_validator.domain_types import (
    MAX_DISTRACTORS as MAX_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    MIN_DISTRACTORS as MIN_DISTRACTORS,
)
from edcraft_validator.domain_types import (
    Difficulty as Difficulty,
)

PHYSICS_ITEM_TOOL = "physics_verify_item"
PHYSICS_OPTIONS_TOOL = "physics_validate_options"
PHYSICS_TEXT_TOOL = "physics_verify_text"
PHYSICS_FIDELITY_TOOL = "physics_verify_text_fidelity"
PHYSICS_TOOL_VERSION = "1.0.0"
PHYSICS_SCHEMA_VERSION: Literal["physics-1d/0.1"] = "physics-1d/0.1"
PHYSICS_VALIDATOR_VERSION: Literal["mcp-physics-template-v1"] = (
    "mcp-physics-template-v1"
)
PHYSICS_FORMAT_VERSION: Literal["1.0.0"] = "1.0.0"
PHYSICS_CHECKING_MODE: Literal["property_based"] = "property_based"

# Authoring limits. Values above these are rejected before any checking runs.
MAX_PARAMETERS = 6
MAX_VALUES_PER_PARAMETER = 16
MAX_DECIMALS = 3
MAX_KNOWN_FORCES = 3
MAX_RECIPE_DEPTH = 5
MAX_RECIPE_NODES = 15
MAX_TOOL_TIMEOUT_SECONDS = 30.0
