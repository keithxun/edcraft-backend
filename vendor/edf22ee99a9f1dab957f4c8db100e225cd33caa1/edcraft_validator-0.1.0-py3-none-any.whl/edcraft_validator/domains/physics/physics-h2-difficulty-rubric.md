# Provisional Singapore H2 Physics difficulty rubric

Rubric version: `physics-h2-9478-v0.1`.
Assessment conditions version: `calculator-untimed-v0.1`.

Assess the demand of a multiple-choice question for a student who has been taught
the relevant 9478 content and can use a scientific calculator without a time
limit. Consider the actual options and any displayed stimulus. The scale is
provisional and uncalibrated. The rating is advisory.

## Dimensions

| Dimension | Low | Moderate | High |
| --- | --- | --- | --- |
| Physical model | Recognise a definition or use a relation with an explicit setup. | Choose the applicable principle or comparison and establish its assumptions. | Coordinate multiple regimes, physical models or constraints. |
| Representation interpretation | Read quantities directly or recognise a familiar symbol. | Infer a sign, relation, slope, phase or connection from a representation or reconcile one conversion. | Integrate several readings or representations with nontrivial signs, scales or geometry. |
| Reasoning chain | Recall or substitute in one routine step. | Infer one intermediate result or apply one concept to a concrete context. | Link several dependent inferences, with the result of one required for the next. |
| Answer discrimination | One recognised fact or simple check distinguishes the key. | An actual application or interpretation is needed to distinguish plausible alternatives. | Plausible alternatives differ on linked steps and require most of the reasoning to resolve. |

## Levels

| Level | Anchor description |
| --- | --- |
| easy | Direct recognition or a single routine substitution using explicit inputs. |
| medium | Apply a principle in context or interpret a representation, with a meaningful inference or short calculation. |
| hard | Coordinate multiple dependent inferences, or integrate evidence and conditions across parts of a problem, with plausible alternatives demanding sustained reasoning. |

Choose the closest anchor to the actual route that distinguishes the options.
Do not sum dimension ratings. Raw numerical size, topic name and statement
count do not determine difficulty. Look for shortcuts through weak options.
Report substantial differences among variants when the payload includes them.

## Worked anchors

### easy

The room temperature is 10.00 °C. What is the absolute temperature?
Choices: 283.15 K, 263.15 K, 10.00 K, 273.15 K.
The answer is 283.15 K from adding 273.15. The learner recognises one conversion.
The remaining choices reflect a sign mistake, using the reading without
conversion, or using the offset alone.

### medium

A capacitor graph plots potential difference against charge from the origin to
the plotted point (4.0 μC, 6.0 V), with a straight line between the points.
Find the energy when the capacitor reaches that point.
Choices: 12 μJ, 24 μJ, 6 μJ, 0.67 μJ.
The answer is 12 μJ from the triangular area under the graph, with
μC × V = μJ. The alternatives use a rectangle, halve the area twice, or use
the ratio of plotted values. Choosing the slope would find a different quantity.

### hard

In a classroom particle-beam demonstration a rightward beam passes undeflected
through a downward electric field of 6.0 × 10³ V/m and a 0.030 T magnetic field
directed into the page. In a second region the electric field is absent. The
same magnetic field bends the beam upwards with radius 0.50 m. Find the signed
charge-to-mass ratio of the particles.
Choices in C/kg: +1.33 × 10⁷, −1.33 × 10⁷, +6.67 × 10⁶, +4.00 × 10⁵.
The first region gives the speed from balancing electric and magnetic forces.
The second gives the sign from the bend direction and the magnitude from
`|q|/m = v/(Br)`. The alternatives reverse the sign, omit division by the radius,
or omit division by magnetic flux density.
