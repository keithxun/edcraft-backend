"""Deterministically expand approved physics templates into seeded questions.

Generation decodes one parameter combination with a mixed radix, rechecks the
same key and option rules the authoring checks apply, and renders the answer.
Nothing here calls a model, MCP, network or worker. The recheck closes the gap
that sampling leaves in large declared domains.
"""

from __future__ import annotations

from typing import cast

from edcraft_validator.domains.domain_support import seeded_index
from edcraft_validator.domains.physics import correctness
from edcraft_validator.domains.physics import text as physics_text
from edcraft_validator.domains.physics.correctness import PhysicsCheckError
from edcraft_validator.domains.physics.h2 import generate_h2_question
from edcraft_validator.domains.physics.h2_statement_data import H2StatementSpec
from edcraft_validator.domains.physics.h2_statements import roll_question
from edcraft_validator.domains.physics.h2_task_data import H2TaskSpec
from edcraft_validator.domains.physics.h2_tasks import generate_task_question
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsQuestionInstance,
    PhysicsTemplateSpec,
    Unit,
    ValidatedPhysicsTemplate,
)
from edcraft_validator.domains.physics.quantities import (
    QUANTITY_UNITS,
    TARGET_QUANTITIES,
    parse_decimal,
)

# A large declared domain is sampled rather than swept, so one seed tries at
# most this many combinations before giving up.
MAX_GENERATION_TRIES = 256


def generate_physics_question(
    validated: ValidatedPhysicsTemplate, seed: int
) -> PhysicsQuestionInstance:
    """Expand one approved template without AI calls or external I/O."""
    template = validated.template
    spec = template.item
    if isinstance(spec, H2TaskSpec):
        return generate_task_question(
            spec,
            template_id=template.template_id,
            artifact_id=validated.artifact_id,
            seed=seed,
        )
    if isinstance(spec, H2StatementSpec):
        return roll_question(
            spec,
            template_id=template.template_id,
            artifact_id=validated.artifact_id,
            seed=seed,
        )
    if isinstance(spec, H2TemplateSpec):
        return generate_h2_question(
            spec,
            template_id=template.template_id,
            artifact_id=validated.artifact_id,
            seed=seed,
        )
    size = _domain_size(spec)
    start = seeded_index(template.template_id, seed, "parameter-combination", size)

    for offset in range(min(size, MAX_GENERATION_TRIES)):
        index = (start + offset) % size
        combination = _decode_combination(spec, index)
        try:
            return _build_instance(validated, spec, seed, combination)
        except PhysicsCheckError:
            continue

    raise ValueError("Could not produce a usable question from this template")


def _domain_size(spec: PhysicsTemplateSpec) -> int:
    size = 1
    for parameter in spec.parameters:
        size *= len(parameter.values)
    return size


def _decode_combination(spec: PhysicsTemplateSpec, index: int) -> dict[str, str]:
    """Decode one mixed-radix index over parameters in declared order."""
    combination: dict[str, str] = {}
    for parameter in spec.parameters:
        ordered = sorted(parameter.values, key=parse_decimal)
        index, position = divmod(index, len(ordered))
        combination[parameter.name] = ordered[position]
    return combination


def _build_instance(
    validated: ValidatedPhysicsTemplate,
    spec: PhysicsTemplateSpec,
    seed: int,
    combination: dict[str, str],
) -> PhysicsQuestionInstance:
    """Recheck one combination and render its key and distractors."""
    canonical = correctness.check_key(spec, combination)
    entries = correctness.check_options(spec, combination)
    failed = next((entry for entry in entries if entry.get("status") != "passed"), None)
    if failed is not None:
        raise PhysicsCheckError(
            str(failed.get("code")),
            f"distractor {failed.get('index')} is not usable for this combination",
        )

    body = spec.body
    quantity = TARGET_QUANTITIES[body.target]
    unit = cast(Unit, QUANTITY_UNITS[quantity])
    values = correctness.parameter_values(spec, combination)
    axis_positive = spec.axis.positive

    answer = correctness.render_answer(
        canonical,
        unit=unit,
        decimals=body.display.decimals,
        form=body.answer_form,
        axis_positive=axis_positive,
    )
    distractor_choices = []
    for distractor in body.distractors:
        value, _ = correctness.evaluate_recipe(distractor.recipe, spec, values)
        distractor_choices.append(
            correctness.render_answer(
                value,
                unit=unit,
                decimals=body.display.decimals,
                form=body.answer_form,
                axis_positive=axis_positive,
            )
        )

    template_id = validated.template.template_id
    choices = list(distractor_choices)
    correct_index = seeded_index(template_id, seed, "correct-index", len(choices) + 1)
    choices.insert(correct_index, answer)

    return PhysicsQuestionInstance(
        template_id=template_id,
        artifact_id=validated.artifact_id,
        seed=seed,
        parameters=combination,
        question=physics_text.render_question(spec, combination),
        choices=choices,
        correct_index=correct_index,
        answer=answer,
        topic=spec.topic,
        target=body.target,
        unit=unit,
        assumptions=physics_text.assumptions(spec),
    )
