# Provisional physics difficulty rubric

Rubric version: `physics-1d-v0.1`.
Assessment conditions version: `calculator-untimed-v0.1`.

Use this rubric to check whether a reusable physics MCQ template matches the user's requested
difficulty. Assess the typical concrete expansion independently, then compare its estimated level
with the request. Levels are EdCraft's provisional task-demand conventions and they are
uncalibrated, with no reference labels behind them, so results stay advisory evidence for educator
review and never override failed correctness checks.

## Assessment conditions and scope

Use a scientific calculator, with no time limit, and assume Newton's second law has been taught.
Record any aids, time limit or scaffolding as a different assessment condition.

The pilot covers one body of constant positive mass on one horizontal axis, with `F_net = m a`, in
SI units. Targets are acceleration, net force, mass and a missing force. Weight, gravity, friction
coefficients and angles sit outside this family.

A calculator changes the keystrokes that a large value costs and it leaves the physics reasoning
unchanged, so number size is not a dimension here. Large values can still be `easy`.

A template is rated on concrete expansions of its declared parameter family, including boundary
values that the checks sample. A sampled match cannot establish that every expansion matches.

Technical correctness, educational difficulty and question quality are separate. Distinct wrong
answers do not establish plausible distractors, and a correct template can still carry weak options.

## Dimensions and evidence to record

Rate each dimension `low`, `moderate` or `high`, or `unknown` when the evidence is insufficient. Do
not sum them or apply a weighted formula to produce a difficulty score. Level boundaries are EdCraft
conventions and they are not calibrated thresholds.

| Dimension | Low | Moderate | High |
| --- | --- | --- | --- |
| Model set-up | Net force given directly. | Two collinear forces to combine. | Three forces, or an unknown force to isolate. |
| Relation use | Direct substitution for F or a. | One rearrangement, for example for m. | Rearrangement plus removal of known forces. |
| Direction reasoning | Everything along the positive direction. | One opposing force, direction stated. | Answer direction varies across the family or must be inferred from signs. |
| Answer discrimination | Options fall to a magnitude check. | Eliminating options needs one rule. | Plausible options need the full sign-aware solution. |

### Model set-up

Describe the force list that the stem supplies. Three forces, or an unknown force to isolate, add
bookkeeping before any relation is used. Record the number of forces and whether one is unknown.

### Relation use

State the algebraic steps between the given quantities and the target. One rearrangement, for
example for `m`, stays routine. Rearrangement plus removal of known forces couples the algebra with
the force list, so record the rearranged form.

### Direction reasoning

Record how the answer direction is settled. One opposing force needs the learner to keep the stated
direction through the arithmetic. When the answer direction varies across the family, or must be
inferred from signs, the reasoning is `high`.

### Answer discrimination

For each distractor, explain the error rule the option hypothesis uses and the rule that eliminates
it. The misconception tag is a hypothesis, and without learner data it is not proof that learners
make that error. Assign the dimension from the easiest defensible way to tell the correct answer
from the actual options. Here discrimination means option-distinguishing demand.

## Overall levels and uncertainty

| Level | Anchor description |
| --- | --- |
| `easy` | A single routine step with the net force or the relation supplied, whole-number values and no opposing force. At most one dimension is moderate. Options fall to a magnitude check. |
| `medium` | Two collinear forces to combine, or one rearrangement, with one opposing force whose direction the stem states. Eliminating options needs one rule. |
| `hard` | Three forces or an unknown force to isolate, with a rearrangement and sign-aware reasoning. Plausible options need the full sign-aware solution. |

Levels in this pilot follow the shared vocabulary. Issue #69 used beginner, intermediate and
advanced, and those labels map to `easy`, `medium` and `hard`. Use the shared terms in records.

Choose the closest worked anchor and explain the similarities and the material differences. A
single high dimension does not force `hard`. A shortcut or weak options can lower the complete
MCQ's demand, and unknown evidence is not defaulted to medium.

Record confidence from 0 to 1 in the selected level. It is a self-estimate and it is uncalibrated.
For missing essential information use `estimated_difficulty: null` with an unable-to-assess reason
and confidence 0. A failed template is ineligible for difficulty assessment.

## Reviewer procedure and records

1. Confirm the checks passed and the stem is clear. Repair ineligible cases first.
2. Hide the requested difficulty, generator identity and other ratings. Show the conditions.
3. Explain the solution and each distractor, then record dimension ratings, nearest anchor, overall
   level, confidence and quality concerns independently.
4. Reveal the requested difficulty and apply the comparison rule to the frozen assessment. A
   mismatch remains advisory and never requests automatic revision.

Store records in versioned files, with the rubric and conditions versions, the reviewed parameter
combinations, the dimension ratings with reasons, the closest anchor, the estimated level or null,
confidence and the match result. Increment the rubric version when dimensions, anchors or conditions
change. Code, value or option edits invalidate the previous assessment.

## Validation plan

Target about 60 concrete questions from at least 20 template families across the four target kinds
and all three requested levels. Split by family before tuning and keep variants of one family
together. Use two or three independent physics teachers, with the author disclosed separately.
Record ordinal Krippendorff's alpha for the overall level, per-dimension exact agreement and a
confusion matrix against the adjudicated reference. Calibration against learner responses is
deferred until response data exists.

## Worked anchors

These examples are reviewer training material, and nobody has rated them independently.

### Easy net force given

A net force of 12 N to the right acts on a 3 kg box. Find its acceleration. A: `4 m/s^2` to the
right, the key, from dividing 12 N by 3 kg. B: `36 m/s^2`, from multiplying instead of dividing.
C: `0.25 m/s^2`, from inverting the ratio. D: `15 m/s^2`, from adding the two numbers.

Answer: A. The solution is one substitution, so all four dimensions are low and the options fall to
a magnitude check.

### Medium two opposing forces

A 5 kg cart has 30 N to the right and 10 N to the left acting on it. Find its acceleration.
A: `4 m/s^2` to the right, the key, from a 20 N net force. B: `8 m/s^2` to the right, from adding
the opposing forces. C: `6 m/s^2` to the right, from ignoring the opposing force. D: `4 m/s^2` to
the left, from a direction sign error.

Answer: A. Model set-up and direction reasoning are moderate because two collinear forces must be
combined and the stated direction must survive the arithmetic. Relation use is low. Answer
discrimination is moderate because the shared magnitude in A and D needs the sign checked.

### Hard missing force

A 2 kg block accelerates at `3 m/s^2` to the left. A 10 N force acts to the right and an unknown
force acts to the left. Find the magnitude of the unknown force. A: `16 N`, the key, because
`m a = 6 N` to the left and `F_u - 10 = 6`. B: `4 N`, from ignoring the direction of the
acceleration. C: `6 N`, from reporting the net force. D: `13 N`, from adding the acceleration to a
force.

Answer: A. Model set-up is high because the unknown force must be isolated from three force terms.
Relation use is high because the learner rearranges for the unknown and then removes the known
force. Answer discrimination is high because B, C and D all look plausible until the sign-aware
solution is complete. Direction reasoning is moderate, since the stem names the side of each force.

## Limits

This rubric is provisional and it is uncalibrated. It has no learner data behind it, and its levels
are EdCraft conventions and they are not calibrated thresholds. The misconception tags in the
worked anchors are hypotheses about error rules, and no response data confirms that learners make
those errors. Ratings are advisory evidence for educator review and they never override failed
correctness checks. A template that fails a check is ineligible for whatever level it appears to
carry.
