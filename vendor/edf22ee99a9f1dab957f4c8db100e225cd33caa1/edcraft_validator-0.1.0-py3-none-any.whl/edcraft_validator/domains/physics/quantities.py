"""Dimensions, units, bounds and exact decimal parsing for the physics pilot.

Every physical quantity is a dimension triple over (M, L, T). Values are parsed
straight into :class:`fractions.Fraction`, so no float ever touches a checked
answer.
"""

from __future__ import annotations

import re
from fractions import Fraction

Dimension = tuple[int, int, int]

DIMENSIONLESS: Dimension = (0, 0, 0)

QUANTITY_DIMENSIONS: dict[str, Dimension] = {
    "mass": (1, 0, 0),
    "force": (1, 1, -2),
    "acceleration": (0, 1, -2),
}

QUANTITY_UNITS: dict[str, str] = {
    "mass": "kg",
    "force": "N",
    "acceleration": "m/s^2",
}

# The quantity each target asks for.
TARGET_QUANTITIES: dict[str, str] = {
    "acceleration": "acceleration",
    "net_force": "force",
    "mass": "mass",
    "missing_force": "force",
}

# The side opposite each named axis direction.
OPPOSITE_SIDE: dict[str, str] = {"right": "left", "left": "right"}

# Learner-facing unit text. The caret form above stays in data and messages.
DISPLAY_UNITS: dict[str, str] = {
    "kg": "kg",
    "N": "N",
    "m/s^2": "m/s²",
}

# Inclusive upper bounds. Mass is strictly positive, which the helper below
# enforces, so a body with no mass never reaches the evaluator.
QUANTITY_BOUNDS: dict[str, tuple[Fraction, Fraction]] = {
    "mass": (Fraction(0), Fraction(1000)),
    "force": (Fraction(0), Fraction(10000)),
    "acceleration": (Fraction(0), Fraction(1000)),
}

_DECIMAL_PATTERN = re.compile(r"^(0|[1-9][0-9]{0,4})(\.[0-9]{1,3})?$")


def parse_decimal(text: str) -> Fraction:
    """Parse an authored non-negative decimal value exactly."""
    if not isinstance(text, str) or _DECIMAL_PATTERN.fullmatch(text) is None:
        raise ValueError(
            f"value {text!r} is not a plain non-negative decimal with at most 3 "
            "decimal places, no sign, no exponent and no leading zeros"
        )
    return Fraction(text)


def within_bounds(quantity: str, value: Fraction) -> bool:
    """Report whether a value satisfies the pilot's range for its quantity."""
    _, high = QUANTITY_BOUNDS[quantity]
    if quantity == "mass":
        return Fraction(0) < value <= high
    return Fraction(0) <= value <= high


def dimension_name(dimension: Dimension) -> str:
    """Readable dimension text such as ``force (M L T^-2)``."""
    quantity = next(
        (name for name, known in QUANTITY_DIMENSIONS.items() if known == dimension),
        None,
    )
    symbol = "dimensionless" if dimension == DIMENSIONLESS else _symbols(dimension)
    if quantity is None:
        return f"unknown ({symbol})"
    return f"{quantity} ({symbol})"


def _symbols(dimension: Dimension) -> str:
    parts = []
    for name, exponent in zip("MLT", dimension, strict=True):
        if exponent == 0:
            continue
        parts.append(name if exponent == 1 else f"{name}^{exponent}")
    return " ".join(parts)
