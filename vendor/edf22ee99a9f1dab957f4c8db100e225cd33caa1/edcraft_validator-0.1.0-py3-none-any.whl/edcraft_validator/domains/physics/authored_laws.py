"""Allowlisted physical laws for authored numerical questions.

Each law declares the quantities it consumes, its conditions of validity, and
its own exact solver. The same quantities and conditions appear in the stem.
"""

from collections.abc import Callable
from dataclasses import dataclass
from fractions import Fraction
from typing import Literal

AuthoredUnit = Literal[
    "kg", "N", "m/s²", "m/s", "m", "s", "kg m/s", "N s", "J", "W", "V", "A", "Ω", "N/m"
]


@dataclass(frozen=True)
class InputQuantity:
    name: str
    unit: AuthoredUnit
    positive: bool = False
    nonnegative: bool = False


@dataclass(frozen=True)
class PhysicalLaw:
    inputs: tuple[InputQuantity, ...]
    output: InputQuantity
    condition: str
    equation: str
    solve: Callable[..., Fraction]


MASS = InputQuantity("mass", "kg", positive=True)
NET_FORCE = InputQuantity("signed net force", "N")
INITIAL_VELOCITY = InputQuantity("signed initial velocity", "m/s")
ACCELERATION = InputQuantity("signed acceleration", "m/s²")
TIME = InputQuantity("elapsed time", "s", nonnegative=True)
CURRENT = InputQuantity("current magnitude", "A", nonnegative=True)
RESISTANCE = InputQuantity("resistance", "Ω", positive=True)

LAWS = {
    "newton_acceleration": PhysicalLaw(
        (NET_FORCE, MASS),
        ACCELERATION,
        "Consider motion along one axis with the given resultant force.",
        "a = F_net / m",
        lambda force, mass: force / mass,
    ),
    "newton_force": PhysicalLaw(
        (MASS, ACCELERATION),
        NET_FORCE,
        "Consider motion along one axis with the given acceleration.",
        "F_net = m × a",
        lambda mass, acceleration: mass * acceleration,
    ),
    "final_velocity": PhysicalLaw(
        (INITIAL_VELOCITY, ACCELERATION, TIME),
        InputQuantity("signed final velocity", "m/s"),
        "Consider straight-line motion with constant acceleration.",
        "v = u + a × t",
        lambda initial, acceleration, time: initial + acceleration * time,
    ),
    "displacement": PhysicalLaw(
        (INITIAL_VELOCITY, ACCELERATION, TIME),
        InputQuantity("signed displacement", "m"),
        "Consider straight-line motion with constant acceleration.",
        "s = u × t + a × t² / 2",
        lambda initial, acceleration, time: initial * time + acceleration * time**2 / 2,
    ),
    "momentum": PhysicalLaw(
        (MASS, InputQuantity("signed velocity", "m/s")),
        InputQuantity("signed momentum", "kg m/s"),
        "Consider linear motion along one axis.",
        "p = m × v",
        lambda mass, velocity: mass * velocity,
    ),
    "impulse": PhysicalLaw(
        (InputQuantity("signed average resultant force", "N"), TIME),
        InputQuantity("signed impulse", "N s"),
        "Consider the resultant force along one axis over the stated interval.",
        "J = F_avg × t",
        lambda force, time: force * time,
    ),
    "kinetic_energy": PhysicalLaw(
        (MASS, InputQuantity("signed velocity", "m/s")),
        InputQuantity("translational kinetic energy", "J", nonnegative=True),
        "Consider nonrelativistic motion in one dimension.",
        "E_k = m × v² / 2",
        lambda mass, velocity: mass * velocity**2 / 2,
    ),
    "average_power": PhysicalLaw(
        (
            InputQuantity("energy transferred", "J", nonnegative=True),
            InputQuantity("elapsed time", "s", positive=True),
        ),
        InputQuantity("average power", "W", nonnegative=True),
        "Consider energy transfer over the stated interval.",
        "P_avg = E / t",
        lambda energy, time: energy / time,
    ),
    "spring_force": PhysicalLaw(
        (
            InputQuantity("spring constant", "N/m", positive=True),
            InputQuantity("extension", "m", nonnegative=True),
        ),
        InputQuantity("force magnitude", "N", nonnegative=True),
        "Consider a spring held at the stated extension within its proportional limit.",
        "F = k × x",
        lambda stiffness, extension: stiffness * extension,
    ),
    "ohmic_current": PhysicalLaw(
        (
            InputQuantity("potential difference magnitude", "V", nonnegative=True),
            RESISTANCE,
        ),
        InputQuantity("current magnitude", "A", nonnegative=True),
        "Consider an ohmic resistor at constant temperature.",
        "I = V / R",
        lambda voltage, resistance: voltage / resistance,
    ),
    "electrical_power": PhysicalLaw(
        (
            InputQuantity("potential difference magnitude", "V", nonnegative=True),
            CURRENT,
        ),
        InputQuantity("electrical power absorbed", "W", nonnegative=True),
        "Consider a passive component in a steady direct-current circuit.",
        "P = V × I",
        lambda voltage, current: voltage * current,
    ),
    "resistive_power": PhysicalLaw(
        (CURRENT, RESISTANCE),
        InputQuantity("electrical power dissipated", "W", nonnegative=True),
        "Consider an ohmic resistor carrying a steady direct current.",
        "P = I² × R",
        lambda current, resistance: current**2 * resistance,
    ),
}
