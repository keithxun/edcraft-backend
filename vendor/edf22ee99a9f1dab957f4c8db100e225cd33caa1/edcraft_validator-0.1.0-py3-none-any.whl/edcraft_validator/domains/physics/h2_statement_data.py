"""Typed stimuli and local evidence for curated 9478 statement questions."""

from __future__ import annotations

import hashlib
import re
from functools import lru_cache
from importlib.resources import files
from itertools import pairwise
from typing import Annotated, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    TypeAdapter,
    field_validator,
    model_validator,
)

from edcraft_validator.domain_types import MAX_DISTRACTORS
from edcraft_validator.validation.distractor_pool import SURPLUS_RECIPES

_OUTCOME = re.compile(
    r"\b(?:outcome|skill|9478|h2 physics)\s*[:#]?\s*"
    r"(20|1[0-9]|[1-9])(?:\(\s*([a-t])\s*\)|([a-t])\b)",
    re.IGNORECASE,
)
_WORD = re.compile(r"[a-z]{3,}")
_COMMON = {
    "physics",
    "question",
    "make",
    "write",
    "about",
    "from",
    "with",
    "the",
    "and",
    "theory",
}


class StrictData(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)


class TraceSeries(StrictData):
    label: str = Field(min_length=1, max_length=60)
    points: list[tuple[float, float]] = Field(min_length=2, max_length=16)

    @model_validator(mode="after")
    def ordered(self) -> TraceSeries:
        if any(a[0] >= b[0] for a, b in pairwise(self.points)):
            raise ValueError("Graph coordinates must have strictly increasing x")
        return self


class TraceGraph(StrictData):
    kind: Literal["graph"]
    x: str = Field(min_length=1, max_length=80)
    y: str = Field(min_length=1, max_length=80)
    series: list[TraceSeries] = Field(min_length=1, max_length=5)


class Schematic(StrictData):
    kind: Literal["diagram"]
    nodes: list[tuple[str, float, float]] = Field(min_length=2, max_length=16)
    edges: list[tuple[str, str, str, bool]] = Field(min_length=1, max_length=24)
    components: dict[
        str,
        Literal[
            "resistor",
            "variable_resistor",
            "cell",
            "battery",
            "diode",
            "switch_open",
            "switch_closed",
            "lamp",
            "ammeter",
            "voltmeter",
            "capacitor",
            "thermistor",
            "ldr",
        ],
    ] = Field(default_factory=dict, max_length=12)

    @field_validator("components")
    @classmethod
    def canonical_indexes(cls, components: dict[str, str]) -> dict[str, str]:
        if any(not re.fullmatch(r"0|[1-9][0-9]?", index) for index in components):
            raise ValueError("Circuit components require nonnegative edge indexes")
        return components

    @model_validator(mode="after")
    def check_endpoints(self) -> Schematic:
        labels = {name for name, _, _ in self.nodes}
        if "" in labels or len(labels) != len(self.nodes):
            raise ValueError("Diagram node labels must be nonempty and distinct")
        if any(
            start not in labels or end not in labels or start == end
            for start, end, _, _ in self.edges
        ):
            raise ValueError("Diagram edges must link two distinct declared nodes")
        if any(
            int(index) >= len(self.edges) or self.edges[int(index)][3]
            for index in self.components
        ):
            raise ValueError("Circuit components must lie on declared non-arrow edges")
        return self


class ObservationTable(StrictData):
    kind: Literal["table"]
    headers: list[str] = Field(min_length=2, max_length=8)
    rows: list[list[str]] = Field(min_length=2, max_length=12)

    @model_validator(mode="after")
    def check_width(self) -> ObservationTable:
        if any(not header for header in self.headers) or any(
            len(row) != len(self.headers) for row in self.rows
        ):
            raise ValueError("The table must have headings and rectangular data")
        return self


Stimulus = Annotated[
    TraceGraph | Schematic | ObservationTable, Field(discriminator="kind")
]


class Proposition(StrictData):
    text: str = Field(min_length=4, max_length=440)
    valid: bool
    reason: str = Field(min_length=4, max_length=500)


class StatementCase(StrictData):
    context: str = Field(min_length=4, max_length=900)
    statements: list[Proposition] = Field(min_length=4, max_length=4)
    stimulus: Stimulus | None = None

    @model_validator(mode="after")
    def check_claims(self) -> StatementCase:
        if (
            len({statement.text.casefold().strip() for statement in self.statements})
            != 4
        ):
            raise ValueError("The four propositions must be distinct")
        if {statement.valid for statement in self.statements} != {True, False}:
            raise ValueError("The case needs both correct and incorrect propositions")
        return self


class ChoiceFamily(StrictData):
    skill: str = Field(min_length=4, max_length=600)
    cases: list[StatementCase] = Field(min_length=1, max_length=8)

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(self.model_dump_json().encode()).hexdigest()


class StatementBody(StrictData):
    target: Literal["h2_statement_set"] = "h2_statement_set"
    key: int = Field(ge=0, le=15)
    distractors: list[Annotated[int, Field(ge=0, le=15)]] = Field(
        min_length=1, max_length=MAX_DISTRACTORS
    )


class H2StatementSpec(StrictData):
    schema_version: Literal["physics-h2-statements/1.0"]
    skill_id: str = Field(pattern=r"^(?:[1-9]|1[0-9]|20)[a-t]$")
    body: StatementBody
    family_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class H2StatementProposal(StrictData):
    skill_id: str = Field(pattern=r"^(?:[1-9]|1[0-9]|20)[a-t]$")
    key: int = Field(ge=0, le=15)
    distractors: list[Annotated[int, Field(ge=0, le=15)]] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


@lru_cache(maxsize=1)
def catalogue() -> dict[str, ChoiceFamily]:
    path = files("edcraft_validator.domains.physics").joinpath(
        "h2_statement_cases.json"
    )
    return TypeAdapter(dict[str, ChoiceFamily]).validate_json(
        path.read_text(encoding="utf8")
    )


@lru_cache(maxsize=1)
def historical_statement_families() -> dict[tuple[str, str], ChoiceFamily]:
    path = files("edcraft_validator.domains.physics").joinpath(
        "h2_statement_family_history.json"
    )
    versions = TypeAdapter(dict[str, list[ChoiceFamily]]).validate_json(
        path.read_text(encoding="utf8")
    )
    return {
        (skill_id, family.fingerprint): family
        for skill_id, families in versions.items()
        for family in families
    }


def requested_skill(prompt: str) -> str | None:
    match = _OUTCOME.search(prompt)
    return f"{match[1]}{(match[2] or match[3]).lower()}" if match else None


def skill_hints(prompt: str) -> list[tuple[str, str]]:
    bank = catalogue()
    requested = requested_skill(prompt)
    if requested:
        return [(requested, bank[requested].skill)] if requested in bank else []
    words = set(_WORD.findall(prompt.casefold())) - _COMMON
    ranked = [
        (
            len(words.intersection(_WORD.findall(family.skill.casefold()))),
            key,
            family.skill,
        )
        for key, family in bank.items()
    ]
    return [
        (key, skill) for score, key, skill in sorted(ranked, reverse=True)[:8] if score
    ]
