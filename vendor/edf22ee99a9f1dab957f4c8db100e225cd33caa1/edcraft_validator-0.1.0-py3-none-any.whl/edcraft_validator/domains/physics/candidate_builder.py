"""Select fixed distractors for a model-authored Physics proposal."""

from __future__ import annotations

from fractions import Fraction

from edcraft_validator.domains.domain_contract import UnsupportedAuthoringRequest
from edcraft_validator.domains.domain_support import (
    build_template_id,
    content_sha256,
)
from edcraft_validator.domains.physics import correctness, h2
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsTemplateCandidate,
    PhysicsTemplateContent,
    PhysicsTemplateRequest,
    PhysicsTemplateSpec,
    UnsupportedPhysicsSpec,
)
from edcraft_validator.domains.physics.quantities import (
    QUANTITY_UNITS,
    TARGET_QUANTITIES,
    parse_decimal,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
    OptionValue,
    UnusableOption,
    sample_assignments,
    select_fixed_subset,
)

_UNSUPPORTED_REASONS = {
    "graph_or_diagram": (
        "The author could not match the requested graph or diagram "
        "to an available Physics question."
    ),
    "practical_investigation": (
        "This request needs hands-on work or original measurements. "
        "Physics authoring can assess practical methods and recorded observations "
        "with multiple-choice questions."
    ),
    "outside_catalogue": (
        "The author could not match this request "
        "to an available Physics multiple-choice question."
    ),
}


def build_physics_candidate(
    request: PhysicsTemplateRequest, proposal: PhysicsTemplateContent
) -> PhysicsTemplateCandidate:
    """Give all required checks and the saved template the same fixed recipes."""
    spec = proposal.item
    if isinstance(spec, UnsupportedPhysicsSpec):
        raise UnsupportedAuthoringRequest(_UNSUPPORTED_REASONS[spec.reason])
    required = request.num_distractors
    count = len(spec.body.distractors)
    if count != required + SURPLUS_RECIPES:
        raise DistractorPoolError(
            f"Author exactly {required + SURPLUS_RECIPES} candidate distractors "
            f"for {required} usable distractors. Received {count}."
        )

    if isinstance(spec, H2TemplateSpec):
        axes = {
            name: sorted(values, key=Fraction)
            for name, values in spec.parameters.items()
        }
    else:
        axes = {
            parameter.name: sorted(parameter.values, key=parse_decimal)
            for parameter in spec.parameters
        }
    assignments = sample_assignments(axes)
    chosen = select_fixed_subset(
        (_option_row(spec, assignment) for assignment in assignments),
        required,
        assignments=assignments,
    )
    item = spec.model_dump()
    authored = item["body"]["distractors"]
    item["body"]["distractors"] = [authored[index] for index in chosen]

    item_model = (
        H2TemplateSpec if isinstance(spec, H2TemplateSpec) else PhysicsTemplateSpec
    )
    return PhysicsTemplateCandidate(
        template_id=build_template_id("physics", request, proposal),
        difficulty=request.difficulty,
        item=item_model.model_validate(item),
        question_type="mcq",
    )


def _option_row(
    spec: PhysicsTemplateSpec | H2TemplateSpec, assignment: dict[str, str]
) -> tuple[OptionValue, list[OptionValue | UnusableOption]]:
    try:
        if isinstance(spec, H2TemplateSpec):
            return h2.option_row(spec, assignment)
        return _legacy_option_row(spec, assignment)
    except correctness.PhysicsCheckError as error:
        raise DistractorPoolError(
            f"{error.code} at {assignment!r}: {error.message}"
        ) from error


def _legacy_option_row(
    spec: PhysicsTemplateSpec, assignment: dict[str, str]
) -> tuple[OptionValue, list[OptionValue | UnusableOption]]:
    body = spec.body
    unit = QUANTITY_UNITS[TARGET_QUANTITIES[body.target]]
    decimals = body.display.decimals
    values = correctness.parameter_values(spec, assignment)

    def option(value: Fraction) -> OptionValue:
        return OptionValue(
            semantic=value,
            display=correctness.render_answer(
                value,
                unit=unit,
                decimals=decimals,
                form=body.answer_form,
                axis_positive=spec.axis.positive,
            ),
        )

    key = correctness.check_key(spec, assignment)

    options: list[OptionValue | UnusableOption] = []
    for distractor in body.distractors:
        try:
            value, _ = correctness.evaluate_recipe(distractor.recipe, spec, values)
        except correctness.PhysicsCheckError as exc:
            options.append(UnusableOption(f"{exc.code}: {exc.message}"))
            continue
        usable = correctness.is_exact(value, decimals) and (
            correctness.is_physical_distractor(
                value, form=body.answer_form, target=body.target
            )
        )
        options.append(
            option(value)
            if usable
            else UnusableOption(
                "inexact at the requested precision or invalid physical magnitude"
            )
        )
    return option(key), options


def template_sha256(candidate: PhysicsTemplateCandidate) -> str:
    """Identify the exact reusable content independently of any assessment."""
    return content_sha256(candidate)
