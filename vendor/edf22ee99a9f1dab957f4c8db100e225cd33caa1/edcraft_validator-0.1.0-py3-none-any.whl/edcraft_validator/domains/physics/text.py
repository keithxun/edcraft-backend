"""Stem rendering and stem checks for physics templates.

The application owns the question sentence and the assumptions. This module
renders the authored stem, appends those fixed parts, and reports stem defects
that would show an unchecked number, direction, motion state or a second
question to the learner.
"""

from __future__ import annotations

import re

from edcraft_validator.domains.physics.physics_schemas import PhysicsTemplateSpec
from edcraft_validator.domains.physics.quantities import DISPLAY_UNITS, OPPOSITE_SIDE

PLACEHOLDER_MISSING = "PLACEHOLDER_MISSING"
PLACEHOLDER_REPEATED = "PLACEHOLDER_REPEATED"
PLACEHOLDER_UNKNOWN = "PLACEHOLDER_UNKNOWN"
LITERAL_NUMBER_IN_TEXT = "LITERAL_NUMBER_IN_TEXT"
QUESTION_IN_STEM = "QUESTION_IN_STEM"
NUMBER_WORD_IN_TEXT = "NUMBER_WORD_IN_TEXT"
MOTION_STATE_IN_TEXT = "MOTION_STATE_IN_TEXT"
ANSWER_INSTRUCTION_IN_TEXT = "ANSWER_INSTRUCTION_IN_TEXT"
UNKNOWN_FORCE_NOT_DESCRIBED = "UNKNOWN_FORCE_NOT_DESCRIBED"
DIRECTION_WORD_IN_TEXT = "DIRECTION_WORD_IN_TEXT"
CHARACTER_NOT_ALLOWED = "CHARACTER_NOT_ALLOWED"
FORCE_LABEL_NOT_BESIDE_VALUE = "FORCE_LABEL_NOT_BESIDE_VALUE"
UNKNOWN_FORCE_GIVEN_A_VALUE = "UNKNOWN_FORCE_GIVEN_A_VALUE"

_PLACEHOLDER = re.compile(r"\{([A-Za-z][A-Za-z0-9_]{0,15})\}")
_WORD = re.compile(r"[a-z]+")
_TOKEN = re.compile(r"\{([A-Za-z][A-Za-z0-9_]{0,15})\}|([A-Za-z]+)")
# Plain letters, spaces and sentence punctuation. A hyphen may only join two
# letters, so no sign or other mark can attach to a rendered value.
_ALLOWED_STEM = re.compile(r"^(?:[A-Za-z ,.;:'()]|(?<=[A-Za-z])-(?=[A-Za-z]))*$")
# How many words before a force placeholder may carry that force's label.
_LABEL_WINDOW = 4

# The stem is free prose, so these lists stop the commonest unchecked claims:
# numbers in words, a motion state the checks never see, and answer instructions
# that could contradict the application's question sentence. They are deny-lists,
# so prose can still carry claims they miss.
_NUMBER_WORDS = frozenset(
    {
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
        "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
        "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "thirty",
        "forty", "fifty", "sixty", "seventy", "eighty", "ninety", "hundred",
        "thousand", "million", "half", "halves", "quarter", "third", "double",
        "twice", "triple", "thrice", "dozen", "single", "pair",
    }
)  # fmt: skip
_MOTION_STATE_PHRASES = (
    "at rest",
    "stationary",
    "constant velocity",
    "constant speed",
    "uniform velocity",
    "uniform speed",
    "steady speed",
    "steady velocity",
    "equilibrium",
    "not moving",
    "does not move",
    "balanced",
    "unbalanced",
    "decelerates",
    "decelerating",
    "slows",
    "slowing",
    "speeds up",
    "motionless",
    "immobile",
    "stopped",
    "stops",
    "halts",
    "coasts",
    "drifts",
    "same speed",
    "same velocity",
    "unchanged speed",
    "unchanged velocity",
)
_DIRECTION_WORDS = frozenset(
    {
        "left",
        "right",
        "leftward",
        "leftwards",
        "rightward",
        "rightwards",
        "east",
        "west",
    }
)
_ANSWER_INSTRUCTION_WORDS = frozenset(
    {
        "answer", "report", "give", "calculate", "find", "determine", "compute",
        "magnitude", "decimal", "decimals", "rounded", "rounding", "significant",
        "positive", "negative", "sign", "signed", "unsigned", "absolute",
    }
)  # fmt: skip


def placeholders(text: str) -> list[str]:
    """Return every ``{name}`` placeholder in order, including repeats."""
    return [match.group(1) for match in _PLACEHOLDER.finditer(text)]


def render_stem(spec: PhysicsTemplateSpec, combination: dict[str, str]) -> str:
    """Render the authored stem with each parameter's value and direction."""
    rendered = _rendered_parameters(spec, combination)

    def replace(match: re.Match[str]) -> str:
        name = match.group(1)
        return rendered.get(name, match.group(0))

    return _PLACEHOLDER.sub(replace, spec.body.text)


def assumptions(spec: PhysicsTemplateSpec) -> list[str]:
    """The fixed assumptions the application adds to every question."""
    body = spec.body
    items = [
        f"Take {spec.axis.positive} as the positive direction.",
        "All forces act along one horizontal line.",
    ]
    if body.net_force is not None:
        items.append(
            "The net force given is the resultant of all horizontal forces on "
            "the object."
        )
    elif body.unknown_force is not None:
        unknown = body.unknown_force
        side = _direction(unknown.direction, spec.axis.positive)
        items.append(f"The {unknown.label} force acts to the {side}.")
        items.append(
            f"The forces described, including the {unknown.label} force, are the "
            "only horizontal forces acting on the object."
        )
    elif body.forces is not None:
        items.append(
            "The forces described are the only horizontal forces acting on the object."
        )
    return items


def question_sentence(spec: PhysicsTemplateSpec) -> str:
    """The fixed question the application adds after the stem."""
    body = spec.body
    target = body.target
    if target == "mass":
        return "What is the mass of the object?"
    if target == "missing_force":
        label = body.unknown_force.label if body.unknown_force else "unknown"
        return f"What is the magnitude of the {label} force?"
    noun = "acceleration" if target == "acceleration" else "net force"
    if body.answer_form == "magnitude_and_direction":
        return f"What is the magnitude and direction of the object's {noun}?"
    return (
        f"What is the object's {noun} along the positive direction? A negative "
        "value means it points the other way."
    )


def render_question(spec: PhysicsTemplateSpec, combination: dict[str, str]) -> str:
    """Stem, assumptions and question sentence as one learner-facing string."""
    parts = [render_stem(spec, combination)]
    parts.extend(assumptions(spec))
    parts.append(question_sentence(spec))
    return " ".join(parts)


def text_findings(spec: PhysicsTemplateSpec) -> list[tuple[str, str]]:
    """Report stem defects. An empty list means the stem passes."""
    text = spec.body.text
    declared = [parameter.name for parameter in spec.parameters]
    found = placeholders(text)
    bare = _PLACEHOLDER.sub("", text)
    findings: list[tuple[str, str]] = []

    for name in declared:
        count = found.count(name)
        if count == 0:
            findings.append(
                (
                    PLACEHOLDER_MISSING,
                    f"the stem never shows the parameter {{{name}}}",
                )
            )
        elif count > 1:
            findings.append(
                (
                    PLACEHOLDER_REPEATED,
                    f"the stem shows the parameter {{{name}}} {count} times",
                )
            )

    for name in dict.fromkeys(found):
        if name not in declared:
            findings.append(
                (
                    PLACEHOLDER_UNKNOWN,
                    f"the stem uses {{{name}}}, which is not a declared parameter",
                )
            )

    if "{" in bare or "}" in bare:
        findings.append(
            (
                PLACEHOLDER_UNKNOWN,
                "the stem contains a brace that is not a whole {name} placeholder",
            )
        )

    if any(character.isdigit() for character in bare):
        findings.append(
            (
                LITERAL_NUMBER_IN_TEXT,
                "the stem shows a number outside a placeholder; every number must "
                "come from a declared parameter",
            )
        )

    if "?" in bare:
        findings.append(
            (
                QUESTION_IN_STEM,
                "the stem contains a question mark; the application adds the "
                "question sentence",
            )
        )

    words = _words(bare)
    number_words = sorted(words & _NUMBER_WORDS)
    if number_words:
        findings.append(
            (
                NUMBER_WORD_IN_TEXT,
                "the stem writes a number in words ("
                + ", ".join(number_words)
                + "); every number must come from a declared parameter",
            )
        )

    phrase_text = " ".join(_WORD.findall(bare.lower().replace("-", " ")))
    states = [
        phrase
        for phrase in _MOTION_STATE_PHRASES
        if f" {phrase} " in f" {phrase_text} "
    ]
    if states:
        findings.append(
            (
                MOTION_STATE_IN_TEXT,
                "the stem states a motion that is not checked ("
                + ", ".join(states)
                + "); describe the object and its forces only",
            )
        )

    instructions = sorted(words & _ANSWER_INSTRUCTION_WORDS)
    if instructions:
        findings.append(
            (
                ANSWER_INSTRUCTION_IN_TEXT,
                "the stem instructs how to answer ("
                + ", ".join(instructions)
                + "); the application writes the question and the answer form",
            )
        )

    directions = sorted(words & _DIRECTION_WORDS)
    if directions:
        findings.append(
            (
                DIRECTION_WORD_IN_TEXT,
                "the stem names a direction outside a placeholder ("
                + ", ".join(directions)
                + "); directions come from the declared roles",
            )
        )

    if not _ALLOWED_STEM.fullmatch(_PLACEHOLDER.sub(" ", text)):
        findings.append(
            (
                CHARACTER_NOT_ALLOWED,
                "the stem may use only letters, spaces and the punctuation , . ; : ' "
                "( ), with a hyphen only between two letters",
            )
        )

    findings.extend(_label_findings(spec, phrase_text))
    return findings


def _label_findings(
    spec: PhysicsTemplateSpec, phrase_text: str
) -> list[tuple[str, str]]:
    """Tie each known force's label to its value and keep the unknown one valueless."""
    body = spec.body
    tokens = _tokens(body.text)
    findings: list[tuple[str, str]] = []

    for force in body.forces or []:
        if not _label_before(tokens, force.param, _label_words(force.label)):
            findings.append(
                (
                    FORCE_LABEL_NOT_BESIDE_VALUE,
                    f"write the {force.label} force's label just before its value, "
                    f"for example '{force.label} of {{{force.param}}}'",
                )
            )

    unknown = body.unknown_force
    if unknown is None:
        return findings
    label = _label_words(unknown.label)
    if f" {' '.join(label)} " not in f" {phrase_text} ":
        findings.append(
            (
                UNKNOWN_FORCE_NOT_DESCRIBED,
                f"the stem never names the {unknown.label} force that the question "
                "asks about",
            )
        )
    valued = [force.param for force in body.forces or []]
    if any(_label_before(tokens, name, label) for name in valued):
        findings.append(
            (
                UNKNOWN_FORCE_GIVEN_A_VALUE,
                f"the {unknown.label} force is the unknown, so its label must not "
                "sit just before a given value",
            )
        )
    return findings


def _tokens(text: str) -> list[str]:
    """Lower-case words and ``{name}`` placeholders in reading order."""
    tokens: list[str] = []
    for match in _TOKEN.finditer(text.replace("-", " ")):
        name, word = match.group(1), match.group(2)
        tokens.append(f"{{{name}}}" if name else word.lower())
    return tokens


def _label_words(label: str) -> list[str]:
    return label.replace("-", " ").split()


def _label_before(tokens: list[str], param: str, label: list[str]) -> bool:
    """Whether the label's words appear among the few words before ``{param}``."""
    placeholder = f"{{{param}}}"
    for index, token in enumerate(tokens):
        if token != placeholder:
            continue
        window = tokens[max(0, index - _LABEL_WINDOW - len(label) + 1) : index]
        for start in range(len(window) - len(label) + 1):
            words = window[start : start + len(label)]
            if all(
                _same_word(word, part) for word, part in zip(words, label, strict=True)
            ):
                return True
    return False


def _same_word(word: str, label_word: str) -> bool:
    """Accept a short inflection, so 'pushed' or 'pulls' match 'push' and 'pull'."""
    return word.startswith(label_word) and len(word) - len(label_word) <= 2


def _words(text: str) -> set[str]:
    return set(_WORD.findall(text.lower()))


def _rendered_parameters(
    spec: PhysicsTemplateSpec, combination: dict[str, str]
) -> dict[str, str]:
    body = spec.body
    rendered: dict[str, str] = {}
    if body.mass is not None:
        rendered[body.mass] = f"{_value(combination, body.mass)} kg"
    if body.net_force is not None:
        rendered[body.net_force.param] = _force_text(
            combination,
            body.net_force.param,
            body.net_force.direction,
            spec.axis.positive,
        )
    for force in body.forces or []:
        rendered[force.param] = _force_text(
            combination, force.param, force.direction, spec.axis.positive
        )
    if body.acceleration is not None:
        rendered[body.acceleration.param] = (
            f"{_value(combination, body.acceleration.param)} "
            f"{DISPLAY_UNITS['m/s^2']} to the "
            f"{_direction(body.acceleration.direction, spec.axis.positive)}"
        )
    return rendered


def _force_text(
    combination: dict[str, str],
    name: str,
    direction: str,
    axis_positive: str,
) -> str:
    return (
        f"{_value(combination, name)} {DISPLAY_UNITS['N']} to the "
        f"{_direction(direction, axis_positive)}"
    )


def _direction(direction: str, axis_positive: str) -> str:
    if direction == "positive":
        return axis_positive
    return OPPOSITE_SIDE[axis_positive]


def _value(combination: dict[str, str], name: str) -> str:
    if name not in combination:
        raise ValueError(f"combination is missing a value for {name!r}")
    return combination[name]
