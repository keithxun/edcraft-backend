"""A compact wire format for explicit H2 requests.

The wire format accepts a small arithmetic syntax. It compiles to the normal
typed recipes before candidate selection. This module never executes expressions.
"""

from __future__ import annotations

import ast
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from edcraft_validator.domain_types import MAX_DISTRACTORS
from edcraft_validator.domains.physics.h2_statement_data import (
    H2StatementProposal,
    requested_skill,
)
from edcraft_validator.domains.physics.physics_schemas import (
    PhysicsTemplateContent,
    RecipeOp,
)
from edcraft_validator.validation.distractor_pool import (
    SURPLUS_RECIPES,
    DistractorPoolError,
)

_H2_REQUEST = re.compile(r"\b(?:h2|9478)\b", re.IGNORECASE)
_ARITHMETIC = re.compile(r"[A-Za-z0-9_.()+*/ \t-]+", re.ASCII)
_OPERATORS: dict[type[ast.operator], RecipeOp] = {
    ast.Add: "add",
    ast.Sub: "sub",
    ast.Mult: "mul",
    ast.Div: "div",
}


class CompactWrongChoice(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    expression: str = Field(min_length=1, max_length=180)
    explanation: str = Field(min_length=1, max_length=200)


class H2CompactProposal(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    family_id: str = Field(pattern=r"^[a-z][a-z0-9_]{0,39}$")
    answer: str = Field(min_length=1, max_length=180)
    distractors: list[CompactWrongChoice] = Field(
        min_length=1, max_length=MAX_DISTRACTORS + SURPLUS_RECIPES
    )


class H2CompactUnsupported(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    unsupported: Literal[
        "graph_or_diagram", "practical_investigation", "outside_catalogue"
    ]


CompactH2Response = H2CompactProposal | H2CompactUnsupported | H2StatementProposal


def is_explicit_h2_request(prompt: str) -> bool:
    return bool(_H2_REQUEST.search(prompt) or requested_skill(prompt))


def _recipe(source: str) -> dict[str, object]:
    source = source.strip()
    if _ARITHMETIC.fullmatch(source) is None:
        raise ValueError(
            "Recipes must use only parameters, decimal numbers and arithmetic"
        )
    # The decay equation uses this conventional symbol, which Python reserves.
    source = re.sub(r"\blambda\b", "decay_constant", source)
    parsed = ast.parse(source, mode="eval")

    def convert(node: ast.expr) -> dict[str, object]:
        if isinstance(node, ast.Name):
            return {"param": "lambda" if node.id == "decay_constant" else node.id}
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return {"const": ast.get_source_segment(source, node)}
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return {"op": "neg", "args": [convert(node.operand)]}
        if isinstance(node, ast.BinOp) and type(node.op) in _OPERATORS:
            return {
                "op": _OPERATORS[type(node.op)],
                "args": [convert(node.left), convert(node.right)],
            }
        raise ValueError("Only +, -, *, / and parentheses are allowed")

    return convert(parsed.body)


def normalise_h2_proposal(
    response: H2CompactProposal | H2CompactUnsupported,
) -> PhysicsTemplateContent:
    if isinstance(response, H2CompactUnsupported):
        return PhysicsTemplateContent.model_validate(
            {
                "item": {
                    "schema_version": "physics-unsupported/1.0",
                    "reason": response.unsupported,
                }
            }
        )
    try:
        return PhysicsTemplateContent.model_validate(
            {
                "item": {
                    "schema_version": "physics-h2/1.0",
                    "family_id": response.family_id,
                    "body": {
                        "answer_recipe": _recipe(response.answer),
                        "distractors": [
                            {
                                "recipe": _recipe(choice.expression),
                                "misconception": "other",
                                "explanation": choice.explanation,
                            }
                            for choice in response.distractors
                        ],
                    },
                }
            }
        )
    except (SyntaxError, ValidationError, ValueError) as error:
        raise DistractorPoolError(f"Invalid H2 proposal: {error}") from error
