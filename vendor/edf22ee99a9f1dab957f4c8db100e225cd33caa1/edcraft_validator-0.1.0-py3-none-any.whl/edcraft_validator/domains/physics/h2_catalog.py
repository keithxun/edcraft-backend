"""Versioned numeric families for the revised Singapore H2 Physics syllabus."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from dataclasses import asdict, dataclass
from fractions import Fraction
from types import MappingProxyType
from typing import Literal

H2Unit = Literal[
    "%",
    "N",
    "m/s²",
    "J",
    "m",
    "m/s",
    "N s",
    "N/kg",
    "mm",
    "kPa",
    "μN",
    "W",
    "V",
    "eV",
    "Bq",
    "°",
    "K",
]


@dataclass(frozen=True)
class AxisValues:
    name: str
    unit: str
    values: tuple[str, ...]


@dataclass(frozen=True)
class Family:
    topic: int
    outcomes: str
    title: str
    stem: str
    unit: H2Unit
    rule: str
    axes: tuple[AxisValues, ...]
    solve: Callable[..., Fraction]
    decimals: int = 3
    signed: bool = False

    @property
    def default_axes(self) -> dict[str, list[str]]:
        return {axis.name: list(axis.values) for axis in self.axes}

    @property
    def fingerprint(self) -> str:
        data = {
            "topic": self.topic,
            "outcomes": self.outcomes,
            "title": self.title,
            "stem": self.stem,
            "unit": self.unit,
            "rule": self.rule,
            "axes": [asdict(axis) for axis in self.axes],
            "decimals": self.decimals,
            "signed": self.signed,
        }
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def axis(name: str, unit: str, values: str) -> AxisValues:
    return AxisValues(name, unit, tuple(values.split()))


FAMILIES = MappingProxyType(
    {
        "density_uncertainty": Family(
            1,
            "(g)",
            "Percentage uncertainty in density",
            "A specimen has mass {m} g with absolute uncertainty {dm} g and "
            "volume {V} cm³ with absolute uncertainty {dV} cm³. Using the "
            "sum of fractional uncertainties, what is the percentage "
            "uncertainty in its density?",
            "%",
            "100 × (dm/m + dV/V)",
            (
                axis("m", "g", "40 80 100"),
                axis("dm", "g", "1 2"),
                axis("V", "cm³", "20 40 50"),
                axis("dV", "cm³", "1 2"),
            ),
            lambda m, dm, V, dV: 100 * (dm / m + dV / V),
        ),
        "balancing_force": Family(
            2,
            "(d), (g)–(h)",
            "Balancing force on a lever",
            "A light horizontal lever is pivoted. A downward load of {load} N "
            "acts {d_load} m from the pivot. A downward effort acts on the "
            "opposite side, {d_effort} m from the pivot. What effort keeps "
            "the lever in rotational equilibrium?",
            "N",
            "load × d_load / d_effort",
            (
                axis("load", "N", "15 30 45"),
                axis("d_load", "m", "0.2 0.4 0.6"),
                axis("d_effort", "m", "0.5 1"),
            ),
            lambda load, d_load, d_effort: load * d_load / d_effort,
        ),
        "spring_force": Family(
            2,
            "(c)",
            "Force extending a spring",
            "A spring of force constant {k} N/m is extended by {x} m within "
            "its proportional limit. What is the magnitude of the force "
            "holding it at that extension?",
            "N",
            "k × x",
            (axis("k", "N/m", "20 40 80"), axis("x", "m", "0.05 0.15 0.25")),
            lambda k, x: k * x,
        ),
        "average_net_force": Family(
            3,
            "(g)–(i)",
            "Average force from momentum change",
            "A trolley of mass {m} kg changes its velocity from {u} m/s to "
            "{v} m/s over {t} s on a straight horizontal track. Positive values "
            "denote motion to the right. What is its signed average resultant "
            "horizontal force?",
            "N",
            "m × (v − u) / t",
            (
                axis("m", "kg", "2 3 5"),
                axis("u", "m/s", "1 2 4"),
                axis("v", "m/s", "-4 -2 6"),
                axis("t", "s", "0.5 1 2"),
            ),
            lambda m, u, v, t: m * (v - u) / t,
            signed=True,
        ),
        "constant_acceleration": Family(
            3,
            "(a), (d)–(e)",
            "Constant linear acceleration",
            "A glider’s speed along a straight track increases uniformly "
            "from {u} m/s to {v} m/s in {t} s without reversing direction. "
            "What is the magnitude of its acceleration?",
            "m/s²",
            "(v − u) / t",
            (
                axis("u", "m/s", "1 2 3"),
                axis("v", "m/s", "5 8 9"),
                axis("t", "s", "0.5 1 2"),
            ),
            lambda u, v, t: (v - u) / t,
        ),
        "kinetic_energy_change": Family(
            4,
            "(b), (e)",
            "Change in kinetic energy",
            "A cart of mass {m} kg changes its speed from {u} m/s to {v} m/s. "
            "What is the increase in its kinetic energy?",
            "J",
            "m × (v² − u²) / 2",
            (
                axis("m", "kg", "2 3 4"),
                axis("u", "m/s", "2 3 5"),
                axis("v", "m/s", "6 8 10"),
            ),
            lambda m, u, v: m * (v * v - u * u) / 2,
        ),
        "horizontal_range": Family(
            5,
            "(b)",
            "Horizontal range from launch speed",
            "A ball rolls with constant horizontal speed. It takes {t_track} s "
            "to travel the last {d} m of a horizontal track. It then leaves "
            "the track with that speed and is airborne for {t_air} s. Ignore air "
            "resistance. How far does it travel horizontally while airborne?",
            "m",
            "d × t_air / t_track",
            (
                axis("d", "m", "0.4 0.8 1.2"),
                axis("t_track", "s", "0.5 1"),
                axis("t_air", "s", "0.25 0.5 0.75"),
            ),
            lambda d, t_track, t_air: d * t_air / t_track,
        ),
        "sticking_velocity": Family(
            6,
            "(b)–(c)",
            "One-dimensional sticking collision",
            "On a straight horizontal track, an approaching glider of mass "
            "{m1} kg has velocity {u1} m/s. It collides with another glider "
            "of mass {m2} kg moving at {u2} m/s. Positive means to the right. "
            "The first approaches from the left and the gliders stick together. "
            "Horizontal external impulse is negligible. What is their "
            "signed velocity just after collision?",
            "m/s",
            "(m1 × u1 + m2 × u2) / (m1 + m2)",
            (
                axis("m1", "kg", "1 3 5"),
                axis("m2", "kg", "1 3"),
                axis("u1", "m/s", "0.6 1.2 2.4"),
                axis("u2", "m/s", "-1.2 -0.6 0"),
            ),
            lambda m1, m2, u1, u2: (m1 * u1 + m2 * u2) / (m1 + m2),
            signed=True,
        ),
        "net_impulse": Family(
            6,
            "(a); 3(g)",
            "Net impulse in a rebound",
            "A trolley of mass {m} kg on a straight horizontal track rebounds "
            "from a bumper. Its velocity changes from {u} m/s to {v} m/s. "
            "Positive means to the right. What is the signed resultant "
            "horizontal impulse on the trolley?",
            "N s",
            "m × (v − u)",
            (
                axis("m", "kg", "2 3 5"),
                axis("u", "m/s", "1 2 4"),
                axis("v", "m/s", "-4 -2 -1"),
            ),
            lambda m, u, v: m * (v - u),
            signed=True,
        ),
        "centripetal_acceleration": Family(
            7,
            "(c)–(d)",
            "Centripetal acceleration",
            "A puck travels at a constant speed of {v} m/s around a "
            "horizontal circle of radius {r} m. What is the magnitude "
            "of its acceleration?",
            "m/s²",
            "v² / r",
            (axis("v", "m/s", "2 4 6"), axis("r", "m", "0.25 0.5 1")),
            lambda v, r: v * v / r,
        ),
        "radial_gravity": Family(
            8,
            "(a)–(b)",
            "Inverse-square gravitational field",
            "A spherical planet has surface gravitational field strength "
            "{g} N/kg. Ignore all other bodies and take the planet as "
            "spherically symmetric. What is the field strength at a point "
            "{n} times the planet’s radius from its centre?",
            "N/kg",
            "g / n²",
            (axis("g", "N/kg", "9 18 27"), axis("n", "ratio", "2 3")),
            lambda g, n: g / (n * n),
        ),
        "shm_acceleration": Family(
            9,
            "(a)–(c)",
            "Acceleration in simple harmonic motion",
            "A horizontal oscillator executes simple harmonic motion at "
            "angular frequency {omega} rad/s. "
            "At an instant when its signed displacement from equilibrium is "
            "{x} m, what is its signed acceleration in the same convention?",
            "m/s²",
            "−omega² × x",
            (axis("omega", "rad/s", "2 4 6"), axis("x", "m", "-0.15 0.05 0.2")),
            lambda omega, x: -omega * omega * x,
            signed=True,
        ),
        "wave_speed": Family(
            10,
            "(b)–(c)",
            "Progressive wave speed",
            "A progressive wave has frequency {f} Hz and wavelength {w} m. "
            "What is its propagation speed?",
            "m/s",
            "f × w",
            (axis("f", "Hz", "2 3 5"), axis("w", "m", "0.2 0.4 0.8")),
            lambda f, w: f * w,
        ),
        "wave_phase_degrees": Family(
            10,
            "(c)",
            "Phase difference from path separation",
            "Two observation points on the same direction of travel of a progressive "
            "sound wave are separated by {d} m. The wavelength is {w} m. "
            "What phase difference in degrees corresponds to this separation?",
            "°",
            "360 × d / w",
            (
                axis("d", "m", "0.1 0.2 0.3"),
                axis("w", "m", "0.4 0.8 1.2"),
            ),
            lambda d, w: 360 * d / w,
        ),
        "fringe_spacing": Family(
            11,
            "Double-slit interference",
            "Double-slit fringe spacing",
            "Monochromatic light of wavelength {w} nm illuminates two narrow "
            "slits separated by {d} mm. A screen is {D} m from the slits. "
            "Using the small-angle approximation, what is the fringe spacing "
            "in mm?",
            "mm",
            "w × D / (1000 × d)",
            (
                axis("w", "nm", "400 600 800"),
                axis("D", "m", "1 2 3"),
                axis("d", "mm", "0.25 0.5 1"),
            ),
            lambda w, D, d: w * D / (1000 * d),
        ),
        "gas_final_pressure": Family(
            12,
            "Ideal gas equation",
            "Pressure after changing gas state",
            "A fixed quantity of ideal gas starts at pressure {p} kPa, volume "
            "{V1} L and temperature {T1} K. Its final volume is {V2} L "
            "and its final temperature is {T2} K. What is its final pressure?",
            "kPa",
            "p × V1 × T2 / (V2 × T1)",
            (
                axis("p", "kPa", "80 100 120"),
                axis("V1", "L", "1.2 2.4"),
                axis("V2", "L", "0.4 0.8 1.6"),
                axis("T1", "K", "250 300"),
                axis("T2", "K", "320 360"),
            ),
            lambda p, V1, V2, T1, T2: p * V1 * T2 / (V2 * T1),
        ),
        "gas_final_temperature": Family(
            12,
            "Ideal gas equation",
            "Thermodynamic temperature after changing gas state",
            "A sealed fixed amount of ideal gas starts at pressure {p1} kPa, "
            "volume {V1} L and temperature {T1} K. Its final pressure is {p2} kPa "
            "and its final volume is {V2} L. What is its final temperature?",
            "K",
            "T1 × p2 × V2 / (p1 × V1)",
            (
                axis("p1", "kPa", "80 160"),
                axis("V1", "L", "1 2"),
                axis("T1", "K", "240 320"),
                axis("p2", "kPa", "100 200"),
                axis("V2", "L", "0.625 1.25"),
            ),
            lambda p1, V1, T1, p2, V2: T1 * p2 * V2 / (p1 * V1),
        ),
        "internal_energy_change": Family(
            13,
            "First law",
            "Internal energy change of a gas",
            "A gas is supplied with {Q} J of thermal energy and does {W} J of "
            "work on its surroundings. Its bulk kinetic and potential "
            "energies do not change. What is its signed change in internal energy?",
            "J",
            "Q − W",
            (axis("Q", "J", "20 60 100"), axis("W", "J", "10 40 80")),
            lambda Q, W: Q - W,
            signed=True,
        ),
        "electric_plate_force": Family(
            14,
            "Uniform electric fields",
            "Electric force between plates",
            "Two parallel plates are {d} m apart and have potential difference "
            "{V} V. A small positive test charge of {q} μC is in the uniform "
            "field away from the edges. What is the magnitude of the electric "
            "force on it in μN?",
            "μN",
            "q × V / d",
            (
                axis("q", "μC", "0.2 0.6 1.2"),
                axis("V", "V", "12 24 36"),
                axis("d", "m", "0.1 0.2 0.4"),
            ),
            lambda q, V, d: q * V / d,
        ),
        "resistor_power": Family(
            15,
            "(d)",
            "Power dissipated in a resistor",
            "A resistor of resistance {R} Ω carries a steady current of "
            "{I} A. What power does it dissipate?",
            "W",
            "I² × R",
            (axis("I", "A", "0.2 0.4 0.6"), axis("R", "Ω", "10 20 25")),
            lambda current, R: current * current * R,
        ),
        "sinusoidal_resistor_power": Family(
            15,
            "(d), (f), (h)–(i)",
            "Mean power from peak sinusoidal current",
            "A resistor of resistance {R} Ω carries a sinusoidal alternating "
            "current with peak value {peak} A. What is the mean power "
            "dissipated in the resistor?",
            "W",
            "peak² × R / 2",
            (axis("peak", "A", "0.4 0.8 1.2"), axis("R", "Ω", "10 20 25")),
            lambda peak, resistance: peak * peak * resistance / 2,
        ),
        "terminal_voltage": Family(
            16,
            "Internal resistance",
            "Loaded cell terminal voltage",
            "A source has electromotive force {E} V and internal resistance "
            "{r} Ω. A resistor of resistance {R} Ω is connected across the "
            "source. What is the potential difference across the resistor?",
            "V",
            "E × R / (R + r)",
            (
                axis("E", "V", "8 12 16"),
                axis("R", "Ω", "1 3 7"),
                axis("r", "Ω", "1"),
            ),
            lambda E, R, r: E * R / (R + r),
        ),
        "magnetic_wire_force": Family(
            17,
            "Current-carrying conductor",
            "Magnetic force on a wire",
            "A straight wire has {L} m of its length in a uniform magnetic "
            "field of flux density {B} T. It carries current {I} A and is "
            "perpendicular to the field. What is the magnetic force magnitude "
            "on the part of the wire in the field?",
            "N",
            "B × I × L",
            (
                axis("B", "T", "0.2 0.3 0.4"),
                axis("I", "A", "1 2 3"),
                axis("L", "m", "0.25 0.5 0.75"),
            ),
            lambda B, current, L: B * current * L,
        ),
        "average_induced_emf": Family(
            18,
            "Faraday’s law",
            "Average induced electromotive force",
            "A coil has {N} identical turns. The magnetic flux through "
            "each turn increases from {initial} Wb to {final} Wb in {t} s. "
            "What is the magnitude of the average induced emf across the coil?",
            "V",
            "N × (final − initial) / t",
            (
                axis("N", "turns", "40 80 120"),
                axis("initial", "Wb", "0.001 0.002"),
                axis("final", "Wb", "0.004 0.006 0.008"),
                axis("t", "s", "0.1 0.2 0.4"),
            ),
            lambda N, initial, final, t: N * (final - initial) / t,
        ),
        "photoelectron_energy": Family(
            19,
            "Related photoelectric context",
            "Maximum photoelectron energy",
            "Photons of energy {photon} eV illuminate a clean metal surface "
            "whose work function is {work} eV. What is the maximum "
            "kinetic energy of the emitted photoelectrons?",
            "eV",
            "photon − work",
            (axis("photon", "eV", "4.5 6 8"), axis("work", "eV", "1.8 2.3 3.1")),
            lambda photon, work: photon - work,
        ),
        "transition_photon_energy": Family(
            19,
            "(k)–(m)",
            "Photon energy from an atomic transition",
            "An electron in an isolated atom drops from an energy level of "
            "{upper} eV to an energy level of {lower} eV. The atom emits one "
            "photon. What is the energy of the photon?",
            "eV",
            "upper − lower",
            (
                axis("upper", "eV", "-3.1 -2.3 -1.8"),
                axis("lower", "eV", "-8 -6 -4.5"),
            ),
            lambda upper, lower: upper - lower,
        ),
        "radioactive_activity": Family(
            20,
            "(h)",
            "Activity from decay constant",
            "A sealed classroom reference sample contains {N} undecayed "
            "radioactive nuclei with decay constant {lambda} s⁻¹. What is "
            "its activity at this instant?",
            "Bq",
            "lambda × N",
            (
                axis("lambda", "s⁻¹", "0.002 0.004 0.008"),
                axis("N", "1", "1250 2500 5000"),
            ),
            lambda decay, N: decay * N,
        ),
    }
)
