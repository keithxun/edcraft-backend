"""Physics plugin for the domain-neutral NL-fidelity gate.

The plugin owns the blind parse-back prompt, the deterministic text anchors and a
conservative comparison between one rendered question and the structured
template that was supposed to produce it. A reading that cannot be compared is
``inconclusive``, and it is never silently approved.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from fractions import Fraction
from typing import Any, Literal, cast

from pydantic import BaseModel, ConfigDict, Field

from edcraft_validator.application.fidelity.contracts import (
    CanonicalArtifact,
    EvidenceStrength,
    FidelityVerdict,
)
from edcraft_validator.domains.physics import text as physics_text
from edcraft_validator.domains.physics.physics_schemas import (
    DirectedParameter,
    ForceTerm,
    PhysicsTemplateSpec,
)
from edcraft_validator.domains.physics.quantities import OPPOSITE_SIDE, parse_decimal
from edcraft_validator.llm.llm_contracts import StructuredGenerationRequest

PROMPT_VERSION = "physics-fidelity/2"
SCHEMA_NAME = "physics_reconstruction"

Side = Literal["left", "right", "unspecified"]
_Target = Literal["acceleration", "net_force", "mass", "missing_force", "other"]
_AnswerForm = Literal["magnitude_and_direction", "signed_component", "magnitude"]

_SYSTEM_PROMPT = """\
You are a blind parser for a physics problem. Restate exactly what the supplied
text says about one object on a horizontal line. You have not seen the source
template, its answer, its distractors or its topic; do not try to infer them.

Rules:
- Do not solve the problem and do not add an answer.
- Parse only what the text states. Do not invent quantities, forces, directions
  or objects.
- Report the positive direction the text declares. `unspecified` means the text
  does not say.
- `mass_kg` is the object's mass in kilograms as a plain decimal string. Leave
  it null when the text gives no mass.
- Report `acceleration` only when the text states the object's acceleration,
  with its magnitude as a plain decimal string and its side. Leave it null
  otherwise.
- Report `net_force` only when the text states a resultant or net force. Leave it
  null when no resultant is stated, including when the question asks for it.
- List every force the text names in `forces`. Give each force's magnitude in
  newtons as a plain decimal string, or null when the text gives no value, as for
  a force the question asks about. Give its side as "left", "right" or
  "unspecified", and a short label naming the force.
- `target` is what the question asks for: acceleration, net_force, mass,
  missing_force or other. For missing_force, put the label of the force the
  question asks about in `unknown_force_label`; otherwise leave it null.
- `answer_form` is the answer form the question asks for:
  magnitude_and_direction, signed_component or magnitude.
- List in `motion_claims` only statements about the object's velocity: at rest,
  stationary, constant velocity or speed, speeding up or slowing down. Moving,
  sliding or being pushed along a surface is not a motion claim, and neither is
  the acceleration the text gives (report that in `acceleration`). Leave the
  list empty when the text makes no such statement.
- List in `additional_rules` every other stated rule or extra body, for example a
  second object, a payload, friction coefficients, gravity or an incline. Leave
  it empty when there are none.
- These standard sentences appear in every question and are NOT additional
  rules: which direction is taken as positive, that all forces act along one
  horizontal line, that the forces described (including any unknown force) are
  the only horizontal forces, that a given net force is the resultant of all
  horizontal forces, and the side an unknown force acts on. Use them to fill
  the fields above, and never list them, or a paraphrase of them, in
  `additional_rules`.
- If the text supports more than one reading, set ambiguous=true and give at
  least one concrete ambiguity. Do not guess a single reading.
"""


class DirectedReading(BaseModel):
    """One directed quantity as the blind parser read it."""

    model_config = ConfigDict(extra="forbid", strict=True)

    magnitude: str | None = None
    side: Side = "unspecified"


class ForceReading(BaseModel):
    """One force the text names, with no assumed link to the template's labels."""

    model_config = ConfigDict(extra="forbid", strict=True)

    label: str = Field(min_length=1)
    magnitude: str | None = None
    side: Side = "unspecified"


class PhysicsReconstruction(BaseModel):
    """The blind parser's reading of one rendered physics question."""

    model_config = ConfigDict(extra="forbid", strict=True)

    target: _Target
    unknown_force_label: str | None = None
    positive_direction: Side = "unspecified"
    mass_kg: str | None = None
    acceleration: DirectedReading | None = None
    net_force: DirectedReading | None = None
    forces: list[ForceReading] = Field(default_factory=list)
    answer_form: _AnswerForm
    motion_claims: list[str] = Field(default_factory=list)
    additional_rules: list[str] = Field(default_factory=list)
    ambiguous: bool = False
    ambiguities: list[str] = Field(default_factory=list)


class PhysicsFidelitySubject(BaseModel):
    """One concrete variant of a physics template."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: PhysicsTemplateSpec
    parameters: dict[str, str]


class PhysicsFidelityPlugin:
    """Blind parse-back and exact structured comparison for physics."""

    domain: str = "physics"
    artifact_model: type[BaseModel] = PhysicsFidelitySubject
    evidence_strength: EvidenceStrength = "probabilistic"

    def requires_check(self, artifact: BaseModel) -> bool:
        _subject(artifact)
        return True

    def reconstruction_request(self, text: str) -> StructuredGenerationRequest[Any]:
        return StructuredGenerationRequest(
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": text},
            ],
            response_model=PhysicsReconstruction,
            schema_name=SCHEMA_NAME,
            prompt_version=PROMPT_VERSION,
        )

    def canonicalize(self, artifact: BaseModel) -> CanonicalArtifact:
        subject = _subject(artifact)
        payload = {
            "template": subject.template.model_dump(
                mode="json",
                exclude={
                    "body": {
                        "answer_recipe": True,
                        "distractors": True,
                    }
                },
            ),
            "parameters": dict(sorted(subject.parameters.items())),
        }
        encoded = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return CanonicalArtifact(
            domain=self.domain,
            payload=payload,
            digest=hashlib.sha256(encoded.encode()).hexdigest(),
        )

    def check_anchors(self, artifact: BaseModel, text: str) -> FidelityVerdict:
        subject = _subject(artifact)
        findings = physics_text.text_findings(subject.template)
        evidence = {
            "template_length": len(subject.template.body.text),
            "rendered_length": len(text),
            "finding_codes": [code for code, _ in findings],
        }
        if findings:
            return FidelityVerdict(
                status="failed",
                reasons=[message for _, message in findings],
                evidence=evidence,
            )
        return FidelityVerdict(status="passed", evidence=evidence)

    def equivalent(
        self, expected: BaseModel, reconstructed: BaseModel
    ) -> FidelityVerdict:
        subject = _subject(expected)
        parse = _reconstruction(reconstructed)
        item = subject.template
        body = item.body

        if parse.ambiguous:
            return FidelityVerdict(
                status="inconclusive",
                reasons=list(parse.ambiguities) or ["the blind parse is ambiguous"],
                evidence={"ambiguous": True, "ambiguities": parse.ambiguities},
            )

        reasons: list[str] = []
        unreadable: list[str] = []
        evidence: dict[str, Any] = {
            "expected_target": body.target,
            "reconstructed_target": parse.target,
            "expected_answer_form": body.answer_form,
            "reconstructed_answer_form": parse.answer_form,
            "expected_positive_direction": item.axis.positive,
            "reconstructed_positive_direction": parse.positive_direction,
        }

        if parse.target != body.target:
            reasons.append(f"target is {parse.target!r}, not {body.target!r}")
        if parse.answer_form != body.answer_form:
            reasons.append(
                f"answer form is {parse.answer_form!r}, not {body.answer_form!r}"
            )

        if parse.positive_direction != item.axis.positive:
            if parse.positive_direction == "unspecified":
                unreadable.append("the text does not state the positive direction")
            else:
                reasons.append(
                    f"the positive direction is {parse.positive_direction!r}, not "
                    f"{item.axis.positive!r}"
                )

        _compare_mass(subject, parse, reasons, unreadable, evidence)
        _compare_directed(
            "acceleration",
            body.acceleration,
            subject,
            parse.acceleration,
            reasons,
            unreadable,
            evidence,
        )
        _compare_directed(
            "net force",
            body.net_force,
            subject,
            parse.net_force,
            reasons,
            unreadable,
            evidence,
        )
        _compare_forces(subject, parse, reasons, unreadable, evidence)

        if parse.motion_claims:
            reasons.append(
                "the text states motion that the template does not: "
                + "; ".join(parse.motion_claims)
            )
        extra_rules = _extra_rules(item, parse.additional_rules)
        evidence["ignored_standard_rules"] = [
            rule for rule in parse.additional_rules if rule not in extra_rules
        ]
        if extra_rules:
            reasons.append(
                "the text adds unsupported rules or objects: " + "; ".join(extra_rules)
            )

        # A definite mismatch fails even when another value could not be read.
        if reasons:
            return FidelityVerdict(
                status="failed", reasons=[*reasons, *unreadable], evidence=evidence
            )
        if unreadable:
            return FidelityVerdict(
                status="inconclusive", reasons=unreadable, evidence=evidence
            )
        return FidelityVerdict(
            status="passed",
            reasons=[
                "target, values, directions and forces agree with the blind parse"
            ],
            evidence=evidence,
        )


def _normalised(text: str) -> str:
    return " ".join("".join(ch if ch.isalnum() else " " for ch in text.lower()).split())


def _extra_rules(item: PhysicsTemplateSpec, rules: list[str]) -> list[str]:
    """Drop rules that only restate the application's own assumption sentences.

    Every question carries these fixed sentences, so a parser that echoes one of
    them has not found anything the template does not already model.
    """
    standard = [_normalised(sentence) for sentence in physics_text.assumptions(item)]
    extra = []
    for rule in rules:
        rule_text = _normalised(rule)
        # A restatement must be a substantial part of one standard sentence, so
        # a short rule such as "gravity" is never absorbed by accident.
        # A rule that contains a standard sentence plus more is kept, because the
        # extra words may add a real rule.
        restates = any(
            rule_text == sentence
            or (len(rule_text.split()) >= 4 and rule_text in sentence)
            for sentence in standard
        )
        if not rule_text or restates:
            continue
        extra.append(rule)
    return extra


PLUGIN = PhysicsFidelityPlugin()


def representative_variants(item: PhysicsTemplateSpec) -> list[dict[str, str]]:
    """The at-most-three variants that blind parse-back reads.

    Every additional variant costs a judge call, so this pilot reads three at
    most: the lowest, middle and highest value of each parameter, staggered by
    parameter position across the three rounds (as biology staggers its
    variants) so a repeated or swapped role is read off the diagonal. Those
    samples always include both extremes, where a rendered value or direction is
    easiest to misstate, and a middle value, where a role swap can hide. Short
    value lists repeat a sample and are deduplicated.
    """
    axes = {
        parameter.name: sorted(parameter.values, key=parse_decimal)
        for parameter in item.parameters
    }
    positions = {
        name: [0, len(values) // 2, len(values) - 1] for name, values in axes.items()
    }
    variants: list[dict[str, str]] = []
    for k in range(3):
        variant = {
            parameter.name: axes[parameter.name][positions[parameter.name][(k + i) % 3]]
            for i, parameter in enumerate(item.parameters)
        }
        if variant not in variants:
            variants.append(variant)
    return variants


def physics_fidelity_plugin() -> PhysicsFidelityPlugin:
    """Return the stateless physics plugin used by application wiring."""
    return PLUGIN


def identity_reconstruction(
    subject: PhysicsFidelitySubject,
) -> PhysicsReconstruction:
    """The reading a perfect blind parser would return for this variant.

    Offline evaluation compares it with the template to check the comparison
    itself without a model call. It is never used as evidence of fidelity.
    """
    item = subject.template
    values = subject.parameters
    body = item.body
    forces = [
        ForceReading(
            label=force.label,
            magnitude=values[force.param],
            side=_side(force.direction, item.axis.positive),
        )
        for force in body.forces or []
    ]
    unknown = body.unknown_force
    if unknown is not None:
        forces.append(
            ForceReading(
                label=unknown.label,
                magnitude=None,
                side=_side(unknown.direction, item.axis.positive),
            )
        )
    return PhysicsReconstruction(
        target=body.target,
        unknown_force_label=unknown.label if unknown is not None else None,
        positive_direction=item.axis.positive,
        mass_kg=values[body.mass] if body.mass is not None else None,
        acceleration=_reading(body.acceleration, values, item.axis.positive),
        net_force=_reading(body.net_force, values, item.axis.positive),
        forces=forces,
        answer_form=body.answer_form,
        motion_claims=[],
        additional_rules=[],
        ambiguous=False,
        ambiguities=[],
    )


def _subject(artifact: BaseModel) -> PhysicsFidelitySubject:
    if not isinstance(artifact, PhysicsFidelitySubject):
        raise TypeError("physics fidelity expects a PhysicsFidelitySubject")
    return artifact


def _reconstruction(artifact: BaseModel) -> PhysicsReconstruction:
    if not isinstance(artifact, PhysicsReconstruction):
        raise TypeError("physics fidelity expects a PhysicsReconstruction")
    return artifact


def _reading(
    directed: DirectedParameter | None,
    values: dict[str, str],
    axis_positive: str,
) -> DirectedReading | None:
    if directed is None:
        return None
    return DirectedReading(
        magnitude=values[directed.param],
        side=_side(directed.direction, axis_positive),
    )


def _side(direction: str, axis_positive: str) -> Side:
    side = axis_positive if direction == "positive" else OPPOSITE_SIDE[axis_positive]
    return cast(Side, side)


def _compare_mass(
    subject: PhysicsFidelitySubject,
    parse: PhysicsReconstruction,
    reasons: list[str],
    unreadable: list[str],
    evidence: dict[str, Any],
) -> None:
    body = subject.template.body
    expected = _parameter_value(subject, body.mass) if body.mass is not None else None
    evidence["expected_mass_kg"] = (
        None if expected is None else _fraction_text(expected)
    )
    evidence["reconstructed_mass_kg"] = parse.mass_kg

    if body.mass is None:
        if parse.mass_kg is not None:
            reasons.append(
                f"the text states a mass of {parse.mass_kg!r} kg but the template "
                "has no mass role"
            )
        return
    if expected is None:  # pragma: no cover - the schema guarantees a value
        unreadable.append("the template's mass value cannot be read")
        return
    if parse.mass_kg is None:
        unreadable.append("the blind parse gives no mass")
        return
    parsed = _as_fraction(parse.mass_kg)
    if parsed is None:
        unreadable.append(
            f"mass {parse.mass_kg!r} cannot be read as a value in kilograms"
        )
        return
    if parsed != expected:
        reasons.append(
            f"mass is {parse.mass_kg!r} kg, not {_fraction_text(expected)} kg"
        )


def _compare_directed(
    label: str,
    directed: DirectedParameter | None,
    subject: PhysicsFidelitySubject,
    reading: DirectedReading | None,
    reasons: list[str],
    unreadable: list[str],
    evidence: dict[str, Any],
) -> None:
    key = "acceleration" if label == "acceleration" else "net_force"
    expected = (
        _parameter_value(subject, directed.param) if directed is not None else None
    )
    expected_side = (
        _side(directed.direction, subject.template.axis.positive)
        if directed is not None
        else None
    )
    evidence[f"expected_{key}"] = (
        None
        if expected is None
        else {"magnitude": _fraction_text(expected), "side": expected_side}
    )
    evidence[f"reconstructed_{key}"] = (
        None if reading is None else reading.model_dump(mode="json")
    )

    if directed is None:
        if reading is not None:
            reasons.append(
                f"the text states a {label} but the template has no {label} role"
            )
        return
    if expected is None or expected_side is None:  # pragma: no cover - schema
        unreadable.append(f"the template's {label} value cannot be read")
        return
    if reading is None:
        unreadable.append(f"the blind parse gives no {label}")
        return
    if reading.magnitude is None:
        unreadable.append(f"the blind parse gives no {label} magnitude")
        return
    parsed = _as_fraction(reading.magnitude)
    if parsed is None:
        unreadable.append(f"the {label} magnitude {reading.magnitude!r} cannot be read")
        return
    if parsed != expected:
        reasons.append(
            f"the {label} magnitude is {reading.magnitude!r}, not "
            f"{_fraction_text(expected)}"
        )
    if reading.side == "unspecified":
        unreadable.append(f"the text does not state the {label}'s side")
    elif reading.side != expected_side:
        reasons.append(f"the {label} points {reading.side}, not {expected_side}")


def _compare_forces(
    subject: PhysicsFidelitySubject,
    parse: PhysicsReconstruction,
    reasons: list[str],
    unreadable: list[str],
    evidence: dict[str, Any],
) -> None:
    body = subject.template.body
    expected: Counter[tuple[Fraction, str]] = Counter()
    for force in body.forces or []:
        value = _parameter_value(subject, force.param)
        if value is None:  # pragma: no cover - the schema guarantees a value
            unreadable.append(f"the template's {force.label} value cannot be read")
            continue
        expected[(value, _force_side(subject, force))] += 1
    evidence["expected_known_forces"] = _counter_evidence(expected)
    parsed, valueless = _parsed_forces(parse, unreadable)
    evidence["reconstructed_known_forces"] = _counter_evidence(parsed)
    evidence["reconstructed_valueless_forces"] = [
        {"label": force.label, "side": force.side} for force in valueless
    ]

    if parsed != expected:
        reasons.append(
            "the text gives known forces "
            f"{_counter_text(parsed)}, not {_counter_text(expected)}"
        )

    if body.target != "missing_force":
        if valueless:
            reasons.append(
                "the text names forces without a magnitude ("
                + ", ".join(force.label for force in valueless)
                + "), but the question does not ask for one"
            )
        return

    unknown = body.unknown_force
    if unknown is None:  # pragma: no cover - the schema guarantees it
        unreadable.append("the template's unknown force cannot be read")
        return
    expected_side = _side(unknown.direction, subject.template.axis.positive)
    if parse.unknown_force_label is None:
        reasons.append("the blind parse does not name the force the question asks for")
    if len(valueless) != 1:
        reasons.append(
            f"the text describes {len(valueless)} forces without a magnitude, not "
            "exactly one"
        )
    elif valueless[0].side == "unspecified":
        unreadable.append("the text does not state the unknown force's side")
    elif valueless[0].side != expected_side:
        reasons.append(
            f"the unknown force points {valueless[0].side}, not {expected_side}"
        )


def _parsed_forces(
    parse: PhysicsReconstruction, unreadable: list[str]
) -> tuple[Counter[tuple[Fraction, str]], list[ForceReading]]:
    known: Counter[tuple[Fraction, str]] = Counter()
    valueless: list[ForceReading] = []
    for force in parse.forces:
        if force.magnitude is None:
            valueless.append(force)
            continue
        if force.side == "unspecified":
            unreadable.append(
                f"the text does not state which way the {force.label} force acts"
            )
            continue
        value = _as_fraction(force.magnitude)
        if value is None:
            unreadable.append(
                f"the {force.label} force magnitude {force.magnitude!r} cannot be read"
            )
            continue
        known[(value, force.side)] += 1
    return known, valueless


def _force_side(subject: PhysicsFidelitySubject, force: ForceTerm) -> str:
    return _side(force.direction, subject.template.axis.positive)


def _parameter_value(
    subject: PhysicsFidelitySubject, name: str | None
) -> Fraction | None:
    if name is None:
        return None
    raw = subject.parameters.get(name)
    if raw is None:
        return None
    return _as_fraction(raw)


def _as_fraction(text: str) -> Fraction | None:
    try:
        return parse_decimal(text)
    except ValueError:
        return None


def _fraction_text(value: Fraction) -> str:
    return str(value)


def _counter_evidence(
    counter: Counter[tuple[Fraction, str]],
) -> list[dict[str, Any]]:
    return [
        {"magnitude": _fraction_text(value), "side": side, "count": count}
        for (value, side), count in sorted(
            counter.items(), key=lambda item: (item[0][1], item[0][0], item[1])
        )
    ]


def _counter_text(counter: Counter[tuple[Fraction, str]]) -> str:
    if not counter:
        return "none"
    return ", ".join(
        f"{_fraction_text(value)} N to the {side}"
        + (f" (x{count})" if count > 1 else "")
        for (value, side), count in sorted(
            counter.items(), key=lambda item: (item[0][1], item[0][0], item[1])
        )
    )
