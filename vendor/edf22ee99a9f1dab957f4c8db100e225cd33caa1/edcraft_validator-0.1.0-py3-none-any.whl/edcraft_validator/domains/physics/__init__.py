"""One-dimensional physics domain (F_net = m a pilot)."""
