"""Entrypoint for one Nomad AI authoring allocation."""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, FiniteFloat

from edcraft_validator.application.authoring_api import (
    AuthoringJobCommand,
    AuthoringJobRecord,
    run_authoring_job_sync,
)
from edcraft_validator.application.authoring_contracts import (
    AuthoringProgress,
    AuthoringResult,
)
from edcraft_validator.application.template_workflow import TemplateApplication
from edcraft_validator.worker.client import WorkerClient
from edcraft_validator.worker.providers import (
    ProviderPlan,
    WorkerPlan,
    build_model_tool_client,
    build_provider,
)

logger = logging.getLogger(__name__)
IMAGE_REVISION_PATH = Path("/app/edcraft-validator-revision")
STARTUP_TIMEOUT_SECONDS = 30


@dataclass(frozen=True)
class WorkerEnvironment:
    context_url: str
    progress_url: str
    callback_url: str
    error_url: str
    library_revision: str
    job_id: UUID
    allocation_id: UUID
    token: str = field(repr=False)


class WorkerContext(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    job_id: UUID
    library_revision: str
    timeout_seconds: FiniteFloat = Field(gt=0)
    command: AuthoringJobCommand
    plan: WorkerPlan


def load_environment(environ: Mapping[str, str]) -> WorkerEnvironment:
    names = ("CONTEXT_URL", "PROGRESS_URL", "CALLBACK_URL", "ERROR_URL")
    context_url, progress_url, callback_url, error_url = (
        environ[f"EDCRAFT_{name}"] for name in names
    )
    origins = set()
    for url in (context_url, progress_url, callback_url, error_url):
        parts = urlsplit(url)
        if (
            parts.scheme not in {"http", "https"}
            or not parts.hostname
            or parts.username is not None
            or parts.password is not None
            or parts.query
            or parts.fragment
        ):
            raise ValueError("Invalid backend worker URL")
        origins.add((parts.scheme, parts.hostname, parts.port))
    token = environ["EDCRAFT_WORKER_TOKEN"]
    revision = environ["EDCRAFT_LIBRARY_REVISION"]
    if (
        len(origins) != 1
        or not token
        or any(not 33 <= ord(char) <= 126 for char in token)
        or len(revision) != 40
        or any(char not in "0123456789abcdef" for char in revision)
    ):
        raise ValueError("Invalid worker origin, token or library revision")
    return WorkerEnvironment(
        context_url=context_url,
        progress_url=progress_url,
        callback_url=callback_url,
        error_url=error_url,
        library_revision=revision,
        job_id=UUID(environ["EDCRAFT_JOB_ID"]),
        allocation_id=UUID(environ["NOMAD_ALLOC_ID"]),
        token=token,
    )


class _SecretFilter(logging.Filter):
    def __init__(self, token: str) -> None:
        super().__init__()
        self.secrets = {token}

    def text(self, value: str) -> str:
        for secret in sorted(self.secrets, key=len, reverse=True):
            value = value.replace(secret, "***")
        return value

    def _contains_secret(self, value: Any) -> bool:
        if isinstance(value, str):
            return any(secret in value for secret in self.secrets)
        if isinstance(value, list):
            return any(self._contains_secret(item) for item in value)
        if isinstance(value, dict):
            return any(
                self._contains_secret(key) or self._contains_secret(item)
                for key, item in value.items()
            )
        return False

    def report_payload(self, result: AuthoringResult) -> dict[str, Any]:
        report = result.model_dump(mode="json")
        for diagnostic in ("reason", "feedback_error"):
            if report[diagnostic] is not None:
                report[diagnostic] = self.text(report[diagnostic])
        for attempt in report["attempts"]:
            for execution in attempt["executions"]:
                if execution["error"] is not None:
                    execution["error"] = self.text(execution["error"])
        # Changing a candidate, artifact or input would invalidate its evidence.
        if self._contains_secret(report):
            raise ValueError("Credential in authoring report data")
        return report

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self.text(record.getMessage())
        record.args = ()
        # Provider exceptions can contain response bodies and request metadata.
        record.exc_info = None
        record.exc_text = None
        return True


def arm_process_timeout(seconds: float) -> None:
    """Let the OS enforce the allocation's deadline, including blocked I/O."""
    signal.signal(signal.SIGALRM, signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL, seconds)


def _context(payload: dict[str, Any], settings: WorkerEnvironment) -> WorkerContext:
    context = WorkerContext.model_validate(payload)
    if context.job_id != settings.job_id or context.command.job_id != settings.job_id:
        raise ValueError("Worker job does not match context")
    if context.library_revision != settings.library_revision:
        raise ValueError("Worker revision does not match context")
    if IMAGE_REVISION_PATH.exists():
        revision = IMAGE_REVISION_PATH.read_text(encoding="ascii").strip()
        if revision != settings.library_revision:
            raise ValueError("Worker image does not match context revision")
    role = context.plan.author
    if context.command.author.provider != role.provider or (
        context.command.author.model is not None
        and context.command.author.model != role.model
    ):
        raise ValueError("Worker author does not match context command")
    return context


def execute_job(
    context: WorkerContext,
    *,
    on_progress: Callable[[AuthoringProgress], None],
    runner: Callable[..., AuthoringJobRecord],
    tool_client_factory: Callable[..., Any],
    provider_factory: Callable[[ProviderPlan], Any],
) -> AuthoringResult:
    plan = context.plan
    tool_client = tool_client_factory(
        difficulty=plan.difficulty,
        relevance=plan.relevance,
        decision_fallback=plan.decision_fallback,
    )
    return runner(
        context.command,
        application_factory=lambda: TemplateApplication(tool_client=tool_client),
        provider_factory=lambda _: provider_factory(plan.author),
        on_progress=on_progress,
    ).report


def _run(
    client: WorkerClient,
    settings: WorkerEnvironment,
    redaction: _SecretFilter,
    *,
    runner: Callable[..., AuthoringJobRecord],
    tool_client_factory: Callable[..., Any],
    provider_factory: Callable[[ProviderPlan], Any],
    arm_timeout: Callable[[float], None],
) -> int:
    job_id = settings.job_id
    try:
        arm_timeout(STARTUP_TIMEOUT_SECONDS)
        context = _context(client.fetch_context(), settings)
        for role in (
            context.plan.author,
            context.plan.difficulty,
            context.plan.relevance,
            context.plan.decision_fallback,
        ):
            if role is not None and role.api_key is not None:
                redaction.secrets.add(role.api_key.get_secret_value())
        arm_timeout(context.timeout_seconds)
    except Exception:
        logger.warning("job=%s Worker could not read or verify its context", job_id)
        client.post_error(
            "The authoring worker could not verify its job configuration."
        )
        return 1

    def on_progress(progress: AuthoringProgress) -> None:
        if progress.current_check is not None:
            progress = progress.model_copy(
                update={"current_check": redaction.text(progress.current_check)}
            )
        if not client.post_progress(progress):
            logger.debug("job=%s Could not deliver authoring progress", job_id)

    try:
        result = execute_job(
            context,
            runner=runner,
            on_progress=on_progress,
            tool_client_factory=tool_client_factory,
            provider_factory=provider_factory,
        )
        if client.deliver_result(
            {
                "library_revision": settings.library_revision,
                "report": redaction.report_payload(result),
            },
        ):
            logger.info(
                "job=%s Delivered authoring result status=%s", job_id, result.status
            )
            return int(result.status == "error")
    except Exception:
        logger.warning("job=%s Worker could not complete authoring", job_id)
        client.post_error("The authoring worker could not complete the job.")
        return 1

    logger.warning("job=%s Worker could not deliver the authoring result", job_id)
    client.post_error("The authoring worker could not deliver its report.")
    return 1


def main(
    argv: Sequence[str] = (),
    *,
    environ: Mapping[str, str] | None = None,
    runner: Callable[..., AuthoringJobRecord] = run_authoring_job_sync,
    tool_client_factory: Callable[..., Any] = build_model_tool_client,
    provider_factory: Callable[[ProviderPlan], Any] = build_provider,
    client_factory: Callable[[WorkerEnvironment], WorkerClient] = WorkerClient,
    arm_timeout: Callable[[float], None] = arm_process_timeout,
) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m edcraft_validator.worker",
        description="Run one AI authoring job configured through EDCRAFT_* variables.",
    )
    parser.parse_args(argv)
    # Do not let HTTP or SDK debug logs emit request bodies or URLs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    try:
        settings = load_environment(os.environ if environ is None else environ)
    except (KeyError, ValueError):
        logger.error("Missing or invalid authoring worker configuration")
        return 1

    redaction = _SecretFilter(settings.token)
    handlers = tuple(logging.getLogger().handlers)
    for handler in handlers:
        handler.addFilter(redaction)
    client = client_factory(settings)
    try:
        return _run(
            client,
            settings,
            redaction,
            runner=runner,
            tool_client_factory=tool_client_factory,
            provider_factory=provider_factory,
            arm_timeout=arm_timeout,
        )
    finally:
        client.close()
        for handler in handlers:
            handler.removeFilter(redaction)
