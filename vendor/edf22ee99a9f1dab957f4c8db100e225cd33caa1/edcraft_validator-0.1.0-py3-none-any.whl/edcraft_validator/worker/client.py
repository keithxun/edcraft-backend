"""Authenticated HTTP channel for backend context and worker callbacks."""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import httpx

from edcraft_validator.application.authoring_contracts import AuthoringProgress

if TYPE_CHECKING:
    from edcraft_validator.worker.main import WorkerEnvironment

CONTEXT_LIMIT_BYTES = 4 * 1024 * 1024
RETRY_DELAYS = (1.0, 2.0, 4.0)


class WorkerClient:
    def __init__(
        self,
        settings: WorkerEnvironment,
        *,
        sleep: Callable[[float], None] = time.sleep,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self._sleep = sleep
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {settings.token}",
                "X-EdCraft-Worker-Allocation": str(settings.allocation_id),
            },
            timeout=httpx.Timeout(15, connect=5),
            trust_env=False,
            follow_redirects=False,
            transport=transport,
        )

    def close(self) -> None:
        self._client.close()

    def fetch_context(self) -> dict[str, Any]:
        for delay in RETRY_DELAYS:
            try:
                return self._fetch_context()
            except httpx.HTTPStatusError as exc:
                if not self._retryable(exc.response.status_code):
                    raise
            except httpx.TransportError:
                pass
            self._sleep(delay)
        return self._fetch_context()

    def _fetch_context(self) -> dict[str, Any]:
        with self._client.stream(
            "GET", self.settings.context_url, headers={"Cache-Control": "no-store"}
        ) as response:
            response.raise_for_status()
            body = bytearray()
            for chunk in response.iter_bytes(chunk_size=65536):
                if len(body) + len(chunk) > CONTEXT_LIMIT_BYTES:
                    raise ValueError("Authoring context exceeds the maximum size")
                body.extend(chunk)
        payload = json.loads(body)
        if not isinstance(payload, dict):
            raise ValueError("Authoring context must be a JSON object")
        return payload

    def post_progress(self, progress: AuthoringProgress) -> bool:
        return self._post(
            self.settings.progress_url,
            progress.model_dump(mode="json", exclude_none=True),
            timeout=2,
        )

    def deliver_result(self, payload: dict[str, Any]) -> bool:
        return self._post(self.settings.callback_url, payload, retries=RETRY_DELAYS)

    def post_error(self, message: str) -> bool:
        return self._post(
            self.settings.error_url,
            {"code": "AUTHORING_FAILED", "message": message},
        )

    def _post(
        self,
        url: str,
        payload: dict[str, Any],
        *,
        timeout: float = 10,
        retries: tuple[float, ...] = (),
    ) -> bool:
        status = self._send(url, payload, timeout=timeout)
        for delay in retries:
            if not self._retryable(status):
                break
            self._sleep(delay)
            status = self._send(url, payload, timeout=timeout)
        return status is not None and 200 <= status < 300

    @staticmethod
    def _retryable(status: int | None) -> bool:
        return status is None or status == 429 or status >= 500

    def _send(self, url: str, payload: dict[str, Any], *, timeout: float) -> int | None:
        try:
            with self._client.stream(
                "POST", url, json=payload, timeout=timeout
            ) as response:
                return response.status_code
        except httpx.TransportError:
            return None
