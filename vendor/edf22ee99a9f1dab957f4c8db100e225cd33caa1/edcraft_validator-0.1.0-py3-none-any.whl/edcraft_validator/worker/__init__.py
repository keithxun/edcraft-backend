"""Run one authoring job in a Nomad batch allocation."""
