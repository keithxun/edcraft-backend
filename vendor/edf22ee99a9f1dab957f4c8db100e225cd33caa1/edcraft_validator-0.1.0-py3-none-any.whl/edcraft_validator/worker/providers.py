"""Model-provider wiring for one worker job.

The context endpoint supplies credentials for the lifetime of one job.
"""

from __future__ import annotations

import ipaddress
import os
import socket
from collections.abc import Callable
from typing import Any, Literal

import httpx
from openai import OpenAI
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    FiniteFloat,
    SecretStr,
    model_validator,
)

from edcraft_validator.llm.llm_contracts import (
    ModelProvider,
    StructuredGenerationRequest,
)
from edcraft_validator.llm.llm_errors import DecisionCapabilityError
from edcraft_validator.llm.openai_compatible_provider import (
    OpenAIProvider,
    SocLaasProvider,
)
from edcraft_validator.mcp.client import FastMcpToolClient
from edcraft_validator.mcp.job_judges import job_judge_client

DEFAULT_TIMEOUT_SECONDS = {
    "soclaas": 600.0,
    "openai": 120.0,
}

ProviderName = Literal["soclaas", "openai"]


class ProviderPlan(BaseModel):
    """One role's non-persisted credentials from the context response."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    provider: ProviderName
    model: str = Field(min_length=1)
    api_key: SecretStr | None = Field(default=None, min_length=1, repr=False)
    base_url: str | None = None
    timeout_seconds: FiniteFloat | None = Field(default=None, gt=0)

    @property
    def effective_timeout_seconds(self) -> float:
        if self.timeout_seconds is not None:
            return self.timeout_seconds
        return DEFAULT_TIMEOUT_SECONDS[self.provider]


class WorkerPlan(BaseModel):
    """Author and advisory roles for exactly one authoring job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    author: ProviderPlan
    difficulty: ProviderPlan
    relevance: ProviderPlan
    decision_fallback: ProviderPlan | None = None

    @model_validator(mode="after")
    def require_author_credentials(self) -> WorkerPlan:
        if self.author.api_key is None:
            raise ValueError("Author credentials are unavailable")
        return self


class ManagedProvider:
    """Adapt a validator provider and own its OpenAI client lifecycle."""

    def __init__(
        self,
        delegate: ModelProvider,
        client: OpenAI,
        *,
        provider: str,
        model: str,
    ) -> None:
        self._delegate = delegate
        self._client = client
        self.provider = provider
        self.model = model

    def generation_settings(self) -> dict[str, Any]:
        return self._delegate.generation_settings()

    def generate(self, request: StructuredGenerationRequest[Any]) -> Any:
        return self._delegate.generate(request)

    def decide(self, messages: list[dict[str, Any]], labels: tuple[str, ...]) -> Any:
        decide = getattr(self._delegate, "decide", None)
        if not callable(decide):
            raise DecisionCapabilityError(
                "Provider does not support token-probability decisions"
            )
        return decide(messages, labels)

    @property
    def last_usage(self) -> Any:
        return getattr(self._delegate, "last_usage", None)

    def close(self) -> None:
        self._client.close()


class _ProviderTransport(httpx.HTTPTransport):
    """Use only addresses checked by the worker while retaining provider TLS SNI."""

    def __init__(self, endpoint: httpx.URL, addresses: list[str]) -> None:
        super().__init__(trust_env=False)
        self._endpoint = endpoint
        self._addresses = addresses

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        endpoint = self._endpoint
        if (request.url.scheme, request.url.host, request.url.port) != (
            endpoint.scheme,
            endpoint.host,
            endpoint.port,
        ):
            raise httpx.ConnectError("Provider origin changed", request=request)
        for index, address in enumerate(self._addresses, start=1):
            # The HTTP Host and HTTPS certificate check use the original name.
            # The socket destination is numeric, so DNS cannot change it.
            pinned = httpx.Request(
                request.method,
                request.url.copy_with(host=address),
                headers=request.headers,
                stream=request.stream,
                extensions={**request.extensions, "sni_hostname": endpoint.host},
            )
            try:
                return super().handle_request(pinned)
            except httpx.ConnectError:
                if index == len(self._addresses):
                    raise
        raise httpx.ConnectError("No provider address available", request=request)


def _provider_endpoint(plan: ProviderPlan) -> tuple[httpx.URL, list[str]]:
    base_url = plan.base_url
    if base_url is None and plan.provider == "openai":
        base_url = "https://api.openai.com/v1"
    endpoint = httpx.URL(base_url or "")
    allow_private = os.getenv("PROVIDER_ALLOW_PRIVATE_HOSTS", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    hostname = endpoint.host.removesuffix(".").lower()
    if (
        (
            endpoint.scheme != "https"
            and not (allow_private and endpoint.scheme == "http")
        )
        or not hostname
        or hostname in {"metadata.google.internal", "metadata", "instance-data"}
        or endpoint.userinfo
        or endpoint.query
        or endpoint.fragment
    ):
        raise ValueError("Invalid provider endpoint")

    port = endpoint.port or (443 if endpoint.scheme == "https" else 80)
    resolved = socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
    addresses = list(dict.fromkeys(str(result[4][0]) for result in resolved))
    if not addresses:
        raise ValueError("No provider address available")
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        if (
            ip.is_link_local
            or ip.is_multicast
            or ip.is_unspecified
            or ip.is_reserved
            or not (ip.is_global or (allow_private and ip.is_private))
        ):
            raise ValueError("Blocked provider address")
    return endpoint, addresses


def build_provider(
    plan: ProviderPlan,
    *,
    client_factory: Callable[..., Any] = OpenAI,
) -> ManagedProvider:
    """Build one role's provider from the credentials supplied in the context."""
    if plan.api_key is None:
        raise ValueError("Model credentials are unavailable")
    endpoint, addresses = _provider_endpoint(plan)
    http_client = httpx.Client(
        transport=_ProviderTransport(endpoint, addresses),
        timeout=plan.effective_timeout_seconds,
        follow_redirects=False,
        trust_env=False,
    )
    try:
        client = client_factory(
            api_key=plan.api_key.get_secret_value(),
            base_url=str(endpoint),
            timeout=plan.effective_timeout_seconds,
            max_retries=1,
            http_client=http_client,
        )
    except Exception:
        http_client.close()
        raise
    try:
        if plan.provider == "soclaas":
            delegate: ModelProvider = SocLaasProvider(client=client, model=plan.model)
        elif plan.provider == "openai":
            delegate = OpenAIProvider(client=client, model=plan.model)
        else:  # pragma: no cover - ProviderPlan already rejects other names
            raise ValueError(f"Unsupported provider: {plan.provider}")
    except Exception:
        client.close()
        raise
    return ManagedProvider(
        delegate,
        client,
        provider=plan.provider,
        model=plan.model,
    )


def build_model_tool_client(
    *,
    difficulty: ProviderPlan,
    relevance: ProviderPlan,
    decision_fallback: ProviderPlan | None = None,
) -> FastMcpToolClient:
    """Build validation tools with separately selected advisory models."""
    return job_judge_client(
        difficulty=difficulty,
        relevance=relevance,
        decision_fallback=decision_fallback,
        open_provider=build_provider,
        model_name=lambda role: (role.provider, role.model),
        use_relevance_for_fidelity=True,
    )
