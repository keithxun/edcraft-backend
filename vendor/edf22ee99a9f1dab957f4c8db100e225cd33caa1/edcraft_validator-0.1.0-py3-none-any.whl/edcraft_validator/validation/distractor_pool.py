"""Select one fixed set of recipes using shared sampled assignments."""

from __future__ import annotations

import operator
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from itertools import combinations
from typing import Any

from edcraft_validator.validation.property_checks import (
    PropertyCheckRun,
    PropertyCheckSettings,
)

SURPLUS_RECIPES = 3


class DistractorPoolError(ValueError):
    """The proposal needs revision before it can become a reusable template."""


@dataclass(frozen=True)
class OptionValue:
    semantic: Any
    display: str


@dataclass(frozen=True)
class UnusableOption:
    reason: str


def select_fixed_subset(
    rows: Iterable[tuple[OptionValue, Sequence[OptionValue | UnusableOption | None]]],
    required: int,
    *,
    required_slots: Sequence[int] = (),
    equivalent: Callable[[Any, Any], bool] = operator.eq,
    assignments: Sequence[Mapping[str, Any]] | None = None,
) -> tuple[int, ...]:
    """Return the first n mutually compatible recipes across *all* sampled rows."""
    if required < 1:
        raise ValueError("required must be positive")
    size = required + SURPLUS_RECIPES
    mandatory = frozenset(required_slots)
    if len(mandatory) > required or any(i < 0 or i >= size for i in mandatory):
        raise DistractorPoolError(
            "Requested option count cannot retain the required misconception contrasts."
        )
    banned: set[int] = set()
    conflicts: set[tuple[int, int]] = set()
    witnesses: list[str] = []

    def same(left: OptionValue, right: OptionValue) -> bool:
        return left.display == right.display or equivalent(
            left.semantic, right.semantic
        )

    seen = False
    for number, (key, options) in enumerate(rows, start=1):
        seen = True
        if len(options) != size:
            raise DistractorPoolError(
                f"Expected {size} candidate recipes for {required} distractors; "
                f"received {len(options)}."
            )
        label = f"sample {number}"
        if assignments is not None:
            label += f" {dict(assignments[number - 1])!r}, key={key.display!r}"
        usable = []
        for i, option in enumerate(options):
            if i in banned:
                continue
            if (
                option is None
                or isinstance(option, UnusableOption)
                or same(key, option)
            ):
                banned.add(i)
                if len(witnesses) < 6:
                    cause = (
                        option.reason
                        if isinstance(option, UnusableOption)
                        else "unusable"
                        if option is None
                        else f"equals key {key.display!r}"
                    )
                    witnesses.append(f"{label}: recipe {i + 1} {cause}")
            else:
                usable.append((i, option))
        for (i, left), (j, right) in combinations(usable, 2):
            if (i, j) not in conflicts and same(left, right):
                conflicts.add((i, j))
                if len(witnesses) < 6:
                    witnesses.append(
                        f"{label}: recipes {i + 1} and {j + 1} collide "
                        f"({left.display!r}, {right.display!r})"
                    )
    if not seen:
        raise DistractorPoolError("No input assignments were checked.")
    for group in combinations((i for i in range(size) if i not in banned), required):
        if mandatory.issubset(group) and all(
            pair not in conflicts for pair in combinations(group, 2)
        ):
            return group
    raise DistractorPoolError(
        f"No fixed set of {required} distinct distractors survived. "
        + "; ".join(witnesses)
    )


def sample_assignments(
    axes: Mapping[str, Sequence[Any]], *, budget: int = 32, seed: int = 0
) -> list[dict[str, Any]]:
    """Sample the declared axes without materialising or sweeping their product."""
    if budget < 1 or any(len(values) == 0 for values in axes.values()):
        raise DistractorPoolError("Need a positive sample budget and nonempty axes.")
    first = {name: values[0] for name, values in axes.items()}
    last = {name: values[-1] for name, values in axes.items()}
    boundary: list[dict[str, Any]] = []
    limit = max(1, budget // 2)

    def add(row: dict[str, Any]) -> None:
        if len(boundary) < limit and row not in boundary:
            boundary.append(row)

    add(first)
    add(last)
    for token in (0, 1, -1):
        # Axes may encode exact numeric parameters as strings.
        row = dict(first)
        for name, values in axes.items():
            target = str(token) if isinstance(values[0], str) else token
            if target in values:
                row[name] = target
                add(first | {name: target})
        add(row)

    for name, values in axes.items():
        add(first | {name: values[-1]})
    for (a, xs), (b, ys) in combinations(axes.items(), 2):
        if len(boundary) >= limit:
            break
        for x in (xs[0], xs[-1], xs[len(xs) // 2]):
            if type(x) is type(ys[0]) and x in ys:
                add(first | {a: x, b: x})
            # Deliberately include equality, sign reversal, neighbours and simple
            # multiples. Only choose values that the author actually declared.
            try:
                number = int(x)
            except (ValueError, TypeError, OverflowError):
                continue
            if str(x) != str(number):
                continue
            for related in (-number, 2 * number, number + 1, number - 1):
                target = str(related) if isinstance(ys[0], str) else related
                if target in ys:
                    add(first | {a: x, b: target})
    if len(boundary) == budget or not axes:
        return boundary
    # Reuse the project Hypothesis runner; its explicit cases are additional to
    # max_examples, so subtract them to keep the combined selection budget fixed.
    run = PropertyCheckRun(
        PropertyCheckSettings(max_examples=budget - len(boundary), seed=seed)
    )
    return run.check(axes, boundary, lambda row, _: row, cover_small_domain=False)
