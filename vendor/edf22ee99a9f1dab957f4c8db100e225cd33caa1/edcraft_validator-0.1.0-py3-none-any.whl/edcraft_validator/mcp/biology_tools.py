"""Biology-domain validation and advisory tools for the authoring flow.

The tools treat a model proposal as an untrusted candidate and run exact,
fidelity and advisory checks through MCP before the application finalises it.
"""

from __future__ import annotations

import time
from functools import partial
from typing import Annotated, Any, Literal

from fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

from edcraft_validator.application.fidelity.contracts import FidelityReport
from edcraft_validator.application.fidelity.engine import verify_text_fidelity
from edcraft_validator.domains.biology.authored_cross import uses_checked_cross_wording
from edcraft_validator.domains.biology.biology_schemas import (
    BiologyTemplateSpec,
    H2TemplateSpec,
)
from edcraft_validator.domains.biology.biology_types import (
    BIOLOGY_CROSS_TOOL,
    BIOLOGY_FIDELITY_TOOL,
    BIOLOGY_OPTIONS_TOOL,
    BIOLOGY_TOOL_VERSION,
)
from edcraft_validator.domains.biology.checking import CheckReport, check_template
from edcraft_validator.domains.biology.fidelity import (
    BiologyFidelitySubject,
    biology_fidelity_plugin,
    representative_variants,
)
from edcraft_validator.domains.biology.fit_schema import GoodnessOfFitTemplate
from edcraft_validator.domains.biology.goodness_of_fit import check_fit_template
from edcraft_validator.domains.biology.h2_authoring import check_h2_template
from edcraft_validator.domains.biology.question_generator import render_text
from edcraft_validator.llm.judge_configuration import (
    configured_judge_provider,
    load_judge_settings,
)
from edcraft_validator.llm.judging import JudgeProviderFactory
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding
from edcraft_validator.validation.property_checks import PropertyCheckSettings


class BiologyFidelityRequest(BaseModel):
    """Blind parse-back check for a template's contrasting variants."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: BiologyTemplateSpec | None = None
    timeout_seconds: float = Field(default=60.0, gt=0, le=310)


def register_biology_tools(
    server: FastMCP,
    *,
    property_settings: PropertyCheckSettings | None = None,
    fidelity_provider_factory: JudgeProviderFactory | None = None,
    fidelity_timeout_seconds: float = 60.0,
) -> None:
    """Register the biology-domain validation and advisory catalogue."""
    if fidelity_timeout_seconds <= 0:
        raise ValueError("fidelity timeout must be positive")

    selected_provider = fidelity_provider_factory
    if selected_provider is None:
        settings = load_judge_settings()
        selected_provider = partial(configured_judge_provider, settings)

    @server.tool(
        name=BIOLOGY_CROSS_TOOL,
        version=BIOLOGY_TOOL_VERSION,
        tags={"domain:biology", "validation:cross"},
        annotations={
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
        description=(
            "Independently check inheritance or plant-count goodness of fit. The "
            "engine derives the key from the declared cross or counts for each "
            "sampled variant and compares every claimed example. The check also "
            "supports previously saved Biology catalogue artifacts."
        ),
    )
    async def biology_verify_cross(
        template: BiologyTemplateSpec | None = None,
    ) -> ToolEvidence:
        return verify_cross(template, settings=property_settings)

    @server.tool(
        name=BIOLOGY_OPTIONS_TOOL,
        version=BIOLOGY_TOOL_VERSION,
        tags={"domain:biology", "validation:options"},
        annotations={
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
        description=(
            "Check a biology template's MCQ options exactly. Every distractor "
            "rule must apply, stay in range, differ from the key and differ from "
            "every other option for every sampled parameter combination. Any "
            "failure blocks approval."
        ),
    )
    async def biology_validate_options(
        template: BiologyTemplateSpec | None = None,
    ) -> ToolEvidence:
        return validate_options(template, settings=property_settings)

    @server.tool(
        name=BIOLOGY_FIDELITY_TOOL,
        version=BIOLOGY_TOOL_VERSION,
        tags={"domain:biology", "validation:fidelity"},
        annotations={
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
        description=(
            "Confirm that learner-facing text comes from the checked Biology "
            "inputs. New authored questions use deterministic wording. Historical "
            "free-text templates use anchors and blind parse-back across contrasting "
            "variants, and historical catalogue cases use their saved wording."
        ),
    )
    async def biology_verify_text_fidelity(
        template: BiologyTemplateSpec | None = None,
        timeout_seconds: Annotated[float, Field(gt=0, le=310)] = 60.0,
    ) -> ToolEvidence:
        request = BiologyFidelityRequest(
            template=template,
            timeout_seconds=timeout_seconds,
        )
        return await verify_text_fidelity_tool(
            request,
            provider_factory=selected_provider,
            timeout_seconds=min(request.timeout_seconds, fidelity_timeout_seconds),
            property_settings=property_settings,
        )


def verify_cross(
    template: BiologyTemplateSpec | None,
    *,
    settings: PropertyCheckSettings | None = None,
) -> ToolEvidence:
    return _run_report(BIOLOGY_CROSS_TOOL, template, settings, aspect="cross")


def validate_options(
    template: BiologyTemplateSpec | None,
    *,
    settings: PropertyCheckSettings | None = None,
) -> ToolEvidence:
    return _run_report(BIOLOGY_OPTIONS_TOOL, template, settings, aspect="options")


def _run_report(
    name: str,
    template: BiologyTemplateSpec | None,
    settings: PropertyCheckSettings | None,
    *,
    aspect: Literal["cross", "options"],
) -> ToolEvidence:
    started = time.perf_counter()
    if template is None:
        return _missing_subject(name, "template")

    try:
        if isinstance(template, H2TemplateSpec):
            report = check_h2_template(template, settings, aspect=aspect)
        elif isinstance(template, GoodnessOfFitTemplate):
            report = check_fit_template(template, settings, aspect=aspect)
        else:
            report = check_template(template, settings, aspect=aspect)
    except Exception as exc:  # noqa: BLE001 - the tool boundary reports failures
        return _check_error(name, exc, started)

    return ToolEvidence(
        tool=name,
        version=BIOLOGY_TOOL_VERSION,
        status=report.status,
        findings=report.findings,
        details=_report_details(report, settings),
        duration_ms=_elapsed_ms(started),
    )


def _report_details(
    report: CheckReport, settings: PropertyCheckSettings | None
) -> dict[str, Any]:
    details = dict(report.details)
    _ensure_property_fields(details, settings)
    details["biology_status"] = report.status
    details["routes_to_review"] = report.status != "passed"
    details["findings"] = [
        finding.model_dump(mode="json") for finding in report.findings
    ]
    return details


def _ensure_property_fields(
    details: dict[str, Any], settings: PropertyCheckSettings | None
) -> None:
    """Early template failures report no sampled coverage; keep the shape."""
    if "checking_mode" in details:
        return
    effective = settings or PropertyCheckSettings()
    details.update(
        checking_mode="property_based",
        examples_checked=0,
        execution_calls=0,
        max_examples=effective.max_examples,
        max_execution_calls=effective.max_execution_calls,
        timeout_seconds=effective.timeout_seconds,
        seed=effective.seed,
        whole_domain=False,
        declared_domain_size=None,
    )


def _check_error(name: str, exc: Exception, started: float) -> ToolEvidence:
    """Report an internal failure without leaking its message."""
    return ToolEvidence(
        tool=name,
        version=BIOLOGY_TOOL_VERSION,
        status="error",
        findings=[
            ToolFinding(
                code="BIOLOGY_CHECK_ERROR",
                message=f"biology check failed with {type(exc).__name__}",
            )
        ],
        duration_ms=_elapsed_ms(started),
    )


async def verify_text_fidelity_tool(
    request: BiologyFidelityRequest,
    *,
    provider_factory: JudgeProviderFactory,
    timeout_seconds: float,
    property_settings: PropertyCheckSettings | None = None,
) -> ToolEvidence:
    """Every representative variant must pass; one failure fails the template."""
    started = time.perf_counter()
    template = request.template
    if template is None:
        return _missing_subject(BIOLOGY_FIDELITY_TOOL, "template")

    if isinstance(template, H2TemplateSpec):
        report = check_h2_template(template, property_settings, aspect="fidelity")
        return ToolEvidence(
            tool=BIOLOGY_FIDELITY_TOOL,
            version=BIOLOGY_TOOL_VERSION,
            status=report.status,
            findings=report.findings,
            details=_report_details(report, property_settings),
            duration_ms=_elapsed_ms(started),
        )

    if isinstance(template, GoodnessOfFitTemplate) or uses_checked_cross_wording(
        template
    ):
        return ToolEvidence(
            tool=BIOLOGY_FIDELITY_TOOL,
            version=BIOLOGY_TOOL_VERSION,
            status="passed",
            details={
                "method": "rendered_from_checked_biology_data",
                "evidence_strength": "deterministic",
            },
        )

    reports: list[tuple[dict[str, str], FidelityReport]] = []
    for parameters in representative_variants(template):
        subject = BiologyFidelitySubject(template=template, parameters=parameters)
        try:
            text = render_text(template, parameters)
            report = await verify_text_fidelity(
                biology_fidelity_plugin(),
                subject,
                text,
                provider_factory=provider_factory,
                timeout_seconds=timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001 - the tool boundary reports failures
            return _fidelity_error(exc, started)
        reports.append((parameters, report))
        if report.status != "passed":
            # Later variants cannot rescue a failed one, so stop paying for them.
            break

    status, findings = _fidelity_outcome(reports)
    return _fidelity_evidence(reports, status, findings, started)


def _missing_subject(name: str, expected: str) -> ToolEvidence:
    return ToolEvidence(
        tool=name,
        version=BIOLOGY_TOOL_VERSION,
        status="error",
        findings=[
            ToolFinding(
                code="NO_SUBJECT",
                message=f"validation requires {expected}",
            )
        ],
    )


def _fidelity_error(exc: Exception, started: float) -> ToolEvidence:
    """Report an execution failure without leaking its message."""
    return ToolEvidence(
        tool=BIOLOGY_FIDELITY_TOOL,
        version=BIOLOGY_TOOL_VERSION,
        status="error",
        findings=[
            ToolFinding(
                code="FIDELITY_EXECUTION_ERROR",
                message=f"fidelity check failed with {type(exc).__name__}",
            )
        ],
        duration_ms=_elapsed_ms(started),
    )


def _fidelity_outcome(
    reports: list[tuple[dict[str, str], FidelityReport]],
) -> tuple[Literal["passed", "failed"], list[ToolFinding]]:
    """Map the variants' verdicts onto the tool's status and findings."""
    findings: list[ToolFinding] = []
    for parameters, report in reports:
        if report.status == "passed":
            continue
        code = (
            "FIDELITY_INCONCLUSIVE"
            if report.status == "inconclusive"
            else "FIDELITY_MISMATCH"
        )
        variant = ", ".join(f"{name}={value}" for name, value in parameters.items())
        reasons = report.verdict.reasons or ["fidelity check did not pass"]
        findings.extend(
            ToolFinding(code=code, message=f"variant {variant}: {reason}")
            for reason in reasons
        )
    return ("failed" if findings else "passed"), findings


def _fidelity_evidence(
    reports: list[tuple[dict[str, str], FidelityReport]],
    status: Literal["passed", "failed"],
    findings: list[ToolFinding],
    started: float,
) -> ToolEvidence:
    return ToolEvidence(
        tool=BIOLOGY_FIDELITY_TOOL,
        version=BIOLOGY_TOOL_VERSION,
        status=status,
        findings=findings,
        details={
            "status": "passed" if status == "passed" else "failed",
            "variants": [
                {"parameters": parameters, **report.model_dump(mode="json")}
                for parameters, report in reports
            ],
            "routes_to_review": status != "passed",
        },
        duration_ms=_elapsed_ms(started),
    )


def _elapsed_ms(started: float) -> float:
    return (time.perf_counter() - started) * 1000
