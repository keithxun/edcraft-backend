"""Deterministic chemistry validation tools for template authoring.

The tools treat a model proposal as an untrusted candidate, run the balance and
option checks in a disposable interpreter, and return structured evidence. No
model code is ever executed.
"""

from __future__ import annotations

import time
from typing import Annotated, Any, Literal, cast

from fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from edcraft_validator.domains.chemistry.chemistry_schemas import ChemistryTemplateSpec
from edcraft_validator.domains.chemistry.chemistry_types import (
    CHEMISTRY_BALANCE_TOOL,
    CHEMISTRY_CONTENT_TOOL,
    CHEMISTRY_OPTIONS_TOOL,
    CHEMISTRY_TOOL_VERSION,
)
from edcraft_validator.domains.chemistry.validation.isolation import (
    DEFAULT_VALIDATION_TIMEOUT_SECONDS,
    ValidationTimeout,
    ValidationWorkerError,
    run_isolated,
)
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding

_MAX_EXPORTED_FINDINGS = 20


class ChemistryToolRequest(BaseModel):
    """One template spec plus the isolated worker's deadline."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: ChemistryTemplateSpec
    timeout_seconds: float = Field(
        default=DEFAULT_VALIDATION_TIMEOUT_SECONDS, gt=0, le=60
    )


def register_chemistry_tools(server: FastMCP) -> None:
    """Register the chemistry-domain validation tools on ``server``."""
    annotations = {
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    }

    @server.tool(
        name=CHEMISTRY_BALANCE_TOOL,
        version=CHEMISTRY_TOOL_VERSION,
        tags={"domain:chemistry", "validation:balance"},
        annotations=annotations,
        description=(
            "Deterministically check that every reaction named by a chemistry "
            "template balances uniquely with the smallest whole-number "
            "coefficients. It recomputes each balance from the embedded snapshot "
            "with exact arithmetic, checks every sampled reaction (the whole "
            "domain when it is small), and compares the snapshot with the live "
            "catalogue. It never runs model-authored code."
        ),
    )
    async def chemistry_verify_balance(
        template: ChemistryTemplateSpec,
        timeout_seconds: Annotated[float, Field(gt=0, le=60)] = (
            DEFAULT_VALIDATION_TIMEOUT_SECONDS
        ),
    ) -> ToolEvidence:
        return verify_balance(
            ChemistryToolRequest(
                template=template,
                timeout_seconds=timeout_seconds,
            )
        )

    @server.tool(
        name=CHEMISTRY_CONTENT_TOOL,
        version=CHEMISTRY_TOOL_VERSION,
        tags={"domain:chemistry", "validation:content"},
        annotations=annotations,
        description=(
            "Deterministically verify concept statements and choices against the "
            "curated H2 catalogue. It never runs model-authored code."
        ),
    )
    async def chemistry_verify_content(template: ChemistryTemplateSpec) -> ToolEvidence:
        return verify_content(ChemistryToolRequest(template=template))

    @server.tool(
        name=CHEMISTRY_OPTIONS_TOOL,
        version=CHEMISTRY_TOOL_VERSION,
        tags={"domain:chemistry", "validation:options"},
        annotations=annotations,
        description=(
            "Deterministically check a balancing, theoretical-yield or conceptual H2 "
            "item. It verifies "
            "that every sampled expansion has the correct key and unique wrong options "
            "using exact arithmetic or the curated concept snapshot. It never runs "
            "model-authored code."
        ),
    )
    async def chemistry_verify_options(
        template: ChemistryTemplateSpec,
        timeout_seconds: Annotated[float, Field(gt=0, le=60)] = (
            DEFAULT_VALIDATION_TIMEOUT_SECONDS
        ),
    ) -> ToolEvidence:
        return verify_options(
            ChemistryToolRequest(
                template=template,
                timeout_seconds=timeout_seconds,
            )
        )


def verify_balance(request: ChemistryToolRequest) -> ToolEvidence:
    """Check every snapshot reaction's balance in the isolated worker."""
    return _verify(
        CHEMISTRY_BALANCE_TOOL,
        "balance",
        request,
    )


def verify_options(request: ChemistryToolRequest) -> ToolEvidence:
    """Check the key and every distractor over the declared grid."""
    return _verify(
        CHEMISTRY_OPTIONS_TOOL,
        "options",
        request,
    )


def verify_content(request: ChemistryToolRequest) -> ToolEvidence:
    return _verify(CHEMISTRY_CONTENT_TOOL, "content", request)


def _verify(
    name: str,
    operation: Literal["balance", "content", "options"],
    request: ChemistryToolRequest,
) -> ToolEvidence:
    started = time.perf_counter()
    payload = {
        "operation": operation,
        "template": request.template.model_dump(mode="json"),
    }

    try:
        response = run_isolated(payload, timeout_seconds=request.timeout_seconds)
    except ValidationTimeout:
        return _validation_error(
            name,
            "VALIDATION_TIMEOUT",
            f"validation exceeded {request.timeout_seconds:g}s",
            started,
        )
    except (ValidationWorkerError, ValueError) as error:
        # The transport raises ValueError for an oversized payload.
        return _validation_error(
            name,
            "VALIDATION_WORKER_ERROR",
            str(error),
            started,
        )

    if not isinstance(response, dict):
        return _malformed(name, "validation worker returned no report", started)
    report = response.get("report")
    if not isinstance(report, dict):
        return _malformed(name, "validation worker did not return a report", started)
    return _evidence(name, cast(dict[str, Any], report), started)


def _evidence(name: str, report: dict[str, Any], started: float) -> ToolEvidence:
    """Map a worker report onto tool evidence without trusting its shape."""
    status = report.get("status")
    if status not in {"passed", "failed"}:
        return _malformed(name, "validation worker returned no usable report", started)

    findings = _report_findings(report)
    if findings is None:
        return _malformed(name, "validation worker returned invalid findings", started)
    if status == "failed" and not findings:
        findings = [
            ToolFinding(code="VALIDATION_FAILED", message="validation did not pass")
        ]

    details = {
        key: value for key, value in report.items() if key not in {"status", "findings"}
    }
    return ToolEvidence(
        tool=name,
        version=CHEMISTRY_TOOL_VERSION,
        status=cast(Literal["passed", "failed"], status),
        findings=findings[:_MAX_EXPORTED_FINDINGS],
        details=details,
        duration_ms=_elapsed_ms(started),
    )


def _report_findings(report: dict[str, Any]) -> list[ToolFinding] | None:
    """Validate the report's findings, returning ``None`` when malformed."""
    raw = report.get("findings", [])
    if not isinstance(raw, list):
        return None

    findings: list[ToolFinding] = []
    for item in raw:
        if not isinstance(item, dict):
            return None
        try:
            findings.append(ToolFinding.model_validate(item))
        except ValidationError:
            return None
    return findings


def _malformed(name: str, message: str, started: float) -> ToolEvidence:
    return _validation_error(
        name,
        "VALIDATION_RESPONSE_MALFORMED",
        message,
        started,
    )


def _validation_error(
    name: str, code: str, message: str, started: float
) -> ToolEvidence:
    return ToolEvidence(
        tool=name,
        version=CHEMISTRY_TOOL_VERSION,
        status="error",
        findings=[ToolFinding(code=code, message=message)],
        duration_ms=_elapsed_ms(started),
    )


def _elapsed_ms(started: float) -> float:
    return (time.perf_counter() - started) * 1000


__all__ = [
    "ChemistryToolRequest",
    "register_chemistry_tools",
    "verify_balance",
    "verify_content",
    "verify_options",
]
