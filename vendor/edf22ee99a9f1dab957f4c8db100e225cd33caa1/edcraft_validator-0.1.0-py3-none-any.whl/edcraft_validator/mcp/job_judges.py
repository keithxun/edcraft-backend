"""Bind the resolved job models to the same checks in inline and worker execution."""

from collections.abc import Callable
from functools import partial

from edcraft_validator.llm.decision import ConfiguredDecisionProvider
from edcraft_validator.llm.judge_configuration import JudgeSettings, judge_settings_for
from edcraft_validator.llm.llm_contracts import ModelProvider, supports_decisions
from edcraft_validator.llm.llm_errors import DecisionCapabilityError
from edcraft_validator.llm.usage import close_provider
from edcraft_validator.mcp.client import FastMcpToolClient
from edcraft_validator.mcp.server import create_validation_server


class SelectedModelDecisionProvider(ConfiguredDecisionProvider):
    def __init__(self, settings: JudgeSettings, provider: ModelProvider) -> None:
        if not supports_decisions(provider):
            close_provider(provider)
            raise DecisionCapabilityError(
                "Provider does not support token-probability decisions"
            )
        self.settings = settings
        self.delegate = provider
        self.provider = provider.provider
        self.model = provider.model
        self.threshold = settings.relevance_threshold
        self.served_model = None


def job_judge_client[Role](
    *,
    difficulty: Role,
    relevance: Role,
    decision_fallback: Role | None,
    open_provider: Callable[[Role], ModelProvider],
    model_name: Callable[[Role], tuple[str, str]],
    use_relevance_for_fidelity: bool = False,
) -> FastMcpToolClient:
    def decision_provider(role: Role) -> SelectedModelDecisionProvider:
        return SelectedModelDecisionProvider(
            judge_settings_for(*model_name(role)), open_provider(role)
        )

    return FastMcpToolClient(
        create_validation_server(
            judge_settings=judge_settings_for(*model_name(difficulty)),
            difficulty_provider_factory=partial(open_provider, difficulty),
            decision_provider_factory=partial(decision_provider, relevance),
            fidelity_provider_factory=(
                partial(open_provider, relevance)
                if use_relevance_for_fidelity
                else None
            ),
            enforce_decision_compatibility=decision_fallback is not None,
            difficulty_fallback_provider_factory=(
                partial(open_provider, decision_fallback)
                if decision_fallback is not None and decision_fallback != difficulty
                else None
            ),
            relevance_fallback_provider_factory=(
                partial(decision_provider, decision_fallback)
                if decision_fallback is not None and decision_fallback != relevance
                else None
            ),
        )
    )
