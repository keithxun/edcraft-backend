"""Physics-domain template checks for the authoring flow.

The tools re-run the exact per-combination checks that gate a saved physics
template: the answer recipe, the distractors, the stem, and the blind
parse-back. All arithmetic is exact over finite parameter families, so the
deterministic work runs in process under the shared property-check budget.
"""

from __future__ import annotations

import time
from functools import partial
from typing import Annotated, Literal

from fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

from edcraft_validator.application.fidelity.contracts import FidelityReport
from edcraft_validator.application.fidelity.engine import verify_text_fidelity
from edcraft_validator.domains.physics import h2
from edcraft_validator.domains.physics import text as physics_text
from edcraft_validator.domains.physics.checks import (
    validate_options,
    verify_item,
    verify_text,
)
from edcraft_validator.domains.physics.fidelity import (
    PhysicsFidelitySubject,
    physics_fidelity_plugin,
    representative_variants,
)
from edcraft_validator.domains.physics.h2_statement_data import H2StatementSpec
from edcraft_validator.domains.physics.h2_statements import verify_statement
from edcraft_validator.domains.physics.h2_task_data import H2TaskSpec
from edcraft_validator.domains.physics.h2_tasks import verify_task
from edcraft_validator.domains.physics.physics_schemas import (
    H2TemplateSpec,
    PhysicsItem,
)
from edcraft_validator.domains.physics.physics_types import (
    MAX_TOOL_TIMEOUT_SECONDS,
    PHYSICS_FIDELITY_TOOL,
    PHYSICS_ITEM_TOOL,
    PHYSICS_OPTIONS_TOOL,
    PHYSICS_TEXT_TOOL,
    PHYSICS_TOOL_VERSION,
)
from edcraft_validator.llm.judge_configuration import (
    configured_judge_provider,
    load_judge_settings,
)
from edcraft_validator.llm.judging import JudgeProviderFactory
from edcraft_validator.validation.check_contracts import ToolEvidence, ToolFinding

_ANNOTATIONS = {
    "readOnlyHint": True,
    "destructiveHint": False,
    "idempotentHint": True,
    "openWorldHint": False,
}
_FIDELITY_TIMEOUT_LIMIT = 310


class PhysicsFidelityRequest(BaseModel):
    """Fidelity check for a template's representative variants."""

    model_config = ConfigDict(extra="forbid", strict=True)

    template: PhysicsItem | None = None
    timeout_seconds: float = Field(default=60.0, gt=0, le=_FIDELITY_TIMEOUT_LIMIT)


def register_physics_tools(
    server: FastMCP,
    *,
    fidelity_provider_factory: JudgeProviderFactory | None = None,
    fidelity_timeout_seconds: float = 60.0,
) -> None:
    """Register the four physics template checks."""
    if fidelity_timeout_seconds <= 0:
        raise ValueError("fidelity timeout must be positive")

    selected_provider = fidelity_provider_factory
    if selected_provider is None:
        settings = load_judge_settings()
        selected_provider = partial(configured_judge_provider, settings)

    @server.tool(
        name=PHYSICS_ITEM_TOOL,
        version=PHYSICS_TOOL_VERSION,
        tags={"domain:physics", "validation:item"},
        annotations=dict(_ANNOTATIONS),
        description=(
            "Check a physics template's answer recipe for every sampled "
            "parameter combination: the template must not be contradictory, the "
            "recipe must evaluate exactly to F_net / m, m a, F_net / a or the "
            "missing force with the target's dimension, and the correct value "
            "must show exactly at the declared decimal places. Small domains are "
            "covered completely and large ones are sampled under a fixed budget."
        ),
    )
    async def physics_verify_item(
        template: PhysicsItem,
        timeout_seconds: Annotated[
            float, Field(gt=0, le=MAX_TOOL_TIMEOUT_SECONDS)
        ] = 30.0,
    ) -> ToolEvidence:
        if isinstance(template, H2TaskSpec):
            return verify_task(
                template, PHYSICS_ITEM_TOOL, timeout_seconds=timeout_seconds
            )
        if isinstance(template, H2StatementSpec):
            return verify_statement(
                template, PHYSICS_ITEM_TOOL, timeout_seconds=timeout_seconds
            )
        if isinstance(template, H2TemplateSpec):
            return h2.verify_numeric(
                template, options=False, timeout_seconds=timeout_seconds
            )
        return verify_item(template, timeout_seconds=timeout_seconds)

    @server.tool(
        name=PHYSICS_OPTIONS_TOOL,
        version=PHYSICS_TOOL_VERSION,
        tags={"domain:physics", "validation:options"},
        annotations=dict(_ANNOTATIONS),
        description=(
            "Check a physics template's multiple-choice options over the same "
            "sampled parameter combinations: every distractor recipe must be "
            "defined, differ from the correct answer, repeat no earlier option "
            "after rendering, show exactly at the declared decimals, and stay "
            "physical for magnitude answers. A distractor's dimension is reported "
            "but does not fail it, because unit slips are the misconception."
        ),
    )
    async def physics_validate_options(
        template: PhysicsItem,
        timeout_seconds: Annotated[
            float, Field(gt=0, le=MAX_TOOL_TIMEOUT_SECONDS)
        ] = 30.0,
    ) -> ToolEvidence:
        if isinstance(template, H2TaskSpec):
            return verify_task(
                template, PHYSICS_OPTIONS_TOOL, timeout_seconds=timeout_seconds
            )
        if isinstance(template, H2StatementSpec):
            return verify_statement(
                template, PHYSICS_OPTIONS_TOOL, timeout_seconds=timeout_seconds
            )
        if isinstance(template, H2TemplateSpec):
            return h2.verify_numeric(
                template, options=True, timeout_seconds=timeout_seconds
            )
        return validate_options(template, timeout_seconds=timeout_seconds)

    @server.tool(
        name=PHYSICS_TEXT_TOOL,
        version=PHYSICS_TOOL_VERSION,
        tags={"domain:physics", "validation:text"},
        annotations=dict(_ANNOTATIONS),
        description=(
            "Check a physics template's stem text: every declared parameter must "
            "appear exactly once as a placeholder, no other placeholder or stray "
            "brace may appear, no digit may sit outside a placeholder, and the "
            "stem must not contain a question mark because the application adds "
            "the question sentence itself."
        ),
    )
    async def physics_verify_text(template: PhysicsItem) -> ToolEvidence:
        if isinstance(template, H2TaskSpec):
            return verify_task(template, PHYSICS_TEXT_TOOL, timeout_seconds=30.0)
        if isinstance(template, H2StatementSpec):
            return verify_statement(template, PHYSICS_TEXT_TOOL)
        if isinstance(template, H2TemplateSpec):
            return h2.verify_realisation(template, fidelity=False)
        return verify_text(template)

    @server.tool(
        name=PHYSICS_FIDELITY_TOOL,
        version=PHYSICS_TOOL_VERSION,
        tags={"domain:physics", "validation:fidelity"},
        annotations={**_ANNOTATIONS, "openWorldHint": True},
        description=(
            "Check physics text fidelity. Built-in H2 families use deterministic "
            "checks against their pinned renderer, including a numerical check "
            "of graph task values. Free-text templates use deterministic anchors "
            "and blind model parse-back of up to three rendered questions. A "
            "mismatch blocks approval."
        ),
    )
    async def physics_verify_text_fidelity(
        template: PhysicsItem | None = None,
        timeout_seconds: Annotated[
            float, Field(gt=0, le=_FIDELITY_TIMEOUT_LIMIT)
        ] = 60.0,
    ) -> ToolEvidence:
        request = PhysicsFidelityRequest(
            template=template,
            timeout_seconds=timeout_seconds,
        )
        return await verify_text_fidelity_tool(
            request,
            provider_factory=selected_provider,
            timeout_seconds=min(request.timeout_seconds, fidelity_timeout_seconds),
        )


async def verify_text_fidelity_tool(
    request: PhysicsFidelityRequest,
    *,
    provider_factory: JudgeProviderFactory,
    timeout_seconds: float,
) -> ToolEvidence:
    """Every representative variant must pass, so one failure fails the template."""
    started = time.perf_counter()
    template = request.template
    if template is None:
        return _missing_subject(PHYSICS_FIDELITY_TOOL, "template")
    if isinstance(template, H2TaskSpec):
        return verify_task(
            template, PHYSICS_FIDELITY_TOOL, timeout_seconds=timeout_seconds
        )
    if isinstance(template, H2StatementSpec):
        return verify_statement(
            template, PHYSICS_FIDELITY_TOOL, timeout_seconds=timeout_seconds
        )
    if isinstance(template, H2TemplateSpec):
        return h2.verify_realisation(template, fidelity=True)

    reports: list[tuple[dict[str, str], FidelityReport]] = []
    for parameters in representative_variants(template):
        subject = PhysicsFidelitySubject(template=template, parameters=parameters)
        try:
            text = physics_text.render_question(template, parameters)
            report = await verify_text_fidelity(
                physics_fidelity_plugin(),
                subject,
                text,
                provider_factory=provider_factory,
                timeout_seconds=timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001 - the tool boundary reports failures
            return _fidelity_error(exc, started)
        reports.append((parameters, report))
        if report.status != "passed":
            # Later variants cannot rescue a failed one, so stop paying for them.
            break

    status, findings = _fidelity_outcome(reports)
    return _fidelity_evidence(reports, status, findings, started)


def _missing_subject(name: str, expected: str) -> ToolEvidence:
    return ToolEvidence(
        tool=name,
        version=PHYSICS_TOOL_VERSION,
        status="error",
        findings=[
            ToolFinding(
                code="NO_SUBJECT",
                message=f"validation requires {expected}",
            )
        ],
    )


def _fidelity_error(exc: Exception, started: float) -> ToolEvidence:
    """Report an execution failure without leaking its message."""
    return ToolEvidence(
        tool=PHYSICS_FIDELITY_TOOL,
        version=PHYSICS_TOOL_VERSION,
        status="error",
        findings=[
            ToolFinding(
                code="FIDELITY_EXECUTION_ERROR",
                message=f"fidelity check failed with {type(exc).__name__}",
            )
        ],
        duration_ms=_elapsed_ms(started),
    )


def _fidelity_outcome(
    reports: list[tuple[dict[str, str], FidelityReport]],
) -> tuple[Literal["passed", "failed"], list[ToolFinding]]:
    """Map the variants' verdicts onto the tool's status and findings."""
    findings: list[ToolFinding] = []
    for parameters, report in reports:
        if report.status == "passed":
            continue
        code = (
            "FIDELITY_INCONCLUSIVE"
            if report.status == "inconclusive"
            else "FIDELITY_MISMATCH"
        )
        variant = ", ".join(f"{name}={value}" for name, value in parameters.items())
        reasons = report.verdict.reasons or ["fidelity check did not pass"]
        findings.extend(
            ToolFinding(code=code, message=f"variant {variant}: {reason}")
            for reason in reasons
        )
    return ("failed" if findings else "passed"), findings


def _fidelity_evidence(
    reports: list[tuple[dict[str, str], FidelityReport]],
    status: Literal["passed", "failed"],
    findings: list[ToolFinding],
    started: float,
) -> ToolEvidence:
    return ToolEvidence(
        tool=PHYSICS_FIDELITY_TOOL,
        version=PHYSICS_TOOL_VERSION,
        status=status,
        findings=findings,
        details={
            "status": status,
            "variants": [
                {
                    "parameters": parameters,
                    "status": report.status,
                    "reasons": list(report.verdict.reasons),
                    "reconstruction": report.reconstruction,
                    "prompt_version": report.prompt_version,
                    "usage": report.usage.model_dump(mode="json"),
                }
                for parameters, report in reports
            ],
            "routes_to_review": status != "passed",
        },
        duration_ms=_elapsed_ms(started),
    )


def _elapsed_ms(started: float) -> float:
    return (time.perf_counter() - started) * 1000
