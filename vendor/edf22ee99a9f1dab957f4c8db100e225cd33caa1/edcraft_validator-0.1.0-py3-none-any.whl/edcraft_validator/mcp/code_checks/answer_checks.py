"""Checks for proposed and execution-derived template answers."""

import copy
from typing import Any

from edcraft_validator.domains.code.code_schemas import (
    CodeTemplateCandidate,
    TemplateValidationError,
)
from edcraft_validator.domains.code.code_types import AnswerTarget, ParameterValue
from edcraft_validator.domains.code.question_values import (
    require_json_value,
    validate_supported_answer,
)
from edcraft_validator.domains.code.safe_expressions import SafeExpression
from edcraft_validator.mcp.code_checks.validation_context import (
    CodeValidationContext,
    DistractorCandidate,
)
from edcraft_validator.tools.python_execution import ExecutionResult
from edcraft_validator.value_comparison import same_value_shape


def check_expressions(context: CodeValidationContext) -> None:
    """Parse the answer and distractor expressions for later checks."""
    context.proposed_answer, context.candidates = _parse_expressions(
        context.template,
        context.names,
        allow_candidate_rejections=context.num_distractors is not None,
    )


def check_proposed_answers(context: CodeValidationContext) -> None:
    """Evaluate the proposed answer on the supplied examples."""
    if context.proposed_answer is None:
        return

    answers = []
    for inputs in context.inputs_cases:
        answer = context.proposed_answer.evaluate(inputs)
        require_json_value(answer, "answer")
        validate_supported_answer(inputs, answer)
        answers.append(answer)

    _require_consistent_answer_shapes(context.inputs_cases, answers)
    context.proposed_answers = answers


def check_canonical_answers(context: CodeValidationContext) -> None:
    """Derive canonical answers without changing the supplied proposal or recipes."""
    answers = []
    for inputs, execution in zip(context.inputs_cases, context.executions, strict=True):
        actual_answer = _execution_answer(execution, context.template.answer_target)
        require_json_value(actual_answer, "executor answer")
        validate_supported_answer(inputs, actual_answer)
        answers.append(copy.deepcopy(actual_answer))

    _require_consistent_answer_shapes(context.inputs_cases, answers)
    context.canonical_answers = answers


def _require_consistent_answer_shapes(
    inputs_cases: list[dict[str, ParameterValue]], answers: list[Any]
) -> None:
    if not answers:
        return

    expected = answers[0]
    for inputs, answer in zip(inputs_cases[1:], answers[1:], strict=True):
        if not same_value_shape(answer, expected):
            raise TemplateValidationError(
                f"answer type changes across parameter cases for inputs {inputs}",
                code="ANSWER_TYPE_INCONSISTENT",
                field="answer_expression",
                inputs=inputs,
            )


def _parse_expressions(
    template: CodeTemplateCandidate,
    names: tuple[str, ...],
    *,
    allow_candidate_rejections: bool,
) -> tuple[SafeExpression | None, list[DistractorCandidate]]:
    answer = _parse_expression(template.answer_expression, names, "answer_expression")
    candidates: list[DistractorCandidate] = []
    for index, recipe in enumerate(template.distractors):
        try:
            expression = _parse_expression(
                recipe.expression, names, f"distractors[{index}].expression"
            )
        except TemplateValidationError as exc:
            if not allow_candidate_rejections:
                raise
            candidates.append(DistractorCandidate(index=index, rejection=str(exc)))
        else:
            candidates.append(DistractorCandidate(index=index, expression=expression))

    return answer, candidates


def _parse_expression(
    source: str, names: tuple[str, ...], field: str
) -> SafeExpression:
    try:
        return SafeExpression(source, names)
    except TemplateValidationError as exc:
        raise TemplateValidationError(
            f"{field} {source!r}: {exc}. Expressions use bare parameter names, "
            "for example a + b. Placeholder braces belong only in text templates.",
            code=exc.code,
            field=field,
        ) from exc


def _execution_answer(execution: ExecutionResult, target: AnswerTarget) -> Any:
    if target == "return_value":
        return execution.answer
    summary = execution.trace_summary
    if not isinstance(summary, dict) or target not in summary:
        raise TemplateValidationError(
            f"execution did not provide answer target {target!r}"
        )
    return summary[target]
